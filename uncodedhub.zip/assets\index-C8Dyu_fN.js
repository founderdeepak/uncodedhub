(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))a(r);new MutationObserver(r=>{for(const l of r)if(l.type==="childList")for(const c of l.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&a(c)}).observe(document,{childList:!0,subtree:!0});function n(r){const l={};return r.integrity&&(l.integrity=r.integrity),r.referrerPolicy&&(l.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?l.credentials="include":r.crossOrigin==="anonymous"?l.credentials="omit":l.credentials="same-origin",l}function a(r){if(r.ep)return;r.ep=!0;const l=n(r);fetch(r.href,l)}})();var Fm={exports:{}},nc={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var gS;function SA(){if(gS)return nc;gS=1;var o=Symbol.for("react.transitional.element"),e=Symbol.for("react.fragment");function n(a,r,l){var c=null;if(l!==void 0&&(c=""+l),r.key!==void 0&&(c=""+r.key),"key"in r){l={};for(var f in r)f!=="key"&&(l[f]=r[f])}else l=r;return r=l.ref,{$$typeof:o,type:a,key:c,ref:r!==void 0?r:null,props:l}}return nc.Fragment=e,nc.jsx=n,nc.jsxs=n,nc}var vS;function MA(){return vS||(vS=1,Fm.exports=SA()),Fm.exports}var j=MA(),Im={exports:{}},St={};/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var xS;function bA(){if(xS)return St;xS=1;var o=Symbol.for("react.transitional.element"),e=Symbol.for("react.portal"),n=Symbol.for("react.fragment"),a=Symbol.for("react.strict_mode"),r=Symbol.for("react.profiler"),l=Symbol.for("react.consumer"),c=Symbol.for("react.context"),f=Symbol.for("react.forward_ref"),p=Symbol.for("react.suspense"),d=Symbol.for("react.memo"),_=Symbol.for("react.lazy"),v=Symbol.for("react.activity"),g=Symbol.iterator;function x(F){return F===null||typeof F!="object"?null:(F=g&&F[g]||F["@@iterator"],typeof F=="function"?F:null)}var M={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},b=Object.assign,y={};function S(F,Q,xe){this.props=F,this.context=Q,this.refs=y,this.updater=xe||M}S.prototype.isReactComponent={},S.prototype.setState=function(F,Q){if(typeof F!="object"&&typeof F!="function"&&F!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,F,Q,"setState")},S.prototype.forceUpdate=function(F){this.updater.enqueueForceUpdate(this,F,"forceUpdate")};function R(){}R.prototype=S.prototype;function N(F,Q,xe){this.props=F,this.context=Q,this.refs=y,this.updater=xe||M}var C=N.prototype=new R;C.constructor=N,b(C,S.prototype),C.isPureReactComponent=!0;var O=Array.isArray;function P(){}var L={H:null,A:null,T:null,S:null},T=Object.prototype.hasOwnProperty;function w(F,Q,xe){var Te=xe.ref;return{$$typeof:o,type:F,key:Q,ref:Te!==void 0?Te:null,props:xe}}function q(F,Q){return w(F.type,Q,F.props)}function G(F){return typeof F=="object"&&F!==null&&F.$$typeof===o}function k(F){var Q={"=":"=0",":":"=2"};return"$"+F.replace(/[=:]/g,function(xe){return Q[xe]})}var $=/\/+/g;function te(F,Q){return typeof F=="object"&&F!==null&&F.key!=null?k(""+F.key):Q.toString(36)}function J(F){switch(F.status){case"fulfilled":return F.value;case"rejected":throw F.reason;default:switch(typeof F.status=="string"?F.then(P,P):(F.status="pending",F.then(function(Q){F.status==="pending"&&(F.status="fulfilled",F.value=Q)},function(Q){F.status==="pending"&&(F.status="rejected",F.reason=Q)})),F.status){case"fulfilled":return F.value;case"rejected":throw F.reason}}throw F}function z(F,Q,xe,Te,Ne){var ne=typeof F;(ne==="undefined"||ne==="boolean")&&(F=null);var _e=!1;if(F===null)_e=!0;else switch(ne){case"bigint":case"string":case"number":_e=!0;break;case"object":switch(F.$$typeof){case o:case e:_e=!0;break;case _:return _e=F._init,z(_e(F._payload),Q,xe,Te,Ne)}}if(_e)return Ne=Ne(F),_e=Te===""?"."+te(F,0):Te,O(Ne)?(xe="",_e!=null&&(xe=_e.replace($,"$&/")+"/"),z(Ne,Q,xe,"",function(tt){return tt})):Ne!=null&&(G(Ne)&&(Ne=q(Ne,xe+(Ne.key==null||F&&F.key===Ne.key?"":(""+Ne.key).replace($,"$&/")+"/")+_e)),Q.push(Ne)),1;_e=0;var be=Te===""?".":Te+":";if(O(F))for(var ze=0;ze<F.length;ze++)Te=F[ze],ne=be+te(Te,ze),_e+=z(Te,Q,xe,ne,Ne);else if(ze=x(F),typeof ze=="function")for(F=ze.call(F),ze=0;!(Te=F.next()).done;)Te=Te.value,ne=be+te(Te,ze++),_e+=z(Te,Q,xe,ne,Ne);else if(ne==="object"){if(typeof F.then=="function")return z(J(F),Q,xe,Te,Ne);throw Q=String(F),Error("Objects are not valid as a React child (found: "+(Q==="[object Object]"?"object with keys {"+Object.keys(F).join(", ")+"}":Q)+"). If you meant to render a collection of children, use an array instead.")}return _e}function I(F,Q,xe){if(F==null)return F;var Te=[],Ne=0;return z(F,Te,"","",function(ne){return Q.call(xe,ne,Ne++)}),Te}function ie(F){if(F._status===-1){var Q=F._result;Q=Q(),Q.then(function(xe){(F._status===0||F._status===-1)&&(F._status=1,F._result=xe)},function(xe){(F._status===0||F._status===-1)&&(F._status=2,F._result=xe)}),F._status===-1&&(F._status=0,F._result=Q)}if(F._status===1)return F._result.default;throw F._result}var he=typeof reportError=="function"?reportError:function(F){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var Q=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof F=="object"&&F!==null&&typeof F.message=="string"?String(F.message):String(F),error:F});if(!window.dispatchEvent(Q))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",F);return}console.error(F)},H={map:I,forEach:function(F,Q,xe){I(F,function(){Q.apply(this,arguments)},xe)},count:function(F){var Q=0;return I(F,function(){Q++}),Q},toArray:function(F){return I(F,function(Q){return Q})||[]},only:function(F){if(!G(F))throw Error("React.Children.only expected to receive a single React element child.");return F}};return St.Activity=v,St.Children=H,St.Component=S,St.Fragment=n,St.Profiler=r,St.PureComponent=N,St.StrictMode=a,St.Suspense=p,St.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=L,St.__COMPILER_RUNTIME={__proto__:null,c:function(F){return L.H.useMemoCache(F)}},St.cache=function(F){return function(){return F.apply(null,arguments)}},St.cacheSignal=function(){return null},St.cloneElement=function(F,Q,xe){if(F==null)throw Error("The argument must be a React element, but you passed "+F+".");var Te=b({},F.props),Ne=F.key;if(Q!=null)for(ne in Q.key!==void 0&&(Ne=""+Q.key),Q)!T.call(Q,ne)||ne==="key"||ne==="__self"||ne==="__source"||ne==="ref"&&Q.ref===void 0||(Te[ne]=Q[ne]);var ne=arguments.length-2;if(ne===1)Te.children=xe;else if(1<ne){for(var _e=Array(ne),be=0;be<ne;be++)_e[be]=arguments[be+2];Te.children=_e}return w(F.type,Ne,Te)},St.createContext=function(F){return F={$$typeof:c,_currentValue:F,_currentValue2:F,_threadCount:0,Provider:null,Consumer:null},F.Provider=F,F.Consumer={$$typeof:l,_context:F},F},St.createElement=function(F,Q,xe){var Te,Ne={},ne=null;if(Q!=null)for(Te in Q.key!==void 0&&(ne=""+Q.key),Q)T.call(Q,Te)&&Te!=="key"&&Te!=="__self"&&Te!=="__source"&&(Ne[Te]=Q[Te]);var _e=arguments.length-2;if(_e===1)Ne.children=xe;else if(1<_e){for(var be=Array(_e),ze=0;ze<_e;ze++)be[ze]=arguments[ze+2];Ne.children=be}if(F&&F.defaultProps)for(Te in _e=F.defaultProps,_e)Ne[Te]===void 0&&(Ne[Te]=_e[Te]);return w(F,ne,Ne)},St.createRef=function(){return{current:null}},St.forwardRef=function(F){return{$$typeof:f,render:F}},St.isValidElement=G,St.lazy=function(F){return{$$typeof:_,_payload:{_status:-1,_result:F},_init:ie}},St.memo=function(F,Q){return{$$typeof:d,type:F,compare:Q===void 0?null:Q}},St.startTransition=function(F){var Q=L.T,xe={};L.T=xe;try{var Te=F(),Ne=L.S;Ne!==null&&Ne(xe,Te),typeof Te=="object"&&Te!==null&&typeof Te.then=="function"&&Te.then(P,he)}catch(ne){he(ne)}finally{Q!==null&&xe.types!==null&&(Q.types=xe.types),L.T=Q}},St.unstable_useCacheRefresh=function(){return L.H.useCacheRefresh()},St.use=function(F){return L.H.use(F)},St.useActionState=function(F,Q,xe){return L.H.useActionState(F,Q,xe)},St.useCallback=function(F,Q){return L.H.useCallback(F,Q)},St.useContext=function(F){return L.H.useContext(F)},St.useDebugValue=function(){},St.useDeferredValue=function(F,Q){return L.H.useDeferredValue(F,Q)},St.useEffect=function(F,Q){return L.H.useEffect(F,Q)},St.useEffectEvent=function(F){return L.H.useEffectEvent(F)},St.useId=function(){return L.H.useId()},St.useImperativeHandle=function(F,Q,xe){return L.H.useImperativeHandle(F,Q,xe)},St.useInsertionEffect=function(F,Q){return L.H.useInsertionEffect(F,Q)},St.useLayoutEffect=function(F,Q){return L.H.useLayoutEffect(F,Q)},St.useMemo=function(F,Q){return L.H.useMemo(F,Q)},St.useOptimistic=function(F,Q){return L.H.useOptimistic(F,Q)},St.useReducer=function(F,Q,xe){return L.H.useReducer(F,Q,xe)},St.useRef=function(F){return L.H.useRef(F)},St.useState=function(F){return L.H.useState(F)},St.useSyncExternalStore=function(F,Q,xe){return L.H.useSyncExternalStore(F,Q,xe)},St.useTransition=function(){return L.H.useTransition()},St.version="19.2.4",St}var yS;function eg(){return yS||(yS=1,Im.exports=bA()),Im.exports}var Jn=eg(),Bm={exports:{}},ic={},Hm={exports:{}},Gm={};/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var SS;function EA(){return SS||(SS=1,(function(o){function e(z,I){var ie=z.length;z.push(I);e:for(;0<ie;){var he=ie-1>>>1,H=z[he];if(0<r(H,I))z[he]=I,z[ie]=H,ie=he;else break e}}function n(z){return z.length===0?null:z[0]}function a(z){if(z.length===0)return null;var I=z[0],ie=z.pop();if(ie!==I){z[0]=ie;e:for(var he=0,H=z.length,F=H>>>1;he<F;){var Q=2*(he+1)-1,xe=z[Q],Te=Q+1,Ne=z[Te];if(0>r(xe,ie))Te<H&&0>r(Ne,xe)?(z[he]=Ne,z[Te]=ie,he=Te):(z[he]=xe,z[Q]=ie,he=Q);else if(Te<H&&0>r(Ne,ie))z[he]=Ne,z[Te]=ie,he=Te;else break e}}return I}function r(z,I){var ie=z.sortIndex-I.sortIndex;return ie!==0?ie:z.id-I.id}if(o.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var l=performance;o.unstable_now=function(){return l.now()}}else{var c=Date,f=c.now();o.unstable_now=function(){return c.now()-f}}var p=[],d=[],_=1,v=null,g=3,x=!1,M=!1,b=!1,y=!1,S=typeof setTimeout=="function"?setTimeout:null,R=typeof clearTimeout=="function"?clearTimeout:null,N=typeof setImmediate<"u"?setImmediate:null;function C(z){for(var I=n(d);I!==null;){if(I.callback===null)a(d);else if(I.startTime<=z)a(d),I.sortIndex=I.expirationTime,e(p,I);else break;I=n(d)}}function O(z){if(b=!1,C(z),!M)if(n(p)!==null)M=!0,P||(P=!0,k());else{var I=n(d);I!==null&&J(O,I.startTime-z)}}var P=!1,L=-1,T=5,w=-1;function q(){return y?!0:!(o.unstable_now()-w<T)}function G(){if(y=!1,P){var z=o.unstable_now();w=z;var I=!0;try{e:{M=!1,b&&(b=!1,R(L),L=-1),x=!0;var ie=g;try{t:{for(C(z),v=n(p);v!==null&&!(v.expirationTime>z&&q());){var he=v.callback;if(typeof he=="function"){v.callback=null,g=v.priorityLevel;var H=he(v.expirationTime<=z);if(z=o.unstable_now(),typeof H=="function"){v.callback=H,C(z),I=!0;break t}v===n(p)&&a(p),C(z)}else a(p);v=n(p)}if(v!==null)I=!0;else{var F=n(d);F!==null&&J(O,F.startTime-z),I=!1}}break e}finally{v=null,g=ie,x=!1}I=void 0}}finally{I?k():P=!1}}}var k;if(typeof N=="function")k=function(){N(G)};else if(typeof MessageChannel<"u"){var $=new MessageChannel,te=$.port2;$.port1.onmessage=G,k=function(){te.postMessage(null)}}else k=function(){S(G,0)};function J(z,I){L=S(function(){z(o.unstable_now())},I)}o.unstable_IdlePriority=5,o.unstable_ImmediatePriority=1,o.unstable_LowPriority=4,o.unstable_NormalPriority=3,o.unstable_Profiling=null,o.unstable_UserBlockingPriority=2,o.unstable_cancelCallback=function(z){z.callback=null},o.unstable_forceFrameRate=function(z){0>z||125<z?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):T=0<z?Math.floor(1e3/z):5},o.unstable_getCurrentPriorityLevel=function(){return g},o.unstable_next=function(z){switch(g){case 1:case 2:case 3:var I=3;break;default:I=g}var ie=g;g=I;try{return z()}finally{g=ie}},o.unstable_requestPaint=function(){y=!0},o.unstable_runWithPriority=function(z,I){switch(z){case 1:case 2:case 3:case 4:case 5:break;default:z=3}var ie=g;g=z;try{return I()}finally{g=ie}},o.unstable_scheduleCallback=function(z,I,ie){var he=o.unstable_now();switch(typeof ie=="object"&&ie!==null?(ie=ie.delay,ie=typeof ie=="number"&&0<ie?he+ie:he):ie=he,z){case 1:var H=-1;break;case 2:H=250;break;case 5:H=1073741823;break;case 4:H=1e4;break;default:H=5e3}return H=ie+H,z={id:_++,callback:I,priorityLevel:z,startTime:ie,expirationTime:H,sortIndex:-1},ie>he?(z.sortIndex=ie,e(d,z),n(p)===null&&z===n(d)&&(b?(R(L),L=-1):b=!0,J(O,ie-he))):(z.sortIndex=H,e(p,z),M||x||(M=!0,P||(P=!0,k()))),z},o.unstable_shouldYield=q,o.unstable_wrapCallback=function(z){var I=g;return function(){var ie=g;g=I;try{return z.apply(this,arguments)}finally{g=ie}}}})(Gm)),Gm}var MS;function TA(){return MS||(MS=1,Hm.exports=EA()),Hm.exports}var Vm={exports:{}},mi={};/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var bS;function AA(){if(bS)return mi;bS=1;var o=eg();function e(p){var d="https://react.dev/errors/"+p;if(1<arguments.length){d+="?args[]="+encodeURIComponent(arguments[1]);for(var _=2;_<arguments.length;_++)d+="&args[]="+encodeURIComponent(arguments[_])}return"Minified React error #"+p+"; visit "+d+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function n(){}var a={d:{f:n,r:function(){throw Error(e(522))},D:n,C:n,L:n,m:n,X:n,S:n,M:n},p:0,findDOMNode:null},r=Symbol.for("react.portal");function l(p,d,_){var v=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:r,key:v==null?null:""+v,children:p,containerInfo:d,implementation:_}}var c=o.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function f(p,d){if(p==="font")return"";if(typeof d=="string")return d==="use-credentials"?d:""}return mi.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=a,mi.createPortal=function(p,d){var _=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!d||d.nodeType!==1&&d.nodeType!==9&&d.nodeType!==11)throw Error(e(299));return l(p,d,null,_)},mi.flushSync=function(p){var d=c.T,_=a.p;try{if(c.T=null,a.p=2,p)return p()}finally{c.T=d,a.p=_,a.d.f()}},mi.preconnect=function(p,d){typeof p=="string"&&(d?(d=d.crossOrigin,d=typeof d=="string"?d==="use-credentials"?d:"":void 0):d=null,a.d.C(p,d))},mi.prefetchDNS=function(p){typeof p=="string"&&a.d.D(p)},mi.preinit=function(p,d){if(typeof p=="string"&&d&&typeof d.as=="string"){var _=d.as,v=f(_,d.crossOrigin),g=typeof d.integrity=="string"?d.integrity:void 0,x=typeof d.fetchPriority=="string"?d.fetchPriority:void 0;_==="style"?a.d.S(p,typeof d.precedence=="string"?d.precedence:void 0,{crossOrigin:v,integrity:g,fetchPriority:x}):_==="script"&&a.d.X(p,{crossOrigin:v,integrity:g,fetchPriority:x,nonce:typeof d.nonce=="string"?d.nonce:void 0})}},mi.preinitModule=function(p,d){if(typeof p=="string")if(typeof d=="object"&&d!==null){if(d.as==null||d.as==="script"){var _=f(d.as,d.crossOrigin);a.d.M(p,{crossOrigin:_,integrity:typeof d.integrity=="string"?d.integrity:void 0,nonce:typeof d.nonce=="string"?d.nonce:void 0})}}else d==null&&a.d.M(p)},mi.preload=function(p,d){if(typeof p=="string"&&typeof d=="object"&&d!==null&&typeof d.as=="string"){var _=d.as,v=f(_,d.crossOrigin);a.d.L(p,_,{crossOrigin:v,integrity:typeof d.integrity=="string"?d.integrity:void 0,nonce:typeof d.nonce=="string"?d.nonce:void 0,type:typeof d.type=="string"?d.type:void 0,fetchPriority:typeof d.fetchPriority=="string"?d.fetchPriority:void 0,referrerPolicy:typeof d.referrerPolicy=="string"?d.referrerPolicy:void 0,imageSrcSet:typeof d.imageSrcSet=="string"?d.imageSrcSet:void 0,imageSizes:typeof d.imageSizes=="string"?d.imageSizes:void 0,media:typeof d.media=="string"?d.media:void 0})}},mi.preloadModule=function(p,d){if(typeof p=="string")if(d){var _=f(d.as,d.crossOrigin);a.d.m(p,{as:typeof d.as=="string"&&d.as!=="script"?d.as:void 0,crossOrigin:_,integrity:typeof d.integrity=="string"?d.integrity:void 0})}else a.d.m(p)},mi.requestFormReset=function(p){a.d.r(p)},mi.unstable_batchedUpdates=function(p,d){return p(d)},mi.useFormState=function(p,d,_){return c.H.useFormState(p,d,_)},mi.useFormStatus=function(){return c.H.useHostTransitionStatus()},mi.version="19.2.4",mi}var ES;function RA(){if(ES)return Vm.exports;ES=1;function o(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(o)}catch(e){console.error(e)}}return o(),Vm.exports=AA(),Vm.exports}/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var TS;function CA(){if(TS)return ic;TS=1;var o=TA(),e=eg(),n=RA();function a(t){var i="https://react.dev/errors/"+t;if(1<arguments.length){i+="?args[]="+encodeURIComponent(arguments[1]);for(var s=2;s<arguments.length;s++)i+="&args[]="+encodeURIComponent(arguments[s])}return"Minified React error #"+t+"; visit "+i+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function r(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)}function l(t){var i=t,s=t;if(t.alternate)for(;i.return;)i=i.return;else{t=i;do i=t,(i.flags&4098)!==0&&(s=i.return),t=i.return;while(t)}return i.tag===3?s:null}function c(t){if(t.tag===13){var i=t.memoizedState;if(i===null&&(t=t.alternate,t!==null&&(i=t.memoizedState)),i!==null)return i.dehydrated}return null}function f(t){if(t.tag===31){var i=t.memoizedState;if(i===null&&(t=t.alternate,t!==null&&(i=t.memoizedState)),i!==null)return i.dehydrated}return null}function p(t){if(l(t)!==t)throw Error(a(188))}function d(t){var i=t.alternate;if(!i){if(i=l(t),i===null)throw Error(a(188));return i!==t?null:t}for(var s=t,u=i;;){var h=s.return;if(h===null)break;var m=h.alternate;if(m===null){if(u=h.return,u!==null){s=u;continue}break}if(h.child===m.child){for(m=h.child;m;){if(m===s)return p(h),t;if(m===u)return p(h),i;m=m.sibling}throw Error(a(188))}if(s.return!==u.return)s=h,u=m;else{for(var E=!1,U=h.child;U;){if(U===s){E=!0,s=h,u=m;break}if(U===u){E=!0,u=h,s=m;break}U=U.sibling}if(!E){for(U=m.child;U;){if(U===s){E=!0,s=m,u=h;break}if(U===u){E=!0,u=m,s=h;break}U=U.sibling}if(!E)throw Error(a(189))}}if(s.alternate!==u)throw Error(a(190))}if(s.tag!==3)throw Error(a(188));return s.stateNode.current===s?t:i}function _(t){var i=t.tag;if(i===5||i===26||i===27||i===6)return t;for(t=t.child;t!==null;){if(i=_(t),i!==null)return i;t=t.sibling}return null}var v=Object.assign,g=Symbol.for("react.element"),x=Symbol.for("react.transitional.element"),M=Symbol.for("react.portal"),b=Symbol.for("react.fragment"),y=Symbol.for("react.strict_mode"),S=Symbol.for("react.profiler"),R=Symbol.for("react.consumer"),N=Symbol.for("react.context"),C=Symbol.for("react.forward_ref"),O=Symbol.for("react.suspense"),P=Symbol.for("react.suspense_list"),L=Symbol.for("react.memo"),T=Symbol.for("react.lazy"),w=Symbol.for("react.activity"),q=Symbol.for("react.memo_cache_sentinel"),G=Symbol.iterator;function k(t){return t===null||typeof t!="object"?null:(t=G&&t[G]||t["@@iterator"],typeof t=="function"?t:null)}var $=Symbol.for("react.client.reference");function te(t){if(t==null)return null;if(typeof t=="function")return t.$$typeof===$?null:t.displayName||t.name||null;if(typeof t=="string")return t;switch(t){case b:return"Fragment";case S:return"Profiler";case y:return"StrictMode";case O:return"Suspense";case P:return"SuspenseList";case w:return"Activity"}if(typeof t=="object")switch(t.$$typeof){case M:return"Portal";case N:return t.displayName||"Context";case R:return(t._context.displayName||"Context")+".Consumer";case C:var i=t.render;return t=t.displayName,t||(t=i.displayName||i.name||"",t=t!==""?"ForwardRef("+t+")":"ForwardRef"),t;case L:return i=t.displayName||null,i!==null?i:te(t.type)||"Memo";case T:i=t._payload,t=t._init;try{return te(t(i))}catch{}}return null}var J=Array.isArray,z=e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,I=n.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,ie={pending:!1,data:null,method:null,action:null},he=[],H=-1;function F(t){return{current:t}}function Q(t){0>H||(t.current=he[H],he[H]=null,H--)}function xe(t,i){H++,he[H]=t.current,t.current=i}var Te=F(null),Ne=F(null),ne=F(null),_e=F(null);function be(t,i){switch(xe(ne,i),xe(Ne,t),xe(Te,null),i.nodeType){case 9:case 11:t=(t=i.documentElement)&&(t=t.namespaceURI)?Hy(t):0;break;default:if(t=i.tagName,i=i.namespaceURI)i=Hy(i),t=Gy(i,t);else switch(t){case"svg":t=1;break;case"math":t=2;break;default:t=0}}Q(Te),xe(Te,t)}function ze(){Q(Te),Q(Ne),Q(ne)}function tt(t){t.memoizedState!==null&&xe(_e,t);var i=Te.current,s=Gy(i,t.type);i!==s&&(xe(Ne,t),xe(Te,s))}function Ke(t){Ne.current===t&&(Q(Te),Q(Ne)),_e.current===t&&(Q(_e),Ju._currentValue=ie)}var Ut,qe;function rt(t){if(Ut===void 0)try{throw Error()}catch(s){var i=s.stack.trim().match(/\n( *(at )?)/);Ut=i&&i[1]||"",qe=-1<s.stack.indexOf(`
    at`)?" (<anonymous>)":-1<s.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Ut+t+qe}var _t=!1;function st(t,i){if(!t||_t)return"";_t=!0;var s=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var u={DetermineComponentFrameRoot:function(){try{if(i){var Me=function(){throw Error()};if(Object.defineProperty(Me.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(Me,[])}catch(pe){var ce=pe}Reflect.construct(t,[],Me)}else{try{Me.call()}catch(pe){ce=pe}t.call(Me.prototype)}}else{try{throw Error()}catch(pe){ce=pe}(Me=t())&&typeof Me.catch=="function"&&Me.catch(function(){})}}catch(pe){if(pe&&ce&&typeof pe.stack=="string")return[pe.stack,ce.stack]}return[null,null]}};u.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var h=Object.getOwnPropertyDescriptor(u.DetermineComponentFrameRoot,"name");h&&h.configurable&&Object.defineProperty(u.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var m=u.DetermineComponentFrameRoot(),E=m[0],U=m[1];if(E&&U){var X=E.split(`
`),oe=U.split(`
`);for(h=u=0;u<X.length&&!X[u].includes("DetermineComponentFrameRoot");)u++;for(;h<oe.length&&!oe[h].includes("DetermineComponentFrameRoot");)h++;if(u===X.length||h===oe.length)for(u=X.length-1,h=oe.length-1;1<=u&&0<=h&&X[u]!==oe[h];)h--;for(;1<=u&&0<=h;u--,h--)if(X[u]!==oe[h]){if(u!==1||h!==1)do if(u--,h--,0>h||X[u]!==oe[h]){var ye=`
`+X[u].replace(" at new "," at ");return t.displayName&&ye.includes("<anonymous>")&&(ye=ye.replace("<anonymous>",t.displayName)),ye}while(1<=u&&0<=h);break}}}finally{_t=!1,Error.prepareStackTrace=s}return(s=t?t.displayName||t.name:"")?rt(s):""}function le(t,i){switch(t.tag){case 26:case 27:case 5:return rt(t.type);case 16:return rt("Lazy");case 13:return t.child!==i&&i!==null?rt("Suspense Fallback"):rt("Suspense");case 19:return rt("SuspenseList");case 0:case 15:return st(t.type,!1);case 11:return st(t.type.render,!1);case 1:return st(t.type,!0);case 31:return rt("Activity");default:return""}}function W(t){try{var i="",s=null;do i+=le(t,s),s=t,t=t.return;while(t);return i}catch(u){return`
Error generating stack: `+u.message+`
`+u.stack}}var Wt=Object.prototype.hasOwnProperty,bt=o.unstable_scheduleCallback,ct=o.unstable_cancelCallback,We=o.unstable_shouldYield,B=o.unstable_requestPaint,A=o.unstable_now,Z=o.unstable_getCurrentPriorityLevel,ge=o.unstable_ImmediatePriority,ve=o.unstable_UserBlockingPriority,de=o.unstable_NormalPriority,Ge=o.unstable_LowPriority,we=o.unstable_IdlePriority,it=o.log,Ye=o.unstable_setDisableYieldValue,Re=null,Ae=null;function He(t){if(typeof it=="function"&&Ye(t),Ae&&typeof Ae.setStrictMode=="function")try{Ae.setStrictMode(Re,t)}catch{}}var Pe=Math.clz32?Math.clz32:V,Fe=Math.log,pt=Math.LN2;function V(t){return t>>>=0,t===0?32:31-(Fe(t)/pt|0)|0}var De=256,Ce=262144,Le=4194304;function Ee(t){var i=t&42;if(i!==0)return i;switch(t&-t){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return t&261888;case 262144:case 524288:case 1048576:case 2097152:return t&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return t&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return t}}function me(t,i,s){var u=t.pendingLanes;if(u===0)return 0;var h=0,m=t.suspendedLanes,E=t.pingedLanes;t=t.warmLanes;var U=u&134217727;return U!==0?(u=U&~m,u!==0?h=Ee(u):(E&=U,E!==0?h=Ee(E):s||(s=U&~t,s!==0&&(h=Ee(s))))):(U=u&~m,U!==0?h=Ee(U):E!==0?h=Ee(E):s||(s=u&~t,s!==0&&(h=Ee(s)))),h===0?0:i!==0&&i!==h&&(i&m)===0&&(m=h&-h,s=i&-i,m>=s||m===32&&(s&4194048)!==0)?i:h}function Xe(t,i){return(t.pendingLanes&~(t.suspendedLanes&~t.pingedLanes)&i)===0}function lt(t,i){switch(t){case 1:case 2:case 4:case 8:case 64:return i+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return i+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Gt(){var t=Le;return Le<<=1,(Le&62914560)===0&&(Le=4194304),t}function Ve(t){for(var i=[],s=0;31>s;s++)i.push(t);return i}function Je(t,i){t.pendingLanes|=i,i!==268435456&&(t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0)}function Et(t,i,s,u,h,m){var E=t.pendingLanes;t.pendingLanes=s,t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0,t.expiredLanes&=s,t.entangledLanes&=s,t.errorRecoveryDisabledLanes&=s,t.shellSuspendCounter=0;var U=t.entanglements,X=t.expirationTimes,oe=t.hiddenUpdates;for(s=E&~s;0<s;){var ye=31-Pe(s),Me=1<<ye;U[ye]=0,X[ye]=-1;var ce=oe[ye];if(ce!==null)for(oe[ye]=null,ye=0;ye<ce.length;ye++){var pe=ce[ye];pe!==null&&(pe.lane&=-536870913)}s&=~Me}u!==0&&Ie(t,u,0),m!==0&&h===0&&t.tag!==0&&(t.suspendedLanes|=m&~(E&~i))}function Ie(t,i,s){t.pendingLanes|=i,t.suspendedLanes&=~i;var u=31-Pe(i);t.entangledLanes|=i,t.entanglements[u]=t.entanglements[u]|1073741824|s&261930}function ht(t,i){var s=t.entangledLanes|=i;for(t=t.entanglements;s;){var u=31-Pe(s),h=1<<u;h&i|t[u]&i&&(t[u]|=i),s&=~h}}function ot(t,i){var s=i&-i;return s=(s&42)!==0?1:dt(s),(s&(t.suspendedLanes|i))!==0?0:s}function dt(t){switch(t){case 2:t=1;break;case 8:t=4;break;case 32:t=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:t=128;break;case 268435456:t=134217728;break;default:t=0}return t}function _n(t){return t&=-t,2<t?8<t?(t&134217727)!==0?32:268435456:8:2}function gt(){var t=I.p;return t!==0?t:(t=window.event,t===void 0?32:cS(t.type))}function rn(t,i){var s=I.p;try{return I.p=t,i()}finally{I.p=s}}var sn=Math.random().toString(36).slice(2),Tt="__reactFiber$"+sn,xt="__reactProps$"+sn,Pt="__reactContainer$"+sn,In="__reactEvents$"+sn,on="__reactListeners$"+sn,ti="__reactHandles$"+sn,Ei="__reactResources$"+sn,gn="__reactMarker$"+sn;function Tn(t){delete t[Tt],delete t[xt],delete t[In],delete t[on],delete t[ti]}function vn(t){var i=t[Tt];if(i)return i;for(var s=t.parentNode;s;){if(i=s[Pt]||s[Tt]){if(s=i.alternate,i.child!==null||s!==null&&s.child!==null)for(t=jy(t);t!==null;){if(s=t[Tt])return s;t=jy(t)}return i}t=s,s=t.parentNode}return null}function pi(t){if(t=t[Tt]||t[Pt]){var i=t.tag;if(i===5||i===6||i===13||i===31||i===26||i===27||i===3)return t}return null}function Sa(t){var i=t.tag;if(i===5||i===26||i===27||i===6)return t.stateNode;throw Error(a(33))}function D(t){var i=t[Ei];return i||(i=t[Ei]={hoistableStyles:new Map,hoistableScripts:new Map}),i}function Y(t){t[gn]=!0}var ue=new Set,se={};function ae(t,i){Ue(t,i),Ue(t+"Capture",i)}function Ue(t,i){for(se[t]=i,t=0;t<i.length;t++)ue.add(i[t])}var Be=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),Oe={},je={};function Ze(t){return Wt.call(je,t)?!0:Wt.call(Oe,t)?!1:Be.test(t)?je[t]=!0:(Oe[t]=!0,!1)}function mt(t,i,s){if(Ze(i))if(s===null)t.removeAttribute(i);else{switch(typeof s){case"undefined":case"function":case"symbol":t.removeAttribute(i);return;case"boolean":var u=i.toLowerCase().slice(0,5);if(u!=="data-"&&u!=="aria-"){t.removeAttribute(i);return}}t.setAttribute(i,""+s)}}function yt(t,i,s){if(s===null)t.removeAttribute(i);else{switch(typeof s){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(i);return}t.setAttribute(i,""+s)}}function Qe(t,i,s,u){if(u===null)t.removeAttribute(s);else{switch(typeof u){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(s);return}t.setAttributeNS(i,s,""+u)}}function Rt(t){switch(typeof t){case"bigint":case"boolean":case"number":case"string":case"undefined":return t;case"object":return t;default:return""}}function Sn(t){var i=t.type;return(t=t.nodeName)&&t.toLowerCase()==="input"&&(i==="checkbox"||i==="radio")}function Mn(t,i,s){var u=Object.getOwnPropertyDescriptor(t.constructor.prototype,i);if(!t.hasOwnProperty(i)&&typeof u<"u"&&typeof u.get=="function"&&typeof u.set=="function"){var h=u.get,m=u.set;return Object.defineProperty(t,i,{configurable:!0,get:function(){return h.call(this)},set:function(E){s=""+E,m.call(this,E)}}),Object.defineProperty(t,i,{enumerable:u.enumerable}),{getValue:function(){return s},setValue:function(E){s=""+E},stopTracking:function(){t._valueTracker=null,delete t[i]}}}}function jt(t){if(!t._valueTracker){var i=Sn(t)?"checked":"value";t._valueTracker=Mn(t,i,""+t[i])}}function jn(t){if(!t)return!1;var i=t._valueTracker;if(!i)return!0;var s=i.getValue(),u="";return t&&(u=Sn(t)?t.checked?"true":"false":t.value),t=u,t!==s?(i.setValue(t),!0):!1}function nt(t){if(t=t||(typeof document<"u"?document:void 0),typeof t>"u")return null;try{return t.activeElement||t.body}catch{return t.body}}var Ti=/[\n"\\]/g;function vt(t){return t.replace(Ti,function(i){return"\\"+i.charCodeAt(0).toString(16)+" "})}function Ai(t,i,s,u,h,m,E,U){t.name="",E!=null&&typeof E!="function"&&typeof E!="symbol"&&typeof E!="boolean"?t.type=E:t.removeAttribute("type"),i!=null?E==="number"?(i===0&&t.value===""||t.value!=i)&&(t.value=""+Rt(i)):t.value!==""+Rt(i)&&(t.value=""+Rt(i)):E!=="submit"&&E!=="reset"||t.removeAttribute("value"),i!=null?Va(t,E,Rt(i)):s!=null?Va(t,E,Rt(s)):u!=null&&t.removeAttribute("value"),h==null&&m!=null&&(t.defaultChecked=!!m),h!=null&&(t.checked=h&&typeof h!="function"&&typeof h!="symbol"),U!=null&&typeof U!="function"&&typeof U!="symbol"&&typeof U!="boolean"?t.name=""+Rt(U):t.removeAttribute("name")}function $i(t,i,s,u,h,m,E,U){if(m!=null&&typeof m!="function"&&typeof m!="symbol"&&typeof m!="boolean"&&(t.type=m),i!=null||s!=null){if(!(m!=="submit"&&m!=="reset"||i!=null)){jt(t);return}s=s!=null?""+Rt(s):"",i=i!=null?""+Rt(i):s,U||i===t.value||(t.value=i),t.defaultValue=i}u=u??h,u=typeof u!="function"&&typeof u!="symbol"&&!!u,t.checked=U?t.checked:!!u,t.defaultChecked=!!u,E!=null&&typeof E!="function"&&typeof E!="symbol"&&typeof E!="boolean"&&(t.name=E),jt(t)}function Va(t,i,s){i==="number"&&nt(t.ownerDocument)===t||t.defaultValue===""+s||(t.defaultValue=""+s)}function ea(t,i,s,u){if(t=t.options,i){i={};for(var h=0;h<s.length;h++)i["$"+s[h]]=!0;for(s=0;s<t.length;s++)h=i.hasOwnProperty("$"+t[s].value),t[s].selected!==h&&(t[s].selected=h),h&&u&&(t[s].defaultSelected=!0)}else{for(s=""+Rt(s),i=null,h=0;h<t.length;h++){if(t[h].value===s){t[h].selected=!0,u&&(t[h].defaultSelected=!0);return}i!==null||t[h].disabled||(i=t[h])}i!==null&&(i.selected=!0)}}function $t(t,i,s){if(i!=null&&(i=""+Rt(i),i!==t.value&&(t.value=i),s==null)){t.defaultValue!==i&&(t.defaultValue=i);return}t.defaultValue=s!=null?""+Rt(s):""}function Bn(t,i,s,u){if(i==null){if(u!=null){if(s!=null)throw Error(a(92));if(J(u)){if(1<u.length)throw Error(a(93));u=u[0]}s=u}s==null&&(s=""),i=s}s=Rt(i),t.defaultValue=s,u=t.textContent,u===s&&u!==""&&u!==null&&(t.value=u),jt(t)}function Ri(t,i){if(i){var s=t.firstChild;if(s&&s===t.lastChild&&s.nodeType===3){s.nodeValue=i;return}}t.textContent=i}var Hn=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function ka(t,i,s){var u=i.indexOf("--")===0;s==null||typeof s=="boolean"||s===""?u?t.setProperty(i,""):i==="float"?t.cssFloat="":t[i]="":u?t.setProperty(i,s):typeof s!="number"||s===0||Hn.has(i)?i==="float"?t.cssFloat=s:t[i]=(""+s).trim():t[i]=s+"px"}function br(t,i,s){if(i!=null&&typeof i!="object")throw Error(a(62));if(t=t.style,s!=null){for(var u in s)!s.hasOwnProperty(u)||i!=null&&i.hasOwnProperty(u)||(u.indexOf("--")===0?t.setProperty(u,""):u==="float"?t.cssFloat="":t[u]="");for(var h in i)u=i[h],i.hasOwnProperty(h)&&s[h]!==u&&ka(t,h,u)}else for(var m in i)i.hasOwnProperty(m)&&ka(t,m,i[m])}function Yo(t){if(t.indexOf("-")===-1)return!1;switch(t){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var gE=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),vE=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function ef(t){return vE.test(""+t)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":t}function Er(){}var Od=null;function Pd(t){return t=t.target||t.srcElement||window,t.correspondingUseElement&&(t=t.correspondingUseElement),t.nodeType===3?t.parentNode:t}var qo=null,jo=null;function Bg(t){var i=pi(t);if(i&&(t=i.stateNode)){var s=t[xt]||null;e:switch(t=i.stateNode,i.type){case"input":if(Ai(t,s.value,s.defaultValue,s.defaultValue,s.checked,s.defaultChecked,s.type,s.name),i=s.name,s.type==="radio"&&i!=null){for(s=t;s.parentNode;)s=s.parentNode;for(s=s.querySelectorAll('input[name="'+vt(""+i)+'"][type="radio"]'),i=0;i<s.length;i++){var u=s[i];if(u!==t&&u.form===t.form){var h=u[xt]||null;if(!h)throw Error(a(90));Ai(u,h.value,h.defaultValue,h.defaultValue,h.checked,h.defaultChecked,h.type,h.name)}}for(i=0;i<s.length;i++)u=s[i],u.form===t.form&&jn(u)}break e;case"textarea":$t(t,s.value,s.defaultValue);break e;case"select":i=s.value,i!=null&&ea(t,!!s.multiple,i,!1)}}}var zd=!1;function Hg(t,i,s){if(zd)return t(i,s);zd=!0;try{var u=t(i);return u}finally{if(zd=!1,(qo!==null||jo!==null)&&(Vf(),qo&&(i=qo,t=jo,jo=qo=null,Bg(i),t)))for(i=0;i<t.length;i++)Bg(t[i])}}function mu(t,i){var s=t.stateNode;if(s===null)return null;var u=s[xt]||null;if(u===null)return null;s=u[i];e:switch(i){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(u=!u.disabled)||(t=t.type,u=!(t==="button"||t==="input"||t==="select"||t==="textarea")),t=!u;break e;default:t=!1}if(t)return null;if(s&&typeof s!="function")throw Error(a(231,i,typeof s));return s}var Tr=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Fd=!1;if(Tr)try{var _u={};Object.defineProperty(_u,"passive",{get:function(){Fd=!0}}),window.addEventListener("test",_u,_u),window.removeEventListener("test",_u,_u)}catch{Fd=!1}var os=null,Id=null,tf=null;function Gg(){if(tf)return tf;var t,i=Id,s=i.length,u,h="value"in os?os.value:os.textContent,m=h.length;for(t=0;t<s&&i[t]===h[t];t++);var E=s-t;for(u=1;u<=E&&i[s-u]===h[m-u];u++);return tf=h.slice(t,1<u?1-u:void 0)}function nf(t){var i=t.keyCode;return"charCode"in t?(t=t.charCode,t===0&&i===13&&(t=13)):t=i,t===10&&(t=13),32<=t||t===13?t:0}function af(){return!0}function Vg(){return!1}function Ii(t){function i(s,u,h,m,E){this._reactName=s,this._targetInst=h,this.type=u,this.nativeEvent=m,this.target=E,this.currentTarget=null;for(var U in t)t.hasOwnProperty(U)&&(s=t[U],this[U]=s?s(m):m[U]);return this.isDefaultPrevented=(m.defaultPrevented!=null?m.defaultPrevented:m.returnValue===!1)?af:Vg,this.isPropagationStopped=Vg,this}return v(i.prototype,{preventDefault:function(){this.defaultPrevented=!0;var s=this.nativeEvent;s&&(s.preventDefault?s.preventDefault():typeof s.returnValue!="unknown"&&(s.returnValue=!1),this.isDefaultPrevented=af)},stopPropagation:function(){var s=this.nativeEvent;s&&(s.stopPropagation?s.stopPropagation():typeof s.cancelBubble!="unknown"&&(s.cancelBubble=!0),this.isPropagationStopped=af)},persist:function(){},isPersistent:af}),i}var $s={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(t){return t.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},rf=Ii($s),gu=v({},$s,{view:0,detail:0}),xE=Ii(gu),Bd,Hd,vu,sf=v({},gu,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Vd,button:0,buttons:0,relatedTarget:function(t){return t.relatedTarget===void 0?t.fromElement===t.srcElement?t.toElement:t.fromElement:t.relatedTarget},movementX:function(t){return"movementX"in t?t.movementX:(t!==vu&&(vu&&t.type==="mousemove"?(Bd=t.screenX-vu.screenX,Hd=t.screenY-vu.screenY):Hd=Bd=0,vu=t),Bd)},movementY:function(t){return"movementY"in t?t.movementY:Hd}}),kg=Ii(sf),yE=v({},sf,{dataTransfer:0}),SE=Ii(yE),ME=v({},gu,{relatedTarget:0}),Gd=Ii(ME),bE=v({},$s,{animationName:0,elapsedTime:0,pseudoElement:0}),EE=Ii(bE),TE=v({},$s,{clipboardData:function(t){return"clipboardData"in t?t.clipboardData:window.clipboardData}}),AE=Ii(TE),RE=v({},$s,{data:0}),Xg=Ii(RE),CE={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},wE={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},DE={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function NE(t){var i=this.nativeEvent;return i.getModifierState?i.getModifierState(t):(t=DE[t])?!!i[t]:!1}function Vd(){return NE}var UE=v({},gu,{key:function(t){if(t.key){var i=CE[t.key]||t.key;if(i!=="Unidentified")return i}return t.type==="keypress"?(t=nf(t),t===13?"Enter":String.fromCharCode(t)):t.type==="keydown"||t.type==="keyup"?wE[t.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Vd,charCode:function(t){return t.type==="keypress"?nf(t):0},keyCode:function(t){return t.type==="keydown"||t.type==="keyup"?t.keyCode:0},which:function(t){return t.type==="keypress"?nf(t):t.type==="keydown"||t.type==="keyup"?t.keyCode:0}}),LE=Ii(UE),OE=v({},sf,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Wg=Ii(OE),PE=v({},gu,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Vd}),zE=Ii(PE),FE=v({},$s,{propertyName:0,elapsedTime:0,pseudoElement:0}),IE=Ii(FE),BE=v({},sf,{deltaX:function(t){return"deltaX"in t?t.deltaX:"wheelDeltaX"in t?-t.wheelDeltaX:0},deltaY:function(t){return"deltaY"in t?t.deltaY:"wheelDeltaY"in t?-t.wheelDeltaY:"wheelDelta"in t?-t.wheelDelta:0},deltaZ:0,deltaMode:0}),HE=Ii(BE),GE=v({},$s,{newState:0,oldState:0}),VE=Ii(GE),kE=[9,13,27,32],kd=Tr&&"CompositionEvent"in window,xu=null;Tr&&"documentMode"in document&&(xu=document.documentMode);var XE=Tr&&"TextEvent"in window&&!xu,Yg=Tr&&(!kd||xu&&8<xu&&11>=xu),qg=" ",jg=!1;function Zg(t,i){switch(t){case"keyup":return kE.indexOf(i.keyCode)!==-1;case"keydown":return i.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Kg(t){return t=t.detail,typeof t=="object"&&"data"in t?t.data:null}var Zo=!1;function WE(t,i){switch(t){case"compositionend":return Kg(i);case"keypress":return i.which!==32?null:(jg=!0,qg);case"textInput":return t=i.data,t===qg&&jg?null:t;default:return null}}function YE(t,i){if(Zo)return t==="compositionend"||!kd&&Zg(t,i)?(t=Gg(),tf=Id=os=null,Zo=!1,t):null;switch(t){case"paste":return null;case"keypress":if(!(i.ctrlKey||i.altKey||i.metaKey)||i.ctrlKey&&i.altKey){if(i.char&&1<i.char.length)return i.char;if(i.which)return String.fromCharCode(i.which)}return null;case"compositionend":return Yg&&i.locale!=="ko"?null:i.data;default:return null}}var qE={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Qg(t){var i=t&&t.nodeName&&t.nodeName.toLowerCase();return i==="input"?!!qE[t.type]:i==="textarea"}function Jg(t,i,s,u){qo?jo?jo.push(u):jo=[u]:qo=u,i=Zf(i,"onChange"),0<i.length&&(s=new rf("onChange","change",null,s,u),t.push({event:s,listeners:i}))}var yu=null,Su=null;function jE(t){Oy(t,0)}function of(t){var i=Sa(t);if(jn(i))return t}function $g(t,i){if(t==="change")return i}var ev=!1;if(Tr){var Xd;if(Tr){var Wd="oninput"in document;if(!Wd){var tv=document.createElement("div");tv.setAttribute("oninput","return;"),Wd=typeof tv.oninput=="function"}Xd=Wd}else Xd=!1;ev=Xd&&(!document.documentMode||9<document.documentMode)}function nv(){yu&&(yu.detachEvent("onpropertychange",iv),Su=yu=null)}function iv(t){if(t.propertyName==="value"&&of(Su)){var i=[];Jg(i,Su,t,Pd(t)),Hg(jE,i)}}function ZE(t,i,s){t==="focusin"?(nv(),yu=i,Su=s,yu.attachEvent("onpropertychange",iv)):t==="focusout"&&nv()}function KE(t){if(t==="selectionchange"||t==="keyup"||t==="keydown")return of(Su)}function QE(t,i){if(t==="click")return of(i)}function JE(t,i){if(t==="input"||t==="change")return of(i)}function $E(t,i){return t===i&&(t!==0||1/t===1/i)||t!==t&&i!==i}var ta=typeof Object.is=="function"?Object.is:$E;function Mu(t,i){if(ta(t,i))return!0;if(typeof t!="object"||t===null||typeof i!="object"||i===null)return!1;var s=Object.keys(t),u=Object.keys(i);if(s.length!==u.length)return!1;for(u=0;u<s.length;u++){var h=s[u];if(!Wt.call(i,h)||!ta(t[h],i[h]))return!1}return!0}function av(t){for(;t&&t.firstChild;)t=t.firstChild;return t}function rv(t,i){var s=av(t);t=0;for(var u;s;){if(s.nodeType===3){if(u=t+s.textContent.length,t<=i&&u>=i)return{node:s,offset:i-t};t=u}e:{for(;s;){if(s.nextSibling){s=s.nextSibling;break e}s=s.parentNode}s=void 0}s=av(s)}}function sv(t,i){return t&&i?t===i?!0:t&&t.nodeType===3?!1:i&&i.nodeType===3?sv(t,i.parentNode):"contains"in t?t.contains(i):t.compareDocumentPosition?!!(t.compareDocumentPosition(i)&16):!1:!1}function ov(t){t=t!=null&&t.ownerDocument!=null&&t.ownerDocument.defaultView!=null?t.ownerDocument.defaultView:window;for(var i=nt(t.document);i instanceof t.HTMLIFrameElement;){try{var s=typeof i.contentWindow.location.href=="string"}catch{s=!1}if(s)t=i.contentWindow;else break;i=nt(t.document)}return i}function Yd(t){var i=t&&t.nodeName&&t.nodeName.toLowerCase();return i&&(i==="input"&&(t.type==="text"||t.type==="search"||t.type==="tel"||t.type==="url"||t.type==="password")||i==="textarea"||t.contentEditable==="true")}var eT=Tr&&"documentMode"in document&&11>=document.documentMode,Ko=null,qd=null,bu=null,jd=!1;function lv(t,i,s){var u=s.window===s?s.document:s.nodeType===9?s:s.ownerDocument;jd||Ko==null||Ko!==nt(u)||(u=Ko,"selectionStart"in u&&Yd(u)?u={start:u.selectionStart,end:u.selectionEnd}:(u=(u.ownerDocument&&u.ownerDocument.defaultView||window).getSelection(),u={anchorNode:u.anchorNode,anchorOffset:u.anchorOffset,focusNode:u.focusNode,focusOffset:u.focusOffset}),bu&&Mu(bu,u)||(bu=u,u=Zf(qd,"onSelect"),0<u.length&&(i=new rf("onSelect","select",null,i,s),t.push({event:i,listeners:u}),i.target=Ko)))}function eo(t,i){var s={};return s[t.toLowerCase()]=i.toLowerCase(),s["Webkit"+t]="webkit"+i,s["Moz"+t]="moz"+i,s}var Qo={animationend:eo("Animation","AnimationEnd"),animationiteration:eo("Animation","AnimationIteration"),animationstart:eo("Animation","AnimationStart"),transitionrun:eo("Transition","TransitionRun"),transitionstart:eo("Transition","TransitionStart"),transitioncancel:eo("Transition","TransitionCancel"),transitionend:eo("Transition","TransitionEnd")},Zd={},uv={};Tr&&(uv=document.createElement("div").style,"AnimationEvent"in window||(delete Qo.animationend.animation,delete Qo.animationiteration.animation,delete Qo.animationstart.animation),"TransitionEvent"in window||delete Qo.transitionend.transition);function to(t){if(Zd[t])return Zd[t];if(!Qo[t])return t;var i=Qo[t],s;for(s in i)if(i.hasOwnProperty(s)&&s in uv)return Zd[t]=i[s];return t}var cv=to("animationend"),fv=to("animationiteration"),hv=to("animationstart"),tT=to("transitionrun"),nT=to("transitionstart"),iT=to("transitioncancel"),dv=to("transitionend"),pv=new Map,Kd="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Kd.push("scrollEnd");function Xa(t,i){pv.set(t,i),ae(i,[t])}var lf=typeof reportError=="function"?reportError:function(t){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var i=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof t=="object"&&t!==null&&typeof t.message=="string"?String(t.message):String(t),error:t});if(!window.dispatchEvent(i))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",t);return}console.error(t)},Ma=[],Jo=0,Qd=0;function uf(){for(var t=Jo,i=Qd=Jo=0;i<t;){var s=Ma[i];Ma[i++]=null;var u=Ma[i];Ma[i++]=null;var h=Ma[i];Ma[i++]=null;var m=Ma[i];if(Ma[i++]=null,u!==null&&h!==null){var E=u.pending;E===null?h.next=h:(h.next=E.next,E.next=h),u.pending=h}m!==0&&mv(s,h,m)}}function cf(t,i,s,u){Ma[Jo++]=t,Ma[Jo++]=i,Ma[Jo++]=s,Ma[Jo++]=u,Qd|=u,t.lanes|=u,t=t.alternate,t!==null&&(t.lanes|=u)}function Jd(t,i,s,u){return cf(t,i,s,u),ff(t)}function no(t,i){return cf(t,null,null,i),ff(t)}function mv(t,i,s){t.lanes|=s;var u=t.alternate;u!==null&&(u.lanes|=s);for(var h=!1,m=t.return;m!==null;)m.childLanes|=s,u=m.alternate,u!==null&&(u.childLanes|=s),m.tag===22&&(t=m.stateNode,t===null||t._visibility&1||(h=!0)),t=m,m=m.return;return t.tag===3?(m=t.stateNode,h&&i!==null&&(h=31-Pe(s),t=m.hiddenUpdates,u=t[h],u===null?t[h]=[i]:u.push(i),i.lane=s|536870912),m):null}function ff(t){if(50<Wu)throw Wu=0,om=null,Error(a(185));for(var i=t.return;i!==null;)t=i,i=t.return;return t.tag===3?t.stateNode:null}var $o={};function aT(t,i,s,u){this.tag=t,this.key=s,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=i,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=u,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function na(t,i,s,u){return new aT(t,i,s,u)}function $d(t){return t=t.prototype,!(!t||!t.isReactComponent)}function Ar(t,i){var s=t.alternate;return s===null?(s=na(t.tag,i,t.key,t.mode),s.elementType=t.elementType,s.type=t.type,s.stateNode=t.stateNode,s.alternate=t,t.alternate=s):(s.pendingProps=i,s.type=t.type,s.flags=0,s.subtreeFlags=0,s.deletions=null),s.flags=t.flags&65011712,s.childLanes=t.childLanes,s.lanes=t.lanes,s.child=t.child,s.memoizedProps=t.memoizedProps,s.memoizedState=t.memoizedState,s.updateQueue=t.updateQueue,i=t.dependencies,s.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext},s.sibling=t.sibling,s.index=t.index,s.ref=t.ref,s.refCleanup=t.refCleanup,s}function _v(t,i){t.flags&=65011714;var s=t.alternate;return s===null?(t.childLanes=0,t.lanes=i,t.child=null,t.subtreeFlags=0,t.memoizedProps=null,t.memoizedState=null,t.updateQueue=null,t.dependencies=null,t.stateNode=null):(t.childLanes=s.childLanes,t.lanes=s.lanes,t.child=s.child,t.subtreeFlags=0,t.deletions=null,t.memoizedProps=s.memoizedProps,t.memoizedState=s.memoizedState,t.updateQueue=s.updateQueue,t.type=s.type,i=s.dependencies,t.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext}),t}function hf(t,i,s,u,h,m){var E=0;if(u=t,typeof t=="function")$d(t)&&(E=1);else if(typeof t=="string")E=uA(t,s,Te.current)?26:t==="html"||t==="head"||t==="body"?27:5;else e:switch(t){case w:return t=na(31,s,i,h),t.elementType=w,t.lanes=m,t;case b:return io(s.children,h,m,i);case y:E=8,h|=24;break;case S:return t=na(12,s,i,h|2),t.elementType=S,t.lanes=m,t;case O:return t=na(13,s,i,h),t.elementType=O,t.lanes=m,t;case P:return t=na(19,s,i,h),t.elementType=P,t.lanes=m,t;default:if(typeof t=="object"&&t!==null)switch(t.$$typeof){case N:E=10;break e;case R:E=9;break e;case C:E=11;break e;case L:E=14;break e;case T:E=16,u=null;break e}E=29,s=Error(a(130,t===null?"null":typeof t,"")),u=null}return i=na(E,s,i,h),i.elementType=t,i.type=u,i.lanes=m,i}function io(t,i,s,u){return t=na(7,t,u,i),t.lanes=s,t}function ep(t,i,s){return t=na(6,t,null,i),t.lanes=s,t}function gv(t){var i=na(18,null,null,0);return i.stateNode=t,i}function tp(t,i,s){return i=na(4,t.children!==null?t.children:[],t.key,i),i.lanes=s,i.stateNode={containerInfo:t.containerInfo,pendingChildren:null,implementation:t.implementation},i}var vv=new WeakMap;function ba(t,i){if(typeof t=="object"&&t!==null){var s=vv.get(t);return s!==void 0?s:(i={value:t,source:i,stack:W(i)},vv.set(t,i),i)}return{value:t,source:i,stack:W(i)}}var el=[],tl=0,df=null,Eu=0,Ea=[],Ta=0,ls=null,tr=1,nr="";function Rr(t,i){el[tl++]=Eu,el[tl++]=df,df=t,Eu=i}function xv(t,i,s){Ea[Ta++]=tr,Ea[Ta++]=nr,Ea[Ta++]=ls,ls=t;var u=tr;t=nr;var h=32-Pe(u)-1;u&=~(1<<h),s+=1;var m=32-Pe(i)+h;if(30<m){var E=h-h%5;m=(u&(1<<E)-1).toString(32),u>>=E,h-=E,tr=1<<32-Pe(i)+h|s<<h|u,nr=m+t}else tr=1<<m|s<<h|u,nr=t}function np(t){t.return!==null&&(Rr(t,1),xv(t,1,0))}function ip(t){for(;t===df;)df=el[--tl],el[tl]=null,Eu=el[--tl],el[tl]=null;for(;t===ls;)ls=Ea[--Ta],Ea[Ta]=null,nr=Ea[--Ta],Ea[Ta]=null,tr=Ea[--Ta],Ea[Ta]=null}function yv(t,i){Ea[Ta++]=tr,Ea[Ta++]=nr,Ea[Ta++]=ls,tr=i.id,nr=i.overflow,ls=t}var oi=null,xn=null,Vt=!1,us=null,Aa=!1,ap=Error(a(519));function cs(t){var i=Error(a(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw Tu(ba(i,t)),ap}function Sv(t){var i=t.stateNode,s=t.type,u=t.memoizedProps;switch(i[Tt]=t,i[xt]=u,s){case"dialog":Ft("cancel",i),Ft("close",i);break;case"iframe":case"object":case"embed":Ft("load",i);break;case"video":case"audio":for(s=0;s<qu.length;s++)Ft(qu[s],i);break;case"source":Ft("error",i);break;case"img":case"image":case"link":Ft("error",i),Ft("load",i);break;case"details":Ft("toggle",i);break;case"input":Ft("invalid",i),$i(i,u.value,u.defaultValue,u.checked,u.defaultChecked,u.type,u.name,!0);break;case"select":Ft("invalid",i);break;case"textarea":Ft("invalid",i),Bn(i,u.value,u.defaultValue,u.children)}s=u.children,typeof s!="string"&&typeof s!="number"&&typeof s!="bigint"||i.textContent===""+s||u.suppressHydrationWarning===!0||Iy(i.textContent,s)?(u.popover!=null&&(Ft("beforetoggle",i),Ft("toggle",i)),u.onScroll!=null&&Ft("scroll",i),u.onScrollEnd!=null&&Ft("scrollend",i),u.onClick!=null&&(i.onclick=Er),i=!0):i=!1,i||cs(t,!0)}function Mv(t){for(oi=t.return;oi;)switch(oi.tag){case 5:case 31:case 13:Aa=!1;return;case 27:case 3:Aa=!0;return;default:oi=oi.return}}function nl(t){if(t!==oi)return!1;if(!Vt)return Mv(t),Vt=!0,!1;var i=t.tag,s;if((s=i!==3&&i!==27)&&((s=i===5)&&(s=t.type,s=!(s!=="form"&&s!=="button")||Mm(t.type,t.memoizedProps)),s=!s),s&&xn&&cs(t),Mv(t),i===13){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(a(317));xn=qy(t)}else if(i===31){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(a(317));xn=qy(t)}else i===27?(i=xn,Es(t.type)?(t=Rm,Rm=null,xn=t):xn=i):xn=oi?Ca(t.stateNode.nextSibling):null;return!0}function ao(){xn=oi=null,Vt=!1}function rp(){var t=us;return t!==null&&(Vi===null?Vi=t:Vi.push.apply(Vi,t),us=null),t}function Tu(t){us===null?us=[t]:us.push(t)}var sp=F(null),ro=null,Cr=null;function fs(t,i,s){xe(sp,i._currentValue),i._currentValue=s}function wr(t){t._currentValue=sp.current,Q(sp)}function op(t,i,s){for(;t!==null;){var u=t.alternate;if((t.childLanes&i)!==i?(t.childLanes|=i,u!==null&&(u.childLanes|=i)):u!==null&&(u.childLanes&i)!==i&&(u.childLanes|=i),t===s)break;t=t.return}}function lp(t,i,s,u){var h=t.child;for(h!==null&&(h.return=t);h!==null;){var m=h.dependencies;if(m!==null){var E=h.child;m=m.firstContext;e:for(;m!==null;){var U=m;m=h;for(var X=0;X<i.length;X++)if(U.context===i[X]){m.lanes|=s,U=m.alternate,U!==null&&(U.lanes|=s),op(m.return,s,t),u||(E=null);break e}m=U.next}}else if(h.tag===18){if(E=h.return,E===null)throw Error(a(341));E.lanes|=s,m=E.alternate,m!==null&&(m.lanes|=s),op(E,s,t),E=null}else E=h.child;if(E!==null)E.return=h;else for(E=h;E!==null;){if(E===t){E=null;break}if(h=E.sibling,h!==null){h.return=E.return,E=h;break}E=E.return}h=E}}function il(t,i,s,u){t=null;for(var h=i,m=!1;h!==null;){if(!m){if((h.flags&524288)!==0)m=!0;else if((h.flags&262144)!==0)break}if(h.tag===10){var E=h.alternate;if(E===null)throw Error(a(387));if(E=E.memoizedProps,E!==null){var U=h.type;ta(h.pendingProps.value,E.value)||(t!==null?t.push(U):t=[U])}}else if(h===_e.current){if(E=h.alternate,E===null)throw Error(a(387));E.memoizedState.memoizedState!==h.memoizedState.memoizedState&&(t!==null?t.push(Ju):t=[Ju])}h=h.return}t!==null&&lp(i,t,s,u),i.flags|=262144}function pf(t){for(t=t.firstContext;t!==null;){if(!ta(t.context._currentValue,t.memoizedValue))return!0;t=t.next}return!1}function so(t){ro=t,Cr=null,t=t.dependencies,t!==null&&(t.firstContext=null)}function li(t){return bv(ro,t)}function mf(t,i){return ro===null&&so(t),bv(t,i)}function bv(t,i){var s=i._currentValue;if(i={context:i,memoizedValue:s,next:null},Cr===null){if(t===null)throw Error(a(308));Cr=i,t.dependencies={lanes:0,firstContext:i},t.flags|=524288}else Cr=Cr.next=i;return s}var rT=typeof AbortController<"u"?AbortController:function(){var t=[],i=this.signal={aborted:!1,addEventListener:function(s,u){t.push(u)}};this.abort=function(){i.aborted=!0,t.forEach(function(s){return s()})}},sT=o.unstable_scheduleCallback,oT=o.unstable_NormalPriority,Gn={$$typeof:N,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function up(){return{controller:new rT,data:new Map,refCount:0}}function Au(t){t.refCount--,t.refCount===0&&sT(oT,function(){t.controller.abort()})}var Ru=null,cp=0,al=0,rl=null;function lT(t,i){if(Ru===null){var s=Ru=[];cp=0,al=dm(),rl={status:"pending",value:void 0,then:function(u){s.push(u)}}}return cp++,i.then(Ev,Ev),i}function Ev(){if(--cp===0&&Ru!==null){rl!==null&&(rl.status="fulfilled");var t=Ru;Ru=null,al=0,rl=null;for(var i=0;i<t.length;i++)(0,t[i])()}}function uT(t,i){var s=[],u={status:"pending",value:null,reason:null,then:function(h){s.push(h)}};return t.then(function(){u.status="fulfilled",u.value=i;for(var h=0;h<s.length;h++)(0,s[h])(i)},function(h){for(u.status="rejected",u.reason=h,h=0;h<s.length;h++)(0,s[h])(void 0)}),u}var Tv=z.S;z.S=function(t,i){ly=A(),typeof i=="object"&&i!==null&&typeof i.then=="function"&&lT(t,i),Tv!==null&&Tv(t,i)};var oo=F(null);function fp(){var t=oo.current;return t!==null?t:hn.pooledCache}function _f(t,i){i===null?xe(oo,oo.current):xe(oo,i.pool)}function Av(){var t=fp();return t===null?null:{parent:Gn._currentValue,pool:t}}var sl=Error(a(460)),hp=Error(a(474)),gf=Error(a(542)),vf={then:function(){}};function Rv(t){return t=t.status,t==="fulfilled"||t==="rejected"}function Cv(t,i,s){switch(s=t[s],s===void 0?t.push(i):s!==i&&(i.then(Er,Er),i=s),i.status){case"fulfilled":return i.value;case"rejected":throw t=i.reason,Dv(t),t;default:if(typeof i.status=="string")i.then(Er,Er);else{if(t=hn,t!==null&&100<t.shellSuspendCounter)throw Error(a(482));t=i,t.status="pending",t.then(function(u){if(i.status==="pending"){var h=i;h.status="fulfilled",h.value=u}},function(u){if(i.status==="pending"){var h=i;h.status="rejected",h.reason=u}})}switch(i.status){case"fulfilled":return i.value;case"rejected":throw t=i.reason,Dv(t),t}throw uo=i,sl}}function lo(t){try{var i=t._init;return i(t._payload)}catch(s){throw s!==null&&typeof s=="object"&&typeof s.then=="function"?(uo=s,sl):s}}var uo=null;function wv(){if(uo===null)throw Error(a(459));var t=uo;return uo=null,t}function Dv(t){if(t===sl||t===gf)throw Error(a(483))}var ol=null,Cu=0;function xf(t){var i=Cu;return Cu+=1,ol===null&&(ol=[]),Cv(ol,t,i)}function wu(t,i){i=i.props.ref,t.ref=i!==void 0?i:null}function yf(t,i){throw i.$$typeof===g?Error(a(525)):(t=Object.prototype.toString.call(i),Error(a(31,t==="[object Object]"?"object with keys {"+Object.keys(i).join(", ")+"}":t)))}function Nv(t){function i(ee,K){if(t){var re=ee.deletions;re===null?(ee.deletions=[K],ee.flags|=16):re.push(K)}}function s(ee,K){if(!t)return null;for(;K!==null;)i(ee,K),K=K.sibling;return null}function u(ee){for(var K=new Map;ee!==null;)ee.key!==null?K.set(ee.key,ee):K.set(ee.index,ee),ee=ee.sibling;return K}function h(ee,K){return ee=Ar(ee,K),ee.index=0,ee.sibling=null,ee}function m(ee,K,re){return ee.index=re,t?(re=ee.alternate,re!==null?(re=re.index,re<K?(ee.flags|=67108866,K):re):(ee.flags|=67108866,K)):(ee.flags|=1048576,K)}function E(ee){return t&&ee.alternate===null&&(ee.flags|=67108866),ee}function U(ee,K,re,Se){return K===null||K.tag!==6?(K=ep(re,ee.mode,Se),K.return=ee,K):(K=h(K,re),K.return=ee,K)}function X(ee,K,re,Se){var ut=re.type;return ut===b?ye(ee,K,re.props.children,Se,re.key):K!==null&&(K.elementType===ut||typeof ut=="object"&&ut!==null&&ut.$$typeof===T&&lo(ut)===K.type)?(K=h(K,re.props),wu(K,re),K.return=ee,K):(K=hf(re.type,re.key,re.props,null,ee.mode,Se),wu(K,re),K.return=ee,K)}function oe(ee,K,re,Se){return K===null||K.tag!==4||K.stateNode.containerInfo!==re.containerInfo||K.stateNode.implementation!==re.implementation?(K=tp(re,ee.mode,Se),K.return=ee,K):(K=h(K,re.children||[]),K.return=ee,K)}function ye(ee,K,re,Se,ut){return K===null||K.tag!==7?(K=io(re,ee.mode,Se,ut),K.return=ee,K):(K=h(K,re),K.return=ee,K)}function Me(ee,K,re){if(typeof K=="string"&&K!==""||typeof K=="number"||typeof K=="bigint")return K=ep(""+K,ee.mode,re),K.return=ee,K;if(typeof K=="object"&&K!==null){switch(K.$$typeof){case x:return re=hf(K.type,K.key,K.props,null,ee.mode,re),wu(re,K),re.return=ee,re;case M:return K=tp(K,ee.mode,re),K.return=ee,K;case T:return K=lo(K),Me(ee,K,re)}if(J(K)||k(K))return K=io(K,ee.mode,re,null),K.return=ee,K;if(typeof K.then=="function")return Me(ee,xf(K),re);if(K.$$typeof===N)return Me(ee,mf(ee,K),re);yf(ee,K)}return null}function ce(ee,K,re,Se){var ut=K!==null?K.key:null;if(typeof re=="string"&&re!==""||typeof re=="number"||typeof re=="bigint")return ut!==null?null:U(ee,K,""+re,Se);if(typeof re=="object"&&re!==null){switch(re.$$typeof){case x:return re.key===ut?X(ee,K,re,Se):null;case M:return re.key===ut?oe(ee,K,re,Se):null;case T:return re=lo(re),ce(ee,K,re,Se)}if(J(re)||k(re))return ut!==null?null:ye(ee,K,re,Se,null);if(typeof re.then=="function")return ce(ee,K,xf(re),Se);if(re.$$typeof===N)return ce(ee,K,mf(ee,re),Se);yf(ee,re)}return null}function pe(ee,K,re,Se,ut){if(typeof Se=="string"&&Se!==""||typeof Se=="number"||typeof Se=="bigint")return ee=ee.get(re)||null,U(K,ee,""+Se,ut);if(typeof Se=="object"&&Se!==null){switch(Se.$$typeof){case x:return ee=ee.get(Se.key===null?re:Se.key)||null,X(K,ee,Se,ut);case M:return ee=ee.get(Se.key===null?re:Se.key)||null,oe(K,ee,Se,ut);case T:return Se=lo(Se),pe(ee,K,re,Se,ut)}if(J(Se)||k(Se))return ee=ee.get(re)||null,ye(K,ee,Se,ut,null);if(typeof Se.then=="function")return pe(ee,K,re,xf(Se),ut);if(Se.$$typeof===N)return pe(ee,K,re,mf(K,Se),ut);yf(K,Se)}return null}function $e(ee,K,re,Se){for(var ut=null,Zt=null,at=K,Ct=K=0,Ht=null;at!==null&&Ct<re.length;Ct++){at.index>Ct?(Ht=at,at=null):Ht=at.sibling;var Kt=ce(ee,at,re[Ct],Se);if(Kt===null){at===null&&(at=Ht);break}t&&at&&Kt.alternate===null&&i(ee,at),K=m(Kt,K,Ct),Zt===null?ut=Kt:Zt.sibling=Kt,Zt=Kt,at=Ht}if(Ct===re.length)return s(ee,at),Vt&&Rr(ee,Ct),ut;if(at===null){for(;Ct<re.length;Ct++)at=Me(ee,re[Ct],Se),at!==null&&(K=m(at,K,Ct),Zt===null?ut=at:Zt.sibling=at,Zt=at);return Vt&&Rr(ee,Ct),ut}for(at=u(at);Ct<re.length;Ct++)Ht=pe(at,ee,Ct,re[Ct],Se),Ht!==null&&(t&&Ht.alternate!==null&&at.delete(Ht.key===null?Ct:Ht.key),K=m(Ht,K,Ct),Zt===null?ut=Ht:Zt.sibling=Ht,Zt=Ht);return t&&at.forEach(function(ws){return i(ee,ws)}),Vt&&Rr(ee,Ct),ut}function ft(ee,K,re,Se){if(re==null)throw Error(a(151));for(var ut=null,Zt=null,at=K,Ct=K=0,Ht=null,Kt=re.next();at!==null&&!Kt.done;Ct++,Kt=re.next()){at.index>Ct?(Ht=at,at=null):Ht=at.sibling;var ws=ce(ee,at,Kt.value,Se);if(ws===null){at===null&&(at=Ht);break}t&&at&&ws.alternate===null&&i(ee,at),K=m(ws,K,Ct),Zt===null?ut=ws:Zt.sibling=ws,Zt=ws,at=Ht}if(Kt.done)return s(ee,at),Vt&&Rr(ee,Ct),ut;if(at===null){for(;!Kt.done;Ct++,Kt=re.next())Kt=Me(ee,Kt.value,Se),Kt!==null&&(K=m(Kt,K,Ct),Zt===null?ut=Kt:Zt.sibling=Kt,Zt=Kt);return Vt&&Rr(ee,Ct),ut}for(at=u(at);!Kt.done;Ct++,Kt=re.next())Kt=pe(at,ee,Ct,Kt.value,Se),Kt!==null&&(t&&Kt.alternate!==null&&at.delete(Kt.key===null?Ct:Kt.key),K=m(Kt,K,Ct),Zt===null?ut=Kt:Zt.sibling=Kt,Zt=Kt);return t&&at.forEach(function(yA){return i(ee,yA)}),Vt&&Rr(ee,Ct),ut}function cn(ee,K,re,Se){if(typeof re=="object"&&re!==null&&re.type===b&&re.key===null&&(re=re.props.children),typeof re=="object"&&re!==null){switch(re.$$typeof){case x:e:{for(var ut=re.key;K!==null;){if(K.key===ut){if(ut=re.type,ut===b){if(K.tag===7){s(ee,K.sibling),Se=h(K,re.props.children),Se.return=ee,ee=Se;break e}}else if(K.elementType===ut||typeof ut=="object"&&ut!==null&&ut.$$typeof===T&&lo(ut)===K.type){s(ee,K.sibling),Se=h(K,re.props),wu(Se,re),Se.return=ee,ee=Se;break e}s(ee,K);break}else i(ee,K);K=K.sibling}re.type===b?(Se=io(re.props.children,ee.mode,Se,re.key),Se.return=ee,ee=Se):(Se=hf(re.type,re.key,re.props,null,ee.mode,Se),wu(Se,re),Se.return=ee,ee=Se)}return E(ee);case M:e:{for(ut=re.key;K!==null;){if(K.key===ut)if(K.tag===4&&K.stateNode.containerInfo===re.containerInfo&&K.stateNode.implementation===re.implementation){s(ee,K.sibling),Se=h(K,re.children||[]),Se.return=ee,ee=Se;break e}else{s(ee,K);break}else i(ee,K);K=K.sibling}Se=tp(re,ee.mode,Se),Se.return=ee,ee=Se}return E(ee);case T:return re=lo(re),cn(ee,K,re,Se)}if(J(re))return $e(ee,K,re,Se);if(k(re)){if(ut=k(re),typeof ut!="function")throw Error(a(150));return re=ut.call(re),ft(ee,K,re,Se)}if(typeof re.then=="function")return cn(ee,K,xf(re),Se);if(re.$$typeof===N)return cn(ee,K,mf(ee,re),Se);yf(ee,re)}return typeof re=="string"&&re!==""||typeof re=="number"||typeof re=="bigint"?(re=""+re,K!==null&&K.tag===6?(s(ee,K.sibling),Se=h(K,re),Se.return=ee,ee=Se):(s(ee,K),Se=ep(re,ee.mode,Se),Se.return=ee,ee=Se),E(ee)):s(ee,K)}return function(ee,K,re,Se){try{Cu=0;var ut=cn(ee,K,re,Se);return ol=null,ut}catch(at){if(at===sl||at===gf)throw at;var Zt=na(29,at,null,ee.mode);return Zt.lanes=Se,Zt.return=ee,Zt}finally{}}}var co=Nv(!0),Uv=Nv(!1),hs=!1;function dp(t){t.updateQueue={baseState:t.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function pp(t,i){t=t.updateQueue,i.updateQueue===t&&(i.updateQueue={baseState:t.baseState,firstBaseUpdate:t.firstBaseUpdate,lastBaseUpdate:t.lastBaseUpdate,shared:t.shared,callbacks:null})}function ds(t){return{lane:t,tag:0,payload:null,callback:null,next:null}}function ps(t,i,s){var u=t.updateQueue;if(u===null)return null;if(u=u.shared,(Jt&2)!==0){var h=u.pending;return h===null?i.next=i:(i.next=h.next,h.next=i),u.pending=i,i=ff(t),mv(t,null,s),i}return cf(t,u,i,s),ff(t)}function Du(t,i,s){if(i=i.updateQueue,i!==null&&(i=i.shared,(s&4194048)!==0)){var u=i.lanes;u&=t.pendingLanes,s|=u,i.lanes=s,ht(t,s)}}function mp(t,i){var s=t.updateQueue,u=t.alternate;if(u!==null&&(u=u.updateQueue,s===u)){var h=null,m=null;if(s=s.firstBaseUpdate,s!==null){do{var E={lane:s.lane,tag:s.tag,payload:s.payload,callback:null,next:null};m===null?h=m=E:m=m.next=E,s=s.next}while(s!==null);m===null?h=m=i:m=m.next=i}else h=m=i;s={baseState:u.baseState,firstBaseUpdate:h,lastBaseUpdate:m,shared:u.shared,callbacks:u.callbacks},t.updateQueue=s;return}t=s.lastBaseUpdate,t===null?s.firstBaseUpdate=i:t.next=i,s.lastBaseUpdate=i}var _p=!1;function Nu(){if(_p){var t=rl;if(t!==null)throw t}}function Uu(t,i,s,u){_p=!1;var h=t.updateQueue;hs=!1;var m=h.firstBaseUpdate,E=h.lastBaseUpdate,U=h.shared.pending;if(U!==null){h.shared.pending=null;var X=U,oe=X.next;X.next=null,E===null?m=oe:E.next=oe,E=X;var ye=t.alternate;ye!==null&&(ye=ye.updateQueue,U=ye.lastBaseUpdate,U!==E&&(U===null?ye.firstBaseUpdate=oe:U.next=oe,ye.lastBaseUpdate=X))}if(m!==null){var Me=h.baseState;E=0,ye=oe=X=null,U=m;do{var ce=U.lane&-536870913,pe=ce!==U.lane;if(pe?(Bt&ce)===ce:(u&ce)===ce){ce!==0&&ce===al&&(_p=!0),ye!==null&&(ye=ye.next={lane:0,tag:U.tag,payload:U.payload,callback:null,next:null});e:{var $e=t,ft=U;ce=i;var cn=s;switch(ft.tag){case 1:if($e=ft.payload,typeof $e=="function"){Me=$e.call(cn,Me,ce);break e}Me=$e;break e;case 3:$e.flags=$e.flags&-65537|128;case 0:if($e=ft.payload,ce=typeof $e=="function"?$e.call(cn,Me,ce):$e,ce==null)break e;Me=v({},Me,ce);break e;case 2:hs=!0}}ce=U.callback,ce!==null&&(t.flags|=64,pe&&(t.flags|=8192),pe=h.callbacks,pe===null?h.callbacks=[ce]:pe.push(ce))}else pe={lane:ce,tag:U.tag,payload:U.payload,callback:U.callback,next:null},ye===null?(oe=ye=pe,X=Me):ye=ye.next=pe,E|=ce;if(U=U.next,U===null){if(U=h.shared.pending,U===null)break;pe=U,U=pe.next,pe.next=null,h.lastBaseUpdate=pe,h.shared.pending=null}}while(!0);ye===null&&(X=Me),h.baseState=X,h.firstBaseUpdate=oe,h.lastBaseUpdate=ye,m===null&&(h.shared.lanes=0),xs|=E,t.lanes=E,t.memoizedState=Me}}function Lv(t,i){if(typeof t!="function")throw Error(a(191,t));t.call(i)}function Ov(t,i){var s=t.callbacks;if(s!==null)for(t.callbacks=null,t=0;t<s.length;t++)Lv(s[t],i)}var ll=F(null),Sf=F(0);function Pv(t,i){t=Ir,xe(Sf,t),xe(ll,i),Ir=t|i.baseLanes}function gp(){xe(Sf,Ir),xe(ll,ll.current)}function vp(){Ir=Sf.current,Q(ll),Q(Sf)}var ia=F(null),Ra=null;function ms(t){var i=t.alternate;xe(Un,Un.current&1),xe(ia,t),Ra===null&&(i===null||ll.current!==null||i.memoizedState!==null)&&(Ra=t)}function xp(t){xe(Un,Un.current),xe(ia,t),Ra===null&&(Ra=t)}function zv(t){t.tag===22?(xe(Un,Un.current),xe(ia,t),Ra===null&&(Ra=t)):_s()}function _s(){xe(Un,Un.current),xe(ia,ia.current)}function aa(t){Q(ia),Ra===t&&(Ra=null),Q(Un)}var Un=F(0);function Mf(t){for(var i=t;i!==null;){if(i.tag===13){var s=i.memoizedState;if(s!==null&&(s=s.dehydrated,s===null||Tm(s)||Am(s)))return i}else if(i.tag===19&&(i.memoizedProps.revealOrder==="forwards"||i.memoizedProps.revealOrder==="backwards"||i.memoizedProps.revealOrder==="unstable_legacy-backwards"||i.memoizedProps.revealOrder==="together")){if((i.flags&128)!==0)return i}else if(i.child!==null){i.child.return=i,i=i.child;continue}if(i===t)break;for(;i.sibling===null;){if(i.return===null||i.return===t)return null;i=i.return}i.sibling.return=i.return,i=i.sibling}return null}var Dr=0,At=null,ln=null,Vn=null,bf=!1,ul=!1,fo=!1,Ef=0,Lu=0,cl=null,cT=0;function wn(){throw Error(a(321))}function yp(t,i){if(i===null)return!1;for(var s=0;s<i.length&&s<t.length;s++)if(!ta(t[s],i[s]))return!1;return!0}function Sp(t,i,s,u,h,m){return Dr=m,At=i,i.memoizedState=null,i.updateQueue=null,i.lanes=0,z.H=t===null||t.memoizedState===null?xx:zp,fo=!1,m=s(u,h),fo=!1,ul&&(m=Iv(i,s,u,h)),Fv(t),m}function Fv(t){z.H=zu;var i=ln!==null&&ln.next!==null;if(Dr=0,Vn=ln=At=null,bf=!1,Lu=0,cl=null,i)throw Error(a(300));t===null||kn||(t=t.dependencies,t!==null&&pf(t)&&(kn=!0))}function Iv(t,i,s,u){At=t;var h=0;do{if(ul&&(cl=null),Lu=0,ul=!1,25<=h)throw Error(a(301));if(h+=1,Vn=ln=null,t.updateQueue!=null){var m=t.updateQueue;m.lastEffect=null,m.events=null,m.stores=null,m.memoCache!=null&&(m.memoCache.index=0)}z.H=yx,m=i(s,u)}while(ul);return m}function fT(){var t=z.H,i=t.useState()[0];return i=typeof i.then=="function"?Ou(i):i,t=t.useState()[0],(ln!==null?ln.memoizedState:null)!==t&&(At.flags|=1024),i}function Mp(){var t=Ef!==0;return Ef=0,t}function bp(t,i,s){i.updateQueue=t.updateQueue,i.flags&=-2053,t.lanes&=~s}function Ep(t){if(bf){for(t=t.memoizedState;t!==null;){var i=t.queue;i!==null&&(i.pending=null),t=t.next}bf=!1}Dr=0,Vn=ln=At=null,ul=!1,Lu=Ef=0,cl=null}function Ci(){var t={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Vn===null?At.memoizedState=Vn=t:Vn=Vn.next=t,Vn}function Ln(){if(ln===null){var t=At.alternate;t=t!==null?t.memoizedState:null}else t=ln.next;var i=Vn===null?At.memoizedState:Vn.next;if(i!==null)Vn=i,ln=t;else{if(t===null)throw At.alternate===null?Error(a(467)):Error(a(310));ln=t,t={memoizedState:ln.memoizedState,baseState:ln.baseState,baseQueue:ln.baseQueue,queue:ln.queue,next:null},Vn===null?At.memoizedState=Vn=t:Vn=Vn.next=t}return Vn}function Tf(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Ou(t){var i=Lu;return Lu+=1,cl===null&&(cl=[]),t=Cv(cl,t,i),i=At,(Vn===null?i.memoizedState:Vn.next)===null&&(i=i.alternate,z.H=i===null||i.memoizedState===null?xx:zp),t}function Af(t){if(t!==null&&typeof t=="object"){if(typeof t.then=="function")return Ou(t);if(t.$$typeof===N)return li(t)}throw Error(a(438,String(t)))}function Tp(t){var i=null,s=At.updateQueue;if(s!==null&&(i=s.memoCache),i==null){var u=At.alternate;u!==null&&(u=u.updateQueue,u!==null&&(u=u.memoCache,u!=null&&(i={data:u.data.map(function(h){return h.slice()}),index:0})))}if(i==null&&(i={data:[],index:0}),s===null&&(s=Tf(),At.updateQueue=s),s.memoCache=i,s=i.data[i.index],s===void 0)for(s=i.data[i.index]=Array(t),u=0;u<t;u++)s[u]=q;return i.index++,s}function Nr(t,i){return typeof i=="function"?i(t):i}function Rf(t){var i=Ln();return Ap(i,ln,t)}function Ap(t,i,s){var u=t.queue;if(u===null)throw Error(a(311));u.lastRenderedReducer=s;var h=t.baseQueue,m=u.pending;if(m!==null){if(h!==null){var E=h.next;h.next=m.next,m.next=E}i.baseQueue=h=m,u.pending=null}if(m=t.baseState,h===null)t.memoizedState=m;else{i=h.next;var U=E=null,X=null,oe=i,ye=!1;do{var Me=oe.lane&-536870913;if(Me!==oe.lane?(Bt&Me)===Me:(Dr&Me)===Me){var ce=oe.revertLane;if(ce===0)X!==null&&(X=X.next={lane:0,revertLane:0,gesture:null,action:oe.action,hasEagerState:oe.hasEagerState,eagerState:oe.eagerState,next:null}),Me===al&&(ye=!0);else if((Dr&ce)===ce){oe=oe.next,ce===al&&(ye=!0);continue}else Me={lane:0,revertLane:oe.revertLane,gesture:null,action:oe.action,hasEagerState:oe.hasEagerState,eagerState:oe.eagerState,next:null},X===null?(U=X=Me,E=m):X=X.next=Me,At.lanes|=ce,xs|=ce;Me=oe.action,fo&&s(m,Me),m=oe.hasEagerState?oe.eagerState:s(m,Me)}else ce={lane:Me,revertLane:oe.revertLane,gesture:oe.gesture,action:oe.action,hasEagerState:oe.hasEagerState,eagerState:oe.eagerState,next:null},X===null?(U=X=ce,E=m):X=X.next=ce,At.lanes|=Me,xs|=Me;oe=oe.next}while(oe!==null&&oe!==i);if(X===null?E=m:X.next=U,!ta(m,t.memoizedState)&&(kn=!0,ye&&(s=rl,s!==null)))throw s;t.memoizedState=m,t.baseState=E,t.baseQueue=X,u.lastRenderedState=m}return h===null&&(u.lanes=0),[t.memoizedState,u.dispatch]}function Rp(t){var i=Ln(),s=i.queue;if(s===null)throw Error(a(311));s.lastRenderedReducer=t;var u=s.dispatch,h=s.pending,m=i.memoizedState;if(h!==null){s.pending=null;var E=h=h.next;do m=t(m,E.action),E=E.next;while(E!==h);ta(m,i.memoizedState)||(kn=!0),i.memoizedState=m,i.baseQueue===null&&(i.baseState=m),s.lastRenderedState=m}return[m,u]}function Bv(t,i,s){var u=At,h=Ln(),m=Vt;if(m){if(s===void 0)throw Error(a(407));s=s()}else s=i();var E=!ta((ln||h).memoizedState,s);if(E&&(h.memoizedState=s,kn=!0),h=h.queue,Dp(Vv.bind(null,u,h,t),[t]),h.getSnapshot!==i||E||Vn!==null&&Vn.memoizedState.tag&1){if(u.flags|=2048,fl(9,{destroy:void 0},Gv.bind(null,u,h,s,i),null),hn===null)throw Error(a(349));m||(Dr&127)!==0||Hv(u,i,s)}return s}function Hv(t,i,s){t.flags|=16384,t={getSnapshot:i,value:s},i=At.updateQueue,i===null?(i=Tf(),At.updateQueue=i,i.stores=[t]):(s=i.stores,s===null?i.stores=[t]:s.push(t))}function Gv(t,i,s,u){i.value=s,i.getSnapshot=u,kv(i)&&Xv(t)}function Vv(t,i,s){return s(function(){kv(i)&&Xv(t)})}function kv(t){var i=t.getSnapshot;t=t.value;try{var s=i();return!ta(t,s)}catch{return!0}}function Xv(t){var i=no(t,2);i!==null&&ki(i,t,2)}function Cp(t){var i=Ci();if(typeof t=="function"){var s=t;if(t=s(),fo){He(!0);try{s()}finally{He(!1)}}}return i.memoizedState=i.baseState=t,i.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Nr,lastRenderedState:t},i}function Wv(t,i,s,u){return t.baseState=s,Ap(t,ln,typeof u=="function"?u:Nr)}function hT(t,i,s,u,h){if(Df(t))throw Error(a(485));if(t=i.action,t!==null){var m={payload:h,action:t,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(E){m.listeners.push(E)}};z.T!==null?s(!0):m.isTransition=!1,u(m),s=i.pending,s===null?(m.next=i.pending=m,Yv(i,m)):(m.next=s.next,i.pending=s.next=m)}}function Yv(t,i){var s=i.action,u=i.payload,h=t.state;if(i.isTransition){var m=z.T,E={};z.T=E;try{var U=s(h,u),X=z.S;X!==null&&X(E,U),qv(t,i,U)}catch(oe){wp(t,i,oe)}finally{m!==null&&E.types!==null&&(m.types=E.types),z.T=m}}else try{m=s(h,u),qv(t,i,m)}catch(oe){wp(t,i,oe)}}function qv(t,i,s){s!==null&&typeof s=="object"&&typeof s.then=="function"?s.then(function(u){jv(t,i,u)},function(u){return wp(t,i,u)}):jv(t,i,s)}function jv(t,i,s){i.status="fulfilled",i.value=s,Zv(i),t.state=s,i=t.pending,i!==null&&(s=i.next,s===i?t.pending=null:(s=s.next,i.next=s,Yv(t,s)))}function wp(t,i,s){var u=t.pending;if(t.pending=null,u!==null){u=u.next;do i.status="rejected",i.reason=s,Zv(i),i=i.next;while(i!==u)}t.action=null}function Zv(t){t=t.listeners;for(var i=0;i<t.length;i++)(0,t[i])()}function Kv(t,i){return i}function Qv(t,i){if(Vt){var s=hn.formState;if(s!==null){e:{var u=At;if(Vt){if(xn){t:{for(var h=xn,m=Aa;h.nodeType!==8;){if(!m){h=null;break t}if(h=Ca(h.nextSibling),h===null){h=null;break t}}m=h.data,h=m==="F!"||m==="F"?h:null}if(h){xn=Ca(h.nextSibling),u=h.data==="F!";break e}}cs(u)}u=!1}u&&(i=s[0])}}return s=Ci(),s.memoizedState=s.baseState=i,u={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Kv,lastRenderedState:i},s.queue=u,s=_x.bind(null,At,u),u.dispatch=s,u=Cp(!1),m=Pp.bind(null,At,!1,u.queue),u=Ci(),h={state:i,dispatch:null,action:t,pending:null},u.queue=h,s=hT.bind(null,At,h,m,s),h.dispatch=s,u.memoizedState=t,[i,s,!1]}function Jv(t){var i=Ln();return $v(i,ln,t)}function $v(t,i,s){if(i=Ap(t,i,Kv)[0],t=Rf(Nr)[0],typeof i=="object"&&i!==null&&typeof i.then=="function")try{var u=Ou(i)}catch(E){throw E===sl?gf:E}else u=i;i=Ln();var h=i.queue,m=h.dispatch;return s!==i.memoizedState&&(At.flags|=2048,fl(9,{destroy:void 0},dT.bind(null,h,s),null)),[u,m,t]}function dT(t,i){t.action=i}function ex(t){var i=Ln(),s=ln;if(s!==null)return $v(i,s,t);Ln(),i=i.memoizedState,s=Ln();var u=s.queue.dispatch;return s.memoizedState=t,[i,u,!1]}function fl(t,i,s,u){return t={tag:t,create:s,deps:u,inst:i,next:null},i=At.updateQueue,i===null&&(i=Tf(),At.updateQueue=i),s=i.lastEffect,s===null?i.lastEffect=t.next=t:(u=s.next,s.next=t,t.next=u,i.lastEffect=t),t}function tx(){return Ln().memoizedState}function Cf(t,i,s,u){var h=Ci();At.flags|=t,h.memoizedState=fl(1|i,{destroy:void 0},s,u===void 0?null:u)}function wf(t,i,s,u){var h=Ln();u=u===void 0?null:u;var m=h.memoizedState.inst;ln!==null&&u!==null&&yp(u,ln.memoizedState.deps)?h.memoizedState=fl(i,m,s,u):(At.flags|=t,h.memoizedState=fl(1|i,m,s,u))}function nx(t,i){Cf(8390656,8,t,i)}function Dp(t,i){wf(2048,8,t,i)}function pT(t){At.flags|=4;var i=At.updateQueue;if(i===null)i=Tf(),At.updateQueue=i,i.events=[t];else{var s=i.events;s===null?i.events=[t]:s.push(t)}}function ix(t){var i=Ln().memoizedState;return pT({ref:i,nextImpl:t}),function(){if((Jt&2)!==0)throw Error(a(440));return i.impl.apply(void 0,arguments)}}function ax(t,i){return wf(4,2,t,i)}function rx(t,i){return wf(4,4,t,i)}function sx(t,i){if(typeof i=="function"){t=t();var s=i(t);return function(){typeof s=="function"?s():i(null)}}if(i!=null)return t=t(),i.current=t,function(){i.current=null}}function ox(t,i,s){s=s!=null?s.concat([t]):null,wf(4,4,sx.bind(null,i,t),s)}function Np(){}function lx(t,i){var s=Ln();i=i===void 0?null:i;var u=s.memoizedState;return i!==null&&yp(i,u[1])?u[0]:(s.memoizedState=[t,i],t)}function ux(t,i){var s=Ln();i=i===void 0?null:i;var u=s.memoizedState;if(i!==null&&yp(i,u[1]))return u[0];if(u=t(),fo){He(!0);try{t()}finally{He(!1)}}return s.memoizedState=[u,i],u}function Up(t,i,s){return s===void 0||(Dr&1073741824)!==0&&(Bt&261930)===0?t.memoizedState=i:(t.memoizedState=s,t=cy(),At.lanes|=t,xs|=t,s)}function cx(t,i,s,u){return ta(s,i)?s:ll.current!==null?(t=Up(t,s,u),ta(t,i)||(kn=!0),t):(Dr&42)===0||(Dr&1073741824)!==0&&(Bt&261930)===0?(kn=!0,t.memoizedState=s):(t=cy(),At.lanes|=t,xs|=t,i)}function fx(t,i,s,u,h){var m=I.p;I.p=m!==0&&8>m?m:8;var E=z.T,U={};z.T=U,Pp(t,!1,i,s);try{var X=h(),oe=z.S;if(oe!==null&&oe(U,X),X!==null&&typeof X=="object"&&typeof X.then=="function"){var ye=uT(X,u);Pu(t,i,ye,oa(t))}else Pu(t,i,u,oa(t))}catch(Me){Pu(t,i,{then:function(){},status:"rejected",reason:Me},oa())}finally{I.p=m,E!==null&&U.types!==null&&(E.types=U.types),z.T=E}}function mT(){}function Lp(t,i,s,u){if(t.tag!==5)throw Error(a(476));var h=hx(t).queue;fx(t,h,i,ie,s===null?mT:function(){return dx(t),s(u)})}function hx(t){var i=t.memoizedState;if(i!==null)return i;i={memoizedState:ie,baseState:ie,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Nr,lastRenderedState:ie},next:null};var s={};return i.next={memoizedState:s,baseState:s,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Nr,lastRenderedState:s},next:null},t.memoizedState=i,t=t.alternate,t!==null&&(t.memoizedState=i),i}function dx(t){var i=hx(t);i.next===null&&(i=t.alternate.memoizedState),Pu(t,i.next.queue,{},oa())}function Op(){return li(Ju)}function px(){return Ln().memoizedState}function mx(){return Ln().memoizedState}function _T(t){for(var i=t.return;i!==null;){switch(i.tag){case 24:case 3:var s=oa();t=ds(s);var u=ps(i,t,s);u!==null&&(ki(u,i,s),Du(u,i,s)),i={cache:up()},t.payload=i;return}i=i.return}}function gT(t,i,s){var u=oa();s={lane:u,revertLane:0,gesture:null,action:s,hasEagerState:!1,eagerState:null,next:null},Df(t)?gx(i,s):(s=Jd(t,i,s,u),s!==null&&(ki(s,t,u),vx(s,i,u)))}function _x(t,i,s){var u=oa();Pu(t,i,s,u)}function Pu(t,i,s,u){var h={lane:u,revertLane:0,gesture:null,action:s,hasEagerState:!1,eagerState:null,next:null};if(Df(t))gx(i,h);else{var m=t.alternate;if(t.lanes===0&&(m===null||m.lanes===0)&&(m=i.lastRenderedReducer,m!==null))try{var E=i.lastRenderedState,U=m(E,s);if(h.hasEagerState=!0,h.eagerState=U,ta(U,E))return cf(t,i,h,0),hn===null&&uf(),!1}catch{}finally{}if(s=Jd(t,i,h,u),s!==null)return ki(s,t,u),vx(s,i,u),!0}return!1}function Pp(t,i,s,u){if(u={lane:2,revertLane:dm(),gesture:null,action:u,hasEagerState:!1,eagerState:null,next:null},Df(t)){if(i)throw Error(a(479))}else i=Jd(t,s,u,2),i!==null&&ki(i,t,2)}function Df(t){var i=t.alternate;return t===At||i!==null&&i===At}function gx(t,i){ul=bf=!0;var s=t.pending;s===null?i.next=i:(i.next=s.next,s.next=i),t.pending=i}function vx(t,i,s){if((s&4194048)!==0){var u=i.lanes;u&=t.pendingLanes,s|=u,i.lanes=s,ht(t,s)}}var zu={readContext:li,use:Af,useCallback:wn,useContext:wn,useEffect:wn,useImperativeHandle:wn,useLayoutEffect:wn,useInsertionEffect:wn,useMemo:wn,useReducer:wn,useRef:wn,useState:wn,useDebugValue:wn,useDeferredValue:wn,useTransition:wn,useSyncExternalStore:wn,useId:wn,useHostTransitionStatus:wn,useFormState:wn,useActionState:wn,useOptimistic:wn,useMemoCache:wn,useCacheRefresh:wn};zu.useEffectEvent=wn;var xx={readContext:li,use:Af,useCallback:function(t,i){return Ci().memoizedState=[t,i===void 0?null:i],t},useContext:li,useEffect:nx,useImperativeHandle:function(t,i,s){s=s!=null?s.concat([t]):null,Cf(4194308,4,sx.bind(null,i,t),s)},useLayoutEffect:function(t,i){return Cf(4194308,4,t,i)},useInsertionEffect:function(t,i){Cf(4,2,t,i)},useMemo:function(t,i){var s=Ci();i=i===void 0?null:i;var u=t();if(fo){He(!0);try{t()}finally{He(!1)}}return s.memoizedState=[u,i],u},useReducer:function(t,i,s){var u=Ci();if(s!==void 0){var h=s(i);if(fo){He(!0);try{s(i)}finally{He(!1)}}}else h=i;return u.memoizedState=u.baseState=h,t={pending:null,lanes:0,dispatch:null,lastRenderedReducer:t,lastRenderedState:h},u.queue=t,t=t.dispatch=gT.bind(null,At,t),[u.memoizedState,t]},useRef:function(t){var i=Ci();return t={current:t},i.memoizedState=t},useState:function(t){t=Cp(t);var i=t.queue,s=_x.bind(null,At,i);return i.dispatch=s,[t.memoizedState,s]},useDebugValue:Np,useDeferredValue:function(t,i){var s=Ci();return Up(s,t,i)},useTransition:function(){var t=Cp(!1);return t=fx.bind(null,At,t.queue,!0,!1),Ci().memoizedState=t,[!1,t]},useSyncExternalStore:function(t,i,s){var u=At,h=Ci();if(Vt){if(s===void 0)throw Error(a(407));s=s()}else{if(s=i(),hn===null)throw Error(a(349));(Bt&127)!==0||Hv(u,i,s)}h.memoizedState=s;var m={value:s,getSnapshot:i};return h.queue=m,nx(Vv.bind(null,u,m,t),[t]),u.flags|=2048,fl(9,{destroy:void 0},Gv.bind(null,u,m,s,i),null),s},useId:function(){var t=Ci(),i=hn.identifierPrefix;if(Vt){var s=nr,u=tr;s=(u&~(1<<32-Pe(u)-1)).toString(32)+s,i="_"+i+"R_"+s,s=Ef++,0<s&&(i+="H"+s.toString(32)),i+="_"}else s=cT++,i="_"+i+"r_"+s.toString(32)+"_";return t.memoizedState=i},useHostTransitionStatus:Op,useFormState:Qv,useActionState:Qv,useOptimistic:function(t){var i=Ci();i.memoizedState=i.baseState=t;var s={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return i.queue=s,i=Pp.bind(null,At,!0,s),s.dispatch=i,[t,i]},useMemoCache:Tp,useCacheRefresh:function(){return Ci().memoizedState=_T.bind(null,At)},useEffectEvent:function(t){var i=Ci(),s={impl:t};return i.memoizedState=s,function(){if((Jt&2)!==0)throw Error(a(440));return s.impl.apply(void 0,arguments)}}},zp={readContext:li,use:Af,useCallback:lx,useContext:li,useEffect:Dp,useImperativeHandle:ox,useInsertionEffect:ax,useLayoutEffect:rx,useMemo:ux,useReducer:Rf,useRef:tx,useState:function(){return Rf(Nr)},useDebugValue:Np,useDeferredValue:function(t,i){var s=Ln();return cx(s,ln.memoizedState,t,i)},useTransition:function(){var t=Rf(Nr)[0],i=Ln().memoizedState;return[typeof t=="boolean"?t:Ou(t),i]},useSyncExternalStore:Bv,useId:px,useHostTransitionStatus:Op,useFormState:Jv,useActionState:Jv,useOptimistic:function(t,i){var s=Ln();return Wv(s,ln,t,i)},useMemoCache:Tp,useCacheRefresh:mx};zp.useEffectEvent=ix;var yx={readContext:li,use:Af,useCallback:lx,useContext:li,useEffect:Dp,useImperativeHandle:ox,useInsertionEffect:ax,useLayoutEffect:rx,useMemo:ux,useReducer:Rp,useRef:tx,useState:function(){return Rp(Nr)},useDebugValue:Np,useDeferredValue:function(t,i){var s=Ln();return ln===null?Up(s,t,i):cx(s,ln.memoizedState,t,i)},useTransition:function(){var t=Rp(Nr)[0],i=Ln().memoizedState;return[typeof t=="boolean"?t:Ou(t),i]},useSyncExternalStore:Bv,useId:px,useHostTransitionStatus:Op,useFormState:ex,useActionState:ex,useOptimistic:function(t,i){var s=Ln();return ln!==null?Wv(s,ln,t,i):(s.baseState=t,[t,s.queue.dispatch])},useMemoCache:Tp,useCacheRefresh:mx};yx.useEffectEvent=ix;function Fp(t,i,s,u){i=t.memoizedState,s=s(u,i),s=s==null?i:v({},i,s),t.memoizedState=s,t.lanes===0&&(t.updateQueue.baseState=s)}var Ip={enqueueSetState:function(t,i,s){t=t._reactInternals;var u=oa(),h=ds(u);h.payload=i,s!=null&&(h.callback=s),i=ps(t,h,u),i!==null&&(ki(i,t,u),Du(i,t,u))},enqueueReplaceState:function(t,i,s){t=t._reactInternals;var u=oa(),h=ds(u);h.tag=1,h.payload=i,s!=null&&(h.callback=s),i=ps(t,h,u),i!==null&&(ki(i,t,u),Du(i,t,u))},enqueueForceUpdate:function(t,i){t=t._reactInternals;var s=oa(),u=ds(s);u.tag=2,i!=null&&(u.callback=i),i=ps(t,u,s),i!==null&&(ki(i,t,s),Du(i,t,s))}};function Sx(t,i,s,u,h,m,E){return t=t.stateNode,typeof t.shouldComponentUpdate=="function"?t.shouldComponentUpdate(u,m,E):i.prototype&&i.prototype.isPureReactComponent?!Mu(s,u)||!Mu(h,m):!0}function Mx(t,i,s,u){t=i.state,typeof i.componentWillReceiveProps=="function"&&i.componentWillReceiveProps(s,u),typeof i.UNSAFE_componentWillReceiveProps=="function"&&i.UNSAFE_componentWillReceiveProps(s,u),i.state!==t&&Ip.enqueueReplaceState(i,i.state,null)}function ho(t,i){var s=i;if("ref"in i){s={};for(var u in i)u!=="ref"&&(s[u]=i[u])}if(t=t.defaultProps){s===i&&(s=v({},s));for(var h in t)s[h]===void 0&&(s[h]=t[h])}return s}function bx(t){lf(t)}function Ex(t){console.error(t)}function Tx(t){lf(t)}function Nf(t,i){try{var s=t.onUncaughtError;s(i.value,{componentStack:i.stack})}catch(u){setTimeout(function(){throw u})}}function Ax(t,i,s){try{var u=t.onCaughtError;u(s.value,{componentStack:s.stack,errorBoundary:i.tag===1?i.stateNode:null})}catch(h){setTimeout(function(){throw h})}}function Bp(t,i,s){return s=ds(s),s.tag=3,s.payload={element:null},s.callback=function(){Nf(t,i)},s}function Rx(t){return t=ds(t),t.tag=3,t}function Cx(t,i,s,u){var h=s.type.getDerivedStateFromError;if(typeof h=="function"){var m=u.value;t.payload=function(){return h(m)},t.callback=function(){Ax(i,s,u)}}var E=s.stateNode;E!==null&&typeof E.componentDidCatch=="function"&&(t.callback=function(){Ax(i,s,u),typeof h!="function"&&(ys===null?ys=new Set([this]):ys.add(this));var U=u.stack;this.componentDidCatch(u.value,{componentStack:U!==null?U:""})})}function vT(t,i,s,u,h){if(s.flags|=32768,u!==null&&typeof u=="object"&&typeof u.then=="function"){if(i=s.alternate,i!==null&&il(i,s,h,!0),s=ia.current,s!==null){switch(s.tag){case 31:case 13:return Ra===null?kf():s.alternate===null&&Dn===0&&(Dn=3),s.flags&=-257,s.flags|=65536,s.lanes=h,u===vf?s.flags|=16384:(i=s.updateQueue,i===null?s.updateQueue=new Set([u]):i.add(u),cm(t,u,h)),!1;case 22:return s.flags|=65536,u===vf?s.flags|=16384:(i=s.updateQueue,i===null?(i={transitions:null,markerInstances:null,retryQueue:new Set([u])},s.updateQueue=i):(s=i.retryQueue,s===null?i.retryQueue=new Set([u]):s.add(u)),cm(t,u,h)),!1}throw Error(a(435,s.tag))}return cm(t,u,h),kf(),!1}if(Vt)return i=ia.current,i!==null?((i.flags&65536)===0&&(i.flags|=256),i.flags|=65536,i.lanes=h,u!==ap&&(t=Error(a(422),{cause:u}),Tu(ba(t,s)))):(u!==ap&&(i=Error(a(423),{cause:u}),Tu(ba(i,s))),t=t.current.alternate,t.flags|=65536,h&=-h,t.lanes|=h,u=ba(u,s),h=Bp(t.stateNode,u,h),mp(t,h),Dn!==4&&(Dn=2)),!1;var m=Error(a(520),{cause:u});if(m=ba(m,s),Xu===null?Xu=[m]:Xu.push(m),Dn!==4&&(Dn=2),i===null)return!0;u=ba(u,s),s=i;do{switch(s.tag){case 3:return s.flags|=65536,t=h&-h,s.lanes|=t,t=Bp(s.stateNode,u,t),mp(s,t),!1;case 1:if(i=s.type,m=s.stateNode,(s.flags&128)===0&&(typeof i.getDerivedStateFromError=="function"||m!==null&&typeof m.componentDidCatch=="function"&&(ys===null||!ys.has(m))))return s.flags|=65536,h&=-h,s.lanes|=h,h=Rx(h),Cx(h,t,s,u),mp(s,h),!1}s=s.return}while(s!==null);return!1}var Hp=Error(a(461)),kn=!1;function ui(t,i,s,u){i.child=t===null?Uv(i,null,s,u):co(i,t.child,s,u)}function wx(t,i,s,u,h){s=s.render;var m=i.ref;if("ref"in u){var E={};for(var U in u)U!=="ref"&&(E[U]=u[U])}else E=u;return so(i),u=Sp(t,i,s,E,m,h),U=Mp(),t!==null&&!kn?(bp(t,i,h),Ur(t,i,h)):(Vt&&U&&np(i),i.flags|=1,ui(t,i,u,h),i.child)}function Dx(t,i,s,u,h){if(t===null){var m=s.type;return typeof m=="function"&&!$d(m)&&m.defaultProps===void 0&&s.compare===null?(i.tag=15,i.type=m,Nx(t,i,m,u,h)):(t=hf(s.type,null,u,i,i.mode,h),t.ref=i.ref,t.return=i,i.child=t)}if(m=t.child,!jp(t,h)){var E=m.memoizedProps;if(s=s.compare,s=s!==null?s:Mu,s(E,u)&&t.ref===i.ref)return Ur(t,i,h)}return i.flags|=1,t=Ar(m,u),t.ref=i.ref,t.return=i,i.child=t}function Nx(t,i,s,u,h){if(t!==null){var m=t.memoizedProps;if(Mu(m,u)&&t.ref===i.ref)if(kn=!1,i.pendingProps=u=m,jp(t,h))(t.flags&131072)!==0&&(kn=!0);else return i.lanes=t.lanes,Ur(t,i,h)}return Gp(t,i,s,u,h)}function Ux(t,i,s,u){var h=u.children,m=t!==null?t.memoizedState:null;if(t===null&&i.stateNode===null&&(i.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),u.mode==="hidden"){if((i.flags&128)!==0){if(m=m!==null?m.baseLanes|s:s,t!==null){for(u=i.child=t.child,h=0;u!==null;)h=h|u.lanes|u.childLanes,u=u.sibling;u=h&~m}else u=0,i.child=null;return Lx(t,i,m,s,u)}if((s&536870912)!==0)i.memoizedState={baseLanes:0,cachePool:null},t!==null&&_f(i,m!==null?m.cachePool:null),m!==null?Pv(i,m):gp(),zv(i);else return u=i.lanes=536870912,Lx(t,i,m!==null?m.baseLanes|s:s,s,u)}else m!==null?(_f(i,m.cachePool),Pv(i,m),_s(),i.memoizedState=null):(t!==null&&_f(i,null),gp(),_s());return ui(t,i,h,s),i.child}function Fu(t,i){return t!==null&&t.tag===22||i.stateNode!==null||(i.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),i.sibling}function Lx(t,i,s,u,h){var m=fp();return m=m===null?null:{parent:Gn._currentValue,pool:m},i.memoizedState={baseLanes:s,cachePool:m},t!==null&&_f(i,null),gp(),zv(i),t!==null&&il(t,i,u,!0),i.childLanes=h,null}function Uf(t,i){return i=Of({mode:i.mode,children:i.children},t.mode),i.ref=t.ref,t.child=i,i.return=t,i}function Ox(t,i,s){return co(i,t.child,null,s),t=Uf(i,i.pendingProps),t.flags|=2,aa(i),i.memoizedState=null,t}function xT(t,i,s){var u=i.pendingProps,h=(i.flags&128)!==0;if(i.flags&=-129,t===null){if(Vt){if(u.mode==="hidden")return t=Uf(i,u),i.lanes=536870912,Fu(null,t);if(xp(i),(t=xn)?(t=Yy(t,Aa),t=t!==null&&t.data==="&"?t:null,t!==null&&(i.memoizedState={dehydrated:t,treeContext:ls!==null?{id:tr,overflow:nr}:null,retryLane:536870912,hydrationErrors:null},s=gv(t),s.return=i,i.child=s,oi=i,xn=null)):t=null,t===null)throw cs(i);return i.lanes=536870912,null}return Uf(i,u)}var m=t.memoizedState;if(m!==null){var E=m.dehydrated;if(xp(i),h)if(i.flags&256)i.flags&=-257,i=Ox(t,i,s);else if(i.memoizedState!==null)i.child=t.child,i.flags|=128,i=null;else throw Error(a(558));else if(kn||il(t,i,s,!1),h=(s&t.childLanes)!==0,kn||h){if(u=hn,u!==null&&(E=ot(u,s),E!==0&&E!==m.retryLane))throw m.retryLane=E,no(t,E),ki(u,t,E),Hp;kf(),i=Ox(t,i,s)}else t=m.treeContext,xn=Ca(E.nextSibling),oi=i,Vt=!0,us=null,Aa=!1,t!==null&&yv(i,t),i=Uf(i,u),i.flags|=4096;return i}return t=Ar(t.child,{mode:u.mode,children:u.children}),t.ref=i.ref,i.child=t,t.return=i,t}function Lf(t,i){var s=i.ref;if(s===null)t!==null&&t.ref!==null&&(i.flags|=4194816);else{if(typeof s!="function"&&typeof s!="object")throw Error(a(284));(t===null||t.ref!==s)&&(i.flags|=4194816)}}function Gp(t,i,s,u,h){return so(i),s=Sp(t,i,s,u,void 0,h),u=Mp(),t!==null&&!kn?(bp(t,i,h),Ur(t,i,h)):(Vt&&u&&np(i),i.flags|=1,ui(t,i,s,h),i.child)}function Px(t,i,s,u,h,m){return so(i),i.updateQueue=null,s=Iv(i,u,s,h),Fv(t),u=Mp(),t!==null&&!kn?(bp(t,i,m),Ur(t,i,m)):(Vt&&u&&np(i),i.flags|=1,ui(t,i,s,m),i.child)}function zx(t,i,s,u,h){if(so(i),i.stateNode===null){var m=$o,E=s.contextType;typeof E=="object"&&E!==null&&(m=li(E)),m=new s(u,m),i.memoizedState=m.state!==null&&m.state!==void 0?m.state:null,m.updater=Ip,i.stateNode=m,m._reactInternals=i,m=i.stateNode,m.props=u,m.state=i.memoizedState,m.refs={},dp(i),E=s.contextType,m.context=typeof E=="object"&&E!==null?li(E):$o,m.state=i.memoizedState,E=s.getDerivedStateFromProps,typeof E=="function"&&(Fp(i,s,E,u),m.state=i.memoizedState),typeof s.getDerivedStateFromProps=="function"||typeof m.getSnapshotBeforeUpdate=="function"||typeof m.UNSAFE_componentWillMount!="function"&&typeof m.componentWillMount!="function"||(E=m.state,typeof m.componentWillMount=="function"&&m.componentWillMount(),typeof m.UNSAFE_componentWillMount=="function"&&m.UNSAFE_componentWillMount(),E!==m.state&&Ip.enqueueReplaceState(m,m.state,null),Uu(i,u,m,h),Nu(),m.state=i.memoizedState),typeof m.componentDidMount=="function"&&(i.flags|=4194308),u=!0}else if(t===null){m=i.stateNode;var U=i.memoizedProps,X=ho(s,U);m.props=X;var oe=m.context,ye=s.contextType;E=$o,typeof ye=="object"&&ye!==null&&(E=li(ye));var Me=s.getDerivedStateFromProps;ye=typeof Me=="function"||typeof m.getSnapshotBeforeUpdate=="function",U=i.pendingProps!==U,ye||typeof m.UNSAFE_componentWillReceiveProps!="function"&&typeof m.componentWillReceiveProps!="function"||(U||oe!==E)&&Mx(i,m,u,E),hs=!1;var ce=i.memoizedState;m.state=ce,Uu(i,u,m,h),Nu(),oe=i.memoizedState,U||ce!==oe||hs?(typeof Me=="function"&&(Fp(i,s,Me,u),oe=i.memoizedState),(X=hs||Sx(i,s,X,u,ce,oe,E))?(ye||typeof m.UNSAFE_componentWillMount!="function"&&typeof m.componentWillMount!="function"||(typeof m.componentWillMount=="function"&&m.componentWillMount(),typeof m.UNSAFE_componentWillMount=="function"&&m.UNSAFE_componentWillMount()),typeof m.componentDidMount=="function"&&(i.flags|=4194308)):(typeof m.componentDidMount=="function"&&(i.flags|=4194308),i.memoizedProps=u,i.memoizedState=oe),m.props=u,m.state=oe,m.context=E,u=X):(typeof m.componentDidMount=="function"&&(i.flags|=4194308),u=!1)}else{m=i.stateNode,pp(t,i),E=i.memoizedProps,ye=ho(s,E),m.props=ye,Me=i.pendingProps,ce=m.context,oe=s.contextType,X=$o,typeof oe=="object"&&oe!==null&&(X=li(oe)),U=s.getDerivedStateFromProps,(oe=typeof U=="function"||typeof m.getSnapshotBeforeUpdate=="function")||typeof m.UNSAFE_componentWillReceiveProps!="function"&&typeof m.componentWillReceiveProps!="function"||(E!==Me||ce!==X)&&Mx(i,m,u,X),hs=!1,ce=i.memoizedState,m.state=ce,Uu(i,u,m,h),Nu();var pe=i.memoizedState;E!==Me||ce!==pe||hs||t!==null&&t.dependencies!==null&&pf(t.dependencies)?(typeof U=="function"&&(Fp(i,s,U,u),pe=i.memoizedState),(ye=hs||Sx(i,s,ye,u,ce,pe,X)||t!==null&&t.dependencies!==null&&pf(t.dependencies))?(oe||typeof m.UNSAFE_componentWillUpdate!="function"&&typeof m.componentWillUpdate!="function"||(typeof m.componentWillUpdate=="function"&&m.componentWillUpdate(u,pe,X),typeof m.UNSAFE_componentWillUpdate=="function"&&m.UNSAFE_componentWillUpdate(u,pe,X)),typeof m.componentDidUpdate=="function"&&(i.flags|=4),typeof m.getSnapshotBeforeUpdate=="function"&&(i.flags|=1024)):(typeof m.componentDidUpdate!="function"||E===t.memoizedProps&&ce===t.memoizedState||(i.flags|=4),typeof m.getSnapshotBeforeUpdate!="function"||E===t.memoizedProps&&ce===t.memoizedState||(i.flags|=1024),i.memoizedProps=u,i.memoizedState=pe),m.props=u,m.state=pe,m.context=X,u=ye):(typeof m.componentDidUpdate!="function"||E===t.memoizedProps&&ce===t.memoizedState||(i.flags|=4),typeof m.getSnapshotBeforeUpdate!="function"||E===t.memoizedProps&&ce===t.memoizedState||(i.flags|=1024),u=!1)}return m=u,Lf(t,i),u=(i.flags&128)!==0,m||u?(m=i.stateNode,s=u&&typeof s.getDerivedStateFromError!="function"?null:m.render(),i.flags|=1,t!==null&&u?(i.child=co(i,t.child,null,h),i.child=co(i,null,s,h)):ui(t,i,s,h),i.memoizedState=m.state,t=i.child):t=Ur(t,i,h),t}function Fx(t,i,s,u){return ao(),i.flags|=256,ui(t,i,s,u),i.child}var Vp={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function kp(t){return{baseLanes:t,cachePool:Av()}}function Xp(t,i,s){return t=t!==null?t.childLanes&~s:0,i&&(t|=sa),t}function Ix(t,i,s){var u=i.pendingProps,h=!1,m=(i.flags&128)!==0,E;if((E=m)||(E=t!==null&&t.memoizedState===null?!1:(Un.current&2)!==0),E&&(h=!0,i.flags&=-129),E=(i.flags&32)!==0,i.flags&=-33,t===null){if(Vt){if(h?ms(i):_s(),(t=xn)?(t=Yy(t,Aa),t=t!==null&&t.data!=="&"?t:null,t!==null&&(i.memoizedState={dehydrated:t,treeContext:ls!==null?{id:tr,overflow:nr}:null,retryLane:536870912,hydrationErrors:null},s=gv(t),s.return=i,i.child=s,oi=i,xn=null)):t=null,t===null)throw cs(i);return Am(t)?i.lanes=32:i.lanes=536870912,null}var U=u.children;return u=u.fallback,h?(_s(),h=i.mode,U=Of({mode:"hidden",children:U},h),u=io(u,h,s,null),U.return=i,u.return=i,U.sibling=u,i.child=U,u=i.child,u.memoizedState=kp(s),u.childLanes=Xp(t,E,s),i.memoizedState=Vp,Fu(null,u)):(ms(i),Wp(i,U))}var X=t.memoizedState;if(X!==null&&(U=X.dehydrated,U!==null)){if(m)i.flags&256?(ms(i),i.flags&=-257,i=Yp(t,i,s)):i.memoizedState!==null?(_s(),i.child=t.child,i.flags|=128,i=null):(_s(),U=u.fallback,h=i.mode,u=Of({mode:"visible",children:u.children},h),U=io(U,h,s,null),U.flags|=2,u.return=i,U.return=i,u.sibling=U,i.child=u,co(i,t.child,null,s),u=i.child,u.memoizedState=kp(s),u.childLanes=Xp(t,E,s),i.memoizedState=Vp,i=Fu(null,u));else if(ms(i),Am(U)){if(E=U.nextSibling&&U.nextSibling.dataset,E)var oe=E.dgst;E=oe,u=Error(a(419)),u.stack="",u.digest=E,Tu({value:u,source:null,stack:null}),i=Yp(t,i,s)}else if(kn||il(t,i,s,!1),E=(s&t.childLanes)!==0,kn||E){if(E=hn,E!==null&&(u=ot(E,s),u!==0&&u!==X.retryLane))throw X.retryLane=u,no(t,u),ki(E,t,u),Hp;Tm(U)||kf(),i=Yp(t,i,s)}else Tm(U)?(i.flags|=192,i.child=t.child,i=null):(t=X.treeContext,xn=Ca(U.nextSibling),oi=i,Vt=!0,us=null,Aa=!1,t!==null&&yv(i,t),i=Wp(i,u.children),i.flags|=4096);return i}return h?(_s(),U=u.fallback,h=i.mode,X=t.child,oe=X.sibling,u=Ar(X,{mode:"hidden",children:u.children}),u.subtreeFlags=X.subtreeFlags&65011712,oe!==null?U=Ar(oe,U):(U=io(U,h,s,null),U.flags|=2),U.return=i,u.return=i,u.sibling=U,i.child=u,Fu(null,u),u=i.child,U=t.child.memoizedState,U===null?U=kp(s):(h=U.cachePool,h!==null?(X=Gn._currentValue,h=h.parent!==X?{parent:X,pool:X}:h):h=Av(),U={baseLanes:U.baseLanes|s,cachePool:h}),u.memoizedState=U,u.childLanes=Xp(t,E,s),i.memoizedState=Vp,Fu(t.child,u)):(ms(i),s=t.child,t=s.sibling,s=Ar(s,{mode:"visible",children:u.children}),s.return=i,s.sibling=null,t!==null&&(E=i.deletions,E===null?(i.deletions=[t],i.flags|=16):E.push(t)),i.child=s,i.memoizedState=null,s)}function Wp(t,i){return i=Of({mode:"visible",children:i},t.mode),i.return=t,t.child=i}function Of(t,i){return t=na(22,t,null,i),t.lanes=0,t}function Yp(t,i,s){return co(i,t.child,null,s),t=Wp(i,i.pendingProps.children),t.flags|=2,i.memoizedState=null,t}function Bx(t,i,s){t.lanes|=i;var u=t.alternate;u!==null&&(u.lanes|=i),op(t.return,i,s)}function qp(t,i,s,u,h,m){var E=t.memoizedState;E===null?t.memoizedState={isBackwards:i,rendering:null,renderingStartTime:0,last:u,tail:s,tailMode:h,treeForkCount:m}:(E.isBackwards=i,E.rendering=null,E.renderingStartTime=0,E.last=u,E.tail=s,E.tailMode=h,E.treeForkCount=m)}function Hx(t,i,s){var u=i.pendingProps,h=u.revealOrder,m=u.tail;u=u.children;var E=Un.current,U=(E&2)!==0;if(U?(E=E&1|2,i.flags|=128):E&=1,xe(Un,E),ui(t,i,u,s),u=Vt?Eu:0,!U&&t!==null&&(t.flags&128)!==0)e:for(t=i.child;t!==null;){if(t.tag===13)t.memoizedState!==null&&Bx(t,s,i);else if(t.tag===19)Bx(t,s,i);else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===i)break e;for(;t.sibling===null;){if(t.return===null||t.return===i)break e;t=t.return}t.sibling.return=t.return,t=t.sibling}switch(h){case"forwards":for(s=i.child,h=null;s!==null;)t=s.alternate,t!==null&&Mf(t)===null&&(h=s),s=s.sibling;s=h,s===null?(h=i.child,i.child=null):(h=s.sibling,s.sibling=null),qp(i,!1,h,s,m,u);break;case"backwards":case"unstable_legacy-backwards":for(s=null,h=i.child,i.child=null;h!==null;){if(t=h.alternate,t!==null&&Mf(t)===null){i.child=h;break}t=h.sibling,h.sibling=s,s=h,h=t}qp(i,!0,s,null,m,u);break;case"together":qp(i,!1,null,null,void 0,u);break;default:i.memoizedState=null}return i.child}function Ur(t,i,s){if(t!==null&&(i.dependencies=t.dependencies),xs|=i.lanes,(s&i.childLanes)===0)if(t!==null){if(il(t,i,s,!1),(s&i.childLanes)===0)return null}else return null;if(t!==null&&i.child!==t.child)throw Error(a(153));if(i.child!==null){for(t=i.child,s=Ar(t,t.pendingProps),i.child=s,s.return=i;t.sibling!==null;)t=t.sibling,s=s.sibling=Ar(t,t.pendingProps),s.return=i;s.sibling=null}return i.child}function jp(t,i){return(t.lanes&i)!==0?!0:(t=t.dependencies,!!(t!==null&&pf(t)))}function yT(t,i,s){switch(i.tag){case 3:be(i,i.stateNode.containerInfo),fs(i,Gn,t.memoizedState.cache),ao();break;case 27:case 5:tt(i);break;case 4:be(i,i.stateNode.containerInfo);break;case 10:fs(i,i.type,i.memoizedProps.value);break;case 31:if(i.memoizedState!==null)return i.flags|=128,xp(i),null;break;case 13:var u=i.memoizedState;if(u!==null)return u.dehydrated!==null?(ms(i),i.flags|=128,null):(s&i.child.childLanes)!==0?Ix(t,i,s):(ms(i),t=Ur(t,i,s),t!==null?t.sibling:null);ms(i);break;case 19:var h=(t.flags&128)!==0;if(u=(s&i.childLanes)!==0,u||(il(t,i,s,!1),u=(s&i.childLanes)!==0),h){if(u)return Hx(t,i,s);i.flags|=128}if(h=i.memoizedState,h!==null&&(h.rendering=null,h.tail=null,h.lastEffect=null),xe(Un,Un.current),u)break;return null;case 22:return i.lanes=0,Ux(t,i,s,i.pendingProps);case 24:fs(i,Gn,t.memoizedState.cache)}return Ur(t,i,s)}function Gx(t,i,s){if(t!==null)if(t.memoizedProps!==i.pendingProps)kn=!0;else{if(!jp(t,s)&&(i.flags&128)===0)return kn=!1,yT(t,i,s);kn=(t.flags&131072)!==0}else kn=!1,Vt&&(i.flags&1048576)!==0&&xv(i,Eu,i.index);switch(i.lanes=0,i.tag){case 16:e:{var u=i.pendingProps;if(t=lo(i.elementType),i.type=t,typeof t=="function")$d(t)?(u=ho(t,u),i.tag=1,i=zx(null,i,t,u,s)):(i.tag=0,i=Gp(null,i,t,u,s));else{if(t!=null){var h=t.$$typeof;if(h===C){i.tag=11,i=wx(null,i,t,u,s);break e}else if(h===L){i.tag=14,i=Dx(null,i,t,u,s);break e}}throw i=te(t)||t,Error(a(306,i,""))}}return i;case 0:return Gp(t,i,i.type,i.pendingProps,s);case 1:return u=i.type,h=ho(u,i.pendingProps),zx(t,i,u,h,s);case 3:e:{if(be(i,i.stateNode.containerInfo),t===null)throw Error(a(387));u=i.pendingProps;var m=i.memoizedState;h=m.element,pp(t,i),Uu(i,u,null,s);var E=i.memoizedState;if(u=E.cache,fs(i,Gn,u),u!==m.cache&&lp(i,[Gn],s,!0),Nu(),u=E.element,m.isDehydrated)if(m={element:u,isDehydrated:!1,cache:E.cache},i.updateQueue.baseState=m,i.memoizedState=m,i.flags&256){i=Fx(t,i,u,s);break e}else if(u!==h){h=ba(Error(a(424)),i),Tu(h),i=Fx(t,i,u,s);break e}else{switch(t=i.stateNode.containerInfo,t.nodeType){case 9:t=t.body;break;default:t=t.nodeName==="HTML"?t.ownerDocument.body:t}for(xn=Ca(t.firstChild),oi=i,Vt=!0,us=null,Aa=!0,s=Uv(i,null,u,s),i.child=s;s;)s.flags=s.flags&-3|4096,s=s.sibling}else{if(ao(),u===h){i=Ur(t,i,s);break e}ui(t,i,u,s)}i=i.child}return i;case 26:return Lf(t,i),t===null?(s=Jy(i.type,null,i.pendingProps,null))?i.memoizedState=s:Vt||(s=i.type,t=i.pendingProps,u=Kf(ne.current).createElement(s),u[Tt]=i,u[xt]=t,ci(u,s,t),Y(u),i.stateNode=u):i.memoizedState=Jy(i.type,t.memoizedProps,i.pendingProps,t.memoizedState),null;case 27:return tt(i),t===null&&Vt&&(u=i.stateNode=Zy(i.type,i.pendingProps,ne.current),oi=i,Aa=!0,h=xn,Es(i.type)?(Rm=h,xn=Ca(u.firstChild)):xn=h),ui(t,i,i.pendingProps.children,s),Lf(t,i),t===null&&(i.flags|=4194304),i.child;case 5:return t===null&&Vt&&((h=u=xn)&&(u=KT(u,i.type,i.pendingProps,Aa),u!==null?(i.stateNode=u,oi=i,xn=Ca(u.firstChild),Aa=!1,h=!0):h=!1),h||cs(i)),tt(i),h=i.type,m=i.pendingProps,E=t!==null?t.memoizedProps:null,u=m.children,Mm(h,m)?u=null:E!==null&&Mm(h,E)&&(i.flags|=32),i.memoizedState!==null&&(h=Sp(t,i,fT,null,null,s),Ju._currentValue=h),Lf(t,i),ui(t,i,u,s),i.child;case 6:return t===null&&Vt&&((t=s=xn)&&(s=QT(s,i.pendingProps,Aa),s!==null?(i.stateNode=s,oi=i,xn=null,t=!0):t=!1),t||cs(i)),null;case 13:return Ix(t,i,s);case 4:return be(i,i.stateNode.containerInfo),u=i.pendingProps,t===null?i.child=co(i,null,u,s):ui(t,i,u,s),i.child;case 11:return wx(t,i,i.type,i.pendingProps,s);case 7:return ui(t,i,i.pendingProps,s),i.child;case 8:return ui(t,i,i.pendingProps.children,s),i.child;case 12:return ui(t,i,i.pendingProps.children,s),i.child;case 10:return u=i.pendingProps,fs(i,i.type,u.value),ui(t,i,u.children,s),i.child;case 9:return h=i.type._context,u=i.pendingProps.children,so(i),h=li(h),u=u(h),i.flags|=1,ui(t,i,u,s),i.child;case 14:return Dx(t,i,i.type,i.pendingProps,s);case 15:return Nx(t,i,i.type,i.pendingProps,s);case 19:return Hx(t,i,s);case 31:return xT(t,i,s);case 22:return Ux(t,i,s,i.pendingProps);case 24:return so(i),u=li(Gn),t===null?(h=fp(),h===null&&(h=hn,m=up(),h.pooledCache=m,m.refCount++,m!==null&&(h.pooledCacheLanes|=s),h=m),i.memoizedState={parent:u,cache:h},dp(i),fs(i,Gn,h)):((t.lanes&s)!==0&&(pp(t,i),Uu(i,null,null,s),Nu()),h=t.memoizedState,m=i.memoizedState,h.parent!==u?(h={parent:u,cache:u},i.memoizedState=h,i.lanes===0&&(i.memoizedState=i.updateQueue.baseState=h),fs(i,Gn,u)):(u=m.cache,fs(i,Gn,u),u!==h.cache&&lp(i,[Gn],s,!0))),ui(t,i,i.pendingProps.children,s),i.child;case 29:throw i.pendingProps}throw Error(a(156,i.tag))}function Lr(t){t.flags|=4}function Zp(t,i,s,u,h){if((i=(t.mode&32)!==0)&&(i=!1),i){if(t.flags|=16777216,(h&335544128)===h)if(t.stateNode.complete)t.flags|=8192;else if(py())t.flags|=8192;else throw uo=vf,hp}else t.flags&=-16777217}function Vx(t,i){if(i.type!=="stylesheet"||(i.state.loading&4)!==0)t.flags&=-16777217;else if(t.flags|=16777216,!iS(i))if(py())t.flags|=8192;else throw uo=vf,hp}function Pf(t,i){i!==null&&(t.flags|=4),t.flags&16384&&(i=t.tag!==22?Gt():536870912,t.lanes|=i,ml|=i)}function Iu(t,i){if(!Vt)switch(t.tailMode){case"hidden":i=t.tail;for(var s=null;i!==null;)i.alternate!==null&&(s=i),i=i.sibling;s===null?t.tail=null:s.sibling=null;break;case"collapsed":s=t.tail;for(var u=null;s!==null;)s.alternate!==null&&(u=s),s=s.sibling;u===null?i||t.tail===null?t.tail=null:t.tail.sibling=null:u.sibling=null}}function yn(t){var i=t.alternate!==null&&t.alternate.child===t.child,s=0,u=0;if(i)for(var h=t.child;h!==null;)s|=h.lanes|h.childLanes,u|=h.subtreeFlags&65011712,u|=h.flags&65011712,h.return=t,h=h.sibling;else for(h=t.child;h!==null;)s|=h.lanes|h.childLanes,u|=h.subtreeFlags,u|=h.flags,h.return=t,h=h.sibling;return t.subtreeFlags|=u,t.childLanes=s,i}function ST(t,i,s){var u=i.pendingProps;switch(ip(i),i.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return yn(i),null;case 1:return yn(i),null;case 3:return s=i.stateNode,u=null,t!==null&&(u=t.memoizedState.cache),i.memoizedState.cache!==u&&(i.flags|=2048),wr(Gn),ze(),s.pendingContext&&(s.context=s.pendingContext,s.pendingContext=null),(t===null||t.child===null)&&(nl(i)?Lr(i):t===null||t.memoizedState.isDehydrated&&(i.flags&256)===0||(i.flags|=1024,rp())),yn(i),null;case 26:var h=i.type,m=i.memoizedState;return t===null?(Lr(i),m!==null?(yn(i),Vx(i,m)):(yn(i),Zp(i,h,null,u,s))):m?m!==t.memoizedState?(Lr(i),yn(i),Vx(i,m)):(yn(i),i.flags&=-16777217):(t=t.memoizedProps,t!==u&&Lr(i),yn(i),Zp(i,h,t,u,s)),null;case 27:if(Ke(i),s=ne.current,h=i.type,t!==null&&i.stateNode!=null)t.memoizedProps!==u&&Lr(i);else{if(!u){if(i.stateNode===null)throw Error(a(166));return yn(i),null}t=Te.current,nl(i)?Sv(i):(t=Zy(h,u,s),i.stateNode=t,Lr(i))}return yn(i),null;case 5:if(Ke(i),h=i.type,t!==null&&i.stateNode!=null)t.memoizedProps!==u&&Lr(i);else{if(!u){if(i.stateNode===null)throw Error(a(166));return yn(i),null}if(m=Te.current,nl(i))Sv(i);else{var E=Kf(ne.current);switch(m){case 1:m=E.createElementNS("http://www.w3.org/2000/svg",h);break;case 2:m=E.createElementNS("http://www.w3.org/1998/Math/MathML",h);break;default:switch(h){case"svg":m=E.createElementNS("http://www.w3.org/2000/svg",h);break;case"math":m=E.createElementNS("http://www.w3.org/1998/Math/MathML",h);break;case"script":m=E.createElement("div"),m.innerHTML="<script><\/script>",m=m.removeChild(m.firstChild);break;case"select":m=typeof u.is=="string"?E.createElement("select",{is:u.is}):E.createElement("select"),u.multiple?m.multiple=!0:u.size&&(m.size=u.size);break;default:m=typeof u.is=="string"?E.createElement(h,{is:u.is}):E.createElement(h)}}m[Tt]=i,m[xt]=u;e:for(E=i.child;E!==null;){if(E.tag===5||E.tag===6)m.appendChild(E.stateNode);else if(E.tag!==4&&E.tag!==27&&E.child!==null){E.child.return=E,E=E.child;continue}if(E===i)break e;for(;E.sibling===null;){if(E.return===null||E.return===i)break e;E=E.return}E.sibling.return=E.return,E=E.sibling}i.stateNode=m;e:switch(ci(m,h,u),h){case"button":case"input":case"select":case"textarea":u=!!u.autoFocus;break e;case"img":u=!0;break e;default:u=!1}u&&Lr(i)}}return yn(i),Zp(i,i.type,t===null?null:t.memoizedProps,i.pendingProps,s),null;case 6:if(t&&i.stateNode!=null)t.memoizedProps!==u&&Lr(i);else{if(typeof u!="string"&&i.stateNode===null)throw Error(a(166));if(t=ne.current,nl(i)){if(t=i.stateNode,s=i.memoizedProps,u=null,h=oi,h!==null)switch(h.tag){case 27:case 5:u=h.memoizedProps}t[Tt]=i,t=!!(t.nodeValue===s||u!==null&&u.suppressHydrationWarning===!0||Iy(t.nodeValue,s)),t||cs(i,!0)}else t=Kf(t).createTextNode(u),t[Tt]=i,i.stateNode=t}return yn(i),null;case 31:if(s=i.memoizedState,t===null||t.memoizedState!==null){if(u=nl(i),s!==null){if(t===null){if(!u)throw Error(a(318));if(t=i.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(a(557));t[Tt]=i}else ao(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;yn(i),t=!1}else s=rp(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=s),t=!0;if(!t)return i.flags&256?(aa(i),i):(aa(i),null);if((i.flags&128)!==0)throw Error(a(558))}return yn(i),null;case 13:if(u=i.memoizedState,t===null||t.memoizedState!==null&&t.memoizedState.dehydrated!==null){if(h=nl(i),u!==null&&u.dehydrated!==null){if(t===null){if(!h)throw Error(a(318));if(h=i.memoizedState,h=h!==null?h.dehydrated:null,!h)throw Error(a(317));h[Tt]=i}else ao(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;yn(i),h=!1}else h=rp(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=h),h=!0;if(!h)return i.flags&256?(aa(i),i):(aa(i),null)}return aa(i),(i.flags&128)!==0?(i.lanes=s,i):(s=u!==null,t=t!==null&&t.memoizedState!==null,s&&(u=i.child,h=null,u.alternate!==null&&u.alternate.memoizedState!==null&&u.alternate.memoizedState.cachePool!==null&&(h=u.alternate.memoizedState.cachePool.pool),m=null,u.memoizedState!==null&&u.memoizedState.cachePool!==null&&(m=u.memoizedState.cachePool.pool),m!==h&&(u.flags|=2048)),s!==t&&s&&(i.child.flags|=8192),Pf(i,i.updateQueue),yn(i),null);case 4:return ze(),t===null&&gm(i.stateNode.containerInfo),yn(i),null;case 10:return wr(i.type),yn(i),null;case 19:if(Q(Un),u=i.memoizedState,u===null)return yn(i),null;if(h=(i.flags&128)!==0,m=u.rendering,m===null)if(h)Iu(u,!1);else{if(Dn!==0||t!==null&&(t.flags&128)!==0)for(t=i.child;t!==null;){if(m=Mf(t),m!==null){for(i.flags|=128,Iu(u,!1),t=m.updateQueue,i.updateQueue=t,Pf(i,t),i.subtreeFlags=0,t=s,s=i.child;s!==null;)_v(s,t),s=s.sibling;return xe(Un,Un.current&1|2),Vt&&Rr(i,u.treeForkCount),i.child}t=t.sibling}u.tail!==null&&A()>Hf&&(i.flags|=128,h=!0,Iu(u,!1),i.lanes=4194304)}else{if(!h)if(t=Mf(m),t!==null){if(i.flags|=128,h=!0,t=t.updateQueue,i.updateQueue=t,Pf(i,t),Iu(u,!0),u.tail===null&&u.tailMode==="hidden"&&!m.alternate&&!Vt)return yn(i),null}else 2*A()-u.renderingStartTime>Hf&&s!==536870912&&(i.flags|=128,h=!0,Iu(u,!1),i.lanes=4194304);u.isBackwards?(m.sibling=i.child,i.child=m):(t=u.last,t!==null?t.sibling=m:i.child=m,u.last=m)}return u.tail!==null?(t=u.tail,u.rendering=t,u.tail=t.sibling,u.renderingStartTime=A(),t.sibling=null,s=Un.current,xe(Un,h?s&1|2:s&1),Vt&&Rr(i,u.treeForkCount),t):(yn(i),null);case 22:case 23:return aa(i),vp(),u=i.memoizedState!==null,t!==null?t.memoizedState!==null!==u&&(i.flags|=8192):u&&(i.flags|=8192),u?(s&536870912)!==0&&(i.flags&128)===0&&(yn(i),i.subtreeFlags&6&&(i.flags|=8192)):yn(i),s=i.updateQueue,s!==null&&Pf(i,s.retryQueue),s=null,t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(s=t.memoizedState.cachePool.pool),u=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(u=i.memoizedState.cachePool.pool),u!==s&&(i.flags|=2048),t!==null&&Q(oo),null;case 24:return s=null,t!==null&&(s=t.memoizedState.cache),i.memoizedState.cache!==s&&(i.flags|=2048),wr(Gn),yn(i),null;case 25:return null;case 30:return null}throw Error(a(156,i.tag))}function MT(t,i){switch(ip(i),i.tag){case 1:return t=i.flags,t&65536?(i.flags=t&-65537|128,i):null;case 3:return wr(Gn),ze(),t=i.flags,(t&65536)!==0&&(t&128)===0?(i.flags=t&-65537|128,i):null;case 26:case 27:case 5:return Ke(i),null;case 31:if(i.memoizedState!==null){if(aa(i),i.alternate===null)throw Error(a(340));ao()}return t=i.flags,t&65536?(i.flags=t&-65537|128,i):null;case 13:if(aa(i),t=i.memoizedState,t!==null&&t.dehydrated!==null){if(i.alternate===null)throw Error(a(340));ao()}return t=i.flags,t&65536?(i.flags=t&-65537|128,i):null;case 19:return Q(Un),null;case 4:return ze(),null;case 10:return wr(i.type),null;case 22:case 23:return aa(i),vp(),t!==null&&Q(oo),t=i.flags,t&65536?(i.flags=t&-65537|128,i):null;case 24:return wr(Gn),null;case 25:return null;default:return null}}function kx(t,i){switch(ip(i),i.tag){case 3:wr(Gn),ze();break;case 26:case 27:case 5:Ke(i);break;case 4:ze();break;case 31:i.memoizedState!==null&&aa(i);break;case 13:aa(i);break;case 19:Q(Un);break;case 10:wr(i.type);break;case 22:case 23:aa(i),vp(),t!==null&&Q(oo);break;case 24:wr(Gn)}}function Bu(t,i){try{var s=i.updateQueue,u=s!==null?s.lastEffect:null;if(u!==null){var h=u.next;s=h;do{if((s.tag&t)===t){u=void 0;var m=s.create,E=s.inst;u=m(),E.destroy=u}s=s.next}while(s!==h)}}catch(U){nn(i,i.return,U)}}function gs(t,i,s){try{var u=i.updateQueue,h=u!==null?u.lastEffect:null;if(h!==null){var m=h.next;u=m;do{if((u.tag&t)===t){var E=u.inst,U=E.destroy;if(U!==void 0){E.destroy=void 0,h=i;var X=s,oe=U;try{oe()}catch(ye){nn(h,X,ye)}}}u=u.next}while(u!==m)}}catch(ye){nn(i,i.return,ye)}}function Xx(t){var i=t.updateQueue;if(i!==null){var s=t.stateNode;try{Ov(i,s)}catch(u){nn(t,t.return,u)}}}function Wx(t,i,s){s.props=ho(t.type,t.memoizedProps),s.state=t.memoizedState;try{s.componentWillUnmount()}catch(u){nn(t,i,u)}}function Hu(t,i){try{var s=t.ref;if(s!==null){switch(t.tag){case 26:case 27:case 5:var u=t.stateNode;break;case 30:u=t.stateNode;break;default:u=t.stateNode}typeof s=="function"?t.refCleanup=s(u):s.current=u}}catch(h){nn(t,i,h)}}function ir(t,i){var s=t.ref,u=t.refCleanup;if(s!==null)if(typeof u=="function")try{u()}catch(h){nn(t,i,h)}finally{t.refCleanup=null,t=t.alternate,t!=null&&(t.refCleanup=null)}else if(typeof s=="function")try{s(null)}catch(h){nn(t,i,h)}else s.current=null}function Yx(t){var i=t.type,s=t.memoizedProps,u=t.stateNode;try{e:switch(i){case"button":case"input":case"select":case"textarea":s.autoFocus&&u.focus();break e;case"img":s.src?u.src=s.src:s.srcSet&&(u.srcset=s.srcSet)}}catch(h){nn(t,t.return,h)}}function Kp(t,i,s){try{var u=t.stateNode;XT(u,t.type,s,i),u[xt]=i}catch(h){nn(t,t.return,h)}}function qx(t){return t.tag===5||t.tag===3||t.tag===26||t.tag===27&&Es(t.type)||t.tag===4}function Qp(t){e:for(;;){for(;t.sibling===null;){if(t.return===null||qx(t.return))return null;t=t.return}for(t.sibling.return=t.return,t=t.sibling;t.tag!==5&&t.tag!==6&&t.tag!==18;){if(t.tag===27&&Es(t.type)||t.flags&2||t.child===null||t.tag===4)continue e;t.child.return=t,t=t.child}if(!(t.flags&2))return t.stateNode}}function Jp(t,i,s){var u=t.tag;if(u===5||u===6)t=t.stateNode,i?(s.nodeType===9?s.body:s.nodeName==="HTML"?s.ownerDocument.body:s).insertBefore(t,i):(i=s.nodeType===9?s.body:s.nodeName==="HTML"?s.ownerDocument.body:s,i.appendChild(t),s=s._reactRootContainer,s!=null||i.onclick!==null||(i.onclick=Er));else if(u!==4&&(u===27&&Es(t.type)&&(s=t.stateNode,i=null),t=t.child,t!==null))for(Jp(t,i,s),t=t.sibling;t!==null;)Jp(t,i,s),t=t.sibling}function zf(t,i,s){var u=t.tag;if(u===5||u===6)t=t.stateNode,i?s.insertBefore(t,i):s.appendChild(t);else if(u!==4&&(u===27&&Es(t.type)&&(s=t.stateNode),t=t.child,t!==null))for(zf(t,i,s),t=t.sibling;t!==null;)zf(t,i,s),t=t.sibling}function jx(t){var i=t.stateNode,s=t.memoizedProps;try{for(var u=t.type,h=i.attributes;h.length;)i.removeAttributeNode(h[0]);ci(i,u,s),i[Tt]=t,i[xt]=s}catch(m){nn(t,t.return,m)}}var Or=!1,Xn=!1,$p=!1,Zx=typeof WeakSet=="function"?WeakSet:Set,ni=null;function bT(t,i){if(t=t.containerInfo,ym=ih,t=ov(t),Yd(t)){if("selectionStart"in t)var s={start:t.selectionStart,end:t.selectionEnd};else e:{s=(s=t.ownerDocument)&&s.defaultView||window;var u=s.getSelection&&s.getSelection();if(u&&u.rangeCount!==0){s=u.anchorNode;var h=u.anchorOffset,m=u.focusNode;u=u.focusOffset;try{s.nodeType,m.nodeType}catch{s=null;break e}var E=0,U=-1,X=-1,oe=0,ye=0,Me=t,ce=null;t:for(;;){for(var pe;Me!==s||h!==0&&Me.nodeType!==3||(U=E+h),Me!==m||u!==0&&Me.nodeType!==3||(X=E+u),Me.nodeType===3&&(E+=Me.nodeValue.length),(pe=Me.firstChild)!==null;)ce=Me,Me=pe;for(;;){if(Me===t)break t;if(ce===s&&++oe===h&&(U=E),ce===m&&++ye===u&&(X=E),(pe=Me.nextSibling)!==null)break;Me=ce,ce=Me.parentNode}Me=pe}s=U===-1||X===-1?null:{start:U,end:X}}else s=null}s=s||{start:0,end:0}}else s=null;for(Sm={focusedElem:t,selectionRange:s},ih=!1,ni=i;ni!==null;)if(i=ni,t=i.child,(i.subtreeFlags&1028)!==0&&t!==null)t.return=i,ni=t;else for(;ni!==null;){switch(i=ni,m=i.alternate,t=i.flags,i.tag){case 0:if((t&4)!==0&&(t=i.updateQueue,t=t!==null?t.events:null,t!==null))for(s=0;s<t.length;s++)h=t[s],h.ref.impl=h.nextImpl;break;case 11:case 15:break;case 1:if((t&1024)!==0&&m!==null){t=void 0,s=i,h=m.memoizedProps,m=m.memoizedState,u=s.stateNode;try{var $e=ho(s.type,h);t=u.getSnapshotBeforeUpdate($e,m),u.__reactInternalSnapshotBeforeUpdate=t}catch(ft){nn(s,s.return,ft)}}break;case 3:if((t&1024)!==0){if(t=i.stateNode.containerInfo,s=t.nodeType,s===9)Em(t);else if(s===1)switch(t.nodeName){case"HEAD":case"HTML":case"BODY":Em(t);break;default:t.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((t&1024)!==0)throw Error(a(163))}if(t=i.sibling,t!==null){t.return=i.return,ni=t;break}ni=i.return}}function Kx(t,i,s){var u=s.flags;switch(s.tag){case 0:case 11:case 15:zr(t,s),u&4&&Bu(5,s);break;case 1:if(zr(t,s),u&4)if(t=s.stateNode,i===null)try{t.componentDidMount()}catch(E){nn(s,s.return,E)}else{var h=ho(s.type,i.memoizedProps);i=i.memoizedState;try{t.componentDidUpdate(h,i,t.__reactInternalSnapshotBeforeUpdate)}catch(E){nn(s,s.return,E)}}u&64&&Xx(s),u&512&&Hu(s,s.return);break;case 3:if(zr(t,s),u&64&&(t=s.updateQueue,t!==null)){if(i=null,s.child!==null)switch(s.child.tag){case 27:case 5:i=s.child.stateNode;break;case 1:i=s.child.stateNode}try{Ov(t,i)}catch(E){nn(s,s.return,E)}}break;case 27:i===null&&u&4&&jx(s);case 26:case 5:zr(t,s),i===null&&u&4&&Yx(s),u&512&&Hu(s,s.return);break;case 12:zr(t,s);break;case 31:zr(t,s),u&4&&$x(t,s);break;case 13:zr(t,s),u&4&&ey(t,s),u&64&&(t=s.memoizedState,t!==null&&(t=t.dehydrated,t!==null&&(s=UT.bind(null,s),JT(t,s))));break;case 22:if(u=s.memoizedState!==null||Or,!u){i=i!==null&&i.memoizedState!==null||Xn,h=Or;var m=Xn;Or=u,(Xn=i)&&!m?Fr(t,s,(s.subtreeFlags&8772)!==0):zr(t,s),Or=h,Xn=m}break;case 30:break;default:zr(t,s)}}function Qx(t){var i=t.alternate;i!==null&&(t.alternate=null,Qx(i)),t.child=null,t.deletions=null,t.sibling=null,t.tag===5&&(i=t.stateNode,i!==null&&Tn(i)),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null}var bn=null,Bi=!1;function Pr(t,i,s){for(s=s.child;s!==null;)Jx(t,i,s),s=s.sibling}function Jx(t,i,s){if(Ae&&typeof Ae.onCommitFiberUnmount=="function")try{Ae.onCommitFiberUnmount(Re,s)}catch{}switch(s.tag){case 26:Xn||ir(s,i),Pr(t,i,s),s.memoizedState?s.memoizedState.count--:s.stateNode&&(s=s.stateNode,s.parentNode.removeChild(s));break;case 27:Xn||ir(s,i);var u=bn,h=Bi;Es(s.type)&&(bn=s.stateNode,Bi=!1),Pr(t,i,s),Zu(s.stateNode),bn=u,Bi=h;break;case 5:Xn||ir(s,i);case 6:if(u=bn,h=Bi,bn=null,Pr(t,i,s),bn=u,Bi=h,bn!==null)if(Bi)try{(bn.nodeType===9?bn.body:bn.nodeName==="HTML"?bn.ownerDocument.body:bn).removeChild(s.stateNode)}catch(m){nn(s,i,m)}else try{bn.removeChild(s.stateNode)}catch(m){nn(s,i,m)}break;case 18:bn!==null&&(Bi?(t=bn,Xy(t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,s.stateNode),bl(t)):Xy(bn,s.stateNode));break;case 4:u=bn,h=Bi,bn=s.stateNode.containerInfo,Bi=!0,Pr(t,i,s),bn=u,Bi=h;break;case 0:case 11:case 14:case 15:gs(2,s,i),Xn||gs(4,s,i),Pr(t,i,s);break;case 1:Xn||(ir(s,i),u=s.stateNode,typeof u.componentWillUnmount=="function"&&Wx(s,i,u)),Pr(t,i,s);break;case 21:Pr(t,i,s);break;case 22:Xn=(u=Xn)||s.memoizedState!==null,Pr(t,i,s),Xn=u;break;default:Pr(t,i,s)}}function $x(t,i){if(i.memoizedState===null&&(t=i.alternate,t!==null&&(t=t.memoizedState,t!==null))){t=t.dehydrated;try{bl(t)}catch(s){nn(i,i.return,s)}}}function ey(t,i){if(i.memoizedState===null&&(t=i.alternate,t!==null&&(t=t.memoizedState,t!==null&&(t=t.dehydrated,t!==null))))try{bl(t)}catch(s){nn(i,i.return,s)}}function ET(t){switch(t.tag){case 31:case 13:case 19:var i=t.stateNode;return i===null&&(i=t.stateNode=new Zx),i;case 22:return t=t.stateNode,i=t._retryCache,i===null&&(i=t._retryCache=new Zx),i;default:throw Error(a(435,t.tag))}}function Ff(t,i){var s=ET(t);i.forEach(function(u){if(!s.has(u)){s.add(u);var h=LT.bind(null,t,u);u.then(h,h)}})}function Hi(t,i){var s=i.deletions;if(s!==null)for(var u=0;u<s.length;u++){var h=s[u],m=t,E=i,U=E;e:for(;U!==null;){switch(U.tag){case 27:if(Es(U.type)){bn=U.stateNode,Bi=!1;break e}break;case 5:bn=U.stateNode,Bi=!1;break e;case 3:case 4:bn=U.stateNode.containerInfo,Bi=!0;break e}U=U.return}if(bn===null)throw Error(a(160));Jx(m,E,h),bn=null,Bi=!1,m=h.alternate,m!==null&&(m.return=null),h.return=null}if(i.subtreeFlags&13886)for(i=i.child;i!==null;)ty(i,t),i=i.sibling}var Wa=null;function ty(t,i){var s=t.alternate,u=t.flags;switch(t.tag){case 0:case 11:case 14:case 15:Hi(i,t),Gi(t),u&4&&(gs(3,t,t.return),Bu(3,t),gs(5,t,t.return));break;case 1:Hi(i,t),Gi(t),u&512&&(Xn||s===null||ir(s,s.return)),u&64&&Or&&(t=t.updateQueue,t!==null&&(u=t.callbacks,u!==null&&(s=t.shared.hiddenCallbacks,t.shared.hiddenCallbacks=s===null?u:s.concat(u))));break;case 26:var h=Wa;if(Hi(i,t),Gi(t),u&512&&(Xn||s===null||ir(s,s.return)),u&4){var m=s!==null?s.memoizedState:null;if(u=t.memoizedState,s===null)if(u===null)if(t.stateNode===null){e:{u=t.type,s=t.memoizedProps,h=h.ownerDocument||h;t:switch(u){case"title":m=h.getElementsByTagName("title")[0],(!m||m[gn]||m[Tt]||m.namespaceURI==="http://www.w3.org/2000/svg"||m.hasAttribute("itemprop"))&&(m=h.createElement(u),h.head.insertBefore(m,h.querySelector("head > title"))),ci(m,u,s),m[Tt]=t,Y(m),u=m;break e;case"link":var E=tS("link","href",h).get(u+(s.href||""));if(E){for(var U=0;U<E.length;U++)if(m=E[U],m.getAttribute("href")===(s.href==null||s.href===""?null:s.href)&&m.getAttribute("rel")===(s.rel==null?null:s.rel)&&m.getAttribute("title")===(s.title==null?null:s.title)&&m.getAttribute("crossorigin")===(s.crossOrigin==null?null:s.crossOrigin)){E.splice(U,1);break t}}m=h.createElement(u),ci(m,u,s),h.head.appendChild(m);break;case"meta":if(E=tS("meta","content",h).get(u+(s.content||""))){for(U=0;U<E.length;U++)if(m=E[U],m.getAttribute("content")===(s.content==null?null:""+s.content)&&m.getAttribute("name")===(s.name==null?null:s.name)&&m.getAttribute("property")===(s.property==null?null:s.property)&&m.getAttribute("http-equiv")===(s.httpEquiv==null?null:s.httpEquiv)&&m.getAttribute("charset")===(s.charSet==null?null:s.charSet)){E.splice(U,1);break t}}m=h.createElement(u),ci(m,u,s),h.head.appendChild(m);break;default:throw Error(a(468,u))}m[Tt]=t,Y(m),u=m}t.stateNode=u}else nS(h,t.type,t.stateNode);else t.stateNode=eS(h,u,t.memoizedProps);else m!==u?(m===null?s.stateNode!==null&&(s=s.stateNode,s.parentNode.removeChild(s)):m.count--,u===null?nS(h,t.type,t.stateNode):eS(h,u,t.memoizedProps)):u===null&&t.stateNode!==null&&Kp(t,t.memoizedProps,s.memoizedProps)}break;case 27:Hi(i,t),Gi(t),u&512&&(Xn||s===null||ir(s,s.return)),s!==null&&u&4&&Kp(t,t.memoizedProps,s.memoizedProps);break;case 5:if(Hi(i,t),Gi(t),u&512&&(Xn||s===null||ir(s,s.return)),t.flags&32){h=t.stateNode;try{Ri(h,"")}catch($e){nn(t,t.return,$e)}}u&4&&t.stateNode!=null&&(h=t.memoizedProps,Kp(t,h,s!==null?s.memoizedProps:h)),u&1024&&($p=!0);break;case 6:if(Hi(i,t),Gi(t),u&4){if(t.stateNode===null)throw Error(a(162));u=t.memoizedProps,s=t.stateNode;try{s.nodeValue=u}catch($e){nn(t,t.return,$e)}}break;case 3:if($f=null,h=Wa,Wa=Qf(i.containerInfo),Hi(i,t),Wa=h,Gi(t),u&4&&s!==null&&s.memoizedState.isDehydrated)try{bl(i.containerInfo)}catch($e){nn(t,t.return,$e)}$p&&($p=!1,ny(t));break;case 4:u=Wa,Wa=Qf(t.stateNode.containerInfo),Hi(i,t),Gi(t),Wa=u;break;case 12:Hi(i,t),Gi(t);break;case 31:Hi(i,t),Gi(t),u&4&&(u=t.updateQueue,u!==null&&(t.updateQueue=null,Ff(t,u)));break;case 13:Hi(i,t),Gi(t),t.child.flags&8192&&t.memoizedState!==null!=(s!==null&&s.memoizedState!==null)&&(Bf=A()),u&4&&(u=t.updateQueue,u!==null&&(t.updateQueue=null,Ff(t,u)));break;case 22:h=t.memoizedState!==null;var X=s!==null&&s.memoizedState!==null,oe=Or,ye=Xn;if(Or=oe||h,Xn=ye||X,Hi(i,t),Xn=ye,Or=oe,Gi(t),u&8192)e:for(i=t.stateNode,i._visibility=h?i._visibility&-2:i._visibility|1,h&&(s===null||X||Or||Xn||po(t)),s=null,i=t;;){if(i.tag===5||i.tag===26){if(s===null){X=s=i;try{if(m=X.stateNode,h)E=m.style,typeof E.setProperty=="function"?E.setProperty("display","none","important"):E.display="none";else{U=X.stateNode;var Me=X.memoizedProps.style,ce=Me!=null&&Me.hasOwnProperty("display")?Me.display:null;U.style.display=ce==null||typeof ce=="boolean"?"":(""+ce).trim()}}catch($e){nn(X,X.return,$e)}}}else if(i.tag===6){if(s===null){X=i;try{X.stateNode.nodeValue=h?"":X.memoizedProps}catch($e){nn(X,X.return,$e)}}}else if(i.tag===18){if(s===null){X=i;try{var pe=X.stateNode;h?Wy(pe,!0):Wy(X.stateNode,!1)}catch($e){nn(X,X.return,$e)}}}else if((i.tag!==22&&i.tag!==23||i.memoizedState===null||i===t)&&i.child!==null){i.child.return=i,i=i.child;continue}if(i===t)break e;for(;i.sibling===null;){if(i.return===null||i.return===t)break e;s===i&&(s=null),i=i.return}s===i&&(s=null),i.sibling.return=i.return,i=i.sibling}u&4&&(u=t.updateQueue,u!==null&&(s=u.retryQueue,s!==null&&(u.retryQueue=null,Ff(t,s))));break;case 19:Hi(i,t),Gi(t),u&4&&(u=t.updateQueue,u!==null&&(t.updateQueue=null,Ff(t,u)));break;case 30:break;case 21:break;default:Hi(i,t),Gi(t)}}function Gi(t){var i=t.flags;if(i&2){try{for(var s,u=t.return;u!==null;){if(qx(u)){s=u;break}u=u.return}if(s==null)throw Error(a(160));switch(s.tag){case 27:var h=s.stateNode,m=Qp(t);zf(t,m,h);break;case 5:var E=s.stateNode;s.flags&32&&(Ri(E,""),s.flags&=-33);var U=Qp(t);zf(t,U,E);break;case 3:case 4:var X=s.stateNode.containerInfo,oe=Qp(t);Jp(t,oe,X);break;default:throw Error(a(161))}}catch(ye){nn(t,t.return,ye)}t.flags&=-3}i&4096&&(t.flags&=-4097)}function ny(t){if(t.subtreeFlags&1024)for(t=t.child;t!==null;){var i=t;ny(i),i.tag===5&&i.flags&1024&&i.stateNode.reset(),t=t.sibling}}function zr(t,i){if(i.subtreeFlags&8772)for(i=i.child;i!==null;)Kx(t,i.alternate,i),i=i.sibling}function po(t){for(t=t.child;t!==null;){var i=t;switch(i.tag){case 0:case 11:case 14:case 15:gs(4,i,i.return),po(i);break;case 1:ir(i,i.return);var s=i.stateNode;typeof s.componentWillUnmount=="function"&&Wx(i,i.return,s),po(i);break;case 27:Zu(i.stateNode);case 26:case 5:ir(i,i.return),po(i);break;case 22:i.memoizedState===null&&po(i);break;case 30:po(i);break;default:po(i)}t=t.sibling}}function Fr(t,i,s){for(s=s&&(i.subtreeFlags&8772)!==0,i=i.child;i!==null;){var u=i.alternate,h=t,m=i,E=m.flags;switch(m.tag){case 0:case 11:case 15:Fr(h,m,s),Bu(4,m);break;case 1:if(Fr(h,m,s),u=m,h=u.stateNode,typeof h.componentDidMount=="function")try{h.componentDidMount()}catch(oe){nn(u,u.return,oe)}if(u=m,h=u.updateQueue,h!==null){var U=u.stateNode;try{var X=h.shared.hiddenCallbacks;if(X!==null)for(h.shared.hiddenCallbacks=null,h=0;h<X.length;h++)Lv(X[h],U)}catch(oe){nn(u,u.return,oe)}}s&&E&64&&Xx(m),Hu(m,m.return);break;case 27:jx(m);case 26:case 5:Fr(h,m,s),s&&u===null&&E&4&&Yx(m),Hu(m,m.return);break;case 12:Fr(h,m,s);break;case 31:Fr(h,m,s),s&&E&4&&$x(h,m);break;case 13:Fr(h,m,s),s&&E&4&&ey(h,m);break;case 22:m.memoizedState===null&&Fr(h,m,s),Hu(m,m.return);break;case 30:break;default:Fr(h,m,s)}i=i.sibling}}function em(t,i){var s=null;t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(s=t.memoizedState.cachePool.pool),t=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(t=i.memoizedState.cachePool.pool),t!==s&&(t!=null&&t.refCount++,s!=null&&Au(s))}function tm(t,i){t=null,i.alternate!==null&&(t=i.alternate.memoizedState.cache),i=i.memoizedState.cache,i!==t&&(i.refCount++,t!=null&&Au(t))}function Ya(t,i,s,u){if(i.subtreeFlags&10256)for(i=i.child;i!==null;)iy(t,i,s,u),i=i.sibling}function iy(t,i,s,u){var h=i.flags;switch(i.tag){case 0:case 11:case 15:Ya(t,i,s,u),h&2048&&Bu(9,i);break;case 1:Ya(t,i,s,u);break;case 3:Ya(t,i,s,u),h&2048&&(t=null,i.alternate!==null&&(t=i.alternate.memoizedState.cache),i=i.memoizedState.cache,i!==t&&(i.refCount++,t!=null&&Au(t)));break;case 12:if(h&2048){Ya(t,i,s,u),t=i.stateNode;try{var m=i.memoizedProps,E=m.id,U=m.onPostCommit;typeof U=="function"&&U(E,i.alternate===null?"mount":"update",t.passiveEffectDuration,-0)}catch(X){nn(i,i.return,X)}}else Ya(t,i,s,u);break;case 31:Ya(t,i,s,u);break;case 13:Ya(t,i,s,u);break;case 23:break;case 22:m=i.stateNode,E=i.alternate,i.memoizedState!==null?m._visibility&2?Ya(t,i,s,u):Gu(t,i):m._visibility&2?Ya(t,i,s,u):(m._visibility|=2,hl(t,i,s,u,(i.subtreeFlags&10256)!==0||!1)),h&2048&&em(E,i);break;case 24:Ya(t,i,s,u),h&2048&&tm(i.alternate,i);break;default:Ya(t,i,s,u)}}function hl(t,i,s,u,h){for(h=h&&((i.subtreeFlags&10256)!==0||!1),i=i.child;i!==null;){var m=t,E=i,U=s,X=u,oe=E.flags;switch(E.tag){case 0:case 11:case 15:hl(m,E,U,X,h),Bu(8,E);break;case 23:break;case 22:var ye=E.stateNode;E.memoizedState!==null?ye._visibility&2?hl(m,E,U,X,h):Gu(m,E):(ye._visibility|=2,hl(m,E,U,X,h)),h&&oe&2048&&em(E.alternate,E);break;case 24:hl(m,E,U,X,h),h&&oe&2048&&tm(E.alternate,E);break;default:hl(m,E,U,X,h)}i=i.sibling}}function Gu(t,i){if(i.subtreeFlags&10256)for(i=i.child;i!==null;){var s=t,u=i,h=u.flags;switch(u.tag){case 22:Gu(s,u),h&2048&&em(u.alternate,u);break;case 24:Gu(s,u),h&2048&&tm(u.alternate,u);break;default:Gu(s,u)}i=i.sibling}}var Vu=8192;function dl(t,i,s){if(t.subtreeFlags&Vu)for(t=t.child;t!==null;)ay(t,i,s),t=t.sibling}function ay(t,i,s){switch(t.tag){case 26:dl(t,i,s),t.flags&Vu&&t.memoizedState!==null&&cA(s,Wa,t.memoizedState,t.memoizedProps);break;case 5:dl(t,i,s);break;case 3:case 4:var u=Wa;Wa=Qf(t.stateNode.containerInfo),dl(t,i,s),Wa=u;break;case 22:t.memoizedState===null&&(u=t.alternate,u!==null&&u.memoizedState!==null?(u=Vu,Vu=16777216,dl(t,i,s),Vu=u):dl(t,i,s));break;default:dl(t,i,s)}}function ry(t){var i=t.alternate;if(i!==null&&(t=i.child,t!==null)){i.child=null;do i=t.sibling,t.sibling=null,t=i;while(t!==null)}}function ku(t){var i=t.deletions;if((t.flags&16)!==0){if(i!==null)for(var s=0;s<i.length;s++){var u=i[s];ni=u,oy(u,t)}ry(t)}if(t.subtreeFlags&10256)for(t=t.child;t!==null;)sy(t),t=t.sibling}function sy(t){switch(t.tag){case 0:case 11:case 15:ku(t),t.flags&2048&&gs(9,t,t.return);break;case 3:ku(t);break;case 12:ku(t);break;case 22:var i=t.stateNode;t.memoizedState!==null&&i._visibility&2&&(t.return===null||t.return.tag!==13)?(i._visibility&=-3,If(t)):ku(t);break;default:ku(t)}}function If(t){var i=t.deletions;if((t.flags&16)!==0){if(i!==null)for(var s=0;s<i.length;s++){var u=i[s];ni=u,oy(u,t)}ry(t)}for(t=t.child;t!==null;){switch(i=t,i.tag){case 0:case 11:case 15:gs(8,i,i.return),If(i);break;case 22:s=i.stateNode,s._visibility&2&&(s._visibility&=-3,If(i));break;default:If(i)}t=t.sibling}}function oy(t,i){for(;ni!==null;){var s=ni;switch(s.tag){case 0:case 11:case 15:gs(8,s,i);break;case 23:case 22:if(s.memoizedState!==null&&s.memoizedState.cachePool!==null){var u=s.memoizedState.cachePool.pool;u!=null&&u.refCount++}break;case 24:Au(s.memoizedState.cache)}if(u=s.child,u!==null)u.return=s,ni=u;else e:for(s=t;ni!==null;){u=ni;var h=u.sibling,m=u.return;if(Qx(u),u===s){ni=null;break e}if(h!==null){h.return=m,ni=h;break e}ni=m}}}var TT={getCacheForType:function(t){var i=li(Gn),s=i.data.get(t);return s===void 0&&(s=t(),i.data.set(t,s)),s},cacheSignal:function(){return li(Gn).controller.signal}},AT=typeof WeakMap=="function"?WeakMap:Map,Jt=0,hn=null,zt=null,Bt=0,tn=0,ra=null,vs=!1,pl=!1,nm=!1,Ir=0,Dn=0,xs=0,mo=0,im=0,sa=0,ml=0,Xu=null,Vi=null,am=!1,Bf=0,ly=0,Hf=1/0,Gf=null,ys=null,Zn=0,Ss=null,_l=null,Br=0,rm=0,sm=null,uy=null,Wu=0,om=null;function oa(){return(Jt&2)!==0&&Bt!==0?Bt&-Bt:z.T!==null?dm():gt()}function cy(){if(sa===0)if((Bt&536870912)===0||Vt){var t=Ce;Ce<<=1,(Ce&3932160)===0&&(Ce=262144),sa=t}else sa=536870912;return t=ia.current,t!==null&&(t.flags|=32),sa}function ki(t,i,s){(t===hn&&(tn===2||tn===9)||t.cancelPendingCommit!==null)&&(gl(t,0),Ms(t,Bt,sa,!1)),Je(t,s),((Jt&2)===0||t!==hn)&&(t===hn&&((Jt&2)===0&&(mo|=s),Dn===4&&Ms(t,Bt,sa,!1)),ar(t))}function fy(t,i,s){if((Jt&6)!==0)throw Error(a(327));var u=!s&&(i&127)===0&&(i&t.expiredLanes)===0||Xe(t,i),h=u?wT(t,i):um(t,i,!0),m=u;do{if(h===0){pl&&!u&&Ms(t,i,0,!1);break}else{if(s=t.current.alternate,m&&!RT(s)){h=um(t,i,!1),m=!1;continue}if(h===2){if(m=i,t.errorRecoveryDisabledLanes&m)var E=0;else E=t.pendingLanes&-536870913,E=E!==0?E:E&536870912?536870912:0;if(E!==0){i=E;e:{var U=t;h=Xu;var X=U.current.memoizedState.isDehydrated;if(X&&(gl(U,E).flags|=256),E=um(U,E,!1),E!==2){if(nm&&!X){U.errorRecoveryDisabledLanes|=m,mo|=m,h=4;break e}m=Vi,Vi=h,m!==null&&(Vi===null?Vi=m:Vi.push.apply(Vi,m))}h=E}if(m=!1,h!==2)continue}}if(h===1){gl(t,0),Ms(t,i,0,!0);break}e:{switch(u=t,m=h,m){case 0:case 1:throw Error(a(345));case 4:if((i&4194048)!==i)break;case 6:Ms(u,i,sa,!vs);break e;case 2:Vi=null;break;case 3:case 5:break;default:throw Error(a(329))}if((i&62914560)===i&&(h=Bf+300-A(),10<h)){if(Ms(u,i,sa,!vs),me(u,0,!0)!==0)break e;Br=i,u.timeoutHandle=Vy(hy.bind(null,u,s,Vi,Gf,am,i,sa,mo,ml,vs,m,"Throttled",-0,0),h);break e}hy(u,s,Vi,Gf,am,i,sa,mo,ml,vs,m,null,-0,0)}}break}while(!0);ar(t)}function hy(t,i,s,u,h,m,E,U,X,oe,ye,Me,ce,pe){if(t.timeoutHandle=-1,Me=i.subtreeFlags,Me&8192||(Me&16785408)===16785408){Me={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:Er},ay(i,m,Me);var $e=(m&62914560)===m?Bf-A():(m&4194048)===m?ly-A():0;if($e=fA(Me,$e),$e!==null){Br=m,t.cancelPendingCommit=$e(yy.bind(null,t,i,m,s,u,h,E,U,X,ye,Me,null,ce,pe)),Ms(t,m,E,!oe);return}}yy(t,i,m,s,u,h,E,U,X)}function RT(t){for(var i=t;;){var s=i.tag;if((s===0||s===11||s===15)&&i.flags&16384&&(s=i.updateQueue,s!==null&&(s=s.stores,s!==null)))for(var u=0;u<s.length;u++){var h=s[u],m=h.getSnapshot;h=h.value;try{if(!ta(m(),h))return!1}catch{return!1}}if(s=i.child,i.subtreeFlags&16384&&s!==null)s.return=i,i=s;else{if(i===t)break;for(;i.sibling===null;){if(i.return===null||i.return===t)return!0;i=i.return}i.sibling.return=i.return,i=i.sibling}}return!0}function Ms(t,i,s,u){i&=~im,i&=~mo,t.suspendedLanes|=i,t.pingedLanes&=~i,u&&(t.warmLanes|=i),u=t.expirationTimes;for(var h=i;0<h;){var m=31-Pe(h),E=1<<m;u[m]=-1,h&=~E}s!==0&&Ie(t,s,i)}function Vf(){return(Jt&6)===0?(Yu(0),!1):!0}function lm(){if(zt!==null){if(tn===0)var t=zt.return;else t=zt,Cr=ro=null,Ep(t),ol=null,Cu=0,t=zt;for(;t!==null;)kx(t.alternate,t),t=t.return;zt=null}}function gl(t,i){var s=t.timeoutHandle;s!==-1&&(t.timeoutHandle=-1,qT(s)),s=t.cancelPendingCommit,s!==null&&(t.cancelPendingCommit=null,s()),Br=0,lm(),hn=t,zt=s=Ar(t.current,null),Bt=i,tn=0,ra=null,vs=!1,pl=Xe(t,i),nm=!1,ml=sa=im=mo=xs=Dn=0,Vi=Xu=null,am=!1,(i&8)!==0&&(i|=i&32);var u=t.entangledLanes;if(u!==0)for(t=t.entanglements,u&=i;0<u;){var h=31-Pe(u),m=1<<h;i|=t[h],u&=~m}return Ir=i,uf(),s}function dy(t,i){At=null,z.H=zu,i===sl||i===gf?(i=wv(),tn=3):i===hp?(i=wv(),tn=4):tn=i===Hp?8:i!==null&&typeof i=="object"&&typeof i.then=="function"?6:1,ra=i,zt===null&&(Dn=1,Nf(t,ba(i,t.current)))}function py(){var t=ia.current;return t===null?!0:(Bt&4194048)===Bt?Ra===null:(Bt&62914560)===Bt||(Bt&536870912)!==0?t===Ra:!1}function my(){var t=z.H;return z.H=zu,t===null?zu:t}function _y(){var t=z.A;return z.A=TT,t}function kf(){Dn=4,vs||(Bt&4194048)!==Bt&&ia.current!==null||(pl=!0),(xs&134217727)===0&&(mo&134217727)===0||hn===null||Ms(hn,Bt,sa,!1)}function um(t,i,s){var u=Jt;Jt|=2;var h=my(),m=_y();(hn!==t||Bt!==i)&&(Gf=null,gl(t,i)),i=!1;var E=Dn;e:do try{if(tn!==0&&zt!==null){var U=zt,X=ra;switch(tn){case 8:lm(),E=6;break e;case 3:case 2:case 9:case 6:ia.current===null&&(i=!0);var oe=tn;if(tn=0,ra=null,vl(t,U,X,oe),s&&pl){E=0;break e}break;default:oe=tn,tn=0,ra=null,vl(t,U,X,oe)}}CT(),E=Dn;break}catch(ye){dy(t,ye)}while(!0);return i&&t.shellSuspendCounter++,Cr=ro=null,Jt=u,z.H=h,z.A=m,zt===null&&(hn=null,Bt=0,uf()),E}function CT(){for(;zt!==null;)gy(zt)}function wT(t,i){var s=Jt;Jt|=2;var u=my(),h=_y();hn!==t||Bt!==i?(Gf=null,Hf=A()+500,gl(t,i)):pl=Xe(t,i);e:do try{if(tn!==0&&zt!==null){i=zt;var m=ra;t:switch(tn){case 1:tn=0,ra=null,vl(t,i,m,1);break;case 2:case 9:if(Rv(m)){tn=0,ra=null,vy(i);break}i=function(){tn!==2&&tn!==9||hn!==t||(tn=7),ar(t)},m.then(i,i);break e;case 3:tn=7;break e;case 4:tn=5;break e;case 7:Rv(m)?(tn=0,ra=null,vy(i)):(tn=0,ra=null,vl(t,i,m,7));break;case 5:var E=null;switch(zt.tag){case 26:E=zt.memoizedState;case 5:case 27:var U=zt;if(E?iS(E):U.stateNode.complete){tn=0,ra=null;var X=U.sibling;if(X!==null)zt=X;else{var oe=U.return;oe!==null?(zt=oe,Xf(oe)):zt=null}break t}}tn=0,ra=null,vl(t,i,m,5);break;case 6:tn=0,ra=null,vl(t,i,m,6);break;case 8:lm(),Dn=6;break e;default:throw Error(a(462))}}DT();break}catch(ye){dy(t,ye)}while(!0);return Cr=ro=null,z.H=u,z.A=h,Jt=s,zt!==null?0:(hn=null,Bt=0,uf(),Dn)}function DT(){for(;zt!==null&&!We();)gy(zt)}function gy(t){var i=Gx(t.alternate,t,Ir);t.memoizedProps=t.pendingProps,i===null?Xf(t):zt=i}function vy(t){var i=t,s=i.alternate;switch(i.tag){case 15:case 0:i=Px(s,i,i.pendingProps,i.type,void 0,Bt);break;case 11:i=Px(s,i,i.pendingProps,i.type.render,i.ref,Bt);break;case 5:Ep(i);default:kx(s,i),i=zt=_v(i,Ir),i=Gx(s,i,Ir)}t.memoizedProps=t.pendingProps,i===null?Xf(t):zt=i}function vl(t,i,s,u){Cr=ro=null,Ep(i),ol=null,Cu=0;var h=i.return;try{if(vT(t,h,i,s,Bt)){Dn=1,Nf(t,ba(s,t.current)),zt=null;return}}catch(m){if(h!==null)throw zt=h,m;Dn=1,Nf(t,ba(s,t.current)),zt=null;return}i.flags&32768?(Vt||u===1?t=!0:pl||(Bt&536870912)!==0?t=!1:(vs=t=!0,(u===2||u===9||u===3||u===6)&&(u=ia.current,u!==null&&u.tag===13&&(u.flags|=16384))),xy(i,t)):Xf(i)}function Xf(t){var i=t;do{if((i.flags&32768)!==0){xy(i,vs);return}t=i.return;var s=ST(i.alternate,i,Ir);if(s!==null){zt=s;return}if(i=i.sibling,i!==null){zt=i;return}zt=i=t}while(i!==null);Dn===0&&(Dn=5)}function xy(t,i){do{var s=MT(t.alternate,t);if(s!==null){s.flags&=32767,zt=s;return}if(s=t.return,s!==null&&(s.flags|=32768,s.subtreeFlags=0,s.deletions=null),!i&&(t=t.sibling,t!==null)){zt=t;return}zt=t=s}while(t!==null);Dn=6,zt=null}function yy(t,i,s,u,h,m,E,U,X){t.cancelPendingCommit=null;do Wf();while(Zn!==0);if((Jt&6)!==0)throw Error(a(327));if(i!==null){if(i===t.current)throw Error(a(177));if(m=i.lanes|i.childLanes,m|=Qd,Et(t,s,m,E,U,X),t===hn&&(zt=hn=null,Bt=0),_l=i,Ss=t,Br=s,rm=m,sm=h,uy=u,(i.subtreeFlags&10256)!==0||(i.flags&10256)!==0?(t.callbackNode=null,t.callbackPriority=0,OT(de,function(){return Ty(),null})):(t.callbackNode=null,t.callbackPriority=0),u=(i.flags&13878)!==0,(i.subtreeFlags&13878)!==0||u){u=z.T,z.T=null,h=I.p,I.p=2,E=Jt,Jt|=4;try{bT(t,i,s)}finally{Jt=E,I.p=h,z.T=u}}Zn=1,Sy(),My(),by()}}function Sy(){if(Zn===1){Zn=0;var t=Ss,i=_l,s=(i.flags&13878)!==0;if((i.subtreeFlags&13878)!==0||s){s=z.T,z.T=null;var u=I.p;I.p=2;var h=Jt;Jt|=4;try{ty(i,t);var m=Sm,E=ov(t.containerInfo),U=m.focusedElem,X=m.selectionRange;if(E!==U&&U&&U.ownerDocument&&sv(U.ownerDocument.documentElement,U)){if(X!==null&&Yd(U)){var oe=X.start,ye=X.end;if(ye===void 0&&(ye=oe),"selectionStart"in U)U.selectionStart=oe,U.selectionEnd=Math.min(ye,U.value.length);else{var Me=U.ownerDocument||document,ce=Me&&Me.defaultView||window;if(ce.getSelection){var pe=ce.getSelection(),$e=U.textContent.length,ft=Math.min(X.start,$e),cn=X.end===void 0?ft:Math.min(X.end,$e);!pe.extend&&ft>cn&&(E=cn,cn=ft,ft=E);var ee=rv(U,ft),K=rv(U,cn);if(ee&&K&&(pe.rangeCount!==1||pe.anchorNode!==ee.node||pe.anchorOffset!==ee.offset||pe.focusNode!==K.node||pe.focusOffset!==K.offset)){var re=Me.createRange();re.setStart(ee.node,ee.offset),pe.removeAllRanges(),ft>cn?(pe.addRange(re),pe.extend(K.node,K.offset)):(re.setEnd(K.node,K.offset),pe.addRange(re))}}}}for(Me=[],pe=U;pe=pe.parentNode;)pe.nodeType===1&&Me.push({element:pe,left:pe.scrollLeft,top:pe.scrollTop});for(typeof U.focus=="function"&&U.focus(),U=0;U<Me.length;U++){var Se=Me[U];Se.element.scrollLeft=Se.left,Se.element.scrollTop=Se.top}}ih=!!ym,Sm=ym=null}finally{Jt=h,I.p=u,z.T=s}}t.current=i,Zn=2}}function My(){if(Zn===2){Zn=0;var t=Ss,i=_l,s=(i.flags&8772)!==0;if((i.subtreeFlags&8772)!==0||s){s=z.T,z.T=null;var u=I.p;I.p=2;var h=Jt;Jt|=4;try{Kx(t,i.alternate,i)}finally{Jt=h,I.p=u,z.T=s}}Zn=3}}function by(){if(Zn===4||Zn===3){Zn=0,B();var t=Ss,i=_l,s=Br,u=uy;(i.subtreeFlags&10256)!==0||(i.flags&10256)!==0?Zn=5:(Zn=0,_l=Ss=null,Ey(t,t.pendingLanes));var h=t.pendingLanes;if(h===0&&(ys=null),_n(s),i=i.stateNode,Ae&&typeof Ae.onCommitFiberRoot=="function")try{Ae.onCommitFiberRoot(Re,i,void 0,(i.current.flags&128)===128)}catch{}if(u!==null){i=z.T,h=I.p,I.p=2,z.T=null;try{for(var m=t.onRecoverableError,E=0;E<u.length;E++){var U=u[E];m(U.value,{componentStack:U.stack})}}finally{z.T=i,I.p=h}}(Br&3)!==0&&Wf(),ar(t),h=t.pendingLanes,(s&261930)!==0&&(h&42)!==0?t===om?Wu++:(Wu=0,om=t):Wu=0,Yu(0)}}function Ey(t,i){(t.pooledCacheLanes&=i)===0&&(i=t.pooledCache,i!=null&&(t.pooledCache=null,Au(i)))}function Wf(){return Sy(),My(),by(),Ty()}function Ty(){if(Zn!==5)return!1;var t=Ss,i=rm;rm=0;var s=_n(Br),u=z.T,h=I.p;try{I.p=32>s?32:s,z.T=null,s=sm,sm=null;var m=Ss,E=Br;if(Zn=0,_l=Ss=null,Br=0,(Jt&6)!==0)throw Error(a(331));var U=Jt;if(Jt|=4,sy(m.current),iy(m,m.current,E,s),Jt=U,Yu(0,!1),Ae&&typeof Ae.onPostCommitFiberRoot=="function")try{Ae.onPostCommitFiberRoot(Re,m)}catch{}return!0}finally{I.p=h,z.T=u,Ey(t,i)}}function Ay(t,i,s){i=ba(s,i),i=Bp(t.stateNode,i,2),t=ps(t,i,2),t!==null&&(Je(t,2),ar(t))}function nn(t,i,s){if(t.tag===3)Ay(t,t,s);else for(;i!==null;){if(i.tag===3){Ay(i,t,s);break}else if(i.tag===1){var u=i.stateNode;if(typeof i.type.getDerivedStateFromError=="function"||typeof u.componentDidCatch=="function"&&(ys===null||!ys.has(u))){t=ba(s,t),s=Rx(2),u=ps(i,s,2),u!==null&&(Cx(s,u,i,t),Je(u,2),ar(u));break}}i=i.return}}function cm(t,i,s){var u=t.pingCache;if(u===null){u=t.pingCache=new AT;var h=new Set;u.set(i,h)}else h=u.get(i),h===void 0&&(h=new Set,u.set(i,h));h.has(s)||(nm=!0,h.add(s),t=NT.bind(null,t,i,s),i.then(t,t))}function NT(t,i,s){var u=t.pingCache;u!==null&&u.delete(i),t.pingedLanes|=t.suspendedLanes&s,t.warmLanes&=~s,hn===t&&(Bt&s)===s&&(Dn===4||Dn===3&&(Bt&62914560)===Bt&&300>A()-Bf?(Jt&2)===0&&gl(t,0):im|=s,ml===Bt&&(ml=0)),ar(t)}function Ry(t,i){i===0&&(i=Gt()),t=no(t,i),t!==null&&(Je(t,i),ar(t))}function UT(t){var i=t.memoizedState,s=0;i!==null&&(s=i.retryLane),Ry(t,s)}function LT(t,i){var s=0;switch(t.tag){case 31:case 13:var u=t.stateNode,h=t.memoizedState;h!==null&&(s=h.retryLane);break;case 19:u=t.stateNode;break;case 22:u=t.stateNode._retryCache;break;default:throw Error(a(314))}u!==null&&u.delete(i),Ry(t,s)}function OT(t,i){return bt(t,i)}var Yf=null,xl=null,fm=!1,qf=!1,hm=!1,bs=0;function ar(t){t!==xl&&t.next===null&&(xl===null?Yf=xl=t:xl=xl.next=t),qf=!0,fm||(fm=!0,zT())}function Yu(t,i){if(!hm&&qf){hm=!0;do for(var s=!1,u=Yf;u!==null;){if(t!==0){var h=u.pendingLanes;if(h===0)var m=0;else{var E=u.suspendedLanes,U=u.pingedLanes;m=(1<<31-Pe(42|t)+1)-1,m&=h&~(E&~U),m=m&201326741?m&201326741|1:m?m|2:0}m!==0&&(s=!0,Ny(u,m))}else m=Bt,m=me(u,u===hn?m:0,u.cancelPendingCommit!==null||u.timeoutHandle!==-1),(m&3)===0||Xe(u,m)||(s=!0,Ny(u,m));u=u.next}while(s);hm=!1}}function PT(){Cy()}function Cy(){qf=fm=!1;var t=0;bs!==0&&YT()&&(t=bs);for(var i=A(),s=null,u=Yf;u!==null;){var h=u.next,m=wy(u,i);m===0?(u.next=null,s===null?Yf=h:s.next=h,h===null&&(xl=s)):(s=u,(t!==0||(m&3)!==0)&&(qf=!0)),u=h}Zn!==0&&Zn!==5||Yu(t),bs!==0&&(bs=0)}function wy(t,i){for(var s=t.suspendedLanes,u=t.pingedLanes,h=t.expirationTimes,m=t.pendingLanes&-62914561;0<m;){var E=31-Pe(m),U=1<<E,X=h[E];X===-1?((U&s)===0||(U&u)!==0)&&(h[E]=lt(U,i)):X<=i&&(t.expiredLanes|=U),m&=~U}if(i=hn,s=Bt,s=me(t,t===i?s:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),u=t.callbackNode,s===0||t===i&&(tn===2||tn===9)||t.cancelPendingCommit!==null)return u!==null&&u!==null&&ct(u),t.callbackNode=null,t.callbackPriority=0;if((s&3)===0||Xe(t,s)){if(i=s&-s,i===t.callbackPriority)return i;switch(u!==null&&ct(u),_n(s)){case 2:case 8:s=ve;break;case 32:s=de;break;case 268435456:s=we;break;default:s=de}return u=Dy.bind(null,t),s=bt(s,u),t.callbackPriority=i,t.callbackNode=s,i}return u!==null&&u!==null&&ct(u),t.callbackPriority=2,t.callbackNode=null,2}function Dy(t,i){if(Zn!==0&&Zn!==5)return t.callbackNode=null,t.callbackPriority=0,null;var s=t.callbackNode;if(Wf()&&t.callbackNode!==s)return null;var u=Bt;return u=me(t,t===hn?u:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),u===0?null:(fy(t,u,i),wy(t,A()),t.callbackNode!=null&&t.callbackNode===s?Dy.bind(null,t):null)}function Ny(t,i){if(Wf())return null;fy(t,i,!0)}function zT(){jT(function(){(Jt&6)!==0?bt(ge,PT):Cy()})}function dm(){if(bs===0){var t=al;t===0&&(t=De,De<<=1,(De&261888)===0&&(De=256)),bs=t}return bs}function Uy(t){return t==null||typeof t=="symbol"||typeof t=="boolean"?null:typeof t=="function"?t:ef(""+t)}function Ly(t,i){var s=i.ownerDocument.createElement("input");return s.name=i.name,s.value=i.value,t.id&&s.setAttribute("form",t.id),i.parentNode.insertBefore(s,i),t=new FormData(t),s.parentNode.removeChild(s),t}function FT(t,i,s,u,h){if(i==="submit"&&s&&s.stateNode===h){var m=Uy((h[xt]||null).action),E=u.submitter;E&&(i=(i=E[xt]||null)?Uy(i.formAction):E.getAttribute("formAction"),i!==null&&(m=i,E=null));var U=new rf("action","action",null,u,h);t.push({event:U,listeners:[{instance:null,listener:function(){if(u.defaultPrevented){if(bs!==0){var X=E?Ly(h,E):new FormData(h);Lp(s,{pending:!0,data:X,method:h.method,action:m},null,X)}}else typeof m=="function"&&(U.preventDefault(),X=E?Ly(h,E):new FormData(h),Lp(s,{pending:!0,data:X,method:h.method,action:m},m,X))},currentTarget:h}]})}}for(var pm=0;pm<Kd.length;pm++){var mm=Kd[pm],IT=mm.toLowerCase(),BT=mm[0].toUpperCase()+mm.slice(1);Xa(IT,"on"+BT)}Xa(cv,"onAnimationEnd"),Xa(fv,"onAnimationIteration"),Xa(hv,"onAnimationStart"),Xa("dblclick","onDoubleClick"),Xa("focusin","onFocus"),Xa("focusout","onBlur"),Xa(tT,"onTransitionRun"),Xa(nT,"onTransitionStart"),Xa(iT,"onTransitionCancel"),Xa(dv,"onTransitionEnd"),Ue("onMouseEnter",["mouseout","mouseover"]),Ue("onMouseLeave",["mouseout","mouseover"]),Ue("onPointerEnter",["pointerout","pointerover"]),Ue("onPointerLeave",["pointerout","pointerover"]),ae("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),ae("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),ae("onBeforeInput",["compositionend","keypress","textInput","paste"]),ae("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),ae("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),ae("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var qu="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),HT=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(qu));function Oy(t,i){i=(i&4)!==0;for(var s=0;s<t.length;s++){var u=t[s],h=u.event;u=u.listeners;e:{var m=void 0;if(i)for(var E=u.length-1;0<=E;E--){var U=u[E],X=U.instance,oe=U.currentTarget;if(U=U.listener,X!==m&&h.isPropagationStopped())break e;m=U,h.currentTarget=oe;try{m(h)}catch(ye){lf(ye)}h.currentTarget=null,m=X}else for(E=0;E<u.length;E++){if(U=u[E],X=U.instance,oe=U.currentTarget,U=U.listener,X!==m&&h.isPropagationStopped())break e;m=U,h.currentTarget=oe;try{m(h)}catch(ye){lf(ye)}h.currentTarget=null,m=X}}}}function Ft(t,i){var s=i[In];s===void 0&&(s=i[In]=new Set);var u=t+"__bubble";s.has(u)||(Py(i,t,2,!1),s.add(u))}function _m(t,i,s){var u=0;i&&(u|=4),Py(s,t,u,i)}var jf="_reactListening"+Math.random().toString(36).slice(2);function gm(t){if(!t[jf]){t[jf]=!0,ue.forEach(function(s){s!=="selectionchange"&&(HT.has(s)||_m(s,!1,t),_m(s,!0,t))});var i=t.nodeType===9?t:t.ownerDocument;i===null||i[jf]||(i[jf]=!0,_m("selectionchange",!1,i))}}function Py(t,i,s,u){switch(cS(i)){case 2:var h=pA;break;case 8:h=mA;break;default:h=Um}s=h.bind(null,i,s,t),h=void 0,!Fd||i!=="touchstart"&&i!=="touchmove"&&i!=="wheel"||(h=!0),u?h!==void 0?t.addEventListener(i,s,{capture:!0,passive:h}):t.addEventListener(i,s,!0):h!==void 0?t.addEventListener(i,s,{passive:h}):t.addEventListener(i,s,!1)}function vm(t,i,s,u,h){var m=u;if((i&1)===0&&(i&2)===0&&u!==null)e:for(;;){if(u===null)return;var E=u.tag;if(E===3||E===4){var U=u.stateNode.containerInfo;if(U===h)break;if(E===4)for(E=u.return;E!==null;){var X=E.tag;if((X===3||X===4)&&E.stateNode.containerInfo===h)return;E=E.return}for(;U!==null;){if(E=vn(U),E===null)return;if(X=E.tag,X===5||X===6||X===26||X===27){u=m=E;continue e}U=U.parentNode}}u=u.return}Hg(function(){var oe=m,ye=Pd(s),Me=[];e:{var ce=pv.get(t);if(ce!==void 0){var pe=rf,$e=t;switch(t){case"keypress":if(nf(s)===0)break e;case"keydown":case"keyup":pe=LE;break;case"focusin":$e="focus",pe=Gd;break;case"focusout":$e="blur",pe=Gd;break;case"beforeblur":case"afterblur":pe=Gd;break;case"click":if(s.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":pe=kg;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":pe=SE;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":pe=zE;break;case cv:case fv:case hv:pe=EE;break;case dv:pe=IE;break;case"scroll":case"scrollend":pe=xE;break;case"wheel":pe=HE;break;case"copy":case"cut":case"paste":pe=AE;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":pe=Wg;break;case"toggle":case"beforetoggle":pe=VE}var ft=(i&4)!==0,cn=!ft&&(t==="scroll"||t==="scrollend"),ee=ft?ce!==null?ce+"Capture":null:ce;ft=[];for(var K=oe,re;K!==null;){var Se=K;if(re=Se.stateNode,Se=Se.tag,Se!==5&&Se!==26&&Se!==27||re===null||ee===null||(Se=mu(K,ee),Se!=null&&ft.push(ju(K,Se,re))),cn)break;K=K.return}0<ft.length&&(ce=new pe(ce,$e,null,s,ye),Me.push({event:ce,listeners:ft}))}}if((i&7)===0){e:{if(ce=t==="mouseover"||t==="pointerover",pe=t==="mouseout"||t==="pointerout",ce&&s!==Od&&($e=s.relatedTarget||s.fromElement)&&(vn($e)||$e[Pt]))break e;if((pe||ce)&&(ce=ye.window===ye?ye:(ce=ye.ownerDocument)?ce.defaultView||ce.parentWindow:window,pe?($e=s.relatedTarget||s.toElement,pe=oe,$e=$e?vn($e):null,$e!==null&&(cn=l($e),ft=$e.tag,$e!==cn||ft!==5&&ft!==27&&ft!==6)&&($e=null)):(pe=null,$e=oe),pe!==$e)){if(ft=kg,Se="onMouseLeave",ee="onMouseEnter",K="mouse",(t==="pointerout"||t==="pointerover")&&(ft=Wg,Se="onPointerLeave",ee="onPointerEnter",K="pointer"),cn=pe==null?ce:Sa(pe),re=$e==null?ce:Sa($e),ce=new ft(Se,K+"leave",pe,s,ye),ce.target=cn,ce.relatedTarget=re,Se=null,vn(ye)===oe&&(ft=new ft(ee,K+"enter",$e,s,ye),ft.target=re,ft.relatedTarget=cn,Se=ft),cn=Se,pe&&$e)t:{for(ft=GT,ee=pe,K=$e,re=0,Se=ee;Se;Se=ft(Se))re++;Se=0;for(var ut=K;ut;ut=ft(ut))Se++;for(;0<re-Se;)ee=ft(ee),re--;for(;0<Se-re;)K=ft(K),Se--;for(;re--;){if(ee===K||K!==null&&ee===K.alternate){ft=ee;break t}ee=ft(ee),K=ft(K)}ft=null}else ft=null;pe!==null&&zy(Me,ce,pe,ft,!1),$e!==null&&cn!==null&&zy(Me,cn,$e,ft,!0)}}e:{if(ce=oe?Sa(oe):window,pe=ce.nodeName&&ce.nodeName.toLowerCase(),pe==="select"||pe==="input"&&ce.type==="file")var Zt=$g;else if(Qg(ce))if(ev)Zt=JE;else{Zt=KE;var at=ZE}else pe=ce.nodeName,!pe||pe.toLowerCase()!=="input"||ce.type!=="checkbox"&&ce.type!=="radio"?oe&&Yo(oe.elementType)&&(Zt=$g):Zt=QE;if(Zt&&(Zt=Zt(t,oe))){Jg(Me,Zt,s,ye);break e}at&&at(t,ce,oe),t==="focusout"&&oe&&ce.type==="number"&&oe.memoizedProps.value!=null&&Va(ce,"number",ce.value)}switch(at=oe?Sa(oe):window,t){case"focusin":(Qg(at)||at.contentEditable==="true")&&(Ko=at,qd=oe,bu=null);break;case"focusout":bu=qd=Ko=null;break;case"mousedown":jd=!0;break;case"contextmenu":case"mouseup":case"dragend":jd=!1,lv(Me,s,ye);break;case"selectionchange":if(eT)break;case"keydown":case"keyup":lv(Me,s,ye)}var Ct;if(kd)e:{switch(t){case"compositionstart":var Ht="onCompositionStart";break e;case"compositionend":Ht="onCompositionEnd";break e;case"compositionupdate":Ht="onCompositionUpdate";break e}Ht=void 0}else Zo?Zg(t,s)&&(Ht="onCompositionEnd"):t==="keydown"&&s.keyCode===229&&(Ht="onCompositionStart");Ht&&(Yg&&s.locale!=="ko"&&(Zo||Ht!=="onCompositionStart"?Ht==="onCompositionEnd"&&Zo&&(Ct=Gg()):(os=ye,Id="value"in os?os.value:os.textContent,Zo=!0)),at=Zf(oe,Ht),0<at.length&&(Ht=new Xg(Ht,t,null,s,ye),Me.push({event:Ht,listeners:at}),Ct?Ht.data=Ct:(Ct=Kg(s),Ct!==null&&(Ht.data=Ct)))),(Ct=XE?WE(t,s):YE(t,s))&&(Ht=Zf(oe,"onBeforeInput"),0<Ht.length&&(at=new Xg("onBeforeInput","beforeinput",null,s,ye),Me.push({event:at,listeners:Ht}),at.data=Ct)),FT(Me,t,oe,s,ye)}Oy(Me,i)})}function ju(t,i,s){return{instance:t,listener:i,currentTarget:s}}function Zf(t,i){for(var s=i+"Capture",u=[];t!==null;){var h=t,m=h.stateNode;if(h=h.tag,h!==5&&h!==26&&h!==27||m===null||(h=mu(t,s),h!=null&&u.unshift(ju(t,h,m)),h=mu(t,i),h!=null&&u.push(ju(t,h,m))),t.tag===3)return u;t=t.return}return[]}function GT(t){if(t===null)return null;do t=t.return;while(t&&t.tag!==5&&t.tag!==27);return t||null}function zy(t,i,s,u,h){for(var m=i._reactName,E=[];s!==null&&s!==u;){var U=s,X=U.alternate,oe=U.stateNode;if(U=U.tag,X!==null&&X===u)break;U!==5&&U!==26&&U!==27||oe===null||(X=oe,h?(oe=mu(s,m),oe!=null&&E.unshift(ju(s,oe,X))):h||(oe=mu(s,m),oe!=null&&E.push(ju(s,oe,X)))),s=s.return}E.length!==0&&t.push({event:i,listeners:E})}var VT=/\r\n?/g,kT=/\u0000|\uFFFD/g;function Fy(t){return(typeof t=="string"?t:""+t).replace(VT,`
`).replace(kT,"")}function Iy(t,i){return i=Fy(i),Fy(t)===i}function un(t,i,s,u,h,m){switch(s){case"children":typeof u=="string"?i==="body"||i==="textarea"&&u===""||Ri(t,u):(typeof u=="number"||typeof u=="bigint")&&i!=="body"&&Ri(t,""+u);break;case"className":yt(t,"class",u);break;case"tabIndex":yt(t,"tabindex",u);break;case"dir":case"role":case"viewBox":case"width":case"height":yt(t,s,u);break;case"style":br(t,u,m);break;case"data":if(i!=="object"){yt(t,"data",u);break}case"src":case"href":if(u===""&&(i!=="a"||s!=="href")){t.removeAttribute(s);break}if(u==null||typeof u=="function"||typeof u=="symbol"||typeof u=="boolean"){t.removeAttribute(s);break}u=ef(""+u),t.setAttribute(s,u);break;case"action":case"formAction":if(typeof u=="function"){t.setAttribute(s,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof m=="function"&&(s==="formAction"?(i!=="input"&&un(t,i,"name",h.name,h,null),un(t,i,"formEncType",h.formEncType,h,null),un(t,i,"formMethod",h.formMethod,h,null),un(t,i,"formTarget",h.formTarget,h,null)):(un(t,i,"encType",h.encType,h,null),un(t,i,"method",h.method,h,null),un(t,i,"target",h.target,h,null)));if(u==null||typeof u=="symbol"||typeof u=="boolean"){t.removeAttribute(s);break}u=ef(""+u),t.setAttribute(s,u);break;case"onClick":u!=null&&(t.onclick=Er);break;case"onScroll":u!=null&&Ft("scroll",t);break;case"onScrollEnd":u!=null&&Ft("scrollend",t);break;case"dangerouslySetInnerHTML":if(u!=null){if(typeof u!="object"||!("__html"in u))throw Error(a(61));if(s=u.__html,s!=null){if(h.children!=null)throw Error(a(60));t.innerHTML=s}}break;case"multiple":t.multiple=u&&typeof u!="function"&&typeof u!="symbol";break;case"muted":t.muted=u&&typeof u!="function"&&typeof u!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(u==null||typeof u=="function"||typeof u=="boolean"||typeof u=="symbol"){t.removeAttribute("xlink:href");break}s=ef(""+u),t.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",s);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":u!=null&&typeof u!="function"&&typeof u!="symbol"?t.setAttribute(s,""+u):t.removeAttribute(s);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":u&&typeof u!="function"&&typeof u!="symbol"?t.setAttribute(s,""):t.removeAttribute(s);break;case"capture":case"download":u===!0?t.setAttribute(s,""):u!==!1&&u!=null&&typeof u!="function"&&typeof u!="symbol"?t.setAttribute(s,u):t.removeAttribute(s);break;case"cols":case"rows":case"size":case"span":u!=null&&typeof u!="function"&&typeof u!="symbol"&&!isNaN(u)&&1<=u?t.setAttribute(s,u):t.removeAttribute(s);break;case"rowSpan":case"start":u==null||typeof u=="function"||typeof u=="symbol"||isNaN(u)?t.removeAttribute(s):t.setAttribute(s,u);break;case"popover":Ft("beforetoggle",t),Ft("toggle",t),mt(t,"popover",u);break;case"xlinkActuate":Qe(t,"http://www.w3.org/1999/xlink","xlink:actuate",u);break;case"xlinkArcrole":Qe(t,"http://www.w3.org/1999/xlink","xlink:arcrole",u);break;case"xlinkRole":Qe(t,"http://www.w3.org/1999/xlink","xlink:role",u);break;case"xlinkShow":Qe(t,"http://www.w3.org/1999/xlink","xlink:show",u);break;case"xlinkTitle":Qe(t,"http://www.w3.org/1999/xlink","xlink:title",u);break;case"xlinkType":Qe(t,"http://www.w3.org/1999/xlink","xlink:type",u);break;case"xmlBase":Qe(t,"http://www.w3.org/XML/1998/namespace","xml:base",u);break;case"xmlLang":Qe(t,"http://www.w3.org/XML/1998/namespace","xml:lang",u);break;case"xmlSpace":Qe(t,"http://www.w3.org/XML/1998/namespace","xml:space",u);break;case"is":mt(t,"is",u);break;case"innerText":case"textContent":break;default:(!(2<s.length)||s[0]!=="o"&&s[0]!=="O"||s[1]!=="n"&&s[1]!=="N")&&(s=gE.get(s)||s,mt(t,s,u))}}function xm(t,i,s,u,h,m){switch(s){case"style":br(t,u,m);break;case"dangerouslySetInnerHTML":if(u!=null){if(typeof u!="object"||!("__html"in u))throw Error(a(61));if(s=u.__html,s!=null){if(h.children!=null)throw Error(a(60));t.innerHTML=s}}break;case"children":typeof u=="string"?Ri(t,u):(typeof u=="number"||typeof u=="bigint")&&Ri(t,""+u);break;case"onScroll":u!=null&&Ft("scroll",t);break;case"onScrollEnd":u!=null&&Ft("scrollend",t);break;case"onClick":u!=null&&(t.onclick=Er);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!se.hasOwnProperty(s))e:{if(s[0]==="o"&&s[1]==="n"&&(h=s.endsWith("Capture"),i=s.slice(2,h?s.length-7:void 0),m=t[xt]||null,m=m!=null?m[s]:null,typeof m=="function"&&t.removeEventListener(i,m,h),typeof u=="function")){typeof m!="function"&&m!==null&&(s in t?t[s]=null:t.hasAttribute(s)&&t.removeAttribute(s)),t.addEventListener(i,u,h);break e}s in t?t[s]=u:u===!0?t.setAttribute(s,""):mt(t,s,u)}}}function ci(t,i,s){switch(i){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":Ft("error",t),Ft("load",t);var u=!1,h=!1,m;for(m in s)if(s.hasOwnProperty(m)){var E=s[m];if(E!=null)switch(m){case"src":u=!0;break;case"srcSet":h=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(a(137,i));default:un(t,i,m,E,s,null)}}h&&un(t,i,"srcSet",s.srcSet,s,null),u&&un(t,i,"src",s.src,s,null);return;case"input":Ft("invalid",t);var U=m=E=h=null,X=null,oe=null;for(u in s)if(s.hasOwnProperty(u)){var ye=s[u];if(ye!=null)switch(u){case"name":h=ye;break;case"type":E=ye;break;case"checked":X=ye;break;case"defaultChecked":oe=ye;break;case"value":m=ye;break;case"defaultValue":U=ye;break;case"children":case"dangerouslySetInnerHTML":if(ye!=null)throw Error(a(137,i));break;default:un(t,i,u,ye,s,null)}}$i(t,m,U,X,oe,E,h,!1);return;case"select":Ft("invalid",t),u=E=m=null;for(h in s)if(s.hasOwnProperty(h)&&(U=s[h],U!=null))switch(h){case"value":m=U;break;case"defaultValue":E=U;break;case"multiple":u=U;default:un(t,i,h,U,s,null)}i=m,s=E,t.multiple=!!u,i!=null?ea(t,!!u,i,!1):s!=null&&ea(t,!!u,s,!0);return;case"textarea":Ft("invalid",t),m=h=u=null;for(E in s)if(s.hasOwnProperty(E)&&(U=s[E],U!=null))switch(E){case"value":u=U;break;case"defaultValue":h=U;break;case"children":m=U;break;case"dangerouslySetInnerHTML":if(U!=null)throw Error(a(91));break;default:un(t,i,E,U,s,null)}Bn(t,u,h,m);return;case"option":for(X in s)if(s.hasOwnProperty(X)&&(u=s[X],u!=null))switch(X){case"selected":t.selected=u&&typeof u!="function"&&typeof u!="symbol";break;default:un(t,i,X,u,s,null)}return;case"dialog":Ft("beforetoggle",t),Ft("toggle",t),Ft("cancel",t),Ft("close",t);break;case"iframe":case"object":Ft("load",t);break;case"video":case"audio":for(u=0;u<qu.length;u++)Ft(qu[u],t);break;case"image":Ft("error",t),Ft("load",t);break;case"details":Ft("toggle",t);break;case"embed":case"source":case"link":Ft("error",t),Ft("load",t);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(oe in s)if(s.hasOwnProperty(oe)&&(u=s[oe],u!=null))switch(oe){case"children":case"dangerouslySetInnerHTML":throw Error(a(137,i));default:un(t,i,oe,u,s,null)}return;default:if(Yo(i)){for(ye in s)s.hasOwnProperty(ye)&&(u=s[ye],u!==void 0&&xm(t,i,ye,u,s,void 0));return}}for(U in s)s.hasOwnProperty(U)&&(u=s[U],u!=null&&un(t,i,U,u,s,null))}function XT(t,i,s,u){switch(i){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var h=null,m=null,E=null,U=null,X=null,oe=null,ye=null;for(pe in s){var Me=s[pe];if(s.hasOwnProperty(pe)&&Me!=null)switch(pe){case"checked":break;case"value":break;case"defaultValue":X=Me;default:u.hasOwnProperty(pe)||un(t,i,pe,null,u,Me)}}for(var ce in u){var pe=u[ce];if(Me=s[ce],u.hasOwnProperty(ce)&&(pe!=null||Me!=null))switch(ce){case"type":m=pe;break;case"name":h=pe;break;case"checked":oe=pe;break;case"defaultChecked":ye=pe;break;case"value":E=pe;break;case"defaultValue":U=pe;break;case"children":case"dangerouslySetInnerHTML":if(pe!=null)throw Error(a(137,i));break;default:pe!==Me&&un(t,i,ce,pe,u,Me)}}Ai(t,E,U,X,oe,ye,m,h);return;case"select":pe=E=U=ce=null;for(m in s)if(X=s[m],s.hasOwnProperty(m)&&X!=null)switch(m){case"value":break;case"multiple":pe=X;default:u.hasOwnProperty(m)||un(t,i,m,null,u,X)}for(h in u)if(m=u[h],X=s[h],u.hasOwnProperty(h)&&(m!=null||X!=null))switch(h){case"value":ce=m;break;case"defaultValue":U=m;break;case"multiple":E=m;default:m!==X&&un(t,i,h,m,u,X)}i=U,s=E,u=pe,ce!=null?ea(t,!!s,ce,!1):!!u!=!!s&&(i!=null?ea(t,!!s,i,!0):ea(t,!!s,s?[]:"",!1));return;case"textarea":pe=ce=null;for(U in s)if(h=s[U],s.hasOwnProperty(U)&&h!=null&&!u.hasOwnProperty(U))switch(U){case"value":break;case"children":break;default:un(t,i,U,null,u,h)}for(E in u)if(h=u[E],m=s[E],u.hasOwnProperty(E)&&(h!=null||m!=null))switch(E){case"value":ce=h;break;case"defaultValue":pe=h;break;case"children":break;case"dangerouslySetInnerHTML":if(h!=null)throw Error(a(91));break;default:h!==m&&un(t,i,E,h,u,m)}$t(t,ce,pe);return;case"option":for(var $e in s)if(ce=s[$e],s.hasOwnProperty($e)&&ce!=null&&!u.hasOwnProperty($e))switch($e){case"selected":t.selected=!1;break;default:un(t,i,$e,null,u,ce)}for(X in u)if(ce=u[X],pe=s[X],u.hasOwnProperty(X)&&ce!==pe&&(ce!=null||pe!=null))switch(X){case"selected":t.selected=ce&&typeof ce!="function"&&typeof ce!="symbol";break;default:un(t,i,X,ce,u,pe)}return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var ft in s)ce=s[ft],s.hasOwnProperty(ft)&&ce!=null&&!u.hasOwnProperty(ft)&&un(t,i,ft,null,u,ce);for(oe in u)if(ce=u[oe],pe=s[oe],u.hasOwnProperty(oe)&&ce!==pe&&(ce!=null||pe!=null))switch(oe){case"children":case"dangerouslySetInnerHTML":if(ce!=null)throw Error(a(137,i));break;default:un(t,i,oe,ce,u,pe)}return;default:if(Yo(i)){for(var cn in s)ce=s[cn],s.hasOwnProperty(cn)&&ce!==void 0&&!u.hasOwnProperty(cn)&&xm(t,i,cn,void 0,u,ce);for(ye in u)ce=u[ye],pe=s[ye],!u.hasOwnProperty(ye)||ce===pe||ce===void 0&&pe===void 0||xm(t,i,ye,ce,u,pe);return}}for(var ee in s)ce=s[ee],s.hasOwnProperty(ee)&&ce!=null&&!u.hasOwnProperty(ee)&&un(t,i,ee,null,u,ce);for(Me in u)ce=u[Me],pe=s[Me],!u.hasOwnProperty(Me)||ce===pe||ce==null&&pe==null||un(t,i,Me,ce,u,pe)}function By(t){switch(t){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function WT(){if(typeof performance.getEntriesByType=="function"){for(var t=0,i=0,s=performance.getEntriesByType("resource"),u=0;u<s.length;u++){var h=s[u],m=h.transferSize,E=h.initiatorType,U=h.duration;if(m&&U&&By(E)){for(E=0,U=h.responseEnd,u+=1;u<s.length;u++){var X=s[u],oe=X.startTime;if(oe>U)break;var ye=X.transferSize,Me=X.initiatorType;ye&&By(Me)&&(X=X.responseEnd,E+=ye*(X<U?1:(U-oe)/(X-oe)))}if(--u,i+=8*(m+E)/(h.duration/1e3),t++,10<t)break}}if(0<t)return i/t/1e6}return navigator.connection&&(t=navigator.connection.downlink,typeof t=="number")?t:5}var ym=null,Sm=null;function Kf(t){return t.nodeType===9?t:t.ownerDocument}function Hy(t){switch(t){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function Gy(t,i){if(t===0)switch(i){case"svg":return 1;case"math":return 2;default:return 0}return t===1&&i==="foreignObject"?0:t}function Mm(t,i){return t==="textarea"||t==="noscript"||typeof i.children=="string"||typeof i.children=="number"||typeof i.children=="bigint"||typeof i.dangerouslySetInnerHTML=="object"&&i.dangerouslySetInnerHTML!==null&&i.dangerouslySetInnerHTML.__html!=null}var bm=null;function YT(){var t=window.event;return t&&t.type==="popstate"?t===bm?!1:(bm=t,!0):(bm=null,!1)}var Vy=typeof setTimeout=="function"?setTimeout:void 0,qT=typeof clearTimeout=="function"?clearTimeout:void 0,ky=typeof Promise=="function"?Promise:void 0,jT=typeof queueMicrotask=="function"?queueMicrotask:typeof ky<"u"?function(t){return ky.resolve(null).then(t).catch(ZT)}:Vy;function ZT(t){setTimeout(function(){throw t})}function Es(t){return t==="head"}function Xy(t,i){var s=i,u=0;do{var h=s.nextSibling;if(t.removeChild(s),h&&h.nodeType===8)if(s=h.data,s==="/$"||s==="/&"){if(u===0){t.removeChild(h),bl(i);return}u--}else if(s==="$"||s==="$?"||s==="$~"||s==="$!"||s==="&")u++;else if(s==="html")Zu(t.ownerDocument.documentElement);else if(s==="head"){s=t.ownerDocument.head,Zu(s);for(var m=s.firstChild;m;){var E=m.nextSibling,U=m.nodeName;m[gn]||U==="SCRIPT"||U==="STYLE"||U==="LINK"&&m.rel.toLowerCase()==="stylesheet"||s.removeChild(m),m=E}}else s==="body"&&Zu(t.ownerDocument.body);s=h}while(s);bl(i)}function Wy(t,i){var s=t;t=0;do{var u=s.nextSibling;if(s.nodeType===1?i?(s._stashedDisplay=s.style.display,s.style.display="none"):(s.style.display=s._stashedDisplay||"",s.getAttribute("style")===""&&s.removeAttribute("style")):s.nodeType===3&&(i?(s._stashedText=s.nodeValue,s.nodeValue=""):s.nodeValue=s._stashedText||""),u&&u.nodeType===8)if(s=u.data,s==="/$"){if(t===0)break;t--}else s!=="$"&&s!=="$?"&&s!=="$~"&&s!=="$!"||t++;s=u}while(s)}function Em(t){var i=t.firstChild;for(i&&i.nodeType===10&&(i=i.nextSibling);i;){var s=i;switch(i=i.nextSibling,s.nodeName){case"HTML":case"HEAD":case"BODY":Em(s),Tn(s);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(s.rel.toLowerCase()==="stylesheet")continue}t.removeChild(s)}}function KT(t,i,s,u){for(;t.nodeType===1;){var h=s;if(t.nodeName.toLowerCase()!==i.toLowerCase()){if(!u&&(t.nodeName!=="INPUT"||t.type!=="hidden"))break}else if(u){if(!t[gn])switch(i){case"meta":if(!t.hasAttribute("itemprop"))break;return t;case"link":if(m=t.getAttribute("rel"),m==="stylesheet"&&t.hasAttribute("data-precedence"))break;if(m!==h.rel||t.getAttribute("href")!==(h.href==null||h.href===""?null:h.href)||t.getAttribute("crossorigin")!==(h.crossOrigin==null?null:h.crossOrigin)||t.getAttribute("title")!==(h.title==null?null:h.title))break;return t;case"style":if(t.hasAttribute("data-precedence"))break;return t;case"script":if(m=t.getAttribute("src"),(m!==(h.src==null?null:h.src)||t.getAttribute("type")!==(h.type==null?null:h.type)||t.getAttribute("crossorigin")!==(h.crossOrigin==null?null:h.crossOrigin))&&m&&t.hasAttribute("async")&&!t.hasAttribute("itemprop"))break;return t;default:return t}}else if(i==="input"&&t.type==="hidden"){var m=h.name==null?null:""+h.name;if(h.type==="hidden"&&t.getAttribute("name")===m)return t}else return t;if(t=Ca(t.nextSibling),t===null)break}return null}function QT(t,i,s){if(i==="")return null;for(;t.nodeType!==3;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!s||(t=Ca(t.nextSibling),t===null))return null;return t}function Yy(t,i){for(;t.nodeType!==8;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!i||(t=Ca(t.nextSibling),t===null))return null;return t}function Tm(t){return t.data==="$?"||t.data==="$~"}function Am(t){return t.data==="$!"||t.data==="$?"&&t.ownerDocument.readyState!=="loading"}function JT(t,i){var s=t.ownerDocument;if(t.data==="$~")t._reactRetry=i;else if(t.data!=="$?"||s.readyState!=="loading")i();else{var u=function(){i(),s.removeEventListener("DOMContentLoaded",u)};s.addEventListener("DOMContentLoaded",u),t._reactRetry=u}}function Ca(t){for(;t!=null;t=t.nextSibling){var i=t.nodeType;if(i===1||i===3)break;if(i===8){if(i=t.data,i==="$"||i==="$!"||i==="$?"||i==="$~"||i==="&"||i==="F!"||i==="F")break;if(i==="/$"||i==="/&")return null}}return t}var Rm=null;function qy(t){t=t.nextSibling;for(var i=0;t;){if(t.nodeType===8){var s=t.data;if(s==="/$"||s==="/&"){if(i===0)return Ca(t.nextSibling);i--}else s!=="$"&&s!=="$!"&&s!=="$?"&&s!=="$~"&&s!=="&"||i++}t=t.nextSibling}return null}function jy(t){t=t.previousSibling;for(var i=0;t;){if(t.nodeType===8){var s=t.data;if(s==="$"||s==="$!"||s==="$?"||s==="$~"||s==="&"){if(i===0)return t;i--}else s!=="/$"&&s!=="/&"||i++}t=t.previousSibling}return null}function Zy(t,i,s){switch(i=Kf(s),t){case"html":if(t=i.documentElement,!t)throw Error(a(452));return t;case"head":if(t=i.head,!t)throw Error(a(453));return t;case"body":if(t=i.body,!t)throw Error(a(454));return t;default:throw Error(a(451))}}function Zu(t){for(var i=t.attributes;i.length;)t.removeAttributeNode(i[0]);Tn(t)}var wa=new Map,Ky=new Set;function Qf(t){return typeof t.getRootNode=="function"?t.getRootNode():t.nodeType===9?t:t.ownerDocument}var Hr=I.d;I.d={f:$T,r:eA,D:tA,C:nA,L:iA,m:aA,X:sA,S:rA,M:oA};function $T(){var t=Hr.f(),i=Vf();return t||i}function eA(t){var i=pi(t);i!==null&&i.tag===5&&i.type==="form"?dx(i):Hr.r(t)}var yl=typeof document>"u"?null:document;function Qy(t,i,s){var u=yl;if(u&&typeof i=="string"&&i){var h=vt(i);h='link[rel="'+t+'"][href="'+h+'"]',typeof s=="string"&&(h+='[crossorigin="'+s+'"]'),Ky.has(h)||(Ky.add(h),t={rel:t,crossOrigin:s,href:i},u.querySelector(h)===null&&(i=u.createElement("link"),ci(i,"link",t),Y(i),u.head.appendChild(i)))}}function tA(t){Hr.D(t),Qy("dns-prefetch",t,null)}function nA(t,i){Hr.C(t,i),Qy("preconnect",t,i)}function iA(t,i,s){Hr.L(t,i,s);var u=yl;if(u&&t&&i){var h='link[rel="preload"][as="'+vt(i)+'"]';i==="image"&&s&&s.imageSrcSet?(h+='[imagesrcset="'+vt(s.imageSrcSet)+'"]',typeof s.imageSizes=="string"&&(h+='[imagesizes="'+vt(s.imageSizes)+'"]')):h+='[href="'+vt(t)+'"]';var m=h;switch(i){case"style":m=Sl(t);break;case"script":m=Ml(t)}wa.has(m)||(t=v({rel:"preload",href:i==="image"&&s&&s.imageSrcSet?void 0:t,as:i},s),wa.set(m,t),u.querySelector(h)!==null||i==="style"&&u.querySelector(Ku(m))||i==="script"&&u.querySelector(Qu(m))||(i=u.createElement("link"),ci(i,"link",t),Y(i),u.head.appendChild(i)))}}function aA(t,i){Hr.m(t,i);var s=yl;if(s&&t){var u=i&&typeof i.as=="string"?i.as:"script",h='link[rel="modulepreload"][as="'+vt(u)+'"][href="'+vt(t)+'"]',m=h;switch(u){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":m=Ml(t)}if(!wa.has(m)&&(t=v({rel:"modulepreload",href:t},i),wa.set(m,t),s.querySelector(h)===null)){switch(u){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(s.querySelector(Qu(m)))return}u=s.createElement("link"),ci(u,"link",t),Y(u),s.head.appendChild(u)}}}function rA(t,i,s){Hr.S(t,i,s);var u=yl;if(u&&t){var h=D(u).hoistableStyles,m=Sl(t);i=i||"default";var E=h.get(m);if(!E){var U={loading:0,preload:null};if(E=u.querySelector(Ku(m)))U.loading=5;else{t=v({rel:"stylesheet",href:t,"data-precedence":i},s),(s=wa.get(m))&&Cm(t,s);var X=E=u.createElement("link");Y(X),ci(X,"link",t),X._p=new Promise(function(oe,ye){X.onload=oe,X.onerror=ye}),X.addEventListener("load",function(){U.loading|=1}),X.addEventListener("error",function(){U.loading|=2}),U.loading|=4,Jf(E,i,u)}E={type:"stylesheet",instance:E,count:1,state:U},h.set(m,E)}}}function sA(t,i){Hr.X(t,i);var s=yl;if(s&&t){var u=D(s).hoistableScripts,h=Ml(t),m=u.get(h);m||(m=s.querySelector(Qu(h)),m||(t=v({src:t,async:!0},i),(i=wa.get(h))&&wm(t,i),m=s.createElement("script"),Y(m),ci(m,"link",t),s.head.appendChild(m)),m={type:"script",instance:m,count:1,state:null},u.set(h,m))}}function oA(t,i){Hr.M(t,i);var s=yl;if(s&&t){var u=D(s).hoistableScripts,h=Ml(t),m=u.get(h);m||(m=s.querySelector(Qu(h)),m||(t=v({src:t,async:!0,type:"module"},i),(i=wa.get(h))&&wm(t,i),m=s.createElement("script"),Y(m),ci(m,"link",t),s.head.appendChild(m)),m={type:"script",instance:m,count:1,state:null},u.set(h,m))}}function Jy(t,i,s,u){var h=(h=ne.current)?Qf(h):null;if(!h)throw Error(a(446));switch(t){case"meta":case"title":return null;case"style":return typeof s.precedence=="string"&&typeof s.href=="string"?(i=Sl(s.href),s=D(h).hoistableStyles,u=s.get(i),u||(u={type:"style",instance:null,count:0,state:null},s.set(i,u)),u):{type:"void",instance:null,count:0,state:null};case"link":if(s.rel==="stylesheet"&&typeof s.href=="string"&&typeof s.precedence=="string"){t=Sl(s.href);var m=D(h).hoistableStyles,E=m.get(t);if(E||(h=h.ownerDocument||h,E={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},m.set(t,E),(m=h.querySelector(Ku(t)))&&!m._p&&(E.instance=m,E.state.loading=5),wa.has(t)||(s={rel:"preload",as:"style",href:s.href,crossOrigin:s.crossOrigin,integrity:s.integrity,media:s.media,hrefLang:s.hrefLang,referrerPolicy:s.referrerPolicy},wa.set(t,s),m||lA(h,t,s,E.state))),i&&u===null)throw Error(a(528,""));return E}if(i&&u!==null)throw Error(a(529,""));return null;case"script":return i=s.async,s=s.src,typeof s=="string"&&i&&typeof i!="function"&&typeof i!="symbol"?(i=Ml(s),s=D(h).hoistableScripts,u=s.get(i),u||(u={type:"script",instance:null,count:0,state:null},s.set(i,u)),u):{type:"void",instance:null,count:0,state:null};default:throw Error(a(444,t))}}function Sl(t){return'href="'+vt(t)+'"'}function Ku(t){return'link[rel="stylesheet"]['+t+"]"}function $y(t){return v({},t,{"data-precedence":t.precedence,precedence:null})}function lA(t,i,s,u){t.querySelector('link[rel="preload"][as="style"]['+i+"]")?u.loading=1:(i=t.createElement("link"),u.preload=i,i.addEventListener("load",function(){return u.loading|=1}),i.addEventListener("error",function(){return u.loading|=2}),ci(i,"link",s),Y(i),t.head.appendChild(i))}function Ml(t){return'[src="'+vt(t)+'"]'}function Qu(t){return"script[async]"+t}function eS(t,i,s){if(i.count++,i.instance===null)switch(i.type){case"style":var u=t.querySelector('style[data-href~="'+vt(s.href)+'"]');if(u)return i.instance=u,Y(u),u;var h=v({},s,{"data-href":s.href,"data-precedence":s.precedence,href:null,precedence:null});return u=(t.ownerDocument||t).createElement("style"),Y(u),ci(u,"style",h),Jf(u,s.precedence,t),i.instance=u;case"stylesheet":h=Sl(s.href);var m=t.querySelector(Ku(h));if(m)return i.state.loading|=4,i.instance=m,Y(m),m;u=$y(s),(h=wa.get(h))&&Cm(u,h),m=(t.ownerDocument||t).createElement("link"),Y(m);var E=m;return E._p=new Promise(function(U,X){E.onload=U,E.onerror=X}),ci(m,"link",u),i.state.loading|=4,Jf(m,s.precedence,t),i.instance=m;case"script":return m=Ml(s.src),(h=t.querySelector(Qu(m)))?(i.instance=h,Y(h),h):(u=s,(h=wa.get(m))&&(u=v({},s),wm(u,h)),t=t.ownerDocument||t,h=t.createElement("script"),Y(h),ci(h,"link",u),t.head.appendChild(h),i.instance=h);case"void":return null;default:throw Error(a(443,i.type))}else i.type==="stylesheet"&&(i.state.loading&4)===0&&(u=i.instance,i.state.loading|=4,Jf(u,s.precedence,t));return i.instance}function Jf(t,i,s){for(var u=s.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),h=u.length?u[u.length-1]:null,m=h,E=0;E<u.length;E++){var U=u[E];if(U.dataset.precedence===i)m=U;else if(m!==h)break}m?m.parentNode.insertBefore(t,m.nextSibling):(i=s.nodeType===9?s.head:s,i.insertBefore(t,i.firstChild))}function Cm(t,i){t.crossOrigin==null&&(t.crossOrigin=i.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=i.referrerPolicy),t.title==null&&(t.title=i.title)}function wm(t,i){t.crossOrigin==null&&(t.crossOrigin=i.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=i.referrerPolicy),t.integrity==null&&(t.integrity=i.integrity)}var $f=null;function tS(t,i,s){if($f===null){var u=new Map,h=$f=new Map;h.set(s,u)}else h=$f,u=h.get(s),u||(u=new Map,h.set(s,u));if(u.has(t))return u;for(u.set(t,null),s=s.getElementsByTagName(t),h=0;h<s.length;h++){var m=s[h];if(!(m[gn]||m[Tt]||t==="link"&&m.getAttribute("rel")==="stylesheet")&&m.namespaceURI!=="http://www.w3.org/2000/svg"){var E=m.getAttribute(i)||"";E=t+E;var U=u.get(E);U?U.push(m):u.set(E,[m])}}return u}function nS(t,i,s){t=t.ownerDocument||t,t.head.insertBefore(s,i==="title"?t.querySelector("head > title"):null)}function uA(t,i,s){if(s===1||i.itemProp!=null)return!1;switch(t){case"meta":case"title":return!0;case"style":if(typeof i.precedence!="string"||typeof i.href!="string"||i.href==="")break;return!0;case"link":if(typeof i.rel!="string"||typeof i.href!="string"||i.href===""||i.onLoad||i.onError)break;switch(i.rel){case"stylesheet":return t=i.disabled,typeof i.precedence=="string"&&t==null;default:return!0}case"script":if(i.async&&typeof i.async!="function"&&typeof i.async!="symbol"&&!i.onLoad&&!i.onError&&i.src&&typeof i.src=="string")return!0}return!1}function iS(t){return!(t.type==="stylesheet"&&(t.state.loading&3)===0)}function cA(t,i,s,u){if(s.type==="stylesheet"&&(typeof u.media!="string"||matchMedia(u.media).matches!==!1)&&(s.state.loading&4)===0){if(s.instance===null){var h=Sl(u.href),m=i.querySelector(Ku(h));if(m){i=m._p,i!==null&&typeof i=="object"&&typeof i.then=="function"&&(t.count++,t=eh.bind(t),i.then(t,t)),s.state.loading|=4,s.instance=m,Y(m);return}m=i.ownerDocument||i,u=$y(u),(h=wa.get(h))&&Cm(u,h),m=m.createElement("link"),Y(m);var E=m;E._p=new Promise(function(U,X){E.onload=U,E.onerror=X}),ci(m,"link",u),s.instance=m}t.stylesheets===null&&(t.stylesheets=new Map),t.stylesheets.set(s,i),(i=s.state.preload)&&(s.state.loading&3)===0&&(t.count++,s=eh.bind(t),i.addEventListener("load",s),i.addEventListener("error",s))}}var Dm=0;function fA(t,i){return t.stylesheets&&t.count===0&&nh(t,t.stylesheets),0<t.count||0<t.imgCount?function(s){var u=setTimeout(function(){if(t.stylesheets&&nh(t,t.stylesheets),t.unsuspend){var m=t.unsuspend;t.unsuspend=null,m()}},6e4+i);0<t.imgBytes&&Dm===0&&(Dm=62500*WT());var h=setTimeout(function(){if(t.waitingForImages=!1,t.count===0&&(t.stylesheets&&nh(t,t.stylesheets),t.unsuspend)){var m=t.unsuspend;t.unsuspend=null,m()}},(t.imgBytes>Dm?50:800)+i);return t.unsuspend=s,function(){t.unsuspend=null,clearTimeout(u),clearTimeout(h)}}:null}function eh(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)nh(this,this.stylesheets);else if(this.unsuspend){var t=this.unsuspend;this.unsuspend=null,t()}}}var th=null;function nh(t,i){t.stylesheets=null,t.unsuspend!==null&&(t.count++,th=new Map,i.forEach(hA,t),th=null,eh.call(t))}function hA(t,i){if(!(i.state.loading&4)){var s=th.get(t);if(s)var u=s.get(null);else{s=new Map,th.set(t,s);for(var h=t.querySelectorAll("link[data-precedence],style[data-precedence]"),m=0;m<h.length;m++){var E=h[m];(E.nodeName==="LINK"||E.getAttribute("media")!=="not all")&&(s.set(E.dataset.precedence,E),u=E)}u&&s.set(null,u)}h=i.instance,E=h.getAttribute("data-precedence"),m=s.get(E)||u,m===u&&s.set(null,h),s.set(E,h),this.count++,u=eh.bind(this),h.addEventListener("load",u),h.addEventListener("error",u),m?m.parentNode.insertBefore(h,m.nextSibling):(t=t.nodeType===9?t.head:t,t.insertBefore(h,t.firstChild)),i.state.loading|=4}}var Ju={$$typeof:N,Provider:null,Consumer:null,_currentValue:ie,_currentValue2:ie,_threadCount:0};function dA(t,i,s,u,h,m,E,U,X){this.tag=1,this.containerInfo=t,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Ve(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Ve(0),this.hiddenUpdates=Ve(null),this.identifierPrefix=u,this.onUncaughtError=h,this.onCaughtError=m,this.onRecoverableError=E,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=X,this.incompleteTransitions=new Map}function aS(t,i,s,u,h,m,E,U,X,oe,ye,Me){return t=new dA(t,i,s,E,X,oe,ye,Me,U),i=1,m===!0&&(i|=24),m=na(3,null,null,i),t.current=m,m.stateNode=t,i=up(),i.refCount++,t.pooledCache=i,i.refCount++,m.memoizedState={element:u,isDehydrated:s,cache:i},dp(m),t}function rS(t){return t?(t=$o,t):$o}function sS(t,i,s,u,h,m){h=rS(h),u.context===null?u.context=h:u.pendingContext=h,u=ds(i),u.payload={element:s},m=m===void 0?null:m,m!==null&&(u.callback=m),s=ps(t,u,i),s!==null&&(ki(s,t,i),Du(s,t,i))}function oS(t,i){if(t=t.memoizedState,t!==null&&t.dehydrated!==null){var s=t.retryLane;t.retryLane=s!==0&&s<i?s:i}}function Nm(t,i){oS(t,i),(t=t.alternate)&&oS(t,i)}function lS(t){if(t.tag===13||t.tag===31){var i=no(t,67108864);i!==null&&ki(i,t,67108864),Nm(t,67108864)}}function uS(t){if(t.tag===13||t.tag===31){var i=oa();i=dt(i);var s=no(t,i);s!==null&&ki(s,t,i),Nm(t,i)}}var ih=!0;function pA(t,i,s,u){var h=z.T;z.T=null;var m=I.p;try{I.p=2,Um(t,i,s,u)}finally{I.p=m,z.T=h}}function mA(t,i,s,u){var h=z.T;z.T=null;var m=I.p;try{I.p=8,Um(t,i,s,u)}finally{I.p=m,z.T=h}}function Um(t,i,s,u){if(ih){var h=Lm(u);if(h===null)vm(t,i,u,ah,s),fS(t,u);else if(gA(h,t,i,s,u))u.stopPropagation();else if(fS(t,u),i&4&&-1<_A.indexOf(t)){for(;h!==null;){var m=pi(h);if(m!==null)switch(m.tag){case 3:if(m=m.stateNode,m.current.memoizedState.isDehydrated){var E=Ee(m.pendingLanes);if(E!==0){var U=m;for(U.pendingLanes|=2,U.entangledLanes|=2;E;){var X=1<<31-Pe(E);U.entanglements[1]|=X,E&=~X}ar(m),(Jt&6)===0&&(Hf=A()+500,Yu(0))}}break;case 31:case 13:U=no(m,2),U!==null&&ki(U,m,2),Vf(),Nm(m,2)}if(m=Lm(u),m===null&&vm(t,i,u,ah,s),m===h)break;h=m}h!==null&&u.stopPropagation()}else vm(t,i,u,null,s)}}function Lm(t){return t=Pd(t),Om(t)}var ah=null;function Om(t){if(ah=null,t=vn(t),t!==null){var i=l(t);if(i===null)t=null;else{var s=i.tag;if(s===13){if(t=c(i),t!==null)return t;t=null}else if(s===31){if(t=f(i),t!==null)return t;t=null}else if(s===3){if(i.stateNode.current.memoizedState.isDehydrated)return i.tag===3?i.stateNode.containerInfo:null;t=null}else i!==t&&(t=null)}}return ah=t,null}function cS(t){switch(t){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(Z()){case ge:return 2;case ve:return 8;case de:case Ge:return 32;case we:return 268435456;default:return 32}default:return 32}}var Pm=!1,Ts=null,As=null,Rs=null,$u=new Map,ec=new Map,Cs=[],_A="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function fS(t,i){switch(t){case"focusin":case"focusout":Ts=null;break;case"dragenter":case"dragleave":As=null;break;case"mouseover":case"mouseout":Rs=null;break;case"pointerover":case"pointerout":$u.delete(i.pointerId);break;case"gotpointercapture":case"lostpointercapture":ec.delete(i.pointerId)}}function tc(t,i,s,u,h,m){return t===null||t.nativeEvent!==m?(t={blockedOn:i,domEventName:s,eventSystemFlags:u,nativeEvent:m,targetContainers:[h]},i!==null&&(i=pi(i),i!==null&&lS(i)),t):(t.eventSystemFlags|=u,i=t.targetContainers,h!==null&&i.indexOf(h)===-1&&i.push(h),t)}function gA(t,i,s,u,h){switch(i){case"focusin":return Ts=tc(Ts,t,i,s,u,h),!0;case"dragenter":return As=tc(As,t,i,s,u,h),!0;case"mouseover":return Rs=tc(Rs,t,i,s,u,h),!0;case"pointerover":var m=h.pointerId;return $u.set(m,tc($u.get(m)||null,t,i,s,u,h)),!0;case"gotpointercapture":return m=h.pointerId,ec.set(m,tc(ec.get(m)||null,t,i,s,u,h)),!0}return!1}function hS(t){var i=vn(t.target);if(i!==null){var s=l(i);if(s!==null){if(i=s.tag,i===13){if(i=c(s),i!==null){t.blockedOn=i,rn(t.priority,function(){uS(s)});return}}else if(i===31){if(i=f(s),i!==null){t.blockedOn=i,rn(t.priority,function(){uS(s)});return}}else if(i===3&&s.stateNode.current.memoizedState.isDehydrated){t.blockedOn=s.tag===3?s.stateNode.containerInfo:null;return}}}t.blockedOn=null}function rh(t){if(t.blockedOn!==null)return!1;for(var i=t.targetContainers;0<i.length;){var s=Lm(t.nativeEvent);if(s===null){s=t.nativeEvent;var u=new s.constructor(s.type,s);Od=u,s.target.dispatchEvent(u),Od=null}else return i=pi(s),i!==null&&lS(i),t.blockedOn=s,!1;i.shift()}return!0}function dS(t,i,s){rh(t)&&s.delete(i)}function vA(){Pm=!1,Ts!==null&&rh(Ts)&&(Ts=null),As!==null&&rh(As)&&(As=null),Rs!==null&&rh(Rs)&&(Rs=null),$u.forEach(dS),ec.forEach(dS)}function sh(t,i){t.blockedOn===i&&(t.blockedOn=null,Pm||(Pm=!0,o.unstable_scheduleCallback(o.unstable_NormalPriority,vA)))}var oh=null;function pS(t){oh!==t&&(oh=t,o.unstable_scheduleCallback(o.unstable_NormalPriority,function(){oh===t&&(oh=null);for(var i=0;i<t.length;i+=3){var s=t[i],u=t[i+1],h=t[i+2];if(typeof u!="function"){if(Om(u||s)===null)continue;break}var m=pi(s);m!==null&&(t.splice(i,3),i-=3,Lp(m,{pending:!0,data:h,method:s.method,action:u},u,h))}}))}function bl(t){function i(X){return sh(X,t)}Ts!==null&&sh(Ts,t),As!==null&&sh(As,t),Rs!==null&&sh(Rs,t),$u.forEach(i),ec.forEach(i);for(var s=0;s<Cs.length;s++){var u=Cs[s];u.blockedOn===t&&(u.blockedOn=null)}for(;0<Cs.length&&(s=Cs[0],s.blockedOn===null);)hS(s),s.blockedOn===null&&Cs.shift();if(s=(t.ownerDocument||t).$$reactFormReplay,s!=null)for(u=0;u<s.length;u+=3){var h=s[u],m=s[u+1],E=h[xt]||null;if(typeof m=="function")E||pS(s);else if(E){var U=null;if(m&&m.hasAttribute("formAction")){if(h=m,E=m[xt]||null)U=E.formAction;else if(Om(h)!==null)continue}else U=E.action;typeof U=="function"?s[u+1]=U:(s.splice(u,3),u-=3),pS(s)}}}function mS(){function t(m){m.canIntercept&&m.info==="react-transition"&&m.intercept({handler:function(){return new Promise(function(E){return h=E})},focusReset:"manual",scroll:"manual"})}function i(){h!==null&&(h(),h=null),u||setTimeout(s,20)}function s(){if(!u&&!navigation.transition){var m=navigation.currentEntry;m&&m.url!=null&&navigation.navigate(m.url,{state:m.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var u=!1,h=null;return navigation.addEventListener("navigate",t),navigation.addEventListener("navigatesuccess",i),navigation.addEventListener("navigateerror",i),setTimeout(s,100),function(){u=!0,navigation.removeEventListener("navigate",t),navigation.removeEventListener("navigatesuccess",i),navigation.removeEventListener("navigateerror",i),h!==null&&(h(),h=null)}}}function zm(t){this._internalRoot=t}lh.prototype.render=zm.prototype.render=function(t){var i=this._internalRoot;if(i===null)throw Error(a(409));var s=i.current,u=oa();sS(s,u,t,i,null,null)},lh.prototype.unmount=zm.prototype.unmount=function(){var t=this._internalRoot;if(t!==null){this._internalRoot=null;var i=t.containerInfo;sS(t.current,2,null,t,null,null),Vf(),i[Pt]=null}};function lh(t){this._internalRoot=t}lh.prototype.unstable_scheduleHydration=function(t){if(t){var i=gt();t={blockedOn:null,target:t,priority:i};for(var s=0;s<Cs.length&&i!==0&&i<Cs[s].priority;s++);Cs.splice(s,0,t),s===0&&hS(t)}};var _S=e.version;if(_S!=="19.2.4")throw Error(a(527,_S,"19.2.4"));I.findDOMNode=function(t){var i=t._reactInternals;if(i===void 0)throw typeof t.render=="function"?Error(a(188)):(t=Object.keys(t).join(","),Error(a(268,t)));return t=d(i),t=t!==null?_(t):null,t=t===null?null:t.stateNode,t};var xA={bundleType:0,version:"19.2.4",rendererPackageName:"react-dom",currentDispatcherRef:z,reconcilerVersion:"19.2.4"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var uh=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!uh.isDisabled&&uh.supportsFiber)try{Re=uh.inject(xA),Ae=uh}catch{}}return ic.createRoot=function(t,i){if(!r(t))throw Error(a(299));var s=!1,u="",h=bx,m=Ex,E=Tx;return i!=null&&(i.unstable_strictMode===!0&&(s=!0),i.identifierPrefix!==void 0&&(u=i.identifierPrefix),i.onUncaughtError!==void 0&&(h=i.onUncaughtError),i.onCaughtError!==void 0&&(m=i.onCaughtError),i.onRecoverableError!==void 0&&(E=i.onRecoverableError)),i=aS(t,1,!1,null,null,s,u,null,h,m,E,mS),t[Pt]=i.current,gm(t),new zm(i)},ic.hydrateRoot=function(t,i,s){if(!r(t))throw Error(a(299));var u=!1,h="",m=bx,E=Ex,U=Tx,X=null;return s!=null&&(s.unstable_strictMode===!0&&(u=!0),s.identifierPrefix!==void 0&&(h=s.identifierPrefix),s.onUncaughtError!==void 0&&(m=s.onUncaughtError),s.onCaughtError!==void 0&&(E=s.onCaughtError),s.onRecoverableError!==void 0&&(U=s.onRecoverableError),s.formState!==void 0&&(X=s.formState)),i=aS(t,1,!0,i,s??null,u,h,X,m,E,U,mS),i.context=rS(null),s=i.current,u=oa(),u=dt(u),h=ds(u),h.callback=null,ps(s,h,u),s=u,i.current.lanes=s,Je(i,s),ar(i),t[Pt]=i.current,gm(t),new lh(i)},ic.version="19.2.4",ic}var AS;function wA(){if(AS)return Bm.exports;AS=1;function o(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(o)}catch(e){console.error(e)}}return o(),Bm.exports=CA(),Bm.exports}var DA=wA();/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const tg="183",NA=0,RS=1,UA=2,jh=1,LA=2,pc=3,qs=0,Yi=1,jr=2,Jr=0,Yl=1,CS=2,wS=3,DS=4,OA=5,Co=100,PA=101,zA=102,FA=103,IA=104,BA=200,HA=201,GA=202,VA=203,F_=204,I_=205,kA=206,XA=207,WA=208,YA=209,qA=210,jA=211,ZA=212,KA=213,QA=214,B_=0,H_=1,G_=2,eu=3,V_=4,k_=5,X_=6,W_=7,f1=0,JA=1,$A=2,gr=0,h1=1,d1=2,p1=3,m1=4,_1=5,g1=6,v1=7,x1=300,Go=301,tu=302,km=303,Xm=304,Td=306,Y_=1e3,Kr=1001,q_=1002,fi=1003,eR=1004,ch=1005,Mi=1006,Wm=1007,Do=1008,za=1009,y1=1010,S1=1011,Fc=1012,ng=1013,Sr=1014,dr=1015,ts=1016,ig=1017,ag=1018,Ic=1020,M1=35902,b1=35899,E1=1021,T1=1022,Ja=1023,ns=1026,No=1027,A1=1028,rg=1029,nu=1030,sg=1031,og=1033,Zh=33776,Kh=33777,Qh=33778,Jh=33779,j_=35840,Z_=35841,K_=35842,Q_=35843,J_=36196,$_=37492,e0=37496,t0=37488,n0=37489,i0=37490,a0=37491,r0=37808,s0=37809,o0=37810,l0=37811,u0=37812,c0=37813,f0=37814,h0=37815,d0=37816,p0=37817,m0=37818,_0=37819,g0=37820,v0=37821,x0=36492,y0=36494,S0=36495,M0=36283,b0=36284,E0=36285,T0=36286,tR=3200,nR=0,iR=1,Fs="",Ua="srgb",iu="srgb-linear",ud="linear",an="srgb",El=7680,NS=519,aR=512,rR=513,sR=514,lg=515,oR=516,lR=517,ug=518,uR=519,US=35044,LS="300 es",pr=2e3,cd=2001;function cR(o){for(let e=o.length-1;e>=0;--e)if(o[e]>=65535)return!0;return!1}function fd(o){return document.createElementNS("http://www.w3.org/1999/xhtml",o)}function fR(){const o=fd("canvas");return o.style.display="block",o}const OS={};function PS(...o){const e="THREE."+o.shift();console.log(e,...o)}function R1(o){const e=o[0];if(typeof e=="string"&&e.startsWith("TSL:")){const n=o[1];n&&n.isStackTrace?o[0]+=" "+n.getLocation():o[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return o}function Mt(...o){o=R1(o);const e="THREE."+o.shift();{const n=o[0];n&&n.isStackTrace?console.warn(n.getError(e)):console.warn(e,...o)}}function Qt(...o){o=R1(o);const e="THREE."+o.shift();{const n=o[0];n&&n.isStackTrace?console.error(n.getError(e)):console.error(e,...o)}}function hd(...o){const e=o.join(" ");e in OS||(OS[e]=!0,Mt(...o))}function hR(o,e,n){return new Promise(function(a,r){function l(){switch(o.clientWaitSync(e,o.SYNC_FLUSH_COMMANDS_BIT,0)){case o.WAIT_FAILED:r();break;case o.TIMEOUT_EXPIRED:setTimeout(l,n);break;default:a()}}setTimeout(l,n)})}const dR={[B_]:H_,[G_]:X_,[V_]:W_,[eu]:k_,[H_]:B_,[X_]:G_,[W_]:V_,[k_]:eu};class hu{addEventListener(e,n){this._listeners===void 0&&(this._listeners={});const a=this._listeners;a[e]===void 0&&(a[e]=[]),a[e].indexOf(n)===-1&&a[e].push(n)}hasEventListener(e,n){const a=this._listeners;return a===void 0?!1:a[e]!==void 0&&a[e].indexOf(n)!==-1}removeEventListener(e,n){const a=this._listeners;if(a===void 0)return;const r=a[e];if(r!==void 0){const l=r.indexOf(n);l!==-1&&r.splice(l,1)}}dispatchEvent(e){const n=this._listeners;if(n===void 0)return;const a=n[e.type];if(a!==void 0){e.target=this;const r=a.slice(0);for(let l=0,c=r.length;l<c;l++)r[l].call(this,e);e.target=null}}}const _i=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Ym=Math.PI/180,A0=180/Math.PI;function Zc(){const o=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0,a=Math.random()*4294967295|0;return(_i[o&255]+_i[o>>8&255]+_i[o>>16&255]+_i[o>>24&255]+"-"+_i[e&255]+_i[e>>8&255]+"-"+_i[e>>16&15|64]+_i[e>>24&255]+"-"+_i[n&63|128]+_i[n>>8&255]+"-"+_i[n>>16&255]+_i[n>>24&255]+_i[a&255]+_i[a>>8&255]+_i[a>>16&255]+_i[a>>24&255]).toLowerCase()}function kt(o,e,n){return Math.max(e,Math.min(n,o))}function pR(o,e){return(o%e+e)%e}function qm(o,e,n){return(1-n)*o+n*e}function ac(o,e){switch(e.constructor){case Float32Array:return o;case Uint32Array:return o/4294967295;case Uint16Array:return o/65535;case Uint8Array:return o/255;case Int32Array:return Math.max(o/2147483647,-1);case Int16Array:return Math.max(o/32767,-1);case Int8Array:return Math.max(o/127,-1);default:throw new Error("Invalid component type.")}}function Xi(o,e){switch(e.constructor){case Float32Array:return o;case Uint32Array:return Math.round(o*4294967295);case Uint16Array:return Math.round(o*65535);case Uint8Array:return Math.round(o*255);case Int32Array:return Math.round(o*2147483647);case Int16Array:return Math.round(o*32767);case Int8Array:return Math.round(o*127);default:throw new Error("Invalid component type.")}}class fn{constructor(e=0,n=0){fn.prototype.isVector2=!0,this.x=e,this.y=n}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,n){return this.x=e,this.y=n,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,n){switch(e){case 0:this.x=n;break;case 1:this.y=n;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,n){return this.x=e.x+n.x,this.y=e.y+n.y,this}addScaledVector(e,n){return this.x+=e.x*n,this.y+=e.y*n,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,n){return this.x=e.x-n.x,this.y=e.y-n.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const n=this.x,a=this.y,r=e.elements;return this.x=r[0]*n+r[3]*a+r[6],this.y=r[1]*n+r[4]*a+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,n){return this.x=kt(this.x,e.x,n.x),this.y=kt(this.y,e.y,n.y),this}clampScalar(e,n){return this.x=kt(this.x,e,n),this.y=kt(this.y,e,n),this}clampLength(e,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(kt(a,e,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const n=Math.sqrt(this.lengthSq()*e.lengthSq());if(n===0)return Math.PI/2;const a=this.dot(e)/n;return Math.acos(kt(a,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const n=this.x-e.x,a=this.y-e.y;return n*n+a*a}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,n){return this.x+=(e.x-this.x)*n,this.y+=(e.y-this.y)*n,this}lerpVectors(e,n,a){return this.x=e.x+(n.x-e.x)*a,this.y=e.y+(n.y-e.y)*a,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,n=0){return this.x=e[n],this.y=e[n+1],this}toArray(e=[],n=0){return e[n]=this.x,e[n+1]=this.y,e}fromBufferAttribute(e,n){return this.x=e.getX(n),this.y=e.getY(n),this}rotateAround(e,n){const a=Math.cos(n),r=Math.sin(n),l=this.x-e.x,c=this.y-e.y;return this.x=l*a-c*r+e.x,this.y=l*r+c*a+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class du{constructor(e=0,n=0,a=0,r=1){this.isQuaternion=!0,this._x=e,this._y=n,this._z=a,this._w=r}static slerpFlat(e,n,a,r,l,c,f){let p=a[r+0],d=a[r+1],_=a[r+2],v=a[r+3],g=l[c+0],x=l[c+1],M=l[c+2],b=l[c+3];if(v!==b||p!==g||d!==x||_!==M){let y=p*g+d*x+_*M+v*b;y<0&&(g=-g,x=-x,M=-M,b=-b,y=-y);let S=1-f;if(y<.9995){const R=Math.acos(y),N=Math.sin(R);S=Math.sin(S*R)/N,f=Math.sin(f*R)/N,p=p*S+g*f,d=d*S+x*f,_=_*S+M*f,v=v*S+b*f}else{p=p*S+g*f,d=d*S+x*f,_=_*S+M*f,v=v*S+b*f;const R=1/Math.sqrt(p*p+d*d+_*_+v*v);p*=R,d*=R,_*=R,v*=R}}e[n]=p,e[n+1]=d,e[n+2]=_,e[n+3]=v}static multiplyQuaternionsFlat(e,n,a,r,l,c){const f=a[r],p=a[r+1],d=a[r+2],_=a[r+3],v=l[c],g=l[c+1],x=l[c+2],M=l[c+3];return e[n]=f*M+_*v+p*x-d*g,e[n+1]=p*M+_*g+d*v-f*x,e[n+2]=d*M+_*x+f*g-p*v,e[n+3]=_*M-f*v-p*g-d*x,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,n,a,r){return this._x=e,this._y=n,this._z=a,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,n=!0){const a=e._x,r=e._y,l=e._z,c=e._order,f=Math.cos,p=Math.sin,d=f(a/2),_=f(r/2),v=f(l/2),g=p(a/2),x=p(r/2),M=p(l/2);switch(c){case"XYZ":this._x=g*_*v+d*x*M,this._y=d*x*v-g*_*M,this._z=d*_*M+g*x*v,this._w=d*_*v-g*x*M;break;case"YXZ":this._x=g*_*v+d*x*M,this._y=d*x*v-g*_*M,this._z=d*_*M-g*x*v,this._w=d*_*v+g*x*M;break;case"ZXY":this._x=g*_*v-d*x*M,this._y=d*x*v+g*_*M,this._z=d*_*M+g*x*v,this._w=d*_*v-g*x*M;break;case"ZYX":this._x=g*_*v-d*x*M,this._y=d*x*v+g*_*M,this._z=d*_*M-g*x*v,this._w=d*_*v+g*x*M;break;case"YZX":this._x=g*_*v+d*x*M,this._y=d*x*v+g*_*M,this._z=d*_*M-g*x*v,this._w=d*_*v-g*x*M;break;case"XZY":this._x=g*_*v-d*x*M,this._y=d*x*v-g*_*M,this._z=d*_*M+g*x*v,this._w=d*_*v+g*x*M;break;default:Mt("Quaternion: .setFromEuler() encountered an unknown order: "+c)}return n===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,n){const a=n/2,r=Math.sin(a);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(a),this._onChangeCallback(),this}setFromRotationMatrix(e){const n=e.elements,a=n[0],r=n[4],l=n[8],c=n[1],f=n[5],p=n[9],d=n[2],_=n[6],v=n[10],g=a+f+v;if(g>0){const x=.5/Math.sqrt(g+1);this._w=.25/x,this._x=(_-p)*x,this._y=(l-d)*x,this._z=(c-r)*x}else if(a>f&&a>v){const x=2*Math.sqrt(1+a-f-v);this._w=(_-p)/x,this._x=.25*x,this._y=(r+c)/x,this._z=(l+d)/x}else if(f>v){const x=2*Math.sqrt(1+f-a-v);this._w=(l-d)/x,this._x=(r+c)/x,this._y=.25*x,this._z=(p+_)/x}else{const x=2*Math.sqrt(1+v-a-f);this._w=(c-r)/x,this._x=(l+d)/x,this._y=(p+_)/x,this._z=.25*x}return this._onChangeCallback(),this}setFromUnitVectors(e,n){let a=e.dot(n)+1;return a<1e-8?(a=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=a):(this._x=0,this._y=-e.z,this._z=e.y,this._w=a)):(this._x=e.y*n.z-e.z*n.y,this._y=e.z*n.x-e.x*n.z,this._z=e.x*n.y-e.y*n.x,this._w=a),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(kt(this.dot(e),-1,1)))}rotateTowards(e,n){const a=this.angleTo(e);if(a===0)return this;const r=Math.min(1,n/a);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,n){const a=e._x,r=e._y,l=e._z,c=e._w,f=n._x,p=n._y,d=n._z,_=n._w;return this._x=a*_+c*f+r*d-l*p,this._y=r*_+c*p+l*f-a*d,this._z=l*_+c*d+a*p-r*f,this._w=c*_-a*f-r*p-l*d,this._onChangeCallback(),this}slerp(e,n){let a=e._x,r=e._y,l=e._z,c=e._w,f=this.dot(e);f<0&&(a=-a,r=-r,l=-l,c=-c,f=-f);let p=1-n;if(f<.9995){const d=Math.acos(f),_=Math.sin(d);p=Math.sin(p*d)/_,n=Math.sin(n*d)/_,this._x=this._x*p+a*n,this._y=this._y*p+r*n,this._z=this._z*p+l*n,this._w=this._w*p+c*n,this._onChangeCallback()}else this._x=this._x*p+a*n,this._y=this._y*p+r*n,this._z=this._z*p+l*n,this._w=this._w*p+c*n,this.normalize();return this}slerpQuaternions(e,n,a){return this.copy(e).slerp(n,a)}random(){const e=2*Math.PI*Math.random(),n=2*Math.PI*Math.random(),a=Math.random(),r=Math.sqrt(1-a),l=Math.sqrt(a);return this.set(r*Math.sin(e),r*Math.cos(e),l*Math.sin(n),l*Math.cos(n))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,n=0){return this._x=e[n],this._y=e[n+1],this._z=e[n+2],this._w=e[n+3],this._onChangeCallback(),this}toArray(e=[],n=0){return e[n]=this._x,e[n+1]=this._y,e[n+2]=this._z,e[n+3]=this._w,e}fromBufferAttribute(e,n){return this._x=e.getX(n),this._y=e.getY(n),this._z=e.getZ(n),this._w=e.getW(n),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class fe{constructor(e=0,n=0,a=0){fe.prototype.isVector3=!0,this.x=e,this.y=n,this.z=a}set(e,n,a){return a===void 0&&(a=this.z),this.x=e,this.y=n,this.z=a,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,n){switch(e){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,n){return this.x=e.x+n.x,this.y=e.y+n.y,this.z=e.z+n.z,this}addScaledVector(e,n){return this.x+=e.x*n,this.y+=e.y*n,this.z+=e.z*n,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,n){return this.x=e.x-n.x,this.y=e.y-n.y,this.z=e.z-n.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,n){return this.x=e.x*n.x,this.y=e.y*n.y,this.z=e.z*n.z,this}applyEuler(e){return this.applyQuaternion(zS.setFromEuler(e))}applyAxisAngle(e,n){return this.applyQuaternion(zS.setFromAxisAngle(e,n))}applyMatrix3(e){const n=this.x,a=this.y,r=this.z,l=e.elements;return this.x=l[0]*n+l[3]*a+l[6]*r,this.y=l[1]*n+l[4]*a+l[7]*r,this.z=l[2]*n+l[5]*a+l[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const n=this.x,a=this.y,r=this.z,l=e.elements,c=1/(l[3]*n+l[7]*a+l[11]*r+l[15]);return this.x=(l[0]*n+l[4]*a+l[8]*r+l[12])*c,this.y=(l[1]*n+l[5]*a+l[9]*r+l[13])*c,this.z=(l[2]*n+l[6]*a+l[10]*r+l[14])*c,this}applyQuaternion(e){const n=this.x,a=this.y,r=this.z,l=e.x,c=e.y,f=e.z,p=e.w,d=2*(c*r-f*a),_=2*(f*n-l*r),v=2*(l*a-c*n);return this.x=n+p*d+c*v-f*_,this.y=a+p*_+f*d-l*v,this.z=r+p*v+l*_-c*d,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const n=this.x,a=this.y,r=this.z,l=e.elements;return this.x=l[0]*n+l[4]*a+l[8]*r,this.y=l[1]*n+l[5]*a+l[9]*r,this.z=l[2]*n+l[6]*a+l[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,n){return this.x=kt(this.x,e.x,n.x),this.y=kt(this.y,e.y,n.y),this.z=kt(this.z,e.z,n.z),this}clampScalar(e,n){return this.x=kt(this.x,e,n),this.y=kt(this.y,e,n),this.z=kt(this.z,e,n),this}clampLength(e,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(kt(a,e,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,n){return this.x+=(e.x-this.x)*n,this.y+=(e.y-this.y)*n,this.z+=(e.z-this.z)*n,this}lerpVectors(e,n,a){return this.x=e.x+(n.x-e.x)*a,this.y=e.y+(n.y-e.y)*a,this.z=e.z+(n.z-e.z)*a,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,n){const a=e.x,r=e.y,l=e.z,c=n.x,f=n.y,p=n.z;return this.x=r*p-l*f,this.y=l*c-a*p,this.z=a*f-r*c,this}projectOnVector(e){const n=e.lengthSq();if(n===0)return this.set(0,0,0);const a=e.dot(this)/n;return this.copy(e).multiplyScalar(a)}projectOnPlane(e){return jm.copy(this).projectOnVector(e),this.sub(jm)}reflect(e){return this.sub(jm.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const n=Math.sqrt(this.lengthSq()*e.lengthSq());if(n===0)return Math.PI/2;const a=this.dot(e)/n;return Math.acos(kt(a,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const n=this.x-e.x,a=this.y-e.y,r=this.z-e.z;return n*n+a*a+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,n,a){const r=Math.sin(n)*e;return this.x=r*Math.sin(a),this.y=Math.cos(n)*e,this.z=r*Math.cos(a),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,n,a){return this.x=e*Math.sin(n),this.y=a,this.z=e*Math.cos(n),this}setFromMatrixPosition(e){const n=e.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this}setFromMatrixScale(e){const n=this.setFromMatrixColumn(e,0).length(),a=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=n,this.y=a,this.z=r,this}setFromMatrixColumn(e,n){return this.fromArray(e.elements,n*4)}setFromMatrix3Column(e,n){return this.fromArray(e.elements,n*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,n=0){return this.x=e[n],this.y=e[n+1],this.z=e[n+2],this}toArray(e=[],n=0){return e[n]=this.x,e[n+1]=this.y,e[n+2]=this.z,e}fromBufferAttribute(e,n){return this.x=e.getX(n),this.y=e.getY(n),this.z=e.getZ(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,n=Math.random()*2-1,a=Math.sqrt(1-n*n);return this.x=a*Math.cos(e),this.y=n,this.z=a*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const jm=new fe,zS=new du;class wt{constructor(e,n,a,r,l,c,f,p,d){wt.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,n,a,r,l,c,f,p,d)}set(e,n,a,r,l,c,f,p,d){const _=this.elements;return _[0]=e,_[1]=r,_[2]=f,_[3]=n,_[4]=l,_[5]=p,_[6]=a,_[7]=c,_[8]=d,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const n=this.elements,a=e.elements;return n[0]=a[0],n[1]=a[1],n[2]=a[2],n[3]=a[3],n[4]=a[4],n[5]=a[5],n[6]=a[6],n[7]=a[7],n[8]=a[8],this}extractBasis(e,n,a){return e.setFromMatrix3Column(this,0),n.setFromMatrix3Column(this,1),a.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const n=e.elements;return this.set(n[0],n[4],n[8],n[1],n[5],n[9],n[2],n[6],n[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,n){const a=e.elements,r=n.elements,l=this.elements,c=a[0],f=a[3],p=a[6],d=a[1],_=a[4],v=a[7],g=a[2],x=a[5],M=a[8],b=r[0],y=r[3],S=r[6],R=r[1],N=r[4],C=r[7],O=r[2],P=r[5],L=r[8];return l[0]=c*b+f*R+p*O,l[3]=c*y+f*N+p*P,l[6]=c*S+f*C+p*L,l[1]=d*b+_*R+v*O,l[4]=d*y+_*N+v*P,l[7]=d*S+_*C+v*L,l[2]=g*b+x*R+M*O,l[5]=g*y+x*N+M*P,l[8]=g*S+x*C+M*L,this}multiplyScalar(e){const n=this.elements;return n[0]*=e,n[3]*=e,n[6]*=e,n[1]*=e,n[4]*=e,n[7]*=e,n[2]*=e,n[5]*=e,n[8]*=e,this}determinant(){const e=this.elements,n=e[0],a=e[1],r=e[2],l=e[3],c=e[4],f=e[5],p=e[6],d=e[7],_=e[8];return n*c*_-n*f*d-a*l*_+a*f*p+r*l*d-r*c*p}invert(){const e=this.elements,n=e[0],a=e[1],r=e[2],l=e[3],c=e[4],f=e[5],p=e[6],d=e[7],_=e[8],v=_*c-f*d,g=f*p-_*l,x=d*l-c*p,M=n*v+a*g+r*x;if(M===0)return this.set(0,0,0,0,0,0,0,0,0);const b=1/M;return e[0]=v*b,e[1]=(r*d-_*a)*b,e[2]=(f*a-r*c)*b,e[3]=g*b,e[4]=(_*n-r*p)*b,e[5]=(r*l-f*n)*b,e[6]=x*b,e[7]=(a*p-d*n)*b,e[8]=(c*n-a*l)*b,this}transpose(){let e;const n=this.elements;return e=n[1],n[1]=n[3],n[3]=e,e=n[2],n[2]=n[6],n[6]=e,e=n[5],n[5]=n[7],n[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const n=this.elements;return e[0]=n[0],e[1]=n[3],e[2]=n[6],e[3]=n[1],e[4]=n[4],e[5]=n[7],e[6]=n[2],e[7]=n[5],e[8]=n[8],this}setUvTransform(e,n,a,r,l,c,f){const p=Math.cos(l),d=Math.sin(l);return this.set(a*p,a*d,-a*(p*c+d*f)+c+e,-r*d,r*p,-r*(-d*c+p*f)+f+n,0,0,1),this}scale(e,n){return this.premultiply(Zm.makeScale(e,n)),this}rotate(e){return this.premultiply(Zm.makeRotation(-e)),this}translate(e,n){return this.premultiply(Zm.makeTranslation(e,n)),this}makeTranslation(e,n){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,n,0,0,1),this}makeRotation(e){const n=Math.cos(e),a=Math.sin(e);return this.set(n,-a,0,a,n,0,0,0,1),this}makeScale(e,n){return this.set(e,0,0,0,n,0,0,0,1),this}equals(e){const n=this.elements,a=e.elements;for(let r=0;r<9;r++)if(n[r]!==a[r])return!1;return!0}fromArray(e,n=0){for(let a=0;a<9;a++)this.elements[a]=e[a+n];return this}toArray(e=[],n=0){const a=this.elements;return e[n]=a[0],e[n+1]=a[1],e[n+2]=a[2],e[n+3]=a[3],e[n+4]=a[4],e[n+5]=a[5],e[n+6]=a[6],e[n+7]=a[7],e[n+8]=a[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const Zm=new wt,FS=new wt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),IS=new wt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function mR(){const o={enabled:!0,workingColorSpace:iu,spaces:{},convert:function(r,l,c){return this.enabled===!1||l===c||!l||!c||(this.spaces[l].transfer===an&&(r.r=$r(r.r),r.g=$r(r.g),r.b=$r(r.b)),this.spaces[l].primaries!==this.spaces[c].primaries&&(r.applyMatrix3(this.spaces[l].toXYZ),r.applyMatrix3(this.spaces[c].fromXYZ)),this.spaces[c].transfer===an&&(r.r=ql(r.r),r.g=ql(r.g),r.b=ql(r.b))),r},workingToColorSpace:function(r,l){return this.convert(r,this.workingColorSpace,l)},colorSpaceToWorking:function(r,l){return this.convert(r,l,this.workingColorSpace)},getPrimaries:function(r){return this.spaces[r].primaries},getTransfer:function(r){return r===Fs?ud:this.spaces[r].transfer},getToneMappingMode:function(r){return this.spaces[r].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(r,l=this.workingColorSpace){return r.fromArray(this.spaces[l].luminanceCoefficients)},define:function(r){Object.assign(this.spaces,r)},_getMatrix:function(r,l,c){return r.copy(this.spaces[l].toXYZ).multiply(this.spaces[c].fromXYZ)},_getDrawingBufferColorSpace:function(r){return this.spaces[r].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(r=this.workingColorSpace){return this.spaces[r].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(r,l){return hd("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),o.workingToColorSpace(r,l)},toWorkingColorSpace:function(r,l){return hd("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),o.colorSpaceToWorking(r,l)}},e=[.64,.33,.3,.6,.15,.06],n=[.2126,.7152,.0722],a=[.3127,.329];return o.define({[iu]:{primaries:e,whitePoint:a,transfer:ud,toXYZ:FS,fromXYZ:IS,luminanceCoefficients:n,workingColorSpaceConfig:{unpackColorSpace:Ua},outputColorSpaceConfig:{drawingBufferColorSpace:Ua}},[Ua]:{primaries:e,whitePoint:a,transfer:an,toXYZ:FS,fromXYZ:IS,luminanceCoefficients:n,outputColorSpaceConfig:{drawingBufferColorSpace:Ua}}}),o}const Yt=mR();function $r(o){return o<.04045?o*.0773993808:Math.pow(o*.9478672986+.0521327014,2.4)}function ql(o){return o<.0031308?o*12.92:1.055*Math.pow(o,.41666)-.055}let Tl;class _R{static getDataURL(e,n="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let a;if(e instanceof HTMLCanvasElement)a=e;else{Tl===void 0&&(Tl=fd("canvas")),Tl.width=e.width,Tl.height=e.height;const r=Tl.getContext("2d");e instanceof ImageData?r.putImageData(e,0,0):r.drawImage(e,0,0,e.width,e.height),a=Tl}return a.toDataURL(n)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const n=fd("canvas");n.width=e.width,n.height=e.height;const a=n.getContext("2d");a.drawImage(e,0,0,e.width,e.height);const r=a.getImageData(0,0,e.width,e.height),l=r.data;for(let c=0;c<l.length;c++)l[c]=$r(l[c]/255)*255;return a.putImageData(r,0,0),n}else if(e.data){const n=e.data.slice(0);for(let a=0;a<n.length;a++)n instanceof Uint8Array||n instanceof Uint8ClampedArray?n[a]=Math.floor($r(n[a]/255)*255):n[a]=$r(n[a]);return{data:n,width:e.width,height:e.height}}else return Mt("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let gR=0;class cg{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:gR++}),this.uuid=Zc(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const n=this.data;return typeof HTMLVideoElement<"u"&&n instanceof HTMLVideoElement?e.set(n.videoWidth,n.videoHeight,0):typeof VideoFrame<"u"&&n instanceof VideoFrame?e.set(n.displayHeight,n.displayWidth,0):n!==null?e.set(n.width,n.height,n.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const n=e===void 0||typeof e=="string";if(!n&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const a={uuid:this.uuid,url:""},r=this.data;if(r!==null){let l;if(Array.isArray(r)){l=[];for(let c=0,f=r.length;c<f;c++)r[c].isDataTexture?l.push(Km(r[c].image)):l.push(Km(r[c]))}else l=Km(r);a.url=l}return n||(e.images[this.uuid]=a),a}}function Km(o){return typeof HTMLImageElement<"u"&&o instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&o instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&o instanceof ImageBitmap?_R.getDataURL(o):o.data?{data:Array.from(o.data),width:o.width,height:o.height,type:o.data.constructor.name}:(Mt("Texture: Unable to serialize Texture."),{})}let vR=0;const Qm=new fe;class Fi extends hu{constructor(e=Fi.DEFAULT_IMAGE,n=Fi.DEFAULT_MAPPING,a=Kr,r=Kr,l=Mi,c=Do,f=Ja,p=za,d=Fi.DEFAULT_ANISOTROPY,_=Fs){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:vR++}),this.uuid=Zc(),this.name="",this.source=new cg(e),this.mipmaps=[],this.mapping=n,this.channel=0,this.wrapS=a,this.wrapT=r,this.magFilter=l,this.minFilter=c,this.anisotropy=d,this.format=f,this.internalFormat=null,this.type=p,this.offset=new fn(0,0),this.repeat=new fn(1,1),this.center=new fn(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new wt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=_,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(Qm).x}get height(){return this.source.getSize(Qm).y}get depth(){return this.source.getSize(Qm).z}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,n){this.updateRanges.push({start:e,count:n})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const n in e){const a=e[n];if(a===void 0){Mt(`Texture.setValues(): parameter '${n}' has value of undefined.`);continue}const r=this[n];if(r===void 0){Mt(`Texture.setValues(): property '${n}' does not exist.`);continue}r&&a&&r.isVector2&&a.isVector2||r&&a&&r.isVector3&&a.isVector3||r&&a&&r.isMatrix3&&a.isMatrix3?r.copy(a):this[n]=a}}toJSON(e){const n=e===void 0||typeof e=="string";if(!n&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const a={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(a.userData=this.userData),n||(e.textures[this.uuid]=a),a}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==x1)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Y_:e.x=e.x-Math.floor(e.x);break;case Kr:e.x=e.x<0?0:1;break;case q_:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Y_:e.y=e.y-Math.floor(e.y);break;case Kr:e.y=e.y<0?0:1;break;case q_:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Fi.DEFAULT_IMAGE=null;Fi.DEFAULT_MAPPING=x1;Fi.DEFAULT_ANISOTROPY=1;class Pn{constructor(e=0,n=0,a=0,r=1){Pn.prototype.isVector4=!0,this.x=e,this.y=n,this.z=a,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,n,a,r){return this.x=e,this.y=n,this.z=a,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,n){switch(e){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;case 3:this.w=n;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,n){return this.x=e.x+n.x,this.y=e.y+n.y,this.z=e.z+n.z,this.w=e.w+n.w,this}addScaledVector(e,n){return this.x+=e.x*n,this.y+=e.y*n,this.z+=e.z*n,this.w+=e.w*n,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,n){return this.x=e.x-n.x,this.y=e.y-n.y,this.z=e.z-n.z,this.w=e.w-n.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const n=this.x,a=this.y,r=this.z,l=this.w,c=e.elements;return this.x=c[0]*n+c[4]*a+c[8]*r+c[12]*l,this.y=c[1]*n+c[5]*a+c[9]*r+c[13]*l,this.z=c[2]*n+c[6]*a+c[10]*r+c[14]*l,this.w=c[3]*n+c[7]*a+c[11]*r+c[15]*l,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const n=Math.sqrt(1-e.w*e.w);return n<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/n,this.y=e.y/n,this.z=e.z/n),this}setAxisAngleFromRotationMatrix(e){let n,a,r,l;const p=e.elements,d=p[0],_=p[4],v=p[8],g=p[1],x=p[5],M=p[9],b=p[2],y=p[6],S=p[10];if(Math.abs(_-g)<.01&&Math.abs(v-b)<.01&&Math.abs(M-y)<.01){if(Math.abs(_+g)<.1&&Math.abs(v+b)<.1&&Math.abs(M+y)<.1&&Math.abs(d+x+S-3)<.1)return this.set(1,0,0,0),this;n=Math.PI;const N=(d+1)/2,C=(x+1)/2,O=(S+1)/2,P=(_+g)/4,L=(v+b)/4,T=(M+y)/4;return N>C&&N>O?N<.01?(a=0,r=.707106781,l=.707106781):(a=Math.sqrt(N),r=P/a,l=L/a):C>O?C<.01?(a=.707106781,r=0,l=.707106781):(r=Math.sqrt(C),a=P/r,l=T/r):O<.01?(a=.707106781,r=.707106781,l=0):(l=Math.sqrt(O),a=L/l,r=T/l),this.set(a,r,l,n),this}let R=Math.sqrt((y-M)*(y-M)+(v-b)*(v-b)+(g-_)*(g-_));return Math.abs(R)<.001&&(R=1),this.x=(y-M)/R,this.y=(v-b)/R,this.z=(g-_)/R,this.w=Math.acos((d+x+S-1)/2),this}setFromMatrixPosition(e){const n=e.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this.w=n[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,n){return this.x=kt(this.x,e.x,n.x),this.y=kt(this.y,e.y,n.y),this.z=kt(this.z,e.z,n.z),this.w=kt(this.w,e.w,n.w),this}clampScalar(e,n){return this.x=kt(this.x,e,n),this.y=kt(this.y,e,n),this.z=kt(this.z,e,n),this.w=kt(this.w,e,n),this}clampLength(e,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(kt(a,e,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,n){return this.x+=(e.x-this.x)*n,this.y+=(e.y-this.y)*n,this.z+=(e.z-this.z)*n,this.w+=(e.w-this.w)*n,this}lerpVectors(e,n,a){return this.x=e.x+(n.x-e.x)*a,this.y=e.y+(n.y-e.y)*a,this.z=e.z+(n.z-e.z)*a,this.w=e.w+(n.w-e.w)*a,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,n=0){return this.x=e[n],this.y=e[n+1],this.z=e[n+2],this.w=e[n+3],this}toArray(e=[],n=0){return e[n]=this.x,e[n+1]=this.y,e[n+2]=this.z,e[n+3]=this.w,e}fromBufferAttribute(e,n){return this.x=e.getX(n),this.y=e.getY(n),this.z=e.getZ(n),this.w=e.getW(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class xR extends hu{constructor(e=1,n=1,a={}){super(),a=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Mi,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},a),this.isRenderTarget=!0,this.width=e,this.height=n,this.depth=a.depth,this.scissor=new Pn(0,0,e,n),this.scissorTest=!1,this.viewport=new Pn(0,0,e,n),this.textures=[];const r={width:e,height:n,depth:a.depth},l=new Fi(r),c=a.count;for(let f=0;f<c;f++)this.textures[f]=l.clone(),this.textures[f].isRenderTargetTexture=!0,this.textures[f].renderTarget=this;this._setTextureOptions(a),this.depthBuffer=a.depthBuffer,this.stencilBuffer=a.stencilBuffer,this.resolveDepthBuffer=a.resolveDepthBuffer,this.resolveStencilBuffer=a.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=a.depthTexture,this.samples=a.samples,this.multiview=a.multiview}_setTextureOptions(e={}){const n={minFilter:Mi,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(n.mapping=e.mapping),e.wrapS!==void 0&&(n.wrapS=e.wrapS),e.wrapT!==void 0&&(n.wrapT=e.wrapT),e.wrapR!==void 0&&(n.wrapR=e.wrapR),e.magFilter!==void 0&&(n.magFilter=e.magFilter),e.minFilter!==void 0&&(n.minFilter=e.minFilter),e.format!==void 0&&(n.format=e.format),e.type!==void 0&&(n.type=e.type),e.anisotropy!==void 0&&(n.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(n.colorSpace=e.colorSpace),e.flipY!==void 0&&(n.flipY=e.flipY),e.generateMipmaps!==void 0&&(n.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(n.internalFormat=e.internalFormat);for(let a=0;a<this.textures.length;a++)this.textures[a].setValues(n)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,n,a=1){if(this.width!==e||this.height!==n||this.depth!==a){this.width=e,this.height=n,this.depth=a;for(let r=0,l=this.textures.length;r<l;r++)this.textures[r].image.width=e,this.textures[r].image.height=n,this.textures[r].image.depth=a,this.textures[r].isData3DTexture!==!0&&(this.textures[r].isArrayTexture=this.textures[r].image.depth>1);this.dispose()}this.viewport.set(0,0,e,n),this.scissor.set(0,0,e,n)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let n=0,a=e.textures.length;n<a;n++){this.textures[n]=e.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0,this.textures[n].renderTarget=this;const r=Object.assign({},e.textures[n].image);this.textures[n].source=new cg(r)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class vr extends xR{constructor(e=1,n=1,a={}){super(e,n,a),this.isWebGLRenderTarget=!0}}class C1 extends Fi{constructor(e=null,n=1,a=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:n,height:a,depth:r},this.magFilter=fi,this.minFilter=fi,this.wrapR=Kr,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class yR extends Fi{constructor(e=null,n=1,a=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:n,height:a,depth:r},this.magFilter=fi,this.minFilter=fi,this.wrapR=Kr,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Fn{constructor(e,n,a,r,l,c,f,p,d,_,v,g,x,M,b,y){Fn.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,n,a,r,l,c,f,p,d,_,v,g,x,M,b,y)}set(e,n,a,r,l,c,f,p,d,_,v,g,x,M,b,y){const S=this.elements;return S[0]=e,S[4]=n,S[8]=a,S[12]=r,S[1]=l,S[5]=c,S[9]=f,S[13]=p,S[2]=d,S[6]=_,S[10]=v,S[14]=g,S[3]=x,S[7]=M,S[11]=b,S[15]=y,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Fn().fromArray(this.elements)}copy(e){const n=this.elements,a=e.elements;return n[0]=a[0],n[1]=a[1],n[2]=a[2],n[3]=a[3],n[4]=a[4],n[5]=a[5],n[6]=a[6],n[7]=a[7],n[8]=a[8],n[9]=a[9],n[10]=a[10],n[11]=a[11],n[12]=a[12],n[13]=a[13],n[14]=a[14],n[15]=a[15],this}copyPosition(e){const n=this.elements,a=e.elements;return n[12]=a[12],n[13]=a[13],n[14]=a[14],this}setFromMatrix3(e){const n=e.elements;return this.set(n[0],n[3],n[6],0,n[1],n[4],n[7],0,n[2],n[5],n[8],0,0,0,0,1),this}extractBasis(e,n,a){return this.determinant()===0?(e.set(1,0,0),n.set(0,1,0),a.set(0,0,1),this):(e.setFromMatrixColumn(this,0),n.setFromMatrixColumn(this,1),a.setFromMatrixColumn(this,2),this)}makeBasis(e,n,a){return this.set(e.x,n.x,a.x,0,e.y,n.y,a.y,0,e.z,n.z,a.z,0,0,0,0,1),this}extractRotation(e){if(e.determinant()===0)return this.identity();const n=this.elements,a=e.elements,r=1/Al.setFromMatrixColumn(e,0).length(),l=1/Al.setFromMatrixColumn(e,1).length(),c=1/Al.setFromMatrixColumn(e,2).length();return n[0]=a[0]*r,n[1]=a[1]*r,n[2]=a[2]*r,n[3]=0,n[4]=a[4]*l,n[5]=a[5]*l,n[6]=a[6]*l,n[7]=0,n[8]=a[8]*c,n[9]=a[9]*c,n[10]=a[10]*c,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromEuler(e){const n=this.elements,a=e.x,r=e.y,l=e.z,c=Math.cos(a),f=Math.sin(a),p=Math.cos(r),d=Math.sin(r),_=Math.cos(l),v=Math.sin(l);if(e.order==="XYZ"){const g=c*_,x=c*v,M=f*_,b=f*v;n[0]=p*_,n[4]=-p*v,n[8]=d,n[1]=x+M*d,n[5]=g-b*d,n[9]=-f*p,n[2]=b-g*d,n[6]=M+x*d,n[10]=c*p}else if(e.order==="YXZ"){const g=p*_,x=p*v,M=d*_,b=d*v;n[0]=g+b*f,n[4]=M*f-x,n[8]=c*d,n[1]=c*v,n[5]=c*_,n[9]=-f,n[2]=x*f-M,n[6]=b+g*f,n[10]=c*p}else if(e.order==="ZXY"){const g=p*_,x=p*v,M=d*_,b=d*v;n[0]=g-b*f,n[4]=-c*v,n[8]=M+x*f,n[1]=x+M*f,n[5]=c*_,n[9]=b-g*f,n[2]=-c*d,n[6]=f,n[10]=c*p}else if(e.order==="ZYX"){const g=c*_,x=c*v,M=f*_,b=f*v;n[0]=p*_,n[4]=M*d-x,n[8]=g*d+b,n[1]=p*v,n[5]=b*d+g,n[9]=x*d-M,n[2]=-d,n[6]=f*p,n[10]=c*p}else if(e.order==="YZX"){const g=c*p,x=c*d,M=f*p,b=f*d;n[0]=p*_,n[4]=b-g*v,n[8]=M*v+x,n[1]=v,n[5]=c*_,n[9]=-f*_,n[2]=-d*_,n[6]=x*v+M,n[10]=g-b*v}else if(e.order==="XZY"){const g=c*p,x=c*d,M=f*p,b=f*d;n[0]=p*_,n[4]=-v,n[8]=d*_,n[1]=g*v+b,n[5]=c*_,n[9]=x*v-M,n[2]=M*v-x,n[6]=f*_,n[10]=b*v+g}return n[3]=0,n[7]=0,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromQuaternion(e){return this.compose(SR,e,MR)}lookAt(e,n,a){const r=this.elements;return la.subVectors(e,n),la.lengthSq()===0&&(la.z=1),la.normalize(),Ds.crossVectors(a,la),Ds.lengthSq()===0&&(Math.abs(a.z)===1?la.x+=1e-4:la.z+=1e-4,la.normalize(),Ds.crossVectors(a,la)),Ds.normalize(),fh.crossVectors(la,Ds),r[0]=Ds.x,r[4]=fh.x,r[8]=la.x,r[1]=Ds.y,r[5]=fh.y,r[9]=la.y,r[2]=Ds.z,r[6]=fh.z,r[10]=la.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,n){const a=e.elements,r=n.elements,l=this.elements,c=a[0],f=a[4],p=a[8],d=a[12],_=a[1],v=a[5],g=a[9],x=a[13],M=a[2],b=a[6],y=a[10],S=a[14],R=a[3],N=a[7],C=a[11],O=a[15],P=r[0],L=r[4],T=r[8],w=r[12],q=r[1],G=r[5],k=r[9],$=r[13],te=r[2],J=r[6],z=r[10],I=r[14],ie=r[3],he=r[7],H=r[11],F=r[15];return l[0]=c*P+f*q+p*te+d*ie,l[4]=c*L+f*G+p*J+d*he,l[8]=c*T+f*k+p*z+d*H,l[12]=c*w+f*$+p*I+d*F,l[1]=_*P+v*q+g*te+x*ie,l[5]=_*L+v*G+g*J+x*he,l[9]=_*T+v*k+g*z+x*H,l[13]=_*w+v*$+g*I+x*F,l[2]=M*P+b*q+y*te+S*ie,l[6]=M*L+b*G+y*J+S*he,l[10]=M*T+b*k+y*z+S*H,l[14]=M*w+b*$+y*I+S*F,l[3]=R*P+N*q+C*te+O*ie,l[7]=R*L+N*G+C*J+O*he,l[11]=R*T+N*k+C*z+O*H,l[15]=R*w+N*$+C*I+O*F,this}multiplyScalar(e){const n=this.elements;return n[0]*=e,n[4]*=e,n[8]*=e,n[12]*=e,n[1]*=e,n[5]*=e,n[9]*=e,n[13]*=e,n[2]*=e,n[6]*=e,n[10]*=e,n[14]*=e,n[3]*=e,n[7]*=e,n[11]*=e,n[15]*=e,this}determinant(){const e=this.elements,n=e[0],a=e[4],r=e[8],l=e[12],c=e[1],f=e[5],p=e[9],d=e[13],_=e[2],v=e[6],g=e[10],x=e[14],M=e[3],b=e[7],y=e[11],S=e[15],R=p*x-d*g,N=f*x-d*v,C=f*g-p*v,O=c*x-d*_,P=c*g-p*_,L=c*v-f*_;return n*(b*R-y*N+S*C)-a*(M*R-y*O+S*P)+r*(M*N-b*O+S*L)-l*(M*C-b*P+y*L)}transpose(){const e=this.elements;let n;return n=e[1],e[1]=e[4],e[4]=n,n=e[2],e[2]=e[8],e[8]=n,n=e[6],e[6]=e[9],e[9]=n,n=e[3],e[3]=e[12],e[12]=n,n=e[7],e[7]=e[13],e[13]=n,n=e[11],e[11]=e[14],e[14]=n,this}setPosition(e,n,a){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=n,r[14]=a),this}invert(){const e=this.elements,n=e[0],a=e[1],r=e[2],l=e[3],c=e[4],f=e[5],p=e[6],d=e[7],_=e[8],v=e[9],g=e[10],x=e[11],M=e[12],b=e[13],y=e[14],S=e[15],R=n*f-a*c,N=n*p-r*c,C=n*d-l*c,O=a*p-r*f,P=a*d-l*f,L=r*d-l*p,T=_*b-v*M,w=_*y-g*M,q=_*S-x*M,G=v*y-g*b,k=v*S-x*b,$=g*S-x*y,te=R*$-N*k+C*G+O*q-P*w+L*T;if(te===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const J=1/te;return e[0]=(f*$-p*k+d*G)*J,e[1]=(r*k-a*$-l*G)*J,e[2]=(b*L-y*P+S*O)*J,e[3]=(g*P-v*L-x*O)*J,e[4]=(p*q-c*$-d*w)*J,e[5]=(n*$-r*q+l*w)*J,e[6]=(y*C-M*L-S*N)*J,e[7]=(_*L-g*C+x*N)*J,e[8]=(c*k-f*q+d*T)*J,e[9]=(a*q-n*k-l*T)*J,e[10]=(M*P-b*C+S*R)*J,e[11]=(v*C-_*P-x*R)*J,e[12]=(f*w-c*G-p*T)*J,e[13]=(n*G-a*w+r*T)*J,e[14]=(b*N-M*O-y*R)*J,e[15]=(_*O-v*N+g*R)*J,this}scale(e){const n=this.elements,a=e.x,r=e.y,l=e.z;return n[0]*=a,n[4]*=r,n[8]*=l,n[1]*=a,n[5]*=r,n[9]*=l,n[2]*=a,n[6]*=r,n[10]*=l,n[3]*=a,n[7]*=r,n[11]*=l,this}getMaxScaleOnAxis(){const e=this.elements,n=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],a=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(n,a,r))}makeTranslation(e,n,a){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,n,0,0,1,a,0,0,0,1),this}makeRotationX(e){const n=Math.cos(e),a=Math.sin(e);return this.set(1,0,0,0,0,n,-a,0,0,a,n,0,0,0,0,1),this}makeRotationY(e){const n=Math.cos(e),a=Math.sin(e);return this.set(n,0,a,0,0,1,0,0,-a,0,n,0,0,0,0,1),this}makeRotationZ(e){const n=Math.cos(e),a=Math.sin(e);return this.set(n,-a,0,0,a,n,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,n){const a=Math.cos(n),r=Math.sin(n),l=1-a,c=e.x,f=e.y,p=e.z,d=l*c,_=l*f;return this.set(d*c+a,d*f-r*p,d*p+r*f,0,d*f+r*p,_*f+a,_*p-r*c,0,d*p-r*f,_*p+r*c,l*p*p+a,0,0,0,0,1),this}makeScale(e,n,a){return this.set(e,0,0,0,0,n,0,0,0,0,a,0,0,0,0,1),this}makeShear(e,n,a,r,l,c){return this.set(1,a,l,0,e,1,c,0,n,r,1,0,0,0,0,1),this}compose(e,n,a){const r=this.elements,l=n._x,c=n._y,f=n._z,p=n._w,d=l+l,_=c+c,v=f+f,g=l*d,x=l*_,M=l*v,b=c*_,y=c*v,S=f*v,R=p*d,N=p*_,C=p*v,O=a.x,P=a.y,L=a.z;return r[0]=(1-(b+S))*O,r[1]=(x+C)*O,r[2]=(M-N)*O,r[3]=0,r[4]=(x-C)*P,r[5]=(1-(g+S))*P,r[6]=(y+R)*P,r[7]=0,r[8]=(M+N)*L,r[9]=(y-R)*L,r[10]=(1-(g+b))*L,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,n,a){const r=this.elements;e.x=r[12],e.y=r[13],e.z=r[14];const l=this.determinant();if(l===0)return a.set(1,1,1),n.identity(),this;let c=Al.set(r[0],r[1],r[2]).length();const f=Al.set(r[4],r[5],r[6]).length(),p=Al.set(r[8],r[9],r[10]).length();l<0&&(c=-c),qa.copy(this);const d=1/c,_=1/f,v=1/p;return qa.elements[0]*=d,qa.elements[1]*=d,qa.elements[2]*=d,qa.elements[4]*=_,qa.elements[5]*=_,qa.elements[6]*=_,qa.elements[8]*=v,qa.elements[9]*=v,qa.elements[10]*=v,n.setFromRotationMatrix(qa),a.x=c,a.y=f,a.z=p,this}makePerspective(e,n,a,r,l,c,f=pr,p=!1){const d=this.elements,_=2*l/(n-e),v=2*l/(a-r),g=(n+e)/(n-e),x=(a+r)/(a-r);let M,b;if(p)M=l/(c-l),b=c*l/(c-l);else if(f===pr)M=-(c+l)/(c-l),b=-2*c*l/(c-l);else if(f===cd)M=-c/(c-l),b=-c*l/(c-l);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+f);return d[0]=_,d[4]=0,d[8]=g,d[12]=0,d[1]=0,d[5]=v,d[9]=x,d[13]=0,d[2]=0,d[6]=0,d[10]=M,d[14]=b,d[3]=0,d[7]=0,d[11]=-1,d[15]=0,this}makeOrthographic(e,n,a,r,l,c,f=pr,p=!1){const d=this.elements,_=2/(n-e),v=2/(a-r),g=-(n+e)/(n-e),x=-(a+r)/(a-r);let M,b;if(p)M=1/(c-l),b=c/(c-l);else if(f===pr)M=-2/(c-l),b=-(c+l)/(c-l);else if(f===cd)M=-1/(c-l),b=-l/(c-l);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+f);return d[0]=_,d[4]=0,d[8]=0,d[12]=g,d[1]=0,d[5]=v,d[9]=0,d[13]=x,d[2]=0,d[6]=0,d[10]=M,d[14]=b,d[3]=0,d[7]=0,d[11]=0,d[15]=1,this}equals(e){const n=this.elements,a=e.elements;for(let r=0;r<16;r++)if(n[r]!==a[r])return!1;return!0}fromArray(e,n=0){for(let a=0;a<16;a++)this.elements[a]=e[a+n];return this}toArray(e=[],n=0){const a=this.elements;return e[n]=a[0],e[n+1]=a[1],e[n+2]=a[2],e[n+3]=a[3],e[n+4]=a[4],e[n+5]=a[5],e[n+6]=a[6],e[n+7]=a[7],e[n+8]=a[8],e[n+9]=a[9],e[n+10]=a[10],e[n+11]=a[11],e[n+12]=a[12],e[n+13]=a[13],e[n+14]=a[14],e[n+15]=a[15],e}}const Al=new fe,qa=new Fn,SR=new fe(0,0,0),MR=new fe(1,1,1),Ds=new fe,fh=new fe,la=new fe,BS=new Fn,HS=new du;class is{constructor(e=0,n=0,a=0,r=is.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=n,this._z=a,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,n,a,r=this._order){return this._x=e,this._y=n,this._z=a,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,n=this._order,a=!0){const r=e.elements,l=r[0],c=r[4],f=r[8],p=r[1],d=r[5],_=r[9],v=r[2],g=r[6],x=r[10];switch(n){case"XYZ":this._y=Math.asin(kt(f,-1,1)),Math.abs(f)<.9999999?(this._x=Math.atan2(-_,x),this._z=Math.atan2(-c,l)):(this._x=Math.atan2(g,d),this._z=0);break;case"YXZ":this._x=Math.asin(-kt(_,-1,1)),Math.abs(_)<.9999999?(this._y=Math.atan2(f,x),this._z=Math.atan2(p,d)):(this._y=Math.atan2(-v,l),this._z=0);break;case"ZXY":this._x=Math.asin(kt(g,-1,1)),Math.abs(g)<.9999999?(this._y=Math.atan2(-v,x),this._z=Math.atan2(-c,d)):(this._y=0,this._z=Math.atan2(p,l));break;case"ZYX":this._y=Math.asin(-kt(v,-1,1)),Math.abs(v)<.9999999?(this._x=Math.atan2(g,x),this._z=Math.atan2(p,l)):(this._x=0,this._z=Math.atan2(-c,d));break;case"YZX":this._z=Math.asin(kt(p,-1,1)),Math.abs(p)<.9999999?(this._x=Math.atan2(-_,d),this._y=Math.atan2(-v,l)):(this._x=0,this._y=Math.atan2(f,x));break;case"XZY":this._z=Math.asin(-kt(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(g,d),this._y=Math.atan2(f,l)):(this._x=Math.atan2(-_,x),this._y=0);break;default:Mt("Euler: .setFromRotationMatrix() encountered an unknown order: "+n)}return this._order=n,a===!0&&this._onChangeCallback(),this}setFromQuaternion(e,n,a){return BS.makeRotationFromQuaternion(e),this.setFromRotationMatrix(BS,n,a)}setFromVector3(e,n=this._order){return this.set(e.x,e.y,e.z,n)}reorder(e){return HS.setFromEuler(this),this.setFromQuaternion(HS,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],n=0){return e[n]=this._x,e[n+1]=this._y,e[n+2]=this._z,e[n+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}is.DEFAULT_ORDER="XYZ";class w1{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let bR=0;const GS=new fe,Rl=new du,Gr=new Fn,hh=new fe,rc=new fe,ER=new fe,TR=new du,VS=new fe(1,0,0),kS=new fe(0,1,0),XS=new fe(0,0,1),WS={type:"added"},AR={type:"removed"},Cl={type:"childadded",child:null},Jm={type:"childremoved",child:null};class qi extends hu{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:bR++}),this.uuid=Zc(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=qi.DEFAULT_UP.clone();const e=new fe,n=new is,a=new du,r=new fe(1,1,1);function l(){a.setFromEuler(n,!1)}function c(){n.setFromQuaternion(a,void 0,!1)}n._onChange(l),a._onChange(c),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:n},quaternion:{configurable:!0,enumerable:!0,value:a},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new Fn},normalMatrix:{value:new wt}}),this.matrix=new Fn,this.matrixWorld=new Fn,this.matrixAutoUpdate=qi.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=qi.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new w1,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,n){this.quaternion.setFromAxisAngle(e,n)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,n){return Rl.setFromAxisAngle(e,n),this.quaternion.multiply(Rl),this}rotateOnWorldAxis(e,n){return Rl.setFromAxisAngle(e,n),this.quaternion.premultiply(Rl),this}rotateX(e){return this.rotateOnAxis(VS,e)}rotateY(e){return this.rotateOnAxis(kS,e)}rotateZ(e){return this.rotateOnAxis(XS,e)}translateOnAxis(e,n){return GS.copy(e).applyQuaternion(this.quaternion),this.position.add(GS.multiplyScalar(n)),this}translateX(e){return this.translateOnAxis(VS,e)}translateY(e){return this.translateOnAxis(kS,e)}translateZ(e){return this.translateOnAxis(XS,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Gr.copy(this.matrixWorld).invert())}lookAt(e,n,a){e.isVector3?hh.copy(e):hh.set(e,n,a);const r=this.parent;this.updateWorldMatrix(!0,!1),rc.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Gr.lookAt(rc,hh,this.up):Gr.lookAt(hh,rc,this.up),this.quaternion.setFromRotationMatrix(Gr),r&&(Gr.extractRotation(r.matrixWorld),Rl.setFromRotationMatrix(Gr),this.quaternion.premultiply(Rl.invert()))}add(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.add(arguments[n]);return this}return e===this?(Qt("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(WS),Cl.child=e,this.dispatchEvent(Cl),Cl.child=null):Qt("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let a=0;a<arguments.length;a++)this.remove(arguments[a]);return this}const n=this.children.indexOf(e);return n!==-1&&(e.parent=null,this.children.splice(n,1),e.dispatchEvent(AR),Jm.child=e,this.dispatchEvent(Jm),Jm.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Gr.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Gr.multiply(e.parent.matrixWorld)),e.applyMatrix4(Gr),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(WS),Cl.child=e,this.dispatchEvent(Cl),Cl.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,n){if(this[e]===n)return this;for(let a=0,r=this.children.length;a<r;a++){const c=this.children[a].getObjectByProperty(e,n);if(c!==void 0)return c}}getObjectsByProperty(e,n,a=[]){this[e]===n&&a.push(this);const r=this.children;for(let l=0,c=r.length;l<c;l++)r[l].getObjectsByProperty(e,n,a);return a}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(rc,e,ER),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(rc,TR,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const n=this.matrixWorld.elements;return e.set(n[8],n[9],n[10]).normalize()}raycast(){}traverse(e){e(this);const n=this.children;for(let a=0,r=n.length;a<r;a++)n[a].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const n=this.children;for(let a=0,r=n.length;a<r;a++)n[a].traverseVisible(e)}traverseAncestors(e){const n=this.parent;n!==null&&(e(n),n.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const n=e.x,a=e.y,r=e.z,l=this.matrix.elements;l[12]+=n-l[0]*n-l[4]*a-l[8]*r,l[13]+=a-l[1]*n-l[5]*a-l[9]*r,l[14]+=r-l[2]*n-l[6]*a-l[10]*r}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const n=this.children;for(let a=0,r=n.length;a<r;a++)n[a].updateMatrixWorld(e)}updateWorldMatrix(e,n){const a=this.parent;if(e===!0&&a!==null&&a.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),n===!0){const r=this.children;for(let l=0,c=r.length;l<c;l++)r[l].updateWorldMatrix(!1,!0)}}toJSON(e){const n=e===void 0||typeof e=="string",a={};n&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},a.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.castShadow===!0&&(r.castShadow=!0),this.receiveShadow===!0&&(r.receiveShadow=!0),this.visible===!1&&(r.visible=!1),this.frustumCulled===!1&&(r.frustumCulled=!1),this.renderOrder!==0&&(r.renderOrder=this.renderOrder),this.static!==!1&&(r.static=this.static),Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.pivot!==null&&(r.pivot=this.pivot.toArray()),this.matrixAutoUpdate===!1&&(r.matrixAutoUpdate=!1),this.morphTargetDictionary!==void 0&&(r.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(r.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(f=>({...f,boundingBox:f.boundingBox?f.boundingBox.toJSON():void 0,boundingSphere:f.boundingSphere?f.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(f=>({...f})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function l(f,p){return f[p.uuid]===void 0&&(f[p.uuid]=p.toJSON(e)),p.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=l(e.geometries,this.geometry);const f=this.geometry.parameters;if(f!==void 0&&f.shapes!==void 0){const p=f.shapes;if(Array.isArray(p))for(let d=0,_=p.length;d<_;d++){const v=p[d];l(e.shapes,v)}else l(e.shapes,p)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(l(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const f=[];for(let p=0,d=this.material.length;p<d;p++)f.push(l(e.materials,this.material[p]));r.material=f}else r.material=l(e.materials,this.material);if(this.children.length>0){r.children=[];for(let f=0;f<this.children.length;f++)r.children.push(this.children[f].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let f=0;f<this.animations.length;f++){const p=this.animations[f];r.animations.push(l(e.animations,p))}}if(n){const f=c(e.geometries),p=c(e.materials),d=c(e.textures),_=c(e.images),v=c(e.shapes),g=c(e.skeletons),x=c(e.animations),M=c(e.nodes);f.length>0&&(a.geometries=f),p.length>0&&(a.materials=p),d.length>0&&(a.textures=d),_.length>0&&(a.images=_),v.length>0&&(a.shapes=v),g.length>0&&(a.skeletons=g),x.length>0&&(a.animations=x),M.length>0&&(a.nodes=M)}return a.object=r,a;function c(f){const p=[];for(const d in f){const _=f[d];delete _.metadata,p.push(_)}return p}}clone(e){return new this.constructor().copy(this,e)}copy(e,n=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),e.pivot!==null&&(this.pivot=e.pivot.clone()),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),n===!0)for(let a=0;a<e.children.length;a++){const r=e.children[a];this.add(r.clone())}return this}}qi.DEFAULT_UP=new fe(0,1,0);qi.DEFAULT_MATRIX_AUTO_UPDATE=!0;qi.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class mc extends qi{constructor(){super(),this.isGroup=!0,this.type="Group"}}const RR={type:"move"};class $m{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new mc,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new mc,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new fe,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new fe),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new mc,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new fe,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new fe),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const n=this._hand;if(n)for(const a of e.hand.values())this._getHandJoint(n,a)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,n,a){let r=null,l=null,c=null;const f=this._targetRay,p=this._grip,d=this._hand;if(e&&n.session.visibilityState!=="visible-blurred"){if(d&&e.hand){c=!0;for(const b of e.hand.values()){const y=n.getJointPose(b,a),S=this._getHandJoint(d,b);y!==null&&(S.matrix.fromArray(y.transform.matrix),S.matrix.decompose(S.position,S.rotation,S.scale),S.matrixWorldNeedsUpdate=!0,S.jointRadius=y.radius),S.visible=y!==null}const _=d.joints["index-finger-tip"],v=d.joints["thumb-tip"],g=_.position.distanceTo(v.position),x=.02,M=.005;d.inputState.pinching&&g>x+M?(d.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!d.inputState.pinching&&g<=x-M&&(d.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else p!==null&&e.gripSpace&&(l=n.getPose(e.gripSpace,a),l!==null&&(p.matrix.fromArray(l.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,l.linearVelocity?(p.hasLinearVelocity=!0,p.linearVelocity.copy(l.linearVelocity)):p.hasLinearVelocity=!1,l.angularVelocity?(p.hasAngularVelocity=!0,p.angularVelocity.copy(l.angularVelocity)):p.hasAngularVelocity=!1));f!==null&&(r=n.getPose(e.targetRaySpace,a),r===null&&l!==null&&(r=l),r!==null&&(f.matrix.fromArray(r.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,r.linearVelocity?(f.hasLinearVelocity=!0,f.linearVelocity.copy(r.linearVelocity)):f.hasLinearVelocity=!1,r.angularVelocity?(f.hasAngularVelocity=!0,f.angularVelocity.copy(r.angularVelocity)):f.hasAngularVelocity=!1,this.dispatchEvent(RR)))}return f!==null&&(f.visible=r!==null),p!==null&&(p.visible=l!==null),d!==null&&(d.visible=c!==null),this}_getHandJoint(e,n){if(e.joints[n.jointName]===void 0){const a=new mc;a.matrixAutoUpdate=!1,a.visible=!1,e.joints[n.jointName]=a,e.add(a)}return e.joints[n.jointName]}}const D1={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Ns={h:0,s:0,l:0},dh={h:0,s:0,l:0};function e_(o,e,n){return n<0&&(n+=1),n>1&&(n-=1),n<1/6?o+(e-o)*6*n:n<1/2?e:n<2/3?o+(e-o)*6*(2/3-n):o}class qt{constructor(e,n,a){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,n,a)}set(e,n,a){if(n===void 0&&a===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,n,a);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,n=Ua){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Yt.colorSpaceToWorking(this,n),this}setRGB(e,n,a,r=Yt.workingColorSpace){return this.r=e,this.g=n,this.b=a,Yt.colorSpaceToWorking(this,r),this}setHSL(e,n,a,r=Yt.workingColorSpace){if(e=pR(e,1),n=kt(n,0,1),a=kt(a,0,1),n===0)this.r=this.g=this.b=a;else{const l=a<=.5?a*(1+n):a+n-a*n,c=2*a-l;this.r=e_(c,l,e+1/3),this.g=e_(c,l,e),this.b=e_(c,l,e-1/3)}return Yt.colorSpaceToWorking(this,r),this}setStyle(e,n=Ua){function a(l){l!==void 0&&parseFloat(l)<1&&Mt("Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let l;const c=r[1],f=r[2];switch(c){case"rgb":case"rgba":if(l=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(f))return a(l[4]),this.setRGB(Math.min(255,parseInt(l[1],10))/255,Math.min(255,parseInt(l[2],10))/255,Math.min(255,parseInt(l[3],10))/255,n);if(l=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(f))return a(l[4]),this.setRGB(Math.min(100,parseInt(l[1],10))/100,Math.min(100,parseInt(l[2],10))/100,Math.min(100,parseInt(l[3],10))/100,n);break;case"hsl":case"hsla":if(l=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(f))return a(l[4]),this.setHSL(parseFloat(l[1])/360,parseFloat(l[2])/100,parseFloat(l[3])/100,n);break;default:Mt("Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const l=r[1],c=l.length;if(c===3)return this.setRGB(parseInt(l.charAt(0),16)/15,parseInt(l.charAt(1),16)/15,parseInt(l.charAt(2),16)/15,n);if(c===6)return this.setHex(parseInt(l,16),n);Mt("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,n);return this}setColorName(e,n=Ua){const a=D1[e.toLowerCase()];return a!==void 0?this.setHex(a,n):Mt("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=$r(e.r),this.g=$r(e.g),this.b=$r(e.b),this}copyLinearToSRGB(e){return this.r=ql(e.r),this.g=ql(e.g),this.b=ql(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Ua){return Yt.workingToColorSpace(gi.copy(this),e),Math.round(kt(gi.r*255,0,255))*65536+Math.round(kt(gi.g*255,0,255))*256+Math.round(kt(gi.b*255,0,255))}getHexString(e=Ua){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,n=Yt.workingColorSpace){Yt.workingToColorSpace(gi.copy(this),n);const a=gi.r,r=gi.g,l=gi.b,c=Math.max(a,r,l),f=Math.min(a,r,l);let p,d;const _=(f+c)/2;if(f===c)p=0,d=0;else{const v=c-f;switch(d=_<=.5?v/(c+f):v/(2-c-f),c){case a:p=(r-l)/v+(r<l?6:0);break;case r:p=(l-a)/v+2;break;case l:p=(a-r)/v+4;break}p/=6}return e.h=p,e.s=d,e.l=_,e}getRGB(e,n=Yt.workingColorSpace){return Yt.workingToColorSpace(gi.copy(this),n),e.r=gi.r,e.g=gi.g,e.b=gi.b,e}getStyle(e=Ua){Yt.workingToColorSpace(gi.copy(this),e);const n=gi.r,a=gi.g,r=gi.b;return e!==Ua?`color(${e} ${n.toFixed(3)} ${a.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(n*255)},${Math.round(a*255)},${Math.round(r*255)})`}offsetHSL(e,n,a){return this.getHSL(Ns),this.setHSL(Ns.h+e,Ns.s+n,Ns.l+a)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,n){return this.r=e.r+n.r,this.g=e.g+n.g,this.b=e.b+n.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,n){return this.r+=(e.r-this.r)*n,this.g+=(e.g-this.g)*n,this.b+=(e.b-this.b)*n,this}lerpColors(e,n,a){return this.r=e.r+(n.r-e.r)*a,this.g=e.g+(n.g-e.g)*a,this.b=e.b+(n.b-e.b)*a,this}lerpHSL(e,n){this.getHSL(Ns),e.getHSL(dh);const a=qm(Ns.h,dh.h,n),r=qm(Ns.s,dh.s,n),l=qm(Ns.l,dh.l,n);return this.setHSL(a,r,l),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const n=this.r,a=this.g,r=this.b,l=e.elements;return this.r=l[0]*n+l[3]*a+l[6]*r,this.g=l[1]*n+l[4]*a+l[7]*r,this.b=l[2]*n+l[5]*a+l[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,n=0){return this.r=e[n],this.g=e[n+1],this.b=e[n+2],this}toArray(e=[],n=0){return e[n]=this.r,e[n+1]=this.g,e[n+2]=this.b,e}fromBufferAttribute(e,n){return this.r=e.getX(n),this.g=e.getY(n),this.b=e.getZ(n),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const gi=new qt;qt.NAMES=D1;class CR extends qi{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new is,this.environmentIntensity=1,this.environmentRotation=new is,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,n){return super.copy(e,n),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const n=super.toJSON(e);return this.fog!==null&&(n.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(n.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(n.object.backgroundIntensity=this.backgroundIntensity),n.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(n.object.environmentIntensity=this.environmentIntensity),n.object.environmentRotation=this.environmentRotation.toArray(),n}}const ja=new fe,Vr=new fe,t_=new fe,kr=new fe,wl=new fe,Dl=new fe,YS=new fe,n_=new fe,i_=new fe,a_=new fe,r_=new Pn,s_=new Pn,o_=new Pn;class Qa{constructor(e=new fe,n=new fe,a=new fe){this.a=e,this.b=n,this.c=a}static getNormal(e,n,a,r){r.subVectors(a,n),ja.subVectors(e,n),r.cross(ja);const l=r.lengthSq();return l>0?r.multiplyScalar(1/Math.sqrt(l)):r.set(0,0,0)}static getBarycoord(e,n,a,r,l){ja.subVectors(r,n),Vr.subVectors(a,n),t_.subVectors(e,n);const c=ja.dot(ja),f=ja.dot(Vr),p=ja.dot(t_),d=Vr.dot(Vr),_=Vr.dot(t_),v=c*d-f*f;if(v===0)return l.set(0,0,0),null;const g=1/v,x=(d*p-f*_)*g,M=(c*_-f*p)*g;return l.set(1-x-M,M,x)}static containsPoint(e,n,a,r){return this.getBarycoord(e,n,a,r,kr)===null?!1:kr.x>=0&&kr.y>=0&&kr.x+kr.y<=1}static getInterpolation(e,n,a,r,l,c,f,p){return this.getBarycoord(e,n,a,r,kr)===null?(p.x=0,p.y=0,"z"in p&&(p.z=0),"w"in p&&(p.w=0),null):(p.setScalar(0),p.addScaledVector(l,kr.x),p.addScaledVector(c,kr.y),p.addScaledVector(f,kr.z),p)}static getInterpolatedAttribute(e,n,a,r,l,c){return r_.setScalar(0),s_.setScalar(0),o_.setScalar(0),r_.fromBufferAttribute(e,n),s_.fromBufferAttribute(e,a),o_.fromBufferAttribute(e,r),c.setScalar(0),c.addScaledVector(r_,l.x),c.addScaledVector(s_,l.y),c.addScaledVector(o_,l.z),c}static isFrontFacing(e,n,a,r){return ja.subVectors(a,n),Vr.subVectors(e,n),ja.cross(Vr).dot(r)<0}set(e,n,a){return this.a.copy(e),this.b.copy(n),this.c.copy(a),this}setFromPointsAndIndices(e,n,a,r){return this.a.copy(e[n]),this.b.copy(e[a]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,n,a,r){return this.a.fromBufferAttribute(e,n),this.b.fromBufferAttribute(e,a),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return ja.subVectors(this.c,this.b),Vr.subVectors(this.a,this.b),ja.cross(Vr).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Qa.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,n){return Qa.getBarycoord(e,this.a,this.b,this.c,n)}getInterpolation(e,n,a,r,l){return Qa.getInterpolation(e,this.a,this.b,this.c,n,a,r,l)}containsPoint(e){return Qa.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Qa.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,n){const a=this.a,r=this.b,l=this.c;let c,f;wl.subVectors(r,a),Dl.subVectors(l,a),n_.subVectors(e,a);const p=wl.dot(n_),d=Dl.dot(n_);if(p<=0&&d<=0)return n.copy(a);i_.subVectors(e,r);const _=wl.dot(i_),v=Dl.dot(i_);if(_>=0&&v<=_)return n.copy(r);const g=p*v-_*d;if(g<=0&&p>=0&&_<=0)return c=p/(p-_),n.copy(a).addScaledVector(wl,c);a_.subVectors(e,l);const x=wl.dot(a_),M=Dl.dot(a_);if(M>=0&&x<=M)return n.copy(l);const b=x*d-p*M;if(b<=0&&d>=0&&M<=0)return f=d/(d-M),n.copy(a).addScaledVector(Dl,f);const y=_*M-x*v;if(y<=0&&v-_>=0&&x-M>=0)return YS.subVectors(l,r),f=(v-_)/(v-_+(x-M)),n.copy(r).addScaledVector(YS,f);const S=1/(y+b+g);return c=b*S,f=g*S,n.copy(a).addScaledVector(wl,c).addScaledVector(Dl,f)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class Kc{constructor(e=new fe(1/0,1/0,1/0),n=new fe(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=n}set(e,n){return this.min.copy(e),this.max.copy(n),this}setFromArray(e){this.makeEmpty();for(let n=0,a=e.length;n<a;n+=3)this.expandByPoint(Za.fromArray(e,n));return this}setFromBufferAttribute(e){this.makeEmpty();for(let n=0,a=e.count;n<a;n++)this.expandByPoint(Za.fromBufferAttribute(e,n));return this}setFromPoints(e){this.makeEmpty();for(let n=0,a=e.length;n<a;n++)this.expandByPoint(e[n]);return this}setFromCenterAndSize(e,n){const a=Za.copy(n).multiplyScalar(.5);return this.min.copy(e).sub(a),this.max.copy(e).add(a),this}setFromObject(e,n=!1){return this.makeEmpty(),this.expandByObject(e,n)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,n=!1){e.updateWorldMatrix(!1,!1);const a=e.geometry;if(a!==void 0){const l=a.getAttribute("position");if(n===!0&&l!==void 0&&e.isInstancedMesh!==!0)for(let c=0,f=l.count;c<f;c++)e.isMesh===!0?e.getVertexPosition(c,Za):Za.fromBufferAttribute(l,c),Za.applyMatrix4(e.matrixWorld),this.expandByPoint(Za);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),ph.copy(e.boundingBox)):(a.boundingBox===null&&a.computeBoundingBox(),ph.copy(a.boundingBox)),ph.applyMatrix4(e.matrixWorld),this.union(ph)}const r=e.children;for(let l=0,c=r.length;l<c;l++)this.expandByObject(r[l],n);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,n){return n.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Za),Za.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let n,a;return e.normal.x>0?(n=e.normal.x*this.min.x,a=e.normal.x*this.max.x):(n=e.normal.x*this.max.x,a=e.normal.x*this.min.x),e.normal.y>0?(n+=e.normal.y*this.min.y,a+=e.normal.y*this.max.y):(n+=e.normal.y*this.max.y,a+=e.normal.y*this.min.y),e.normal.z>0?(n+=e.normal.z*this.min.z,a+=e.normal.z*this.max.z):(n+=e.normal.z*this.max.z,a+=e.normal.z*this.min.z),n<=-e.constant&&a>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(sc),mh.subVectors(this.max,sc),Nl.subVectors(e.a,sc),Ul.subVectors(e.b,sc),Ll.subVectors(e.c,sc),Us.subVectors(Ul,Nl),Ls.subVectors(Ll,Ul),_o.subVectors(Nl,Ll);let n=[0,-Us.z,Us.y,0,-Ls.z,Ls.y,0,-_o.z,_o.y,Us.z,0,-Us.x,Ls.z,0,-Ls.x,_o.z,0,-_o.x,-Us.y,Us.x,0,-Ls.y,Ls.x,0,-_o.y,_o.x,0];return!l_(n,Nl,Ul,Ll,mh)||(n=[1,0,0,0,1,0,0,0,1],!l_(n,Nl,Ul,Ll,mh))?!1:(_h.crossVectors(Us,Ls),n=[_h.x,_h.y,_h.z],l_(n,Nl,Ul,Ll,mh))}clampPoint(e,n){return n.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Za).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Za).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Xr[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Xr[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Xr[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Xr[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Xr[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Xr[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Xr[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Xr[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Xr),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const Xr=[new fe,new fe,new fe,new fe,new fe,new fe,new fe,new fe],Za=new fe,ph=new Kc,Nl=new fe,Ul=new fe,Ll=new fe,Us=new fe,Ls=new fe,_o=new fe,sc=new fe,mh=new fe,_h=new fe,go=new fe;function l_(o,e,n,a,r){for(let l=0,c=o.length-3;l<=c;l+=3){go.fromArray(o,l);const f=r.x*Math.abs(go.x)+r.y*Math.abs(go.y)+r.z*Math.abs(go.z),p=e.dot(go),d=n.dot(go),_=a.dot(go);if(Math.max(-Math.max(p,d,_),Math.min(p,d,_))>f)return!1}return!0}const Wn=new fe,gh=new fn;let wR=0;class xr{constructor(e,n,a=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:wR++}),this.name="",this.array=e,this.itemSize=n,this.count=e!==void 0?e.length/n:0,this.normalized=a,this.usage=US,this.updateRanges=[],this.gpuType=dr,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,n){this.updateRanges.push({start:e,count:n})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,n,a){e*=this.itemSize,a*=n.itemSize;for(let r=0,l=this.itemSize;r<l;r++)this.array[e+r]=n.array[a+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let n=0,a=this.count;n<a;n++)gh.fromBufferAttribute(this,n),gh.applyMatrix3(e),this.setXY(n,gh.x,gh.y);else if(this.itemSize===3)for(let n=0,a=this.count;n<a;n++)Wn.fromBufferAttribute(this,n),Wn.applyMatrix3(e),this.setXYZ(n,Wn.x,Wn.y,Wn.z);return this}applyMatrix4(e){for(let n=0,a=this.count;n<a;n++)Wn.fromBufferAttribute(this,n),Wn.applyMatrix4(e),this.setXYZ(n,Wn.x,Wn.y,Wn.z);return this}applyNormalMatrix(e){for(let n=0,a=this.count;n<a;n++)Wn.fromBufferAttribute(this,n),Wn.applyNormalMatrix(e),this.setXYZ(n,Wn.x,Wn.y,Wn.z);return this}transformDirection(e){for(let n=0,a=this.count;n<a;n++)Wn.fromBufferAttribute(this,n),Wn.transformDirection(e),this.setXYZ(n,Wn.x,Wn.y,Wn.z);return this}set(e,n=0){return this.array.set(e,n),this}getComponent(e,n){let a=this.array[e*this.itemSize+n];return this.normalized&&(a=ac(a,this.array)),a}setComponent(e,n,a){return this.normalized&&(a=Xi(a,this.array)),this.array[e*this.itemSize+n]=a,this}getX(e){let n=this.array[e*this.itemSize];return this.normalized&&(n=ac(n,this.array)),n}setX(e,n){return this.normalized&&(n=Xi(n,this.array)),this.array[e*this.itemSize]=n,this}getY(e){let n=this.array[e*this.itemSize+1];return this.normalized&&(n=ac(n,this.array)),n}setY(e,n){return this.normalized&&(n=Xi(n,this.array)),this.array[e*this.itemSize+1]=n,this}getZ(e){let n=this.array[e*this.itemSize+2];return this.normalized&&(n=ac(n,this.array)),n}setZ(e,n){return this.normalized&&(n=Xi(n,this.array)),this.array[e*this.itemSize+2]=n,this}getW(e){let n=this.array[e*this.itemSize+3];return this.normalized&&(n=ac(n,this.array)),n}setW(e,n){return this.normalized&&(n=Xi(n,this.array)),this.array[e*this.itemSize+3]=n,this}setXY(e,n,a){return e*=this.itemSize,this.normalized&&(n=Xi(n,this.array),a=Xi(a,this.array)),this.array[e+0]=n,this.array[e+1]=a,this}setXYZ(e,n,a,r){return e*=this.itemSize,this.normalized&&(n=Xi(n,this.array),a=Xi(a,this.array),r=Xi(r,this.array)),this.array[e+0]=n,this.array[e+1]=a,this.array[e+2]=r,this}setXYZW(e,n,a,r,l){return e*=this.itemSize,this.normalized&&(n=Xi(n,this.array),a=Xi(a,this.array),r=Xi(r,this.array),l=Xi(l,this.array)),this.array[e+0]=n,this.array[e+1]=a,this.array[e+2]=r,this.array[e+3]=l,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==US&&(e.usage=this.usage),e}}class N1 extends xr{constructor(e,n,a){super(new Uint16Array(e),n,a)}}class U1 extends xr{constructor(e,n,a){super(new Uint32Array(e),n,a)}}class Ba extends xr{constructor(e,n,a){super(new Float32Array(e),n,a)}}const DR=new Kc,oc=new fe,u_=new fe;class Ad{constructor(e=new fe,n=-1){this.isSphere=!0,this.center=e,this.radius=n}set(e,n){return this.center.copy(e),this.radius=n,this}setFromPoints(e,n){const a=this.center;n!==void 0?a.copy(n):DR.setFromPoints(e).getCenter(a);let r=0;for(let l=0,c=e.length;l<c;l++)r=Math.max(r,a.distanceToSquared(e[l]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const n=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=n*n}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,n){const a=this.center.distanceToSquared(e);return n.copy(e),a>this.radius*this.radius&&(n.sub(this.center).normalize(),n.multiplyScalar(this.radius).add(this.center)),n}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;oc.subVectors(e,this.center);const n=oc.lengthSq();if(n>this.radius*this.radius){const a=Math.sqrt(n),r=(a-this.radius)*.5;this.center.addScaledVector(oc,r/a),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(u_.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(oc.copy(e.center).add(u_)),this.expandByPoint(oc.copy(e.center).sub(u_))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let NR=0;const Da=new Fn,c_=new qi,Ol=new fe,ua=new Kc,lc=new Kc,ii=new fe;class er extends hu{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:NR++}),this.uuid=Zc(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(cR(e)?U1:N1)(e,1):this.index=e,this}setIndirect(e,n=0){return this.indirect=e,this.indirectOffset=n,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,n){return this.attributes[e]=n,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,n,a=0){this.groups.push({start:e,count:n,materialIndex:a})}clearGroups(){this.groups=[]}setDrawRange(e,n){this.drawRange.start=e,this.drawRange.count=n}applyMatrix4(e){const n=this.attributes.position;n!==void 0&&(n.applyMatrix4(e),n.needsUpdate=!0);const a=this.attributes.normal;if(a!==void 0){const l=new wt().getNormalMatrix(e);a.applyNormalMatrix(l),a.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Da.makeRotationFromQuaternion(e),this.applyMatrix4(Da),this}rotateX(e){return Da.makeRotationX(e),this.applyMatrix4(Da),this}rotateY(e){return Da.makeRotationY(e),this.applyMatrix4(Da),this}rotateZ(e){return Da.makeRotationZ(e),this.applyMatrix4(Da),this}translate(e,n,a){return Da.makeTranslation(e,n,a),this.applyMatrix4(Da),this}scale(e,n,a){return Da.makeScale(e,n,a),this.applyMatrix4(Da),this}lookAt(e){return c_.lookAt(e),c_.updateMatrix(),this.applyMatrix4(c_.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Ol).negate(),this.translate(Ol.x,Ol.y,Ol.z),this}setFromPoints(e){const n=this.getAttribute("position");if(n===void 0){const a=[];for(let r=0,l=e.length;r<l;r++){const c=e[r];a.push(c.x,c.y,c.z||0)}this.setAttribute("position",new Ba(a,3))}else{const a=Math.min(e.length,n.count);for(let r=0;r<a;r++){const l=e[r];n.setXYZ(r,l.x,l.y,l.z||0)}e.length>n.count&&Mt("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),n.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Kc);const e=this.attributes.position,n=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Qt("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new fe(-1/0,-1/0,-1/0),new fe(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),n)for(let a=0,r=n.length;a<r;a++){const l=n[a];ua.setFromBufferAttribute(l),this.morphTargetsRelative?(ii.addVectors(this.boundingBox.min,ua.min),this.boundingBox.expandByPoint(ii),ii.addVectors(this.boundingBox.max,ua.max),this.boundingBox.expandByPoint(ii)):(this.boundingBox.expandByPoint(ua.min),this.boundingBox.expandByPoint(ua.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Qt('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ad);const e=this.attributes.position,n=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){Qt("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new fe,1/0);return}if(e){const a=this.boundingSphere.center;if(ua.setFromBufferAttribute(e),n)for(let l=0,c=n.length;l<c;l++){const f=n[l];lc.setFromBufferAttribute(f),this.morphTargetsRelative?(ii.addVectors(ua.min,lc.min),ua.expandByPoint(ii),ii.addVectors(ua.max,lc.max),ua.expandByPoint(ii)):(ua.expandByPoint(lc.min),ua.expandByPoint(lc.max))}ua.getCenter(a);let r=0;for(let l=0,c=e.count;l<c;l++)ii.fromBufferAttribute(e,l),r=Math.max(r,a.distanceToSquared(ii));if(n)for(let l=0,c=n.length;l<c;l++){const f=n[l],p=this.morphTargetsRelative;for(let d=0,_=f.count;d<_;d++)ii.fromBufferAttribute(f,d),p&&(Ol.fromBufferAttribute(e,d),ii.add(Ol)),r=Math.max(r,a.distanceToSquared(ii))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&Qt('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,n=this.attributes;if(e===null||n.position===void 0||n.normal===void 0||n.uv===void 0){Qt("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const a=n.position,r=n.normal,l=n.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new xr(new Float32Array(4*a.count),4));const c=this.getAttribute("tangent"),f=[],p=[];for(let T=0;T<a.count;T++)f[T]=new fe,p[T]=new fe;const d=new fe,_=new fe,v=new fe,g=new fn,x=new fn,M=new fn,b=new fe,y=new fe;function S(T,w,q){d.fromBufferAttribute(a,T),_.fromBufferAttribute(a,w),v.fromBufferAttribute(a,q),g.fromBufferAttribute(l,T),x.fromBufferAttribute(l,w),M.fromBufferAttribute(l,q),_.sub(d),v.sub(d),x.sub(g),M.sub(g);const G=1/(x.x*M.y-M.x*x.y);isFinite(G)&&(b.copy(_).multiplyScalar(M.y).addScaledVector(v,-x.y).multiplyScalar(G),y.copy(v).multiplyScalar(x.x).addScaledVector(_,-M.x).multiplyScalar(G),f[T].add(b),f[w].add(b),f[q].add(b),p[T].add(y),p[w].add(y),p[q].add(y))}let R=this.groups;R.length===0&&(R=[{start:0,count:e.count}]);for(let T=0,w=R.length;T<w;++T){const q=R[T],G=q.start,k=q.count;for(let $=G,te=G+k;$<te;$+=3)S(e.getX($+0),e.getX($+1),e.getX($+2))}const N=new fe,C=new fe,O=new fe,P=new fe;function L(T){O.fromBufferAttribute(r,T),P.copy(O);const w=f[T];N.copy(w),N.sub(O.multiplyScalar(O.dot(w))).normalize(),C.crossVectors(P,w);const G=C.dot(p[T])<0?-1:1;c.setXYZW(T,N.x,N.y,N.z,G)}for(let T=0,w=R.length;T<w;++T){const q=R[T],G=q.start,k=q.count;for(let $=G,te=G+k;$<te;$+=3)L(e.getX($+0)),L(e.getX($+1)),L(e.getX($+2))}}computeVertexNormals(){const e=this.index,n=this.getAttribute("position");if(n!==void 0){let a=this.getAttribute("normal");if(a===void 0)a=new xr(new Float32Array(n.count*3),3),this.setAttribute("normal",a);else for(let g=0,x=a.count;g<x;g++)a.setXYZ(g,0,0,0);const r=new fe,l=new fe,c=new fe,f=new fe,p=new fe,d=new fe,_=new fe,v=new fe;if(e)for(let g=0,x=e.count;g<x;g+=3){const M=e.getX(g+0),b=e.getX(g+1),y=e.getX(g+2);r.fromBufferAttribute(n,M),l.fromBufferAttribute(n,b),c.fromBufferAttribute(n,y),_.subVectors(c,l),v.subVectors(r,l),_.cross(v),f.fromBufferAttribute(a,M),p.fromBufferAttribute(a,b),d.fromBufferAttribute(a,y),f.add(_),p.add(_),d.add(_),a.setXYZ(M,f.x,f.y,f.z),a.setXYZ(b,p.x,p.y,p.z),a.setXYZ(y,d.x,d.y,d.z)}else for(let g=0,x=n.count;g<x;g+=3)r.fromBufferAttribute(n,g+0),l.fromBufferAttribute(n,g+1),c.fromBufferAttribute(n,g+2),_.subVectors(c,l),v.subVectors(r,l),_.cross(v),a.setXYZ(g+0,_.x,_.y,_.z),a.setXYZ(g+1,_.x,_.y,_.z),a.setXYZ(g+2,_.x,_.y,_.z);this.normalizeNormals(),a.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let n=0,a=e.count;n<a;n++)ii.fromBufferAttribute(e,n),ii.normalize(),e.setXYZ(n,ii.x,ii.y,ii.z)}toNonIndexed(){function e(f,p){const d=f.array,_=f.itemSize,v=f.normalized,g=new d.constructor(p.length*_);let x=0,M=0;for(let b=0,y=p.length;b<y;b++){f.isInterleavedBufferAttribute?x=p[b]*f.data.stride+f.offset:x=p[b]*_;for(let S=0;S<_;S++)g[M++]=d[x++]}return new xr(g,_,v)}if(this.index===null)return Mt("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const n=new er,a=this.index.array,r=this.attributes;for(const f in r){const p=r[f],d=e(p,a);n.setAttribute(f,d)}const l=this.morphAttributes;for(const f in l){const p=[],d=l[f];for(let _=0,v=d.length;_<v;_++){const g=d[_],x=e(g,a);p.push(x)}n.morphAttributes[f]=p}n.morphTargetsRelative=this.morphTargetsRelative;const c=this.groups;for(let f=0,p=c.length;f<p;f++){const d=c[f];n.addGroup(d.start,d.count,d.materialIndex)}return n}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const p=this.parameters;for(const d in p)p[d]!==void 0&&(e[d]=p[d]);return e}e.data={attributes:{}};const n=this.index;n!==null&&(e.data.index={type:n.array.constructor.name,array:Array.prototype.slice.call(n.array)});const a=this.attributes;for(const p in a){const d=a[p];e.data.attributes[p]=d.toJSON(e.data)}const r={};let l=!1;for(const p in this.morphAttributes){const d=this.morphAttributes[p],_=[];for(let v=0,g=d.length;v<g;v++){const x=d[v];_.push(x.toJSON(e.data))}_.length>0&&(r[p]=_,l=!0)}l&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const c=this.groups;c.length>0&&(e.data.groups=JSON.parse(JSON.stringify(c)));const f=this.boundingSphere;return f!==null&&(e.data.boundingSphere=f.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const n={};this.name=e.name;const a=e.index;a!==null&&this.setIndex(a.clone());const r=e.attributes;for(const d in r){const _=r[d];this.setAttribute(d,_.clone(n))}const l=e.morphAttributes;for(const d in l){const _=[],v=l[d];for(let g=0,x=v.length;g<x;g++)_.push(v[g].clone(n));this.morphAttributes[d]=_}this.morphTargetsRelative=e.morphTargetsRelative;const c=e.groups;for(let d=0,_=c.length;d<_;d++){const v=c[d];this.addGroup(v.start,v.count,v.materialIndex)}const f=e.boundingBox;f!==null&&(this.boundingBox=f.clone());const p=e.boundingSphere;return p!==null&&(this.boundingSphere=p.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}let UR=0;class Qc extends hu{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:UR++}),this.uuid=Zc(),this.name="",this.type="Material",this.blending=Yl,this.side=qs,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=F_,this.blendDst=I_,this.blendEquation=Co,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new qt(0,0,0),this.blendAlpha=0,this.depthFunc=eu,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=NS,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=El,this.stencilZFail=El,this.stencilZPass=El,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const n in e){const a=e[n];if(a===void 0){Mt(`Material: parameter '${n}' has value of undefined.`);continue}const r=this[n];if(r===void 0){Mt(`Material: '${n}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(a):r&&r.isVector3&&a&&a.isVector3?r.copy(a):this[n]=a}}toJSON(e){const n=e===void 0||typeof e=="string";n&&(e={textures:{},images:{}});const a={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};a.uuid=this.uuid,a.type=this.type,this.name!==""&&(a.name=this.name),this.color&&this.color.isColor&&(a.color=this.color.getHex()),this.roughness!==void 0&&(a.roughness=this.roughness),this.metalness!==void 0&&(a.metalness=this.metalness),this.sheen!==void 0&&(a.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(a.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(a.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(a.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(a.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(a.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(a.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(a.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(a.shininess=this.shininess),this.clearcoat!==void 0&&(a.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(a.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(a.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(a.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(a.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,a.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(a.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(a.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(a.dispersion=this.dispersion),this.iridescence!==void 0&&(a.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(a.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(a.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(a.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(a.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(a.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(a.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(a.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(a.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(a.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(a.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(a.lightMap=this.lightMap.toJSON(e).uuid,a.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(a.aoMap=this.aoMap.toJSON(e).uuid,a.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(a.bumpMap=this.bumpMap.toJSON(e).uuid,a.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(a.normalMap=this.normalMap.toJSON(e).uuid,a.normalMapType=this.normalMapType,a.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(a.displacementMap=this.displacementMap.toJSON(e).uuid,a.displacementScale=this.displacementScale,a.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(a.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(a.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(a.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(a.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(a.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(a.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(a.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(a.combine=this.combine)),this.envMapRotation!==void 0&&(a.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(a.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(a.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(a.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(a.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(a.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(a.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(a.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(a.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(a.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(a.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(a.size=this.size),this.shadowSide!==null&&(a.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(a.sizeAttenuation=this.sizeAttenuation),this.blending!==Yl&&(a.blending=this.blending),this.side!==qs&&(a.side=this.side),this.vertexColors===!0&&(a.vertexColors=!0),this.opacity<1&&(a.opacity=this.opacity),this.transparent===!0&&(a.transparent=!0),this.blendSrc!==F_&&(a.blendSrc=this.blendSrc),this.blendDst!==I_&&(a.blendDst=this.blendDst),this.blendEquation!==Co&&(a.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(a.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(a.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(a.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(a.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(a.blendAlpha=this.blendAlpha),this.depthFunc!==eu&&(a.depthFunc=this.depthFunc),this.depthTest===!1&&(a.depthTest=this.depthTest),this.depthWrite===!1&&(a.depthWrite=this.depthWrite),this.colorWrite===!1&&(a.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(a.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==NS&&(a.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(a.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(a.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==El&&(a.stencilFail=this.stencilFail),this.stencilZFail!==El&&(a.stencilZFail=this.stencilZFail),this.stencilZPass!==El&&(a.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(a.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(a.rotation=this.rotation),this.polygonOffset===!0&&(a.polygonOffset=!0),this.polygonOffsetFactor!==0&&(a.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(a.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(a.linewidth=this.linewidth),this.dashSize!==void 0&&(a.dashSize=this.dashSize),this.gapSize!==void 0&&(a.gapSize=this.gapSize),this.scale!==void 0&&(a.scale=this.scale),this.dithering===!0&&(a.dithering=!0),this.alphaTest>0&&(a.alphaTest=this.alphaTest),this.alphaHash===!0&&(a.alphaHash=!0),this.alphaToCoverage===!0&&(a.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(a.premultipliedAlpha=!0),this.forceSinglePass===!0&&(a.forceSinglePass=!0),this.allowOverride===!1&&(a.allowOverride=!1),this.wireframe===!0&&(a.wireframe=!0),this.wireframeLinewidth>1&&(a.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(a.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(a.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(a.flatShading=!0),this.visible===!1&&(a.visible=!1),this.toneMapped===!1&&(a.toneMapped=!1),this.fog===!1&&(a.fog=!1),Object.keys(this.userData).length>0&&(a.userData=this.userData);function r(l){const c=[];for(const f in l){const p=l[f];delete p.metadata,c.push(p)}return c}if(n){const l=r(e.textures),c=r(e.images);l.length>0&&(a.textures=l),c.length>0&&(a.images=c)}return a}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const n=e.clippingPlanes;let a=null;if(n!==null){const r=n.length;a=new Array(r);for(let l=0;l!==r;++l)a[l]=n[l].clone()}return this.clippingPlanes=a,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}const Wr=new fe,f_=new fe,vh=new fe,Os=new fe,h_=new fe,xh=new fe,d_=new fe;class L1{constructor(e=new fe,n=new fe(0,0,-1)){this.origin=e,this.direction=n}set(e,n){return this.origin.copy(e),this.direction.copy(n),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,n){return n.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Wr)),this}closestPointToPoint(e,n){n.subVectors(e,this.origin);const a=n.dot(this.direction);return a<0?n.copy(this.origin):n.copy(this.origin).addScaledVector(this.direction,a)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const n=Wr.subVectors(e,this.origin).dot(this.direction);return n<0?this.origin.distanceToSquared(e):(Wr.copy(this.origin).addScaledVector(this.direction,n),Wr.distanceToSquared(e))}distanceSqToSegment(e,n,a,r){f_.copy(e).add(n).multiplyScalar(.5),vh.copy(n).sub(e).normalize(),Os.copy(this.origin).sub(f_);const l=e.distanceTo(n)*.5,c=-this.direction.dot(vh),f=Os.dot(this.direction),p=-Os.dot(vh),d=Os.lengthSq(),_=Math.abs(1-c*c);let v,g,x,M;if(_>0)if(v=c*p-f,g=c*f-p,M=l*_,v>=0)if(g>=-M)if(g<=M){const b=1/_;v*=b,g*=b,x=v*(v+c*g+2*f)+g*(c*v+g+2*p)+d}else g=l,v=Math.max(0,-(c*g+f)),x=-v*v+g*(g+2*p)+d;else g=-l,v=Math.max(0,-(c*g+f)),x=-v*v+g*(g+2*p)+d;else g<=-M?(v=Math.max(0,-(-c*l+f)),g=v>0?-l:Math.min(Math.max(-l,-p),l),x=-v*v+g*(g+2*p)+d):g<=M?(v=0,g=Math.min(Math.max(-l,-p),l),x=g*(g+2*p)+d):(v=Math.max(0,-(c*l+f)),g=v>0?l:Math.min(Math.max(-l,-p),l),x=-v*v+g*(g+2*p)+d);else g=c>0?-l:l,v=Math.max(0,-(c*g+f)),x=-v*v+g*(g+2*p)+d;return a&&a.copy(this.origin).addScaledVector(this.direction,v),r&&r.copy(f_).addScaledVector(vh,g),x}intersectSphere(e,n){Wr.subVectors(e.center,this.origin);const a=Wr.dot(this.direction),r=Wr.dot(Wr)-a*a,l=e.radius*e.radius;if(r>l)return null;const c=Math.sqrt(l-r),f=a-c,p=a+c;return p<0?null:f<0?this.at(p,n):this.at(f,n)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const n=e.normal.dot(this.direction);if(n===0)return e.distanceToPoint(this.origin)===0?0:null;const a=-(this.origin.dot(e.normal)+e.constant)/n;return a>=0?a:null}intersectPlane(e,n){const a=this.distanceToPlane(e);return a===null?null:this.at(a,n)}intersectsPlane(e){const n=e.distanceToPoint(this.origin);return n===0||e.normal.dot(this.direction)*n<0}intersectBox(e,n){let a,r,l,c,f,p;const d=1/this.direction.x,_=1/this.direction.y,v=1/this.direction.z,g=this.origin;return d>=0?(a=(e.min.x-g.x)*d,r=(e.max.x-g.x)*d):(a=(e.max.x-g.x)*d,r=(e.min.x-g.x)*d),_>=0?(l=(e.min.y-g.y)*_,c=(e.max.y-g.y)*_):(l=(e.max.y-g.y)*_,c=(e.min.y-g.y)*_),a>c||l>r||((l>a||isNaN(a))&&(a=l),(c<r||isNaN(r))&&(r=c),v>=0?(f=(e.min.z-g.z)*v,p=(e.max.z-g.z)*v):(f=(e.max.z-g.z)*v,p=(e.min.z-g.z)*v),a>p||f>r)||((f>a||a!==a)&&(a=f),(p<r||r!==r)&&(r=p),r<0)?null:this.at(a>=0?a:r,n)}intersectsBox(e){return this.intersectBox(e,Wr)!==null}intersectTriangle(e,n,a,r,l){h_.subVectors(n,e),xh.subVectors(a,e),d_.crossVectors(h_,xh);let c=this.direction.dot(d_),f;if(c>0){if(r)return null;f=1}else if(c<0)f=-1,c=-c;else return null;Os.subVectors(this.origin,e);const p=f*this.direction.dot(xh.crossVectors(Os,xh));if(p<0)return null;const d=f*this.direction.dot(h_.cross(Os));if(d<0||p+d>c)return null;const _=-f*Os.dot(d_);return _<0?null:this.at(_/c,l)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class fg extends Qc{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new qt(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new is,this.combine=f1,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const qS=new Fn,vo=new L1,yh=new Ad,jS=new fe,Sh=new fe,Mh=new fe,bh=new fe,p_=new fe,Eh=new fe,ZS=new fe,Th=new fe;class $a extends qi{constructor(e=new er,n=new fg){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=n,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,n){return super.copy(e,n),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const n=this.geometry.morphAttributes,a=Object.keys(n);if(a.length>0){const r=n[a[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let l=0,c=r.length;l<c;l++){const f=r[l].name||String(l);this.morphTargetInfluences.push(0),this.morphTargetDictionary[f]=l}}}}getVertexPosition(e,n){const a=this.geometry,r=a.attributes.position,l=a.morphAttributes.position,c=a.morphTargetsRelative;n.fromBufferAttribute(r,e);const f=this.morphTargetInfluences;if(l&&f){Eh.set(0,0,0);for(let p=0,d=l.length;p<d;p++){const _=f[p],v=l[p];_!==0&&(p_.fromBufferAttribute(v,e),c?Eh.addScaledVector(p_,_):Eh.addScaledVector(p_.sub(n),_))}n.add(Eh)}return n}raycast(e,n){const a=this.geometry,r=this.material,l=this.matrixWorld;r!==void 0&&(a.boundingSphere===null&&a.computeBoundingSphere(),yh.copy(a.boundingSphere),yh.applyMatrix4(l),vo.copy(e.ray).recast(e.near),!(yh.containsPoint(vo.origin)===!1&&(vo.intersectSphere(yh,jS)===null||vo.origin.distanceToSquared(jS)>(e.far-e.near)**2))&&(qS.copy(l).invert(),vo.copy(e.ray).applyMatrix4(qS),!(a.boundingBox!==null&&vo.intersectsBox(a.boundingBox)===!1)&&this._computeIntersections(e,n,vo)))}_computeIntersections(e,n,a){let r;const l=this.geometry,c=this.material,f=l.index,p=l.attributes.position,d=l.attributes.uv,_=l.attributes.uv1,v=l.attributes.normal,g=l.groups,x=l.drawRange;if(f!==null)if(Array.isArray(c))for(let M=0,b=g.length;M<b;M++){const y=g[M],S=c[y.materialIndex],R=Math.max(y.start,x.start),N=Math.min(f.count,Math.min(y.start+y.count,x.start+x.count));for(let C=R,O=N;C<O;C+=3){const P=f.getX(C),L=f.getX(C+1),T=f.getX(C+2);r=Ah(this,S,e,a,d,_,v,P,L,T),r&&(r.faceIndex=Math.floor(C/3),r.face.materialIndex=y.materialIndex,n.push(r))}}else{const M=Math.max(0,x.start),b=Math.min(f.count,x.start+x.count);for(let y=M,S=b;y<S;y+=3){const R=f.getX(y),N=f.getX(y+1),C=f.getX(y+2);r=Ah(this,c,e,a,d,_,v,R,N,C),r&&(r.faceIndex=Math.floor(y/3),n.push(r))}}else if(p!==void 0)if(Array.isArray(c))for(let M=0,b=g.length;M<b;M++){const y=g[M],S=c[y.materialIndex],R=Math.max(y.start,x.start),N=Math.min(p.count,Math.min(y.start+y.count,x.start+x.count));for(let C=R,O=N;C<O;C+=3){const P=C,L=C+1,T=C+2;r=Ah(this,S,e,a,d,_,v,P,L,T),r&&(r.faceIndex=Math.floor(C/3),r.face.materialIndex=y.materialIndex,n.push(r))}}else{const M=Math.max(0,x.start),b=Math.min(p.count,x.start+x.count);for(let y=M,S=b;y<S;y+=3){const R=y,N=y+1,C=y+2;r=Ah(this,c,e,a,d,_,v,R,N,C),r&&(r.faceIndex=Math.floor(y/3),n.push(r))}}}}function LR(o,e,n,a,r,l,c,f){let p;if(e.side===Yi?p=a.intersectTriangle(c,l,r,!0,f):p=a.intersectTriangle(r,l,c,e.side===qs,f),p===null)return null;Th.copy(f),Th.applyMatrix4(o.matrixWorld);const d=n.ray.origin.distanceTo(Th);return d<n.near||d>n.far?null:{distance:d,point:Th.clone(),object:o}}function Ah(o,e,n,a,r,l,c,f,p,d){o.getVertexPosition(f,Sh),o.getVertexPosition(p,Mh),o.getVertexPosition(d,bh);const _=LR(o,e,n,a,Sh,Mh,bh,ZS);if(_){const v=new fe;Qa.getBarycoord(ZS,Sh,Mh,bh,v),r&&(_.uv=Qa.getInterpolatedAttribute(r,f,p,d,v,new fn)),l&&(_.uv1=Qa.getInterpolatedAttribute(l,f,p,d,v,new fn)),c&&(_.normal=Qa.getInterpolatedAttribute(c,f,p,d,v,new fe),_.normal.dot(a.direction)>0&&_.normal.multiplyScalar(-1));const g={a:f,b:p,c:d,normal:new fe,materialIndex:0};Qa.getNormal(Sh,Mh,bh,g.normal),_.face=g,_.barycoord=v}return _}class OR extends Fi{constructor(e=null,n=1,a=1,r,l,c,f,p,d=fi,_=fi,v,g){super(null,c,f,p,d,_,r,l,v,g),this.isDataTexture=!0,this.image={data:e,width:n,height:a},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const m_=new fe,PR=new fe,zR=new wt;class Eo{constructor(e=new fe(1,0,0),n=0){this.isPlane=!0,this.normal=e,this.constant=n}set(e,n){return this.normal.copy(e),this.constant=n,this}setComponents(e,n,a,r){return this.normal.set(e,n,a),this.constant=r,this}setFromNormalAndCoplanarPoint(e,n){return this.normal.copy(e),this.constant=-n.dot(this.normal),this}setFromCoplanarPoints(e,n,a){const r=m_.subVectors(a,n).cross(PR.subVectors(e,n)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,n){return n.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,n){const a=e.delta(m_),r=this.normal.dot(a);if(r===0)return this.distanceToPoint(e.start)===0?n.copy(e.start):null;const l=-(e.start.dot(this.normal)+this.constant)/r;return l<0||l>1?null:n.copy(e.start).addScaledVector(a,l)}intersectsLine(e){const n=this.distanceToPoint(e.start),a=this.distanceToPoint(e.end);return n<0&&a>0||a<0&&n>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,n){const a=n||zR.getNormalMatrix(e),r=this.coplanarPoint(m_).applyMatrix4(e),l=this.normal.applyMatrix3(a).normalize();return this.constant=-r.dot(l),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const xo=new Ad,FR=new fn(.5,.5),Rh=new fe;class O1{constructor(e=new Eo,n=new Eo,a=new Eo,r=new Eo,l=new Eo,c=new Eo){this.planes=[e,n,a,r,l,c]}set(e,n,a,r,l,c){const f=this.planes;return f[0].copy(e),f[1].copy(n),f[2].copy(a),f[3].copy(r),f[4].copy(l),f[5].copy(c),this}copy(e){const n=this.planes;for(let a=0;a<6;a++)n[a].copy(e.planes[a]);return this}setFromProjectionMatrix(e,n=pr,a=!1){const r=this.planes,l=e.elements,c=l[0],f=l[1],p=l[2],d=l[3],_=l[4],v=l[5],g=l[6],x=l[7],M=l[8],b=l[9],y=l[10],S=l[11],R=l[12],N=l[13],C=l[14],O=l[15];if(r[0].setComponents(d-c,x-_,S-M,O-R).normalize(),r[1].setComponents(d+c,x+_,S+M,O+R).normalize(),r[2].setComponents(d+f,x+v,S+b,O+N).normalize(),r[3].setComponents(d-f,x-v,S-b,O-N).normalize(),a)r[4].setComponents(p,g,y,C).normalize(),r[5].setComponents(d-p,x-g,S-y,O-C).normalize();else if(r[4].setComponents(d-p,x-g,S-y,O-C).normalize(),n===pr)r[5].setComponents(d+p,x+g,S+y,O+C).normalize();else if(n===cd)r[5].setComponents(p,g,y,C).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+n);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),xo.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const n=e.geometry;n.boundingSphere===null&&n.computeBoundingSphere(),xo.copy(n.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(xo)}intersectsSprite(e){xo.center.set(0,0,0);const n=FR.distanceTo(e.center);return xo.radius=.7071067811865476+n,xo.applyMatrix4(e.matrixWorld),this.intersectsSphere(xo)}intersectsSphere(e){const n=this.planes,a=e.center,r=-e.radius;for(let l=0;l<6;l++)if(n[l].distanceToPoint(a)<r)return!1;return!0}intersectsBox(e){const n=this.planes;for(let a=0;a<6;a++){const r=n[a];if(Rh.x=r.normal.x>0?e.max.x:e.min.x,Rh.y=r.normal.y>0?e.max.y:e.min.y,Rh.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Rh)<0)return!1}return!0}containsPoint(e){const n=this.planes;for(let a=0;a<6;a++)if(n[a].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class IR extends Qc{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new qt(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const KS=new Fn,R0=new L1,Ch=new Ad,wh=new fe;class BR extends qi{constructor(e=new er,n=new IR){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=n,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,n){return super.copy(e,n),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,n){const a=this.geometry,r=this.matrixWorld,l=e.params.Points.threshold,c=a.drawRange;if(a.boundingSphere===null&&a.computeBoundingSphere(),Ch.copy(a.boundingSphere),Ch.applyMatrix4(r),Ch.radius+=l,e.ray.intersectsSphere(Ch)===!1)return;KS.copy(r).invert(),R0.copy(e.ray).applyMatrix4(KS);const f=l/((this.scale.x+this.scale.y+this.scale.z)/3),p=f*f,d=a.index,v=a.attributes.position;if(d!==null){const g=Math.max(0,c.start),x=Math.min(d.count,c.start+c.count);for(let M=g,b=x;M<b;M++){const y=d.getX(M);wh.fromBufferAttribute(v,y),QS(wh,y,p,r,e,n,this)}}else{const g=Math.max(0,c.start),x=Math.min(v.count,c.start+c.count);for(let M=g,b=x;M<b;M++)wh.fromBufferAttribute(v,M),QS(wh,M,p,r,e,n,this)}}updateMorphTargets(){const n=this.geometry.morphAttributes,a=Object.keys(n);if(a.length>0){const r=n[a[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let l=0,c=r.length;l<c;l++){const f=r[l].name||String(l);this.morphTargetInfluences.push(0),this.morphTargetDictionary[f]=l}}}}}function QS(o,e,n,a,r,l,c){const f=R0.distanceSqToPoint(o);if(f<n){const p=new fe;R0.closestPointToPoint(o,p),p.applyMatrix4(a);const d=r.ray.origin.distanceTo(p);if(d<r.near||d>r.far)return;l.push({distance:d,distanceToRay:Math.sqrt(f),point:p,index:e,face:null,faceIndex:null,barycoord:null,object:c})}}class P1 extends Fi{constructor(e=[],n=Go,a,r,l,c,f,p,d,_){super(e,n,a,r,l,c,f,p,d,_),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Bc extends Fi{constructor(e,n,a=Sr,r,l,c,f=fi,p=fi,d,_=ns,v=1){if(_!==ns&&_!==No)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const g={width:e,height:n,depth:v};super(g,r,l,c,f,p,_,a,d),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new cg(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const n=super.toJSON(e);return this.compareFunction!==null&&(n.compareFunction=this.compareFunction),n}}class HR extends Bc{constructor(e,n=Sr,a=Go,r,l,c=fi,f=fi,p,d=ns){const _={width:e,height:e,depth:1},v=[_,_,_,_,_,_];super(e,e,n,a,r,l,c,f,p,d),this.image=v,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class z1 extends Fi{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class Jc extends er{constructor(e=1,n=1,a=1,r=1,l=1,c=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:n,depth:a,widthSegments:r,heightSegments:l,depthSegments:c};const f=this;r=Math.floor(r),l=Math.floor(l),c=Math.floor(c);const p=[],d=[],_=[],v=[];let g=0,x=0;M("z","y","x",-1,-1,a,n,e,c,l,0),M("z","y","x",1,-1,a,n,-e,c,l,1),M("x","z","y",1,1,e,a,n,r,c,2),M("x","z","y",1,-1,e,a,-n,r,c,3),M("x","y","z",1,-1,e,n,a,r,l,4),M("x","y","z",-1,-1,e,n,-a,r,l,5),this.setIndex(p),this.setAttribute("position",new Ba(d,3)),this.setAttribute("normal",new Ba(_,3)),this.setAttribute("uv",new Ba(v,2));function M(b,y,S,R,N,C,O,P,L,T,w){const q=C/L,G=O/T,k=C/2,$=O/2,te=P/2,J=L+1,z=T+1;let I=0,ie=0;const he=new fe;for(let H=0;H<z;H++){const F=H*G-$;for(let Q=0;Q<J;Q++){const xe=Q*q-k;he[b]=xe*R,he[y]=F*N,he[S]=te,d.push(he.x,he.y,he.z),he[b]=0,he[y]=0,he[S]=P>0?1:-1,_.push(he.x,he.y,he.z),v.push(Q/L),v.push(1-H/T),I+=1}}for(let H=0;H<T;H++)for(let F=0;F<L;F++){const Q=g+F+J*H,xe=g+F+J*(H+1),Te=g+(F+1)+J*(H+1),Ne=g+(F+1)+J*H;p.push(Q,xe,Ne),p.push(xe,Te,Ne),ie+=6}f.addGroup(x,ie,w),x+=ie,g+=I}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Jc(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class Rd extends er{constructor(e=1,n=1,a=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:n,widthSegments:a,heightSegments:r};const l=e/2,c=n/2,f=Math.floor(a),p=Math.floor(r),d=f+1,_=p+1,v=e/f,g=n/p,x=[],M=[],b=[],y=[];for(let S=0;S<_;S++){const R=S*g-c;for(let N=0;N<d;N++){const C=N*v-l;M.push(C,-R,0),b.push(0,0,1),y.push(N/f),y.push(1-S/p)}}for(let S=0;S<p;S++)for(let R=0;R<f;R++){const N=R+d*S,C=R+d*(S+1),O=R+1+d*(S+1),P=R+1+d*S;x.push(N,C,P),x.push(C,O,P)}this.setIndex(x),this.setAttribute("position",new Ba(M,3)),this.setAttribute("normal",new Ba(b,3)),this.setAttribute("uv",new Ba(y,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Rd(e.width,e.height,e.widthSegments,e.heightSegments)}}class dd extends er{constructor(e=1,n=32,a=16,r=0,l=Math.PI*2,c=0,f=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:n,heightSegments:a,phiStart:r,phiLength:l,thetaStart:c,thetaLength:f},n=Math.max(3,Math.floor(n)),a=Math.max(2,Math.floor(a));const p=Math.min(c+f,Math.PI);let d=0;const _=[],v=new fe,g=new fe,x=[],M=[],b=[],y=[];for(let S=0;S<=a;S++){const R=[],N=S/a;let C=0;S===0&&c===0?C=.5/n:S===a&&p===Math.PI&&(C=-.5/n);for(let O=0;O<=n;O++){const P=O/n;v.x=-e*Math.cos(r+P*l)*Math.sin(c+N*f),v.y=e*Math.cos(c+N*f),v.z=e*Math.sin(r+P*l)*Math.sin(c+N*f),M.push(v.x,v.y,v.z),g.copy(v).normalize(),b.push(g.x,g.y,g.z),y.push(P+C,1-N),R.push(d++)}_.push(R)}for(let S=0;S<a;S++)for(let R=0;R<n;R++){const N=_[S][R+1],C=_[S][R],O=_[S+1][R],P=_[S+1][R+1];(S!==0||c>0)&&x.push(N,C,P),(S!==a-1||p<Math.PI)&&x.push(C,O,P)}this.setIndex(x),this.setAttribute("position",new Ba(M,3)),this.setAttribute("normal",new Ba(b,3)),this.setAttribute("uv",new Ba(y,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new dd(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}function au(o){const e={};for(const n in o){e[n]={};for(const a in o[n]){const r=o[n][a];r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)?r.isRenderTargetTexture?(Mt("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[n][a]=null):e[n][a]=r.clone():Array.isArray(r)?e[n][a]=r.slice():e[n][a]=r}}return e}function Ni(o){const e={};for(let n=0;n<o.length;n++){const a=au(o[n]);for(const r in a)e[r]=a[r]}return e}function GR(o){const e=[];for(let n=0;n<o.length;n++)e.push(o[n].clone());return e}function F1(o){const e=o.getRenderTarget();return e===null?o.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:Yt.workingColorSpace}const VR={clone:au,merge:Ni};var kR=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,XR=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Ga extends Qc{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=kR,this.fragmentShader=XR,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=au(e.uniforms),this.uniformsGroups=GR(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const n=super.toJSON(e);n.glslVersion=this.glslVersion,n.uniforms={};for(const r in this.uniforms){const c=this.uniforms[r].value;c&&c.isTexture?n.uniforms[r]={type:"t",value:c.toJSON(e).uuid}:c&&c.isColor?n.uniforms[r]={type:"c",value:c.getHex()}:c&&c.isVector2?n.uniforms[r]={type:"v2",value:c.toArray()}:c&&c.isVector3?n.uniforms[r]={type:"v3",value:c.toArray()}:c&&c.isVector4?n.uniforms[r]={type:"v4",value:c.toArray()}:c&&c.isMatrix3?n.uniforms[r]={type:"m3",value:c.toArray()}:c&&c.isMatrix4?n.uniforms[r]={type:"m4",value:c.toArray()}:n.uniforms[r]={value:c}}Object.keys(this.defines).length>0&&(n.defines=this.defines),n.vertexShader=this.vertexShader,n.fragmentShader=this.fragmentShader,n.lights=this.lights,n.clipping=this.clipping;const a={};for(const r in this.extensions)this.extensions[r]===!0&&(a[r]=!0);return Object.keys(a).length>0&&(n.extensions=a),n}}class WR extends Ga{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class YR extends Qc{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=tR,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class qR extends Qc{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const Dh=new fe,Nh=new du,rr=new fe;class I1 extends qi{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Fn,this.projectionMatrix=new Fn,this.projectionMatrixInverse=new Fn,this.coordinateSystem=pr,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,n){return super.copy(e,n),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Dh,Nh,rr),rr.x===1&&rr.y===1&&rr.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Dh,Nh,rr.set(1,1,1)).invert()}updateWorldMatrix(e,n){super.updateWorldMatrix(e,n),this.matrixWorld.decompose(Dh,Nh,rr),rr.x===1&&rr.y===1&&rr.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Dh,Nh,rr.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const Ps=new fe,JS=new fn,$S=new fn;class La extends I1{constructor(e=50,n=1,a=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=a,this.far=r,this.focus=10,this.aspect=n,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,n){return super.copy(e,n),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const n=.5*this.getFilmHeight()/e;this.fov=A0*2*Math.atan(n),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(Ym*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return A0*2*Math.atan(Math.tan(Ym*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,n,a){Ps.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Ps.x,Ps.y).multiplyScalar(-e/Ps.z),Ps.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),a.set(Ps.x,Ps.y).multiplyScalar(-e/Ps.z)}getViewSize(e,n){return this.getViewBounds(e,JS,$S),n.subVectors($S,JS)}setViewOffset(e,n,a,r,l,c){this.aspect=e/n,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=n,this.view.offsetX=a,this.view.offsetY=r,this.view.width=l,this.view.height=c,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let n=e*Math.tan(Ym*.5*this.fov)/this.zoom,a=2*n,r=this.aspect*a,l=-.5*r;const c=this.view;if(this.view!==null&&this.view.enabled){const p=c.fullWidth,d=c.fullHeight;l+=c.offsetX*r/p,n-=c.offsetY*a/d,r*=c.width/p,a*=c.height/d}const f=this.filmOffset;f!==0&&(l+=e*f/this.getFilmWidth()),this.projectionMatrix.makePerspective(l,l+r,n,n-a,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const n=super.toJSON(e);return n.object.fov=this.fov,n.object.zoom=this.zoom,n.object.near=this.near,n.object.far=this.far,n.object.focus=this.focus,n.object.aspect=this.aspect,this.view!==null&&(n.object.view=Object.assign({},this.view)),n.object.filmGauge=this.filmGauge,n.object.filmOffset=this.filmOffset,n}}class B1 extends I1{constructor(e=-1,n=1,a=1,r=-1,l=.1,c=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=n,this.top=a,this.bottom=r,this.near=l,this.far=c,this.updateProjectionMatrix()}copy(e,n){return super.copy(e,n),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,n,a,r,l,c){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=n,this.view.offsetX=a,this.view.offsetY=r,this.view.width=l,this.view.height=c,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),n=(this.top-this.bottom)/(2*this.zoom),a=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let l=a-e,c=a+e,f=r+n,p=r-n;if(this.view!==null&&this.view.enabled){const d=(this.right-this.left)/this.view.fullWidth/this.zoom,_=(this.top-this.bottom)/this.view.fullHeight/this.zoom;l+=d*this.view.offsetX,c=l+d*this.view.width,f-=_*this.view.offsetY,p=f-_*this.view.height}this.projectionMatrix.makeOrthographic(l,c,f,p,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const n=super.toJSON(e);return n.object.zoom=this.zoom,n.object.left=this.left,n.object.right=this.right,n.object.top=this.top,n.object.bottom=this.bottom,n.object.near=this.near,n.object.far=this.far,this.view!==null&&(n.object.view=Object.assign({},this.view)),n}}const Pl=-90,zl=1;class jR extends qi{constructor(e,n,a){super(),this.type="CubeCamera",this.renderTarget=a,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new La(Pl,zl,e,n);r.layers=this.layers,this.add(r);const l=new La(Pl,zl,e,n);l.layers=this.layers,this.add(l);const c=new La(Pl,zl,e,n);c.layers=this.layers,this.add(c);const f=new La(Pl,zl,e,n);f.layers=this.layers,this.add(f);const p=new La(Pl,zl,e,n);p.layers=this.layers,this.add(p);const d=new La(Pl,zl,e,n);d.layers=this.layers,this.add(d)}updateCoordinateSystem(){const e=this.coordinateSystem,n=this.children.concat(),[a,r,l,c,f,p]=n;for(const d of n)this.remove(d);if(e===pr)a.up.set(0,1,0),a.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),l.up.set(0,0,-1),l.lookAt(0,1,0),c.up.set(0,0,1),c.lookAt(0,-1,0),f.up.set(0,1,0),f.lookAt(0,0,1),p.up.set(0,1,0),p.lookAt(0,0,-1);else if(e===cd)a.up.set(0,-1,0),a.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),l.up.set(0,0,1),l.lookAt(0,1,0),c.up.set(0,0,-1),c.lookAt(0,-1,0),f.up.set(0,-1,0),f.lookAt(0,0,1),p.up.set(0,-1,0),p.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const d of n)this.add(d),d.updateMatrixWorld()}update(e,n){this.parent===null&&this.updateMatrixWorld();const{renderTarget:a,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[l,c,f,p,d,_]=this.children,v=e.getRenderTarget(),g=e.getActiveCubeFace(),x=e.getActiveMipmapLevel(),M=e.xr.enabled;e.xr.enabled=!1;const b=a.texture.generateMipmaps;a.texture.generateMipmaps=!1;let y=!1;e.isWebGLRenderer===!0?y=e.state.buffers.depth.getReversed():y=e.reversedDepthBuffer,e.setRenderTarget(a,0,r),y&&e.autoClear===!1&&e.clearDepth(),e.render(n,l),e.setRenderTarget(a,1,r),y&&e.autoClear===!1&&e.clearDepth(),e.render(n,c),e.setRenderTarget(a,2,r),y&&e.autoClear===!1&&e.clearDepth(),e.render(n,f),e.setRenderTarget(a,3,r),y&&e.autoClear===!1&&e.clearDepth(),e.render(n,p),e.setRenderTarget(a,4,r),y&&e.autoClear===!1&&e.clearDepth(),e.render(n,d),a.texture.generateMipmaps=b,e.setRenderTarget(a,5,r),y&&e.autoClear===!1&&e.clearDepth(),e.render(n,_),e.setRenderTarget(v,g,x),e.xr.enabled=M,a.texture.needsPMREMUpdate=!0}}class ZR extends La{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}function eM(o,e,n,a){const r=KR(a);switch(n){case E1:return o*e;case A1:return o*e/r.components*r.byteLength;case rg:return o*e/r.components*r.byteLength;case nu:return o*e*2/r.components*r.byteLength;case sg:return o*e*2/r.components*r.byteLength;case T1:return o*e*3/r.components*r.byteLength;case Ja:return o*e*4/r.components*r.byteLength;case og:return o*e*4/r.components*r.byteLength;case Zh:case Kh:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*8;case Qh:case Jh:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*16;case Z_:case Q_:return Math.max(o,16)*Math.max(e,8)/4;case j_:case K_:return Math.max(o,8)*Math.max(e,8)/2;case J_:case $_:case t0:case n0:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*8;case e0:case i0:case a0:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*16;case r0:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*16;case s0:return Math.floor((o+4)/5)*Math.floor((e+3)/4)*16;case o0:return Math.floor((o+4)/5)*Math.floor((e+4)/5)*16;case l0:return Math.floor((o+5)/6)*Math.floor((e+4)/5)*16;case u0:return Math.floor((o+5)/6)*Math.floor((e+5)/6)*16;case c0:return Math.floor((o+7)/8)*Math.floor((e+4)/5)*16;case f0:return Math.floor((o+7)/8)*Math.floor((e+5)/6)*16;case h0:return Math.floor((o+7)/8)*Math.floor((e+7)/8)*16;case d0:return Math.floor((o+9)/10)*Math.floor((e+4)/5)*16;case p0:return Math.floor((o+9)/10)*Math.floor((e+5)/6)*16;case m0:return Math.floor((o+9)/10)*Math.floor((e+7)/8)*16;case _0:return Math.floor((o+9)/10)*Math.floor((e+9)/10)*16;case g0:return Math.floor((o+11)/12)*Math.floor((e+9)/10)*16;case v0:return Math.floor((o+11)/12)*Math.floor((e+11)/12)*16;case x0:case y0:case S0:return Math.ceil(o/4)*Math.ceil(e/4)*16;case M0:case b0:return Math.ceil(o/4)*Math.ceil(e/4)*8;case E0:case T0:return Math.ceil(o/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${n} format.`)}function KR(o){switch(o){case za:case y1:return{byteLength:1,components:1};case Fc:case S1:case ts:return{byteLength:2,components:1};case ig:case ag:return{byteLength:2,components:4};case Sr:case ng:case dr:return{byteLength:4,components:1};case M1:case b1:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${o}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:tg}}));typeof window<"u"&&(window.__THREE__?Mt("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=tg);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function H1(){let o=null,e=!1,n=null,a=null;function r(l,c){n(l,c),a=o.requestAnimationFrame(r)}return{start:function(){e!==!0&&n!==null&&(a=o.requestAnimationFrame(r),e=!0)},stop:function(){o.cancelAnimationFrame(a),e=!1},setAnimationLoop:function(l){n=l},setContext:function(l){o=l}}}function QR(o){const e=new WeakMap;function n(f,p){const d=f.array,_=f.usage,v=d.byteLength,g=o.createBuffer();o.bindBuffer(p,g),o.bufferData(p,d,_),f.onUploadCallback();let x;if(d instanceof Float32Array)x=o.FLOAT;else if(typeof Float16Array<"u"&&d instanceof Float16Array)x=o.HALF_FLOAT;else if(d instanceof Uint16Array)f.isFloat16BufferAttribute?x=o.HALF_FLOAT:x=o.UNSIGNED_SHORT;else if(d instanceof Int16Array)x=o.SHORT;else if(d instanceof Uint32Array)x=o.UNSIGNED_INT;else if(d instanceof Int32Array)x=o.INT;else if(d instanceof Int8Array)x=o.BYTE;else if(d instanceof Uint8Array)x=o.UNSIGNED_BYTE;else if(d instanceof Uint8ClampedArray)x=o.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+d);return{buffer:g,type:x,bytesPerElement:d.BYTES_PER_ELEMENT,version:f.version,size:v}}function a(f,p,d){const _=p.array,v=p.updateRanges;if(o.bindBuffer(d,f),v.length===0)o.bufferSubData(d,0,_);else{v.sort((x,M)=>x.start-M.start);let g=0;for(let x=1;x<v.length;x++){const M=v[g],b=v[x];b.start<=M.start+M.count+1?M.count=Math.max(M.count,b.start+b.count-M.start):(++g,v[g]=b)}v.length=g+1;for(let x=0,M=v.length;x<M;x++){const b=v[x];o.bufferSubData(d,b.start*_.BYTES_PER_ELEMENT,_,b.start,b.count)}p.clearUpdateRanges()}p.onUploadCallback()}function r(f){return f.isInterleavedBufferAttribute&&(f=f.data),e.get(f)}function l(f){f.isInterleavedBufferAttribute&&(f=f.data);const p=e.get(f);p&&(o.deleteBuffer(p.buffer),e.delete(f))}function c(f,p){if(f.isInterleavedBufferAttribute&&(f=f.data),f.isGLBufferAttribute){const _=e.get(f);(!_||_.version<f.version)&&e.set(f,{buffer:f.buffer,type:f.type,bytesPerElement:f.elementSize,version:f.version});return}const d=e.get(f);if(d===void 0)e.set(f,n(f,p));else if(d.version<f.version){if(d.size!==f.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");a(d.buffer,f,p),d.version=f.version}}return{get:r,remove:l,update:c}}var JR=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,$R=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,eC=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,tC=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,nC=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,iC=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,aC=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,rC=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,sC=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,oC=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,lC=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,uC=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,cC=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,fC=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,hC=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,dC=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,pC=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,mC=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,_C=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,gC=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,vC=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,xC=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,yC=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,SC=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,MC=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,bC=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,EC=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,TC=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,AC=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,RC=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,CC="gl_FragColor = linearToOutputTexel( gl_FragColor );",wC=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,DC=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,NC=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,UC=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,LC=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,OC=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,PC=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,zC=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,FC=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,IC=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,BC=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,HC=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,GC=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,VC=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,kC=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,XC=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,WC=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,YC=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,qC=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,jC=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,ZC=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,KC=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return v;
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,QC=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,JC=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,$C=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,e2=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,t2=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,n2=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,i2=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,a2=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,r2=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,s2=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,o2=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,l2=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,u2=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,c2=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,f2=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,h2=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,d2=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,p2=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,m2=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,_2=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,g2=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,v2=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,x2=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,y2=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,S2=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,M2=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,b2=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,E2=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,T2=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,A2=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,R2=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,C2=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,w2=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,D2=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,N2=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,U2=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,L2=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,O2=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,P2=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,z2=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,F2=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,I2=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,B2=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,H2=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,G2=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,V2=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,k2=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,X2=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,W2=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Y2=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,q2=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,j2=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Z2=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,K2=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Q2=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,J2=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,$2=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,ew=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,tw=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,nw=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,iw=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,aw=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,rw=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,sw=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,ow=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,lw=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,uw=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,cw=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,fw=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,hw=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,dw=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,pw=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,mw=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,_w=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,gw=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,vw=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,xw=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,yw=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Sw=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Mw=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,bw=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ew=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Tw=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Aw=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Rw=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Cw=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,ww=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Dw=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Dt={alphahash_fragment:JR,alphahash_pars_fragment:$R,alphamap_fragment:eC,alphamap_pars_fragment:tC,alphatest_fragment:nC,alphatest_pars_fragment:iC,aomap_fragment:aC,aomap_pars_fragment:rC,batching_pars_vertex:sC,batching_vertex:oC,begin_vertex:lC,beginnormal_vertex:uC,bsdfs:cC,iridescence_fragment:fC,bumpmap_pars_fragment:hC,clipping_planes_fragment:dC,clipping_planes_pars_fragment:pC,clipping_planes_pars_vertex:mC,clipping_planes_vertex:_C,color_fragment:gC,color_pars_fragment:vC,color_pars_vertex:xC,color_vertex:yC,common:SC,cube_uv_reflection_fragment:MC,defaultnormal_vertex:bC,displacementmap_pars_vertex:EC,displacementmap_vertex:TC,emissivemap_fragment:AC,emissivemap_pars_fragment:RC,colorspace_fragment:CC,colorspace_pars_fragment:wC,envmap_fragment:DC,envmap_common_pars_fragment:NC,envmap_pars_fragment:UC,envmap_pars_vertex:LC,envmap_physical_pars_fragment:XC,envmap_vertex:OC,fog_vertex:PC,fog_pars_vertex:zC,fog_fragment:FC,fog_pars_fragment:IC,gradientmap_pars_fragment:BC,lightmap_pars_fragment:HC,lights_lambert_fragment:GC,lights_lambert_pars_fragment:VC,lights_pars_begin:kC,lights_toon_fragment:WC,lights_toon_pars_fragment:YC,lights_phong_fragment:qC,lights_phong_pars_fragment:jC,lights_physical_fragment:ZC,lights_physical_pars_fragment:KC,lights_fragment_begin:QC,lights_fragment_maps:JC,lights_fragment_end:$C,logdepthbuf_fragment:e2,logdepthbuf_pars_fragment:t2,logdepthbuf_pars_vertex:n2,logdepthbuf_vertex:i2,map_fragment:a2,map_pars_fragment:r2,map_particle_fragment:s2,map_particle_pars_fragment:o2,metalnessmap_fragment:l2,metalnessmap_pars_fragment:u2,morphinstance_vertex:c2,morphcolor_vertex:f2,morphnormal_vertex:h2,morphtarget_pars_vertex:d2,morphtarget_vertex:p2,normal_fragment_begin:m2,normal_fragment_maps:_2,normal_pars_fragment:g2,normal_pars_vertex:v2,normal_vertex:x2,normalmap_pars_fragment:y2,clearcoat_normal_fragment_begin:S2,clearcoat_normal_fragment_maps:M2,clearcoat_pars_fragment:b2,iridescence_pars_fragment:E2,opaque_fragment:T2,packing:A2,premultiplied_alpha_fragment:R2,project_vertex:C2,dithering_fragment:w2,dithering_pars_fragment:D2,roughnessmap_fragment:N2,roughnessmap_pars_fragment:U2,shadowmap_pars_fragment:L2,shadowmap_pars_vertex:O2,shadowmap_vertex:P2,shadowmask_pars_fragment:z2,skinbase_vertex:F2,skinning_pars_vertex:I2,skinning_vertex:B2,skinnormal_vertex:H2,specularmap_fragment:G2,specularmap_pars_fragment:V2,tonemapping_fragment:k2,tonemapping_pars_fragment:X2,transmission_fragment:W2,transmission_pars_fragment:Y2,uv_pars_fragment:q2,uv_pars_vertex:j2,uv_vertex:Z2,worldpos_vertex:K2,background_vert:Q2,background_frag:J2,backgroundCube_vert:$2,backgroundCube_frag:ew,cube_vert:tw,cube_frag:nw,depth_vert:iw,depth_frag:aw,distance_vert:rw,distance_frag:sw,equirect_vert:ow,equirect_frag:lw,linedashed_vert:uw,linedashed_frag:cw,meshbasic_vert:fw,meshbasic_frag:hw,meshlambert_vert:dw,meshlambert_frag:pw,meshmatcap_vert:mw,meshmatcap_frag:_w,meshnormal_vert:gw,meshnormal_frag:vw,meshphong_vert:xw,meshphong_frag:yw,meshphysical_vert:Sw,meshphysical_frag:Mw,meshtoon_vert:bw,meshtoon_frag:Ew,points_vert:Tw,points_frag:Aw,shadow_vert:Rw,shadow_frag:Cw,sprite_vert:ww,sprite_frag:Dw},ke={common:{diffuse:{value:new qt(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new wt},alphaMap:{value:null},alphaMapTransform:{value:new wt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new wt}},envmap:{envMap:{value:null},envMapRotation:{value:new wt},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new wt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new wt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new wt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new wt},normalScale:{value:new fn(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new wt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new wt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new wt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new wt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new qt(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new qt(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new wt},alphaTest:{value:0},uvTransform:{value:new wt}},sprite:{diffuse:{value:new qt(16777215)},opacity:{value:1},center:{value:new fn(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new wt},alphaMap:{value:null},alphaMapTransform:{value:new wt},alphaTest:{value:0}}},fr={basic:{uniforms:Ni([ke.common,ke.specularmap,ke.envmap,ke.aomap,ke.lightmap,ke.fog]),vertexShader:Dt.meshbasic_vert,fragmentShader:Dt.meshbasic_frag},lambert:{uniforms:Ni([ke.common,ke.specularmap,ke.envmap,ke.aomap,ke.lightmap,ke.emissivemap,ke.bumpmap,ke.normalmap,ke.displacementmap,ke.fog,ke.lights,{emissive:{value:new qt(0)},envMapIntensity:{value:1}}]),vertexShader:Dt.meshlambert_vert,fragmentShader:Dt.meshlambert_frag},phong:{uniforms:Ni([ke.common,ke.specularmap,ke.envmap,ke.aomap,ke.lightmap,ke.emissivemap,ke.bumpmap,ke.normalmap,ke.displacementmap,ke.fog,ke.lights,{emissive:{value:new qt(0)},specular:{value:new qt(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Dt.meshphong_vert,fragmentShader:Dt.meshphong_frag},standard:{uniforms:Ni([ke.common,ke.envmap,ke.aomap,ke.lightmap,ke.emissivemap,ke.bumpmap,ke.normalmap,ke.displacementmap,ke.roughnessmap,ke.metalnessmap,ke.fog,ke.lights,{emissive:{value:new qt(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Dt.meshphysical_vert,fragmentShader:Dt.meshphysical_frag},toon:{uniforms:Ni([ke.common,ke.aomap,ke.lightmap,ke.emissivemap,ke.bumpmap,ke.normalmap,ke.displacementmap,ke.gradientmap,ke.fog,ke.lights,{emissive:{value:new qt(0)}}]),vertexShader:Dt.meshtoon_vert,fragmentShader:Dt.meshtoon_frag},matcap:{uniforms:Ni([ke.common,ke.bumpmap,ke.normalmap,ke.displacementmap,ke.fog,{matcap:{value:null}}]),vertexShader:Dt.meshmatcap_vert,fragmentShader:Dt.meshmatcap_frag},points:{uniforms:Ni([ke.points,ke.fog]),vertexShader:Dt.points_vert,fragmentShader:Dt.points_frag},dashed:{uniforms:Ni([ke.common,ke.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Dt.linedashed_vert,fragmentShader:Dt.linedashed_frag},depth:{uniforms:Ni([ke.common,ke.displacementmap]),vertexShader:Dt.depth_vert,fragmentShader:Dt.depth_frag},normal:{uniforms:Ni([ke.common,ke.bumpmap,ke.normalmap,ke.displacementmap,{opacity:{value:1}}]),vertexShader:Dt.meshnormal_vert,fragmentShader:Dt.meshnormal_frag},sprite:{uniforms:Ni([ke.sprite,ke.fog]),vertexShader:Dt.sprite_vert,fragmentShader:Dt.sprite_frag},background:{uniforms:{uvTransform:{value:new wt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Dt.background_vert,fragmentShader:Dt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new wt}},vertexShader:Dt.backgroundCube_vert,fragmentShader:Dt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Dt.cube_vert,fragmentShader:Dt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Dt.equirect_vert,fragmentShader:Dt.equirect_frag},distance:{uniforms:Ni([ke.common,ke.displacementmap,{referencePosition:{value:new fe},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Dt.distance_vert,fragmentShader:Dt.distance_frag},shadow:{uniforms:Ni([ke.lights,ke.fog,{color:{value:new qt(0)},opacity:{value:1}}]),vertexShader:Dt.shadow_vert,fragmentShader:Dt.shadow_frag}};fr.physical={uniforms:Ni([fr.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new wt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new wt},clearcoatNormalScale:{value:new fn(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new wt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new wt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new wt},sheen:{value:0},sheenColor:{value:new qt(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new wt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new wt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new wt},transmissionSamplerSize:{value:new fn},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new wt},attenuationDistance:{value:0},attenuationColor:{value:new qt(0)},specularColor:{value:new qt(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new wt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new wt},anisotropyVector:{value:new fn},anisotropyMap:{value:null},anisotropyMapTransform:{value:new wt}}]),vertexShader:Dt.meshphysical_vert,fragmentShader:Dt.meshphysical_frag};const Uh={r:0,b:0,g:0},yo=new is,Nw=new Fn;function Uw(o,e,n,a,r,l){const c=new qt(0);let f=r===!0?0:1,p,d,_=null,v=0,g=null;function x(R){let N=R.isScene===!0?R.background:null;if(N&&N.isTexture){const C=R.backgroundBlurriness>0;N=e.get(N,C)}return N}function M(R){let N=!1;const C=x(R);C===null?y(c,f):C&&C.isColor&&(y(C,1),N=!0);const O=o.xr.getEnvironmentBlendMode();O==="additive"?n.buffers.color.setClear(0,0,0,1,l):O==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,l),(o.autoClear||N)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),o.clear(o.autoClearColor,o.autoClearDepth,o.autoClearStencil))}function b(R,N){const C=x(N);C&&(C.isCubeTexture||C.mapping===Td)?(d===void 0&&(d=new $a(new Jc(1,1,1),new Ga({name:"BackgroundCubeMaterial",uniforms:au(fr.backgroundCube.uniforms),vertexShader:fr.backgroundCube.vertexShader,fragmentShader:fr.backgroundCube.fragmentShader,side:Yi,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),d.geometry.deleteAttribute("normal"),d.geometry.deleteAttribute("uv"),d.onBeforeRender=function(O,P,L){this.matrixWorld.copyPosition(L.matrixWorld)},Object.defineProperty(d.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),a.update(d)),yo.copy(N.backgroundRotation),yo.x*=-1,yo.y*=-1,yo.z*=-1,C.isCubeTexture&&C.isRenderTargetTexture===!1&&(yo.y*=-1,yo.z*=-1),d.material.uniforms.envMap.value=C,d.material.uniforms.flipEnvMap.value=C.isCubeTexture&&C.isRenderTargetTexture===!1?-1:1,d.material.uniforms.backgroundBlurriness.value=N.backgroundBlurriness,d.material.uniforms.backgroundIntensity.value=N.backgroundIntensity,d.material.uniforms.backgroundRotation.value.setFromMatrix4(Nw.makeRotationFromEuler(yo)),d.material.toneMapped=Yt.getTransfer(C.colorSpace)!==an,(_!==C||v!==C.version||g!==o.toneMapping)&&(d.material.needsUpdate=!0,_=C,v=C.version,g=o.toneMapping),d.layers.enableAll(),R.unshift(d,d.geometry,d.material,0,0,null)):C&&C.isTexture&&(p===void 0&&(p=new $a(new Rd(2,2),new Ga({name:"BackgroundMaterial",uniforms:au(fr.background.uniforms),vertexShader:fr.background.vertexShader,fragmentShader:fr.background.fragmentShader,side:qs,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),p.geometry.deleteAttribute("normal"),Object.defineProperty(p.material,"map",{get:function(){return this.uniforms.t2D.value}}),a.update(p)),p.material.uniforms.t2D.value=C,p.material.uniforms.backgroundIntensity.value=N.backgroundIntensity,p.material.toneMapped=Yt.getTransfer(C.colorSpace)!==an,C.matrixAutoUpdate===!0&&C.updateMatrix(),p.material.uniforms.uvTransform.value.copy(C.matrix),(_!==C||v!==C.version||g!==o.toneMapping)&&(p.material.needsUpdate=!0,_=C,v=C.version,g=o.toneMapping),p.layers.enableAll(),R.unshift(p,p.geometry,p.material,0,0,null))}function y(R,N){R.getRGB(Uh,F1(o)),n.buffers.color.setClear(Uh.r,Uh.g,Uh.b,N,l)}function S(){d!==void 0&&(d.geometry.dispose(),d.material.dispose(),d=void 0),p!==void 0&&(p.geometry.dispose(),p.material.dispose(),p=void 0)}return{getClearColor:function(){return c},setClearColor:function(R,N=1){c.set(R),f=N,y(c,f)},getClearAlpha:function(){return f},setClearAlpha:function(R){f=R,y(c,f)},render:M,addToRenderList:b,dispose:S}}function Lw(o,e){const n=o.getParameter(o.MAX_VERTEX_ATTRIBS),a={},r=g(null);let l=r,c=!1;function f(G,k,$,te,J){let z=!1;const I=v(G,te,$,k);l!==I&&(l=I,d(l.object)),z=x(G,te,$,J),z&&M(G,te,$,J),J!==null&&e.update(J,o.ELEMENT_ARRAY_BUFFER),(z||c)&&(c=!1,C(G,k,$,te),J!==null&&o.bindBuffer(o.ELEMENT_ARRAY_BUFFER,e.get(J).buffer))}function p(){return o.createVertexArray()}function d(G){return o.bindVertexArray(G)}function _(G){return o.deleteVertexArray(G)}function v(G,k,$,te){const J=te.wireframe===!0;let z=a[k.id];z===void 0&&(z={},a[k.id]=z);const I=G.isInstancedMesh===!0?G.id:0;let ie=z[I];ie===void 0&&(ie={},z[I]=ie);let he=ie[$.id];he===void 0&&(he={},ie[$.id]=he);let H=he[J];return H===void 0&&(H=g(p()),he[J]=H),H}function g(G){const k=[],$=[],te=[];for(let J=0;J<n;J++)k[J]=0,$[J]=0,te[J]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:k,enabledAttributes:$,attributeDivisors:te,object:G,attributes:{},index:null}}function x(G,k,$,te){const J=l.attributes,z=k.attributes;let I=0;const ie=$.getAttributes();for(const he in ie)if(ie[he].location>=0){const F=J[he];let Q=z[he];if(Q===void 0&&(he==="instanceMatrix"&&G.instanceMatrix&&(Q=G.instanceMatrix),he==="instanceColor"&&G.instanceColor&&(Q=G.instanceColor)),F===void 0||F.attribute!==Q||Q&&F.data!==Q.data)return!0;I++}return l.attributesNum!==I||l.index!==te}function M(G,k,$,te){const J={},z=k.attributes;let I=0;const ie=$.getAttributes();for(const he in ie)if(ie[he].location>=0){let F=z[he];F===void 0&&(he==="instanceMatrix"&&G.instanceMatrix&&(F=G.instanceMatrix),he==="instanceColor"&&G.instanceColor&&(F=G.instanceColor));const Q={};Q.attribute=F,F&&F.data&&(Q.data=F.data),J[he]=Q,I++}l.attributes=J,l.attributesNum=I,l.index=te}function b(){const G=l.newAttributes;for(let k=0,$=G.length;k<$;k++)G[k]=0}function y(G){S(G,0)}function S(G,k){const $=l.newAttributes,te=l.enabledAttributes,J=l.attributeDivisors;$[G]=1,te[G]===0&&(o.enableVertexAttribArray(G),te[G]=1),J[G]!==k&&(o.vertexAttribDivisor(G,k),J[G]=k)}function R(){const G=l.newAttributes,k=l.enabledAttributes;for(let $=0,te=k.length;$<te;$++)k[$]!==G[$]&&(o.disableVertexAttribArray($),k[$]=0)}function N(G,k,$,te,J,z,I){I===!0?o.vertexAttribIPointer(G,k,$,J,z):o.vertexAttribPointer(G,k,$,te,J,z)}function C(G,k,$,te){b();const J=te.attributes,z=$.getAttributes(),I=k.defaultAttributeValues;for(const ie in z){const he=z[ie];if(he.location>=0){let H=J[ie];if(H===void 0&&(ie==="instanceMatrix"&&G.instanceMatrix&&(H=G.instanceMatrix),ie==="instanceColor"&&G.instanceColor&&(H=G.instanceColor)),H!==void 0){const F=H.normalized,Q=H.itemSize,xe=e.get(H);if(xe===void 0)continue;const Te=xe.buffer,Ne=xe.type,ne=xe.bytesPerElement,_e=Ne===o.INT||Ne===o.UNSIGNED_INT||H.gpuType===ng;if(H.isInterleavedBufferAttribute){const be=H.data,ze=be.stride,tt=H.offset;if(be.isInstancedInterleavedBuffer){for(let Ke=0;Ke<he.locationSize;Ke++)S(he.location+Ke,be.meshPerAttribute);G.isInstancedMesh!==!0&&te._maxInstanceCount===void 0&&(te._maxInstanceCount=be.meshPerAttribute*be.count)}else for(let Ke=0;Ke<he.locationSize;Ke++)y(he.location+Ke);o.bindBuffer(o.ARRAY_BUFFER,Te);for(let Ke=0;Ke<he.locationSize;Ke++)N(he.location+Ke,Q/he.locationSize,Ne,F,ze*ne,(tt+Q/he.locationSize*Ke)*ne,_e)}else{if(H.isInstancedBufferAttribute){for(let be=0;be<he.locationSize;be++)S(he.location+be,H.meshPerAttribute);G.isInstancedMesh!==!0&&te._maxInstanceCount===void 0&&(te._maxInstanceCount=H.meshPerAttribute*H.count)}else for(let be=0;be<he.locationSize;be++)y(he.location+be);o.bindBuffer(o.ARRAY_BUFFER,Te);for(let be=0;be<he.locationSize;be++)N(he.location+be,Q/he.locationSize,Ne,F,Q*ne,Q/he.locationSize*be*ne,_e)}}else if(I!==void 0){const F=I[ie];if(F!==void 0)switch(F.length){case 2:o.vertexAttrib2fv(he.location,F);break;case 3:o.vertexAttrib3fv(he.location,F);break;case 4:o.vertexAttrib4fv(he.location,F);break;default:o.vertexAttrib1fv(he.location,F)}}}}R()}function O(){w();for(const G in a){const k=a[G];for(const $ in k){const te=k[$];for(const J in te){const z=te[J];for(const I in z)_(z[I].object),delete z[I];delete te[J]}}delete a[G]}}function P(G){if(a[G.id]===void 0)return;const k=a[G.id];for(const $ in k){const te=k[$];for(const J in te){const z=te[J];for(const I in z)_(z[I].object),delete z[I];delete te[J]}}delete a[G.id]}function L(G){for(const k in a){const $=a[k];for(const te in $){const J=$[te];if(J[G.id]===void 0)continue;const z=J[G.id];for(const I in z)_(z[I].object),delete z[I];delete J[G.id]}}}function T(G){for(const k in a){const $=a[k],te=G.isInstancedMesh===!0?G.id:0,J=$[te];if(J!==void 0){for(const z in J){const I=J[z];for(const ie in I)_(I[ie].object),delete I[ie];delete J[z]}delete $[te],Object.keys($).length===0&&delete a[k]}}}function w(){q(),c=!0,l!==r&&(l=r,d(l.object))}function q(){r.geometry=null,r.program=null,r.wireframe=!1}return{setup:f,reset:w,resetDefaultState:q,dispose:O,releaseStatesOfGeometry:P,releaseStatesOfObject:T,releaseStatesOfProgram:L,initAttributes:b,enableAttribute:y,disableUnusedAttributes:R}}function Ow(o,e,n){let a;function r(d){a=d}function l(d,_){o.drawArrays(a,d,_),n.update(_,a,1)}function c(d,_,v){v!==0&&(o.drawArraysInstanced(a,d,_,v),n.update(_,a,v))}function f(d,_,v){if(v===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(a,d,0,_,0,v);let x=0;for(let M=0;M<v;M++)x+=_[M];n.update(x,a,1)}function p(d,_,v,g){if(v===0)return;const x=e.get("WEBGL_multi_draw");if(x===null)for(let M=0;M<d.length;M++)c(d[M],_[M],g[M]);else{x.multiDrawArraysInstancedWEBGL(a,d,0,_,0,g,0,v);let M=0;for(let b=0;b<v;b++)M+=_[b]*g[b];n.update(M,a,1)}}this.setMode=r,this.render=l,this.renderInstances=c,this.renderMultiDraw=f,this.renderMultiDrawInstances=p}function Pw(o,e,n,a){let r;function l(){if(r!==void 0)return r;if(e.has("EXT_texture_filter_anisotropic")===!0){const L=e.get("EXT_texture_filter_anisotropic");r=o.getParameter(L.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else r=0;return r}function c(L){return!(L!==Ja&&a.convert(L)!==o.getParameter(o.IMPLEMENTATION_COLOR_READ_FORMAT))}function f(L){const T=L===ts&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(L!==za&&a.convert(L)!==o.getParameter(o.IMPLEMENTATION_COLOR_READ_TYPE)&&L!==dr&&!T)}function p(L){if(L==="highp"){if(o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.HIGH_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.HIGH_FLOAT).precision>0)return"highp";L="mediump"}return L==="mediump"&&o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.MEDIUM_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let d=n.precision!==void 0?n.precision:"highp";const _=p(d);_!==d&&(Mt("WebGLRenderer:",d,"not supported, using",_,"instead."),d=_);const v=n.logarithmicDepthBuffer===!0,g=n.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),x=o.getParameter(o.MAX_TEXTURE_IMAGE_UNITS),M=o.getParameter(o.MAX_VERTEX_TEXTURE_IMAGE_UNITS),b=o.getParameter(o.MAX_TEXTURE_SIZE),y=o.getParameter(o.MAX_CUBE_MAP_TEXTURE_SIZE),S=o.getParameter(o.MAX_VERTEX_ATTRIBS),R=o.getParameter(o.MAX_VERTEX_UNIFORM_VECTORS),N=o.getParameter(o.MAX_VARYING_VECTORS),C=o.getParameter(o.MAX_FRAGMENT_UNIFORM_VECTORS),O=o.getParameter(o.MAX_SAMPLES),P=o.getParameter(o.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:l,getMaxPrecision:p,textureFormatReadable:c,textureTypeReadable:f,precision:d,logarithmicDepthBuffer:v,reversedDepthBuffer:g,maxTextures:x,maxVertexTextures:M,maxTextureSize:b,maxCubemapSize:y,maxAttributes:S,maxVertexUniforms:R,maxVaryings:N,maxFragmentUniforms:C,maxSamples:O,samples:P}}function zw(o){const e=this;let n=null,a=0,r=!1,l=!1;const c=new Eo,f=new wt,p={value:null,needsUpdate:!1};this.uniform=p,this.numPlanes=0,this.numIntersection=0,this.init=function(v,g){const x=v.length!==0||g||a!==0||r;return r=g,a=v.length,x},this.beginShadows=function(){l=!0,_(null)},this.endShadows=function(){l=!1},this.setGlobalState=function(v,g){n=_(v,g,0)},this.setState=function(v,g,x){const M=v.clippingPlanes,b=v.clipIntersection,y=v.clipShadows,S=o.get(v);if(!r||M===null||M.length===0||l&&!y)l?_(null):d();else{const R=l?0:a,N=R*4;let C=S.clippingState||null;p.value=C,C=_(M,g,N,x);for(let O=0;O!==N;++O)C[O]=n[O];S.clippingState=C,this.numIntersection=b?this.numPlanes:0,this.numPlanes+=R}};function d(){p.value!==n&&(p.value=n,p.needsUpdate=a>0),e.numPlanes=a,e.numIntersection=0}function _(v,g,x,M){const b=v!==null?v.length:0;let y=null;if(b!==0){if(y=p.value,M!==!0||y===null){const S=x+b*4,R=g.matrixWorldInverse;f.getNormalMatrix(R),(y===null||y.length<S)&&(y=new Float32Array(S));for(let N=0,C=x;N!==b;++N,C+=4)c.copy(v[N]).applyMatrix4(R,f),c.normal.toArray(y,C),y[C+3]=c.constant}p.value=y,p.needsUpdate=!0}return e.numPlanes=b,e.numIntersection=0,y}}const Is=4,tM=[.125,.215,.35,.446,.526,.582],wo=20,Fw=256,uc=new B1,nM=new qt;let __=null,g_=0,v_=0,x_=!1;const Iw=new fe;class iM{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,n=0,a=.1,r=100,l={}){const{size:c=256,position:f=Iw}=l;__=this._renderer.getRenderTarget(),g_=this._renderer.getActiveCubeFace(),v_=this._renderer.getActiveMipmapLevel(),x_=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(c);const p=this._allocateTargets();return p.depthBuffer=!0,this._sceneToCubeUV(e,a,r,p,f),n>0&&this._blur(p,0,0,n),this._applyPMREM(p),this._cleanup(p),p}fromEquirectangular(e,n=null){return this._fromTexture(e,n)}fromCubemap(e,n=null){return this._fromTexture(e,n)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=sM(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=rM(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(__,g_,v_),this._renderer.xr.enabled=x_,e.scissorTest=!1,Fl(e,0,0,e.width,e.height)}_fromTexture(e,n){e.mapping===Go||e.mapping===tu?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),__=this._renderer.getRenderTarget(),g_=this._renderer.getActiveCubeFace(),v_=this._renderer.getActiveMipmapLevel(),x_=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const a=n||this._allocateTargets();return this._textureToCubeUV(e,a),this._applyPMREM(a),this._cleanup(a),a}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),n=4*this._cubeSize,a={magFilter:Mi,minFilter:Mi,generateMipmaps:!1,type:ts,format:Ja,colorSpace:iu,depthBuffer:!1},r=aM(e,n,a);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==n){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=aM(e,n,a);const{_lodMax:l}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=Bw(l)),this._blurMaterial=Gw(l,e,n),this._ggxMaterial=Hw(l,e,n)}return r}_compileMaterial(e){const n=new $a(new er,e);this._renderer.compile(n,uc)}_sceneToCubeUV(e,n,a,r,l){const p=new La(90,1,n,a),d=[1,-1,1,1,1,1],_=[1,1,1,-1,-1,-1],v=this._renderer,g=v.autoClear,x=v.toneMapping;v.getClearColor(nM),v.toneMapping=gr,v.autoClear=!1,v.state.buffers.depth.getReversed()&&(v.setRenderTarget(r),v.clearDepth(),v.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new $a(new Jc,new fg({name:"PMREM.Background",side:Yi,depthWrite:!1,depthTest:!1})));const b=this._backgroundBox,y=b.material;let S=!1;const R=e.background;R?R.isColor&&(y.color.copy(R),e.background=null,S=!0):(y.color.copy(nM),S=!0);for(let N=0;N<6;N++){const C=N%3;C===0?(p.up.set(0,d[N],0),p.position.set(l.x,l.y,l.z),p.lookAt(l.x+_[N],l.y,l.z)):C===1?(p.up.set(0,0,d[N]),p.position.set(l.x,l.y,l.z),p.lookAt(l.x,l.y+_[N],l.z)):(p.up.set(0,d[N],0),p.position.set(l.x,l.y,l.z),p.lookAt(l.x,l.y,l.z+_[N]));const O=this._cubeSize;Fl(r,C*O,N>2?O:0,O,O),v.setRenderTarget(r),S&&v.render(b,p),v.render(e,p)}v.toneMapping=x,v.autoClear=g,e.background=R}_textureToCubeUV(e,n){const a=this._renderer,r=e.mapping===Go||e.mapping===tu;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=sM()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=rM());const l=r?this._cubemapMaterial:this._equirectMaterial,c=this._lodMeshes[0];c.material=l;const f=l.uniforms;f.envMap.value=e;const p=this._cubeSize;Fl(n,0,0,3*p,2*p),a.setRenderTarget(n),a.render(c,uc)}_applyPMREM(e){const n=this._renderer,a=n.autoClear;n.autoClear=!1;const r=this._lodMeshes.length;for(let l=1;l<r;l++)this._applyGGXFilter(e,l-1,l);n.autoClear=a}_applyGGXFilter(e,n,a){const r=this._renderer,l=this._pingPongRenderTarget,c=this._ggxMaterial,f=this._lodMeshes[a];f.material=c;const p=c.uniforms,d=a/(this._lodMeshes.length-1),_=n/(this._lodMeshes.length-1),v=Math.sqrt(d*d-_*_),g=0+d*1.25,x=v*g,{_lodMax:M}=this,b=this._sizeLods[a],y=3*b*(a>M-Is?a-M+Is:0),S=4*(this._cubeSize-b);p.envMap.value=e.texture,p.roughness.value=x,p.mipInt.value=M-n,Fl(l,y,S,3*b,2*b),r.setRenderTarget(l),r.render(f,uc),p.envMap.value=l.texture,p.roughness.value=0,p.mipInt.value=M-a,Fl(e,y,S,3*b,2*b),r.setRenderTarget(e),r.render(f,uc)}_blur(e,n,a,r,l){const c=this._pingPongRenderTarget;this._halfBlur(e,c,n,a,r,"latitudinal",l),this._halfBlur(c,e,a,a,r,"longitudinal",l)}_halfBlur(e,n,a,r,l,c,f){const p=this._renderer,d=this._blurMaterial;c!=="latitudinal"&&c!=="longitudinal"&&Qt("blur direction must be either latitudinal or longitudinal!");const _=3,v=this._lodMeshes[r];v.material=d;const g=d.uniforms,x=this._sizeLods[a]-1,M=isFinite(l)?Math.PI/(2*x):2*Math.PI/(2*wo-1),b=l/M,y=isFinite(l)?1+Math.floor(_*b):wo;y>wo&&Mt(`sigmaRadians, ${l}, is too large and will clip, as it requested ${y} samples when the maximum is set to ${wo}`);const S=[];let R=0;for(let L=0;L<wo;++L){const T=L/b,w=Math.exp(-T*T/2);S.push(w),L===0?R+=w:L<y&&(R+=2*w)}for(let L=0;L<S.length;L++)S[L]=S[L]/R;g.envMap.value=e.texture,g.samples.value=y,g.weights.value=S,g.latitudinal.value=c==="latitudinal",f&&(g.poleAxis.value=f);const{_lodMax:N}=this;g.dTheta.value=M,g.mipInt.value=N-a;const C=this._sizeLods[r],O=3*C*(r>N-Is?r-N+Is:0),P=4*(this._cubeSize-C);Fl(n,O,P,3*C,2*C),p.setRenderTarget(n),p.render(v,uc)}}function Bw(o){const e=[],n=[],a=[];let r=o;const l=o-Is+1+tM.length;for(let c=0;c<l;c++){const f=Math.pow(2,r);e.push(f);let p=1/f;c>o-Is?p=tM[c-o+Is-1]:c===0&&(p=0),n.push(p);const d=1/(f-2),_=-d,v=1+d,g=[_,_,v,_,v,v,_,_,v,v,_,v],x=6,M=6,b=3,y=2,S=1,R=new Float32Array(b*M*x),N=new Float32Array(y*M*x),C=new Float32Array(S*M*x);for(let P=0;P<x;P++){const L=P%3*2/3-1,T=P>2?0:-1,w=[L,T,0,L+2/3,T,0,L+2/3,T+1,0,L,T,0,L+2/3,T+1,0,L,T+1,0];R.set(w,b*M*P),N.set(g,y*M*P);const q=[P,P,P,P,P,P];C.set(q,S*M*P)}const O=new er;O.setAttribute("position",new xr(R,b)),O.setAttribute("uv",new xr(N,y)),O.setAttribute("faceIndex",new xr(C,S)),a.push(new $a(O,null)),r>Is&&r--}return{lodMeshes:a,sizeLods:e,sigmas:n}}function aM(o,e,n){const a=new vr(o,e,n);return a.texture.mapping=Td,a.texture.name="PMREM.cubeUv",a.scissorTest=!0,a}function Fl(o,e,n,a,r){o.viewport.set(e,n,a,r),o.scissor.set(e,n,a,r)}function Hw(o,e,n){return new Ga({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:Fw,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${o}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Cd(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Jr,depthTest:!1,depthWrite:!1})}function Gw(o,e,n){const a=new Float32Array(wo),r=new fe(0,1,0);return new Ga({name:"SphericalGaussianBlur",defines:{n:wo,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${o}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:a},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:r}},vertexShader:Cd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Jr,depthTest:!1,depthWrite:!1})}function rM(){return new Ga({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Cd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Jr,depthTest:!1,depthWrite:!1})}function sM(){return new Ga({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Cd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Jr,depthTest:!1,depthWrite:!1})}function Cd(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}class G1 extends vr{constructor(e=1,n={}){super(e,e,n),this.isWebGLCubeRenderTarget=!0;const a={width:e,height:e,depth:1},r=[a,a,a,a,a,a];this.texture=new P1(r),this._setTextureOptions(n),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,n){this.texture.type=n.type,this.texture.colorSpace=n.colorSpace,this.texture.generateMipmaps=n.generateMipmaps,this.texture.minFilter=n.minFilter,this.texture.magFilter=n.magFilter;const a={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new Jc(5,5,5),l=new Ga({name:"CubemapFromEquirect",uniforms:au(a.uniforms),vertexShader:a.vertexShader,fragmentShader:a.fragmentShader,side:Yi,blending:Jr});l.uniforms.tEquirect.value=n;const c=new $a(r,l),f=n.minFilter;return n.minFilter===Do&&(n.minFilter=Mi),new jR(1,10,this).update(e,c),n.minFilter=f,c.geometry.dispose(),c.material.dispose(),this}clear(e,n=!0,a=!0,r=!0){const l=e.getRenderTarget();for(let c=0;c<6;c++)e.setRenderTarget(this,c),e.clear(n,a,r);e.setRenderTarget(l)}}function Vw(o){let e=new WeakMap,n=new WeakMap,a=null;function r(g,x=!1){return g==null?null:x?c(g):l(g)}function l(g){if(g&&g.isTexture){const x=g.mapping;if(x===km||x===Xm)if(e.has(g)){const M=e.get(g).texture;return f(M,g.mapping)}else{const M=g.image;if(M&&M.height>0){const b=new G1(M.height);return b.fromEquirectangularTexture(o,g),e.set(g,b),g.addEventListener("dispose",d),f(b.texture,g.mapping)}else return null}}return g}function c(g){if(g&&g.isTexture){const x=g.mapping,M=x===km||x===Xm,b=x===Go||x===tu;if(M||b){let y=n.get(g);const S=y!==void 0?y.texture.pmremVersion:0;if(g.isRenderTargetTexture&&g.pmremVersion!==S)return a===null&&(a=new iM(o)),y=M?a.fromEquirectangular(g,y):a.fromCubemap(g,y),y.texture.pmremVersion=g.pmremVersion,n.set(g,y),y.texture;if(y!==void 0)return y.texture;{const R=g.image;return M&&R&&R.height>0||b&&R&&p(R)?(a===null&&(a=new iM(o)),y=M?a.fromEquirectangular(g):a.fromCubemap(g),y.texture.pmremVersion=g.pmremVersion,n.set(g,y),g.addEventListener("dispose",_),y.texture):null}}}return g}function f(g,x){return x===km?g.mapping=Go:x===Xm&&(g.mapping=tu),g}function p(g){let x=0;const M=6;for(let b=0;b<M;b++)g[b]!==void 0&&x++;return x===M}function d(g){const x=g.target;x.removeEventListener("dispose",d);const M=e.get(x);M!==void 0&&(e.delete(x),M.dispose())}function _(g){const x=g.target;x.removeEventListener("dispose",_);const M=n.get(x);M!==void 0&&(n.delete(x),M.dispose())}function v(){e=new WeakMap,n=new WeakMap,a!==null&&(a.dispose(),a=null)}return{get:r,dispose:v}}function kw(o){const e={};function n(a){if(e[a]!==void 0)return e[a];const r=o.getExtension(a);return e[a]=r,r}return{has:function(a){return n(a)!==null},init:function(){n("EXT_color_buffer_float"),n("WEBGL_clip_cull_distance"),n("OES_texture_float_linear"),n("EXT_color_buffer_half_float"),n("WEBGL_multisampled_render_to_texture"),n("WEBGL_render_shared_exponent")},get:function(a){const r=n(a);return r===null&&hd("WebGLRenderer: "+a+" extension not supported."),r}}}function Xw(o,e,n,a){const r={},l=new WeakMap;function c(v){const g=v.target;g.index!==null&&e.remove(g.index);for(const M in g.attributes)e.remove(g.attributes[M]);g.removeEventListener("dispose",c),delete r[g.id];const x=l.get(g);x&&(e.remove(x),l.delete(g)),a.releaseStatesOfGeometry(g),g.isInstancedBufferGeometry===!0&&delete g._maxInstanceCount,n.memory.geometries--}function f(v,g){return r[g.id]===!0||(g.addEventListener("dispose",c),r[g.id]=!0,n.memory.geometries++),g}function p(v){const g=v.attributes;for(const x in g)e.update(g[x],o.ARRAY_BUFFER)}function d(v){const g=[],x=v.index,M=v.attributes.position;let b=0;if(M===void 0)return;if(x!==null){const R=x.array;b=x.version;for(let N=0,C=R.length;N<C;N+=3){const O=R[N+0],P=R[N+1],L=R[N+2];g.push(O,P,P,L,L,O)}}else{const R=M.array;b=M.version;for(let N=0,C=R.length/3-1;N<C;N+=3){const O=N+0,P=N+1,L=N+2;g.push(O,P,P,L,L,O)}}const y=new(M.count>=65535?U1:N1)(g,1);y.version=b;const S=l.get(v);S&&e.remove(S),l.set(v,y)}function _(v){const g=l.get(v);if(g){const x=v.index;x!==null&&g.version<x.version&&d(v)}else d(v);return l.get(v)}return{get:f,update:p,getWireframeAttribute:_}}function Ww(o,e,n){let a;function r(g){a=g}let l,c;function f(g){l=g.type,c=g.bytesPerElement}function p(g,x){o.drawElements(a,x,l,g*c),n.update(x,a,1)}function d(g,x,M){M!==0&&(o.drawElementsInstanced(a,x,l,g*c,M),n.update(x,a,M))}function _(g,x,M){if(M===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(a,x,0,l,g,0,M);let y=0;for(let S=0;S<M;S++)y+=x[S];n.update(y,a,1)}function v(g,x,M,b){if(M===0)return;const y=e.get("WEBGL_multi_draw");if(y===null)for(let S=0;S<g.length;S++)d(g[S]/c,x[S],b[S]);else{y.multiDrawElementsInstancedWEBGL(a,x,0,l,g,0,b,0,M);let S=0;for(let R=0;R<M;R++)S+=x[R]*b[R];n.update(S,a,1)}}this.setMode=r,this.setIndex=f,this.render=p,this.renderInstances=d,this.renderMultiDraw=_,this.renderMultiDrawInstances=v}function Yw(o){const e={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function a(l,c,f){switch(n.calls++,c){case o.TRIANGLES:n.triangles+=f*(l/3);break;case o.LINES:n.lines+=f*(l/2);break;case o.LINE_STRIP:n.lines+=f*(l-1);break;case o.LINE_LOOP:n.lines+=f*l;break;case o.POINTS:n.points+=f*l;break;default:Qt("WebGLInfo: Unknown draw mode:",c);break}}function r(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:e,render:n,programs:null,autoReset:!0,reset:r,update:a}}function qw(o,e,n){const a=new WeakMap,r=new Pn;function l(c,f,p){const d=c.morphTargetInfluences,_=f.morphAttributes.position||f.morphAttributes.normal||f.morphAttributes.color,v=_!==void 0?_.length:0;let g=a.get(f);if(g===void 0||g.count!==v){let q=function(){T.dispose(),a.delete(f),f.removeEventListener("dispose",q)};var x=q;g!==void 0&&g.texture.dispose();const M=f.morphAttributes.position!==void 0,b=f.morphAttributes.normal!==void 0,y=f.morphAttributes.color!==void 0,S=f.morphAttributes.position||[],R=f.morphAttributes.normal||[],N=f.morphAttributes.color||[];let C=0;M===!0&&(C=1),b===!0&&(C=2),y===!0&&(C=3);let O=f.attributes.position.count*C,P=1;O>e.maxTextureSize&&(P=Math.ceil(O/e.maxTextureSize),O=e.maxTextureSize);const L=new Float32Array(O*P*4*v),T=new C1(L,O,P,v);T.type=dr,T.needsUpdate=!0;const w=C*4;for(let G=0;G<v;G++){const k=S[G],$=R[G],te=N[G],J=O*P*4*G;for(let z=0;z<k.count;z++){const I=z*w;M===!0&&(r.fromBufferAttribute(k,z),L[J+I+0]=r.x,L[J+I+1]=r.y,L[J+I+2]=r.z,L[J+I+3]=0),b===!0&&(r.fromBufferAttribute($,z),L[J+I+4]=r.x,L[J+I+5]=r.y,L[J+I+6]=r.z,L[J+I+7]=0),y===!0&&(r.fromBufferAttribute(te,z),L[J+I+8]=r.x,L[J+I+9]=r.y,L[J+I+10]=r.z,L[J+I+11]=te.itemSize===4?r.w:1)}}g={count:v,texture:T,size:new fn(O,P)},a.set(f,g),f.addEventListener("dispose",q)}if(c.isInstancedMesh===!0&&c.morphTexture!==null)p.getUniforms().setValue(o,"morphTexture",c.morphTexture,n);else{let M=0;for(let y=0;y<d.length;y++)M+=d[y];const b=f.morphTargetsRelative?1:1-M;p.getUniforms().setValue(o,"morphTargetBaseInfluence",b),p.getUniforms().setValue(o,"morphTargetInfluences",d)}p.getUniforms().setValue(o,"morphTargetsTexture",g.texture,n),p.getUniforms().setValue(o,"morphTargetsTextureSize",g.size)}return{update:l}}function jw(o,e,n,a,r){let l=new WeakMap;function c(d){const _=r.render.frame,v=d.geometry,g=e.get(d,v);if(l.get(g)!==_&&(e.update(g),l.set(g,_)),d.isInstancedMesh&&(d.hasEventListener("dispose",p)===!1&&d.addEventListener("dispose",p),l.get(d)!==_&&(n.update(d.instanceMatrix,o.ARRAY_BUFFER),d.instanceColor!==null&&n.update(d.instanceColor,o.ARRAY_BUFFER),l.set(d,_))),d.isSkinnedMesh){const x=d.skeleton;l.get(x)!==_&&(x.update(),l.set(x,_))}return g}function f(){l=new WeakMap}function p(d){const _=d.target;_.removeEventListener("dispose",p),a.releaseStatesOfObject(_),n.remove(_.instanceMatrix),_.instanceColor!==null&&n.remove(_.instanceColor)}return{update:c,dispose:f}}const Zw={[h1]:"LINEAR_TONE_MAPPING",[d1]:"REINHARD_TONE_MAPPING",[p1]:"CINEON_TONE_MAPPING",[m1]:"ACES_FILMIC_TONE_MAPPING",[g1]:"AGX_TONE_MAPPING",[v1]:"NEUTRAL_TONE_MAPPING",[_1]:"CUSTOM_TONE_MAPPING"};function Kw(o,e,n,a,r){const l=new vr(e,n,{type:o,depthBuffer:a,stencilBuffer:r}),c=new vr(e,n,{type:ts,depthBuffer:!1,stencilBuffer:!1}),f=new er;f.setAttribute("position",new Ba([-1,3,0,-1,-1,0,3,-1,0],3)),f.setAttribute("uv",new Ba([0,2,0,0,2,0],2));const p=new WR({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),d=new $a(f,p),_=new B1(-1,1,1,-1,0,1);let v=null,g=null,x=!1,M,b=null,y=[],S=!1;this.setSize=function(R,N){l.setSize(R,N),c.setSize(R,N);for(let C=0;C<y.length;C++){const O=y[C];O.setSize&&O.setSize(R,N)}},this.setEffects=function(R){y=R,S=y.length>0&&y[0].isRenderPass===!0;const N=l.width,C=l.height;for(let O=0;O<y.length;O++){const P=y[O];P.setSize&&P.setSize(N,C)}},this.begin=function(R,N){if(x||R.toneMapping===gr&&y.length===0)return!1;if(b=N,N!==null){const C=N.width,O=N.height;(l.width!==C||l.height!==O)&&this.setSize(C,O)}return S===!1&&R.setRenderTarget(l),M=R.toneMapping,R.toneMapping=gr,!0},this.hasRenderPass=function(){return S},this.end=function(R,N){R.toneMapping=M,x=!0;let C=l,O=c;for(let P=0;P<y.length;P++){const L=y[P];if(L.enabled!==!1&&(L.render(R,O,C,N),L.needsSwap!==!1)){const T=C;C=O,O=T}}if(v!==R.outputColorSpace||g!==R.toneMapping){v=R.outputColorSpace,g=R.toneMapping,p.defines={},Yt.getTransfer(v)===an&&(p.defines.SRGB_TRANSFER="");const P=Zw[g];P&&(p.defines[P]=""),p.needsUpdate=!0}p.uniforms.tDiffuse.value=C.texture,R.setRenderTarget(b),R.render(d,_),b=null,x=!1},this.isCompositing=function(){return x},this.dispose=function(){l.dispose(),c.dispose(),f.dispose(),p.dispose()}}const V1=new Fi,C0=new Bc(1,1),k1=new C1,X1=new yR,W1=new P1,oM=[],lM=[],uM=new Float32Array(16),cM=new Float32Array(9),fM=new Float32Array(4);function pu(o,e,n){const a=o[0];if(a<=0||a>0)return o;const r=e*n;let l=oM[r];if(l===void 0&&(l=new Float32Array(r),oM[r]=l),e!==0){a.toArray(l,0);for(let c=1,f=0;c!==e;++c)f+=n,o[c].toArray(l,f)}return l}function $n(o,e){if(o.length!==e.length)return!1;for(let n=0,a=o.length;n<a;n++)if(o[n]!==e[n])return!1;return!0}function ei(o,e){for(let n=0,a=e.length;n<a;n++)o[n]=e[n]}function wd(o,e){let n=lM[e];n===void 0&&(n=new Int32Array(e),lM[e]=n);for(let a=0;a!==e;++a)n[a]=o.allocateTextureUnit();return n}function Qw(o,e){const n=this.cache;n[0]!==e&&(o.uniform1f(this.addr,e),n[0]=e)}function Jw(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y)&&(o.uniform2f(this.addr,e.x,e.y),n[0]=e.x,n[1]=e.y);else{if($n(n,e))return;o.uniform2fv(this.addr,e),ei(n,e)}}function $w(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z)&&(o.uniform3f(this.addr,e.x,e.y,e.z),n[0]=e.x,n[1]=e.y,n[2]=e.z);else if(e.r!==void 0)(n[0]!==e.r||n[1]!==e.g||n[2]!==e.b)&&(o.uniform3f(this.addr,e.r,e.g,e.b),n[0]=e.r,n[1]=e.g,n[2]=e.b);else{if($n(n,e))return;o.uniform3fv(this.addr,e),ei(n,e)}}function e3(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z||n[3]!==e.w)&&(o.uniform4f(this.addr,e.x,e.y,e.z,e.w),n[0]=e.x,n[1]=e.y,n[2]=e.z,n[3]=e.w);else{if($n(n,e))return;o.uniform4fv(this.addr,e),ei(n,e)}}function t3(o,e){const n=this.cache,a=e.elements;if(a===void 0){if($n(n,e))return;o.uniformMatrix2fv(this.addr,!1,e),ei(n,e)}else{if($n(n,a))return;fM.set(a),o.uniformMatrix2fv(this.addr,!1,fM),ei(n,a)}}function n3(o,e){const n=this.cache,a=e.elements;if(a===void 0){if($n(n,e))return;o.uniformMatrix3fv(this.addr,!1,e),ei(n,e)}else{if($n(n,a))return;cM.set(a),o.uniformMatrix3fv(this.addr,!1,cM),ei(n,a)}}function i3(o,e){const n=this.cache,a=e.elements;if(a===void 0){if($n(n,e))return;o.uniformMatrix4fv(this.addr,!1,e),ei(n,e)}else{if($n(n,a))return;uM.set(a),o.uniformMatrix4fv(this.addr,!1,uM),ei(n,a)}}function a3(o,e){const n=this.cache;n[0]!==e&&(o.uniform1i(this.addr,e),n[0]=e)}function r3(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y)&&(o.uniform2i(this.addr,e.x,e.y),n[0]=e.x,n[1]=e.y);else{if($n(n,e))return;o.uniform2iv(this.addr,e),ei(n,e)}}function s3(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z)&&(o.uniform3i(this.addr,e.x,e.y,e.z),n[0]=e.x,n[1]=e.y,n[2]=e.z);else{if($n(n,e))return;o.uniform3iv(this.addr,e),ei(n,e)}}function o3(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z||n[3]!==e.w)&&(o.uniform4i(this.addr,e.x,e.y,e.z,e.w),n[0]=e.x,n[1]=e.y,n[2]=e.z,n[3]=e.w);else{if($n(n,e))return;o.uniform4iv(this.addr,e),ei(n,e)}}function l3(o,e){const n=this.cache;n[0]!==e&&(o.uniform1ui(this.addr,e),n[0]=e)}function u3(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y)&&(o.uniform2ui(this.addr,e.x,e.y),n[0]=e.x,n[1]=e.y);else{if($n(n,e))return;o.uniform2uiv(this.addr,e),ei(n,e)}}function c3(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z)&&(o.uniform3ui(this.addr,e.x,e.y,e.z),n[0]=e.x,n[1]=e.y,n[2]=e.z);else{if($n(n,e))return;o.uniform3uiv(this.addr,e),ei(n,e)}}function f3(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z||n[3]!==e.w)&&(o.uniform4ui(this.addr,e.x,e.y,e.z,e.w),n[0]=e.x,n[1]=e.y,n[2]=e.z,n[3]=e.w);else{if($n(n,e))return;o.uniform4uiv(this.addr,e),ei(n,e)}}function h3(o,e,n){const a=this.cache,r=n.allocateTextureUnit();a[0]!==r&&(o.uniform1i(this.addr,r),a[0]=r);let l;this.type===o.SAMPLER_2D_SHADOW?(C0.compareFunction=n.isReversedDepthBuffer()?ug:lg,l=C0):l=V1,n.setTexture2D(e||l,r)}function d3(o,e,n){const a=this.cache,r=n.allocateTextureUnit();a[0]!==r&&(o.uniform1i(this.addr,r),a[0]=r),n.setTexture3D(e||X1,r)}function p3(o,e,n){const a=this.cache,r=n.allocateTextureUnit();a[0]!==r&&(o.uniform1i(this.addr,r),a[0]=r),n.setTextureCube(e||W1,r)}function m3(o,e,n){const a=this.cache,r=n.allocateTextureUnit();a[0]!==r&&(o.uniform1i(this.addr,r),a[0]=r),n.setTexture2DArray(e||k1,r)}function _3(o){switch(o){case 5126:return Qw;case 35664:return Jw;case 35665:return $w;case 35666:return e3;case 35674:return t3;case 35675:return n3;case 35676:return i3;case 5124:case 35670:return a3;case 35667:case 35671:return r3;case 35668:case 35672:return s3;case 35669:case 35673:return o3;case 5125:return l3;case 36294:return u3;case 36295:return c3;case 36296:return f3;case 35678:case 36198:case 36298:case 36306:case 35682:return h3;case 35679:case 36299:case 36307:return d3;case 35680:case 36300:case 36308:case 36293:return p3;case 36289:case 36303:case 36311:case 36292:return m3}}function g3(o,e){o.uniform1fv(this.addr,e)}function v3(o,e){const n=pu(e,this.size,2);o.uniform2fv(this.addr,n)}function x3(o,e){const n=pu(e,this.size,3);o.uniform3fv(this.addr,n)}function y3(o,e){const n=pu(e,this.size,4);o.uniform4fv(this.addr,n)}function S3(o,e){const n=pu(e,this.size,4);o.uniformMatrix2fv(this.addr,!1,n)}function M3(o,e){const n=pu(e,this.size,9);o.uniformMatrix3fv(this.addr,!1,n)}function b3(o,e){const n=pu(e,this.size,16);o.uniformMatrix4fv(this.addr,!1,n)}function E3(o,e){o.uniform1iv(this.addr,e)}function T3(o,e){o.uniform2iv(this.addr,e)}function A3(o,e){o.uniform3iv(this.addr,e)}function R3(o,e){o.uniform4iv(this.addr,e)}function C3(o,e){o.uniform1uiv(this.addr,e)}function w3(o,e){o.uniform2uiv(this.addr,e)}function D3(o,e){o.uniform3uiv(this.addr,e)}function N3(o,e){o.uniform4uiv(this.addr,e)}function U3(o,e,n){const a=this.cache,r=e.length,l=wd(n,r);$n(a,l)||(o.uniform1iv(this.addr,l),ei(a,l));let c;this.type===o.SAMPLER_2D_SHADOW?c=C0:c=V1;for(let f=0;f!==r;++f)n.setTexture2D(e[f]||c,l[f])}function L3(o,e,n){const a=this.cache,r=e.length,l=wd(n,r);$n(a,l)||(o.uniform1iv(this.addr,l),ei(a,l));for(let c=0;c!==r;++c)n.setTexture3D(e[c]||X1,l[c])}function O3(o,e,n){const a=this.cache,r=e.length,l=wd(n,r);$n(a,l)||(o.uniform1iv(this.addr,l),ei(a,l));for(let c=0;c!==r;++c)n.setTextureCube(e[c]||W1,l[c])}function P3(o,e,n){const a=this.cache,r=e.length,l=wd(n,r);$n(a,l)||(o.uniform1iv(this.addr,l),ei(a,l));for(let c=0;c!==r;++c)n.setTexture2DArray(e[c]||k1,l[c])}function z3(o){switch(o){case 5126:return g3;case 35664:return v3;case 35665:return x3;case 35666:return y3;case 35674:return S3;case 35675:return M3;case 35676:return b3;case 5124:case 35670:return E3;case 35667:case 35671:return T3;case 35668:case 35672:return A3;case 35669:case 35673:return R3;case 5125:return C3;case 36294:return w3;case 36295:return D3;case 36296:return N3;case 35678:case 36198:case 36298:case 36306:case 35682:return U3;case 35679:case 36299:case 36307:return L3;case 35680:case 36300:case 36308:case 36293:return O3;case 36289:case 36303:case 36311:case 36292:return P3}}class F3{constructor(e,n,a){this.id=e,this.addr=a,this.cache=[],this.type=n.type,this.setValue=_3(n.type)}}class I3{constructor(e,n,a){this.id=e,this.addr=a,this.cache=[],this.type=n.type,this.size=n.size,this.setValue=z3(n.type)}}class B3{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,n,a){const r=this.seq;for(let l=0,c=r.length;l!==c;++l){const f=r[l];f.setValue(e,n[f.id],a)}}}const y_=/(\w+)(\])?(\[|\.)?/g;function hM(o,e){o.seq.push(e),o.map[e.id]=e}function H3(o,e,n){const a=o.name,r=a.length;for(y_.lastIndex=0;;){const l=y_.exec(a),c=y_.lastIndex;let f=l[1];const p=l[2]==="]",d=l[3];if(p&&(f=f|0),d===void 0||d==="["&&c+2===r){hM(n,d===void 0?new F3(f,o,e):new I3(f,o,e));break}else{let v=n.map[f];v===void 0&&(v=new B3(f),hM(n,v)),n=v}}}class $h{constructor(e,n){this.seq=[],this.map={};const a=e.getProgramParameter(n,e.ACTIVE_UNIFORMS);for(let c=0;c<a;++c){const f=e.getActiveUniform(n,c),p=e.getUniformLocation(n,f.name);H3(f,p,this)}const r=[],l=[];for(const c of this.seq)c.type===e.SAMPLER_2D_SHADOW||c.type===e.SAMPLER_CUBE_SHADOW||c.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(c):l.push(c);r.length>0&&(this.seq=r.concat(l))}setValue(e,n,a,r){const l=this.map[n];l!==void 0&&l.setValue(e,a,r)}setOptional(e,n,a){const r=n[a];r!==void 0&&this.setValue(e,a,r)}static upload(e,n,a,r){for(let l=0,c=n.length;l!==c;++l){const f=n[l],p=a[f.id];p.needsUpdate!==!1&&f.setValue(e,p.value,r)}}static seqWithValue(e,n){const a=[];for(let r=0,l=e.length;r!==l;++r){const c=e[r];c.id in n&&a.push(c)}return a}}function dM(o,e,n){const a=o.createShader(e);return o.shaderSource(a,n),o.compileShader(a),a}const G3=37297;let V3=0;function k3(o,e){const n=o.split(`
`),a=[],r=Math.max(e-6,0),l=Math.min(e+6,n.length);for(let c=r;c<l;c++){const f=c+1;a.push(`${f===e?">":" "} ${f}: ${n[c]}`)}return a.join(`
`)}const pM=new wt;function X3(o){Yt._getMatrix(pM,Yt.workingColorSpace,o);const e=`mat3( ${pM.elements.map(n=>n.toFixed(4))} )`;switch(Yt.getTransfer(o)){case ud:return[e,"LinearTransferOETF"];case an:return[e,"sRGBTransferOETF"];default:return Mt("WebGLProgram: Unsupported color space: ",o),[e,"LinearTransferOETF"]}}function mM(o,e,n){const a=o.getShaderParameter(e,o.COMPILE_STATUS),l=(o.getShaderInfoLog(e)||"").trim();if(a&&l==="")return"";const c=/ERROR: 0:(\d+)/.exec(l);if(c){const f=parseInt(c[1]);return n.toUpperCase()+`

`+l+`

`+k3(o.getShaderSource(e),f)}else return l}function W3(o,e){const n=X3(e);return[`vec4 ${o}( vec4 value ) {`,`	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );`,"}"].join(`
`)}const Y3={[h1]:"Linear",[d1]:"Reinhard",[p1]:"Cineon",[m1]:"ACESFilmic",[g1]:"AgX",[v1]:"Neutral",[_1]:"Custom"};function q3(o,e){const n=Y3[e];return n===void 0?(Mt("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+o+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+o+"( vec3 color ) { return "+n+"ToneMapping( color ); }"}const Lh=new fe;function j3(){Yt.getLuminanceCoefficients(Lh);const o=Lh.x.toFixed(4),e=Lh.y.toFixed(4),n=Lh.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${o}, ${e}, ${n} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Z3(o){return[o.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",o.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(_c).join(`
`)}function K3(o){const e=[];for(const n in o){const a=o[n];a!==!1&&e.push("#define "+n+" "+a)}return e.join(`
`)}function Q3(o,e){const n={},a=o.getProgramParameter(e,o.ACTIVE_ATTRIBUTES);for(let r=0;r<a;r++){const l=o.getActiveAttrib(e,r),c=l.name;let f=1;l.type===o.FLOAT_MAT2&&(f=2),l.type===o.FLOAT_MAT3&&(f=3),l.type===o.FLOAT_MAT4&&(f=4),n[c]={type:l.type,location:o.getAttribLocation(e,c),locationSize:f}}return n}function _c(o){return o!==""}function _M(o,e){const n=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return o.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function gM(o,e){return o.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const J3=/^[ \t]*#include +<([\w\d./]+)>/gm;function w0(o){return o.replace(J3,eD)}const $3=new Map;function eD(o,e){let n=Dt[e];if(n===void 0){const a=$3.get(e);if(a!==void 0)n=Dt[a],Mt('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,a);else throw new Error("Can not resolve #include <"+e+">")}return w0(n)}const tD=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function vM(o){return o.replace(tD,nD)}function nD(o,e,n,a){let r="";for(let l=parseInt(e);l<parseInt(n);l++)r+=a.replace(/\[\s*i\s*\]/g,"[ "+l+" ]").replace(/UNROLLED_LOOP_INDEX/g,l);return r}function xM(o){let e=`precision ${o.precision} float;
	precision ${o.precision} int;
	precision ${o.precision} sampler2D;
	precision ${o.precision} samplerCube;
	precision ${o.precision} sampler3D;
	precision ${o.precision} sampler2DArray;
	precision ${o.precision} sampler2DShadow;
	precision ${o.precision} samplerCubeShadow;
	precision ${o.precision} sampler2DArrayShadow;
	precision ${o.precision} isampler2D;
	precision ${o.precision} isampler3D;
	precision ${o.precision} isamplerCube;
	precision ${o.precision} isampler2DArray;
	precision ${o.precision} usampler2D;
	precision ${o.precision} usampler3D;
	precision ${o.precision} usamplerCube;
	precision ${o.precision} usampler2DArray;
	`;return o.precision==="highp"?e+=`
#define HIGH_PRECISION`:o.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:o.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const iD={[jh]:"SHADOWMAP_TYPE_PCF",[pc]:"SHADOWMAP_TYPE_VSM"};function aD(o){return iD[o.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const rD={[Go]:"ENVMAP_TYPE_CUBE",[tu]:"ENVMAP_TYPE_CUBE",[Td]:"ENVMAP_TYPE_CUBE_UV"};function sD(o){return o.envMap===!1?"ENVMAP_TYPE_CUBE":rD[o.envMapMode]||"ENVMAP_TYPE_CUBE"}const oD={[tu]:"ENVMAP_MODE_REFRACTION"};function lD(o){return o.envMap===!1?"ENVMAP_MODE_REFLECTION":oD[o.envMapMode]||"ENVMAP_MODE_REFLECTION"}const uD={[f1]:"ENVMAP_BLENDING_MULTIPLY",[JA]:"ENVMAP_BLENDING_MIX",[$A]:"ENVMAP_BLENDING_ADD"};function cD(o){return o.envMap===!1?"ENVMAP_BLENDING_NONE":uD[o.combine]||"ENVMAP_BLENDING_NONE"}function fD(o){const e=o.envMapCubeUVHeight;if(e===null)return null;const n=Math.log2(e)-2,a=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,n),112)),texelHeight:a,maxMip:n}}function hD(o,e,n,a){const r=o.getContext(),l=n.defines;let c=n.vertexShader,f=n.fragmentShader;const p=aD(n),d=sD(n),_=lD(n),v=cD(n),g=fD(n),x=Z3(n),M=K3(l),b=r.createProgram();let y,S,R=n.glslVersion?"#version "+n.glslVersion+`
`:"";n.isRawShaderMaterial?(y=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,M].filter(_c).join(`
`),y.length>0&&(y+=`
`),S=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,M].filter(_c).join(`
`),S.length>0&&(S+=`
`)):(y=[xM(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,M,n.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",n.batching?"#define USE_BATCHING":"",n.batchingColor?"#define USE_BATCHING_COLOR":"",n.instancing?"#define USE_INSTANCING":"",n.instancingColor?"#define USE_INSTANCING_COLOR":"",n.instancingMorph?"#define USE_INSTANCING_MORPH":"",n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.map?"#define USE_MAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+_:"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.displacementMap?"#define USE_DISPLACEMENTMAP":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.mapUv?"#define MAP_UV "+n.mapUv:"",n.alphaMapUv?"#define ALPHAMAP_UV "+n.alphaMapUv:"",n.lightMapUv?"#define LIGHTMAP_UV "+n.lightMapUv:"",n.aoMapUv?"#define AOMAP_UV "+n.aoMapUv:"",n.emissiveMapUv?"#define EMISSIVEMAP_UV "+n.emissiveMapUv:"",n.bumpMapUv?"#define BUMPMAP_UV "+n.bumpMapUv:"",n.normalMapUv?"#define NORMALMAP_UV "+n.normalMapUv:"",n.displacementMapUv?"#define DISPLACEMENTMAP_UV "+n.displacementMapUv:"",n.metalnessMapUv?"#define METALNESSMAP_UV "+n.metalnessMapUv:"",n.roughnessMapUv?"#define ROUGHNESSMAP_UV "+n.roughnessMapUv:"",n.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+n.anisotropyMapUv:"",n.clearcoatMapUv?"#define CLEARCOATMAP_UV "+n.clearcoatMapUv:"",n.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+n.clearcoatNormalMapUv:"",n.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+n.clearcoatRoughnessMapUv:"",n.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+n.iridescenceMapUv:"",n.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+n.iridescenceThicknessMapUv:"",n.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+n.sheenColorMapUv:"",n.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+n.sheenRoughnessMapUv:"",n.specularMapUv?"#define SPECULARMAP_UV "+n.specularMapUv:"",n.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+n.specularColorMapUv:"",n.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+n.specularIntensityMapUv:"",n.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+n.transmissionMapUv:"",n.thicknessMapUv?"#define THICKNESSMAP_UV "+n.thicknessMapUv:"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexColors?"#define USE_COLOR":"",n.vertexAlphas?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.flatShading?"#define FLAT_SHADED":"",n.skinning?"#define USE_SKINNING":"",n.morphTargets?"#define USE_MORPHTARGETS":"",n.morphNormals&&n.flatShading===!1?"#define USE_MORPHNORMALS":"",n.morphColors?"#define USE_MORPHCOLORS":"",n.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+n.morphTextureStride:"",n.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+n.morphTargetsCount:"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+p:"",n.sizeAttenuation?"#define USE_SIZEATTENUATION":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(_c).join(`
`),S=[xM(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,M,n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",n.map?"#define USE_MAP":"",n.matcap?"#define USE_MATCAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+d:"",n.envMap?"#define "+_:"",n.envMap?"#define "+v:"",g?"#define CUBEUV_TEXEL_WIDTH "+g.texelWidth:"",g?"#define CUBEUV_TEXEL_HEIGHT "+g.texelHeight:"",g?"#define CUBEUV_MAX_MIP "+g.maxMip+".0":"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoat?"#define USE_CLEARCOAT":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.dispersion?"#define USE_DISPERSION":"",n.iridescence?"#define USE_IRIDESCENCE":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaTest?"#define USE_ALPHATEST":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.sheen?"#define USE_SHEEN":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexColors||n.instancingColor?"#define USE_COLOR":"",n.vertexAlphas||n.batchingColor?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.gradientMap?"#define USE_GRADIENTMAP":"",n.flatShading?"#define FLAT_SHADED":"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+p:"",n.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",n.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",n.toneMapping!==gr?"#define TONE_MAPPING":"",n.toneMapping!==gr?Dt.tonemapping_pars_fragment:"",n.toneMapping!==gr?q3("toneMapping",n.toneMapping):"",n.dithering?"#define DITHERING":"",n.opaque?"#define OPAQUE":"",Dt.colorspace_pars_fragment,W3("linearToOutputTexel",n.outputColorSpace),j3(),n.useDepthPacking?"#define DEPTH_PACKING "+n.depthPacking:"",`
`].filter(_c).join(`
`)),c=w0(c),c=_M(c,n),c=gM(c,n),f=w0(f),f=_M(f,n),f=gM(f,n),c=vM(c),f=vM(f),n.isRawShaderMaterial!==!0&&(R=`#version 300 es
`,y=[x,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+y,S=["#define varying in",n.glslVersion===LS?"":"layout(location = 0) out highp vec4 pc_fragColor;",n.glslVersion===LS?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+S);const N=R+y+c,C=R+S+f,O=dM(r,r.VERTEX_SHADER,N),P=dM(r,r.FRAGMENT_SHADER,C);r.attachShader(b,O),r.attachShader(b,P),n.index0AttributeName!==void 0?r.bindAttribLocation(b,0,n.index0AttributeName):n.morphTargets===!0&&r.bindAttribLocation(b,0,"position"),r.linkProgram(b);function L(G){if(o.debug.checkShaderErrors){const k=r.getProgramInfoLog(b)||"",$=r.getShaderInfoLog(O)||"",te=r.getShaderInfoLog(P)||"",J=k.trim(),z=$.trim(),I=te.trim();let ie=!0,he=!0;if(r.getProgramParameter(b,r.LINK_STATUS)===!1)if(ie=!1,typeof o.debug.onShaderError=="function")o.debug.onShaderError(r,b,O,P);else{const H=mM(r,O,"vertex"),F=mM(r,P,"fragment");Qt("THREE.WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(b,r.VALIDATE_STATUS)+`

Material Name: `+G.name+`
Material Type: `+G.type+`

Program Info Log: `+J+`
`+H+`
`+F)}else J!==""?Mt("WebGLProgram: Program Info Log:",J):(z===""||I==="")&&(he=!1);he&&(G.diagnostics={runnable:ie,programLog:J,vertexShader:{log:z,prefix:y},fragmentShader:{log:I,prefix:S}})}r.deleteShader(O),r.deleteShader(P),T=new $h(r,b),w=Q3(r,b)}let T;this.getUniforms=function(){return T===void 0&&L(this),T};let w;this.getAttributes=function(){return w===void 0&&L(this),w};let q=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return q===!1&&(q=r.getProgramParameter(b,G3)),q},this.destroy=function(){a.releaseStatesOfProgram(this),r.deleteProgram(b),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=V3++,this.cacheKey=e,this.usedTimes=1,this.program=b,this.vertexShader=O,this.fragmentShader=P,this}let dD=0;class pD{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const n=e.vertexShader,a=e.fragmentShader,r=this._getShaderStage(n),l=this._getShaderStage(a),c=this._getShaderCacheForMaterial(e);return c.has(r)===!1&&(c.add(r),r.usedTimes++),c.has(l)===!1&&(c.add(l),l.usedTimes++),this}remove(e){const n=this.materialCache.get(e);for(const a of n)a.usedTimes--,a.usedTimes===0&&this.shaderCache.delete(a.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const n=this.materialCache;let a=n.get(e);return a===void 0&&(a=new Set,n.set(e,a)),a}_getShaderStage(e){const n=this.shaderCache;let a=n.get(e);return a===void 0&&(a=new mD(e),n.set(e,a)),a}}class mD{constructor(e){this.id=dD++,this.code=e,this.usedTimes=0}}function _D(o,e,n,a,r,l){const c=new w1,f=new pD,p=new Set,d=[],_=new Map,v=a.logarithmicDepthBuffer;let g=a.precision;const x={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function M(T){return p.add(T),T===0?"uv":`uv${T}`}function b(T,w,q,G,k){const $=G.fog,te=k.geometry,J=T.isMeshStandardMaterial||T.isMeshLambertMaterial||T.isMeshPhongMaterial?G.environment:null,z=T.isMeshStandardMaterial||T.isMeshLambertMaterial&&!T.envMap||T.isMeshPhongMaterial&&!T.envMap,I=e.get(T.envMap||J,z),ie=I&&I.mapping===Td?I.image.height:null,he=x[T.type];T.precision!==null&&(g=a.getMaxPrecision(T.precision),g!==T.precision&&Mt("WebGLProgram.getParameters:",T.precision,"not supported, using",g,"instead."));const H=te.morphAttributes.position||te.morphAttributes.normal||te.morphAttributes.color,F=H!==void 0?H.length:0;let Q=0;te.morphAttributes.position!==void 0&&(Q=1),te.morphAttributes.normal!==void 0&&(Q=2),te.morphAttributes.color!==void 0&&(Q=3);let xe,Te,Ne,ne;if(he){const Ve=fr[he];xe=Ve.vertexShader,Te=Ve.fragmentShader}else xe=T.vertexShader,Te=T.fragmentShader,f.update(T),Ne=f.getVertexShaderID(T),ne=f.getFragmentShaderID(T);const _e=o.getRenderTarget(),be=o.state.buffers.depth.getReversed(),ze=k.isInstancedMesh===!0,tt=k.isBatchedMesh===!0,Ke=!!T.map,Ut=!!T.matcap,qe=!!I,rt=!!T.aoMap,_t=!!T.lightMap,st=!!T.bumpMap,le=!!T.normalMap,W=!!T.displacementMap,Wt=!!T.emissiveMap,bt=!!T.metalnessMap,ct=!!T.roughnessMap,We=T.anisotropy>0,B=T.clearcoat>0,A=T.dispersion>0,Z=T.iridescence>0,ge=T.sheen>0,ve=T.transmission>0,de=We&&!!T.anisotropyMap,Ge=B&&!!T.clearcoatMap,we=B&&!!T.clearcoatNormalMap,it=B&&!!T.clearcoatRoughnessMap,Ye=Z&&!!T.iridescenceMap,Re=Z&&!!T.iridescenceThicknessMap,Ae=ge&&!!T.sheenColorMap,He=ge&&!!T.sheenRoughnessMap,Pe=!!T.specularMap,Fe=!!T.specularColorMap,pt=!!T.specularIntensityMap,V=ve&&!!T.transmissionMap,De=ve&&!!T.thicknessMap,Ce=!!T.gradientMap,Le=!!T.alphaMap,Ee=T.alphaTest>0,me=!!T.alphaHash,Xe=!!T.extensions;let lt=gr;T.toneMapped&&(_e===null||_e.isXRRenderTarget===!0)&&(lt=o.toneMapping);const Gt={shaderID:he,shaderType:T.type,shaderName:T.name,vertexShader:xe,fragmentShader:Te,defines:T.defines,customVertexShaderID:Ne,customFragmentShaderID:ne,isRawShaderMaterial:T.isRawShaderMaterial===!0,glslVersion:T.glslVersion,precision:g,batching:tt,batchingColor:tt&&k._colorsTexture!==null,instancing:ze,instancingColor:ze&&k.instanceColor!==null,instancingMorph:ze&&k.morphTexture!==null,outputColorSpace:_e===null?o.outputColorSpace:_e.isXRRenderTarget===!0?_e.texture.colorSpace:iu,alphaToCoverage:!!T.alphaToCoverage,map:Ke,matcap:Ut,envMap:qe,envMapMode:qe&&I.mapping,envMapCubeUVHeight:ie,aoMap:rt,lightMap:_t,bumpMap:st,normalMap:le,displacementMap:W,emissiveMap:Wt,normalMapObjectSpace:le&&T.normalMapType===iR,normalMapTangentSpace:le&&T.normalMapType===nR,metalnessMap:bt,roughnessMap:ct,anisotropy:We,anisotropyMap:de,clearcoat:B,clearcoatMap:Ge,clearcoatNormalMap:we,clearcoatRoughnessMap:it,dispersion:A,iridescence:Z,iridescenceMap:Ye,iridescenceThicknessMap:Re,sheen:ge,sheenColorMap:Ae,sheenRoughnessMap:He,specularMap:Pe,specularColorMap:Fe,specularIntensityMap:pt,transmission:ve,transmissionMap:V,thicknessMap:De,gradientMap:Ce,opaque:T.transparent===!1&&T.blending===Yl&&T.alphaToCoverage===!1,alphaMap:Le,alphaTest:Ee,alphaHash:me,combine:T.combine,mapUv:Ke&&M(T.map.channel),aoMapUv:rt&&M(T.aoMap.channel),lightMapUv:_t&&M(T.lightMap.channel),bumpMapUv:st&&M(T.bumpMap.channel),normalMapUv:le&&M(T.normalMap.channel),displacementMapUv:W&&M(T.displacementMap.channel),emissiveMapUv:Wt&&M(T.emissiveMap.channel),metalnessMapUv:bt&&M(T.metalnessMap.channel),roughnessMapUv:ct&&M(T.roughnessMap.channel),anisotropyMapUv:de&&M(T.anisotropyMap.channel),clearcoatMapUv:Ge&&M(T.clearcoatMap.channel),clearcoatNormalMapUv:we&&M(T.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:it&&M(T.clearcoatRoughnessMap.channel),iridescenceMapUv:Ye&&M(T.iridescenceMap.channel),iridescenceThicknessMapUv:Re&&M(T.iridescenceThicknessMap.channel),sheenColorMapUv:Ae&&M(T.sheenColorMap.channel),sheenRoughnessMapUv:He&&M(T.sheenRoughnessMap.channel),specularMapUv:Pe&&M(T.specularMap.channel),specularColorMapUv:Fe&&M(T.specularColorMap.channel),specularIntensityMapUv:pt&&M(T.specularIntensityMap.channel),transmissionMapUv:V&&M(T.transmissionMap.channel),thicknessMapUv:De&&M(T.thicknessMap.channel),alphaMapUv:Le&&M(T.alphaMap.channel),vertexTangents:!!te.attributes.tangent&&(le||We),vertexColors:T.vertexColors,vertexAlphas:T.vertexColors===!0&&!!te.attributes.color&&te.attributes.color.itemSize===4,pointsUvs:k.isPoints===!0&&!!te.attributes.uv&&(Ke||Le),fog:!!$,useFog:T.fog===!0,fogExp2:!!$&&$.isFogExp2,flatShading:T.wireframe===!1&&(T.flatShading===!0||te.attributes.normal===void 0&&le===!1&&(T.isMeshLambertMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isMeshPhysicalMaterial)),sizeAttenuation:T.sizeAttenuation===!0,logarithmicDepthBuffer:v,reversedDepthBuffer:be,skinning:k.isSkinnedMesh===!0,morphTargets:te.morphAttributes.position!==void 0,morphNormals:te.morphAttributes.normal!==void 0,morphColors:te.morphAttributes.color!==void 0,morphTargetsCount:F,morphTextureStride:Q,numDirLights:w.directional.length,numPointLights:w.point.length,numSpotLights:w.spot.length,numSpotLightMaps:w.spotLightMap.length,numRectAreaLights:w.rectArea.length,numHemiLights:w.hemi.length,numDirLightShadows:w.directionalShadowMap.length,numPointLightShadows:w.pointShadowMap.length,numSpotLightShadows:w.spotShadowMap.length,numSpotLightShadowsWithMaps:w.numSpotLightShadowsWithMaps,numLightProbes:w.numLightProbes,numClippingPlanes:l.numPlanes,numClipIntersection:l.numIntersection,dithering:T.dithering,shadowMapEnabled:o.shadowMap.enabled&&q.length>0,shadowMapType:o.shadowMap.type,toneMapping:lt,decodeVideoTexture:Ke&&T.map.isVideoTexture===!0&&Yt.getTransfer(T.map.colorSpace)===an,decodeVideoTextureEmissive:Wt&&T.emissiveMap.isVideoTexture===!0&&Yt.getTransfer(T.emissiveMap.colorSpace)===an,premultipliedAlpha:T.premultipliedAlpha,doubleSided:T.side===jr,flipSided:T.side===Yi,useDepthPacking:T.depthPacking>=0,depthPacking:T.depthPacking||0,index0AttributeName:T.index0AttributeName,extensionClipCullDistance:Xe&&T.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Xe&&T.extensions.multiDraw===!0||tt)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:T.customProgramCacheKey()};return Gt.vertexUv1s=p.has(1),Gt.vertexUv2s=p.has(2),Gt.vertexUv3s=p.has(3),p.clear(),Gt}function y(T){const w=[];if(T.shaderID?w.push(T.shaderID):(w.push(T.customVertexShaderID),w.push(T.customFragmentShaderID)),T.defines!==void 0)for(const q in T.defines)w.push(q),w.push(T.defines[q]);return T.isRawShaderMaterial===!1&&(S(w,T),R(w,T),w.push(o.outputColorSpace)),w.push(T.customProgramCacheKey),w.join()}function S(T,w){T.push(w.precision),T.push(w.outputColorSpace),T.push(w.envMapMode),T.push(w.envMapCubeUVHeight),T.push(w.mapUv),T.push(w.alphaMapUv),T.push(w.lightMapUv),T.push(w.aoMapUv),T.push(w.bumpMapUv),T.push(w.normalMapUv),T.push(w.displacementMapUv),T.push(w.emissiveMapUv),T.push(w.metalnessMapUv),T.push(w.roughnessMapUv),T.push(w.anisotropyMapUv),T.push(w.clearcoatMapUv),T.push(w.clearcoatNormalMapUv),T.push(w.clearcoatRoughnessMapUv),T.push(w.iridescenceMapUv),T.push(w.iridescenceThicknessMapUv),T.push(w.sheenColorMapUv),T.push(w.sheenRoughnessMapUv),T.push(w.specularMapUv),T.push(w.specularColorMapUv),T.push(w.specularIntensityMapUv),T.push(w.transmissionMapUv),T.push(w.thicknessMapUv),T.push(w.combine),T.push(w.fogExp2),T.push(w.sizeAttenuation),T.push(w.morphTargetsCount),T.push(w.morphAttributeCount),T.push(w.numDirLights),T.push(w.numPointLights),T.push(w.numSpotLights),T.push(w.numSpotLightMaps),T.push(w.numHemiLights),T.push(w.numRectAreaLights),T.push(w.numDirLightShadows),T.push(w.numPointLightShadows),T.push(w.numSpotLightShadows),T.push(w.numSpotLightShadowsWithMaps),T.push(w.numLightProbes),T.push(w.shadowMapType),T.push(w.toneMapping),T.push(w.numClippingPlanes),T.push(w.numClipIntersection),T.push(w.depthPacking)}function R(T,w){c.disableAll(),w.instancing&&c.enable(0),w.instancingColor&&c.enable(1),w.instancingMorph&&c.enable(2),w.matcap&&c.enable(3),w.envMap&&c.enable(4),w.normalMapObjectSpace&&c.enable(5),w.normalMapTangentSpace&&c.enable(6),w.clearcoat&&c.enable(7),w.iridescence&&c.enable(8),w.alphaTest&&c.enable(9),w.vertexColors&&c.enable(10),w.vertexAlphas&&c.enable(11),w.vertexUv1s&&c.enable(12),w.vertexUv2s&&c.enable(13),w.vertexUv3s&&c.enable(14),w.vertexTangents&&c.enable(15),w.anisotropy&&c.enable(16),w.alphaHash&&c.enable(17),w.batching&&c.enable(18),w.dispersion&&c.enable(19),w.batchingColor&&c.enable(20),w.gradientMap&&c.enable(21),T.push(c.mask),c.disableAll(),w.fog&&c.enable(0),w.useFog&&c.enable(1),w.flatShading&&c.enable(2),w.logarithmicDepthBuffer&&c.enable(3),w.reversedDepthBuffer&&c.enable(4),w.skinning&&c.enable(5),w.morphTargets&&c.enable(6),w.morphNormals&&c.enable(7),w.morphColors&&c.enable(8),w.premultipliedAlpha&&c.enable(9),w.shadowMapEnabled&&c.enable(10),w.doubleSided&&c.enable(11),w.flipSided&&c.enable(12),w.useDepthPacking&&c.enable(13),w.dithering&&c.enable(14),w.transmission&&c.enable(15),w.sheen&&c.enable(16),w.opaque&&c.enable(17),w.pointsUvs&&c.enable(18),w.decodeVideoTexture&&c.enable(19),w.decodeVideoTextureEmissive&&c.enable(20),w.alphaToCoverage&&c.enable(21),T.push(c.mask)}function N(T){const w=x[T.type];let q;if(w){const G=fr[w];q=VR.clone(G.uniforms)}else q=T.uniforms;return q}function C(T,w){let q=_.get(w);return q!==void 0?++q.usedTimes:(q=new hD(o,w,T,r),d.push(q),_.set(w,q)),q}function O(T){if(--T.usedTimes===0){const w=d.indexOf(T);d[w]=d[d.length-1],d.pop(),_.delete(T.cacheKey),T.destroy()}}function P(T){f.remove(T)}function L(){f.dispose()}return{getParameters:b,getProgramCacheKey:y,getUniforms:N,acquireProgram:C,releaseProgram:O,releaseShaderCache:P,programs:d,dispose:L}}function gD(){let o=new WeakMap;function e(c){return o.has(c)}function n(c){let f=o.get(c);return f===void 0&&(f={},o.set(c,f)),f}function a(c){o.delete(c)}function r(c,f,p){o.get(c)[f]=p}function l(){o=new WeakMap}return{has:e,get:n,remove:a,update:r,dispose:l}}function vD(o,e){return o.groupOrder!==e.groupOrder?o.groupOrder-e.groupOrder:o.renderOrder!==e.renderOrder?o.renderOrder-e.renderOrder:o.material.id!==e.material.id?o.material.id-e.material.id:o.materialVariant!==e.materialVariant?o.materialVariant-e.materialVariant:o.z!==e.z?o.z-e.z:o.id-e.id}function yM(o,e){return o.groupOrder!==e.groupOrder?o.groupOrder-e.groupOrder:o.renderOrder!==e.renderOrder?o.renderOrder-e.renderOrder:o.z!==e.z?e.z-o.z:o.id-e.id}function SM(){const o=[];let e=0;const n=[],a=[],r=[];function l(){e=0,n.length=0,a.length=0,r.length=0}function c(g){let x=0;return g.isInstancedMesh&&(x+=2),g.isSkinnedMesh&&(x+=1),x}function f(g,x,M,b,y,S){let R=o[e];return R===void 0?(R={id:g.id,object:g,geometry:x,material:M,materialVariant:c(g),groupOrder:b,renderOrder:g.renderOrder,z:y,group:S},o[e]=R):(R.id=g.id,R.object=g,R.geometry=x,R.material=M,R.materialVariant=c(g),R.groupOrder=b,R.renderOrder=g.renderOrder,R.z=y,R.group=S),e++,R}function p(g,x,M,b,y,S){const R=f(g,x,M,b,y,S);M.transmission>0?a.push(R):M.transparent===!0?r.push(R):n.push(R)}function d(g,x,M,b,y,S){const R=f(g,x,M,b,y,S);M.transmission>0?a.unshift(R):M.transparent===!0?r.unshift(R):n.unshift(R)}function _(g,x){n.length>1&&n.sort(g||vD),a.length>1&&a.sort(x||yM),r.length>1&&r.sort(x||yM)}function v(){for(let g=e,x=o.length;g<x;g++){const M=o[g];if(M.id===null)break;M.id=null,M.object=null,M.geometry=null,M.material=null,M.group=null}}return{opaque:n,transmissive:a,transparent:r,init:l,push:p,unshift:d,finish:v,sort:_}}function xD(){let o=new WeakMap;function e(a,r){const l=o.get(a);let c;return l===void 0?(c=new SM,o.set(a,[c])):r>=l.length?(c=new SM,l.push(c)):c=l[r],c}function n(){o=new WeakMap}return{get:e,dispose:n}}function yD(){const o={};return{get:function(e){if(o[e.id]!==void 0)return o[e.id];let n;switch(e.type){case"DirectionalLight":n={direction:new fe,color:new qt};break;case"SpotLight":n={position:new fe,direction:new fe,color:new qt,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":n={position:new fe,color:new qt,distance:0,decay:0};break;case"HemisphereLight":n={direction:new fe,skyColor:new qt,groundColor:new qt};break;case"RectAreaLight":n={color:new qt,position:new fe,halfWidth:new fe,halfHeight:new fe};break}return o[e.id]=n,n}}}function SD(){const o={};return{get:function(e){if(o[e.id]!==void 0)return o[e.id];let n;switch(e.type){case"DirectionalLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new fn};break;case"SpotLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new fn};break;case"PointLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new fn,shadowCameraNear:1,shadowCameraFar:1e3};break}return o[e.id]=n,n}}}let MD=0;function bD(o,e){return(e.castShadow?2:0)-(o.castShadow?2:0)+(e.map?1:0)-(o.map?1:0)}function ED(o){const e=new yD,n=SD(),a={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let d=0;d<9;d++)a.probe.push(new fe);const r=new fe,l=new Fn,c=new Fn;function f(d){let _=0,v=0,g=0;for(let w=0;w<9;w++)a.probe[w].set(0,0,0);let x=0,M=0,b=0,y=0,S=0,R=0,N=0,C=0,O=0,P=0,L=0;d.sort(bD);for(let w=0,q=d.length;w<q;w++){const G=d[w],k=G.color,$=G.intensity,te=G.distance;let J=null;if(G.shadow&&G.shadow.map&&(G.shadow.map.texture.format===nu?J=G.shadow.map.texture:J=G.shadow.map.depthTexture||G.shadow.map.texture),G.isAmbientLight)_+=k.r*$,v+=k.g*$,g+=k.b*$;else if(G.isLightProbe){for(let z=0;z<9;z++)a.probe[z].addScaledVector(G.sh.coefficients[z],$);L++}else if(G.isDirectionalLight){const z=e.get(G);if(z.color.copy(G.color).multiplyScalar(G.intensity),G.castShadow){const I=G.shadow,ie=n.get(G);ie.shadowIntensity=I.intensity,ie.shadowBias=I.bias,ie.shadowNormalBias=I.normalBias,ie.shadowRadius=I.radius,ie.shadowMapSize=I.mapSize,a.directionalShadow[x]=ie,a.directionalShadowMap[x]=J,a.directionalShadowMatrix[x]=G.shadow.matrix,R++}a.directional[x]=z,x++}else if(G.isSpotLight){const z=e.get(G);z.position.setFromMatrixPosition(G.matrixWorld),z.color.copy(k).multiplyScalar($),z.distance=te,z.coneCos=Math.cos(G.angle),z.penumbraCos=Math.cos(G.angle*(1-G.penumbra)),z.decay=G.decay,a.spot[b]=z;const I=G.shadow;if(G.map&&(a.spotLightMap[O]=G.map,O++,I.updateMatrices(G),G.castShadow&&P++),a.spotLightMatrix[b]=I.matrix,G.castShadow){const ie=n.get(G);ie.shadowIntensity=I.intensity,ie.shadowBias=I.bias,ie.shadowNormalBias=I.normalBias,ie.shadowRadius=I.radius,ie.shadowMapSize=I.mapSize,a.spotShadow[b]=ie,a.spotShadowMap[b]=J,C++}b++}else if(G.isRectAreaLight){const z=e.get(G);z.color.copy(k).multiplyScalar($),z.halfWidth.set(G.width*.5,0,0),z.halfHeight.set(0,G.height*.5,0),a.rectArea[y]=z,y++}else if(G.isPointLight){const z=e.get(G);if(z.color.copy(G.color).multiplyScalar(G.intensity),z.distance=G.distance,z.decay=G.decay,G.castShadow){const I=G.shadow,ie=n.get(G);ie.shadowIntensity=I.intensity,ie.shadowBias=I.bias,ie.shadowNormalBias=I.normalBias,ie.shadowRadius=I.radius,ie.shadowMapSize=I.mapSize,ie.shadowCameraNear=I.camera.near,ie.shadowCameraFar=I.camera.far,a.pointShadow[M]=ie,a.pointShadowMap[M]=J,a.pointShadowMatrix[M]=G.shadow.matrix,N++}a.point[M]=z,M++}else if(G.isHemisphereLight){const z=e.get(G);z.skyColor.copy(G.color).multiplyScalar($),z.groundColor.copy(G.groundColor).multiplyScalar($),a.hemi[S]=z,S++}}y>0&&(o.has("OES_texture_float_linear")===!0?(a.rectAreaLTC1=ke.LTC_FLOAT_1,a.rectAreaLTC2=ke.LTC_FLOAT_2):(a.rectAreaLTC1=ke.LTC_HALF_1,a.rectAreaLTC2=ke.LTC_HALF_2)),a.ambient[0]=_,a.ambient[1]=v,a.ambient[2]=g;const T=a.hash;(T.directionalLength!==x||T.pointLength!==M||T.spotLength!==b||T.rectAreaLength!==y||T.hemiLength!==S||T.numDirectionalShadows!==R||T.numPointShadows!==N||T.numSpotShadows!==C||T.numSpotMaps!==O||T.numLightProbes!==L)&&(a.directional.length=x,a.spot.length=b,a.rectArea.length=y,a.point.length=M,a.hemi.length=S,a.directionalShadow.length=R,a.directionalShadowMap.length=R,a.pointShadow.length=N,a.pointShadowMap.length=N,a.spotShadow.length=C,a.spotShadowMap.length=C,a.directionalShadowMatrix.length=R,a.pointShadowMatrix.length=N,a.spotLightMatrix.length=C+O-P,a.spotLightMap.length=O,a.numSpotLightShadowsWithMaps=P,a.numLightProbes=L,T.directionalLength=x,T.pointLength=M,T.spotLength=b,T.rectAreaLength=y,T.hemiLength=S,T.numDirectionalShadows=R,T.numPointShadows=N,T.numSpotShadows=C,T.numSpotMaps=O,T.numLightProbes=L,a.version=MD++)}function p(d,_){let v=0,g=0,x=0,M=0,b=0;const y=_.matrixWorldInverse;for(let S=0,R=d.length;S<R;S++){const N=d[S];if(N.isDirectionalLight){const C=a.directional[v];C.direction.setFromMatrixPosition(N.matrixWorld),r.setFromMatrixPosition(N.target.matrixWorld),C.direction.sub(r),C.direction.transformDirection(y),v++}else if(N.isSpotLight){const C=a.spot[x];C.position.setFromMatrixPosition(N.matrixWorld),C.position.applyMatrix4(y),C.direction.setFromMatrixPosition(N.matrixWorld),r.setFromMatrixPosition(N.target.matrixWorld),C.direction.sub(r),C.direction.transformDirection(y),x++}else if(N.isRectAreaLight){const C=a.rectArea[M];C.position.setFromMatrixPosition(N.matrixWorld),C.position.applyMatrix4(y),c.identity(),l.copy(N.matrixWorld),l.premultiply(y),c.extractRotation(l),C.halfWidth.set(N.width*.5,0,0),C.halfHeight.set(0,N.height*.5,0),C.halfWidth.applyMatrix4(c),C.halfHeight.applyMatrix4(c),M++}else if(N.isPointLight){const C=a.point[g];C.position.setFromMatrixPosition(N.matrixWorld),C.position.applyMatrix4(y),g++}else if(N.isHemisphereLight){const C=a.hemi[b];C.direction.setFromMatrixPosition(N.matrixWorld),C.direction.transformDirection(y),b++}}}return{setup:f,setupView:p,state:a}}function MM(o){const e=new ED(o),n=[],a=[];function r(_){d.camera=_,n.length=0,a.length=0}function l(_){n.push(_)}function c(_){a.push(_)}function f(){e.setup(n)}function p(_){e.setupView(n,_)}const d={lightsArray:n,shadowsArray:a,camera:null,lights:e,transmissionRenderTarget:{}};return{init:r,state:d,setupLights:f,setupLightsView:p,pushLight:l,pushShadow:c}}function TD(o){let e=new WeakMap;function n(r,l=0){const c=e.get(r);let f;return c===void 0?(f=new MM(o),e.set(r,[f])):l>=c.length?(f=new MM(o),c.push(f)):f=c[l],f}function a(){e=new WeakMap}return{get:n,dispose:a}}const AD=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,RD=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,CD=[new fe(1,0,0),new fe(-1,0,0),new fe(0,1,0),new fe(0,-1,0),new fe(0,0,1),new fe(0,0,-1)],wD=[new fe(0,-1,0),new fe(0,-1,0),new fe(0,0,1),new fe(0,0,-1),new fe(0,-1,0),new fe(0,-1,0)],bM=new Fn,cc=new fe,S_=new fe;function DD(o,e,n){let a=new O1;const r=new fn,l=new fn,c=new Pn,f=new YR,p=new qR,d={},_=n.maxTextureSize,v={[qs]:Yi,[Yi]:qs,[jr]:jr},g=new Ga({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new fn},radius:{value:4}},vertexShader:AD,fragmentShader:RD}),x=g.clone();x.defines.HORIZONTAL_PASS=1;const M=new er;M.setAttribute("position",new xr(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const b=new $a(M,g),y=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=jh;let S=this.type;this.render=function(P,L,T){if(y.enabled===!1||y.autoUpdate===!1&&y.needsUpdate===!1||P.length===0)return;this.type===LA&&(Mt("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=jh);const w=o.getRenderTarget(),q=o.getActiveCubeFace(),G=o.getActiveMipmapLevel(),k=o.state;k.setBlending(Jr),k.buffers.depth.getReversed()===!0?k.buffers.color.setClear(0,0,0,0):k.buffers.color.setClear(1,1,1,1),k.buffers.depth.setTest(!0),k.setScissorTest(!1);const $=S!==this.type;$&&L.traverse(function(te){te.material&&(Array.isArray(te.material)?te.material.forEach(J=>J.needsUpdate=!0):te.material.needsUpdate=!0)});for(let te=0,J=P.length;te<J;te++){const z=P[te],I=z.shadow;if(I===void 0){Mt("WebGLShadowMap:",z,"has no shadow.");continue}if(I.autoUpdate===!1&&I.needsUpdate===!1)continue;r.copy(I.mapSize);const ie=I.getFrameExtents();r.multiply(ie),l.copy(I.mapSize),(r.x>_||r.y>_)&&(r.x>_&&(l.x=Math.floor(_/ie.x),r.x=l.x*ie.x,I.mapSize.x=l.x),r.y>_&&(l.y=Math.floor(_/ie.y),r.y=l.y*ie.y,I.mapSize.y=l.y));const he=o.state.buffers.depth.getReversed();if(I.camera._reversedDepth=he,I.map===null||$===!0){if(I.map!==null&&(I.map.depthTexture!==null&&(I.map.depthTexture.dispose(),I.map.depthTexture=null),I.map.dispose()),this.type===pc){if(z.isPointLight){Mt("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}I.map=new vr(r.x,r.y,{format:nu,type:ts,minFilter:Mi,magFilter:Mi,generateMipmaps:!1}),I.map.texture.name=z.name+".shadowMap",I.map.depthTexture=new Bc(r.x,r.y,dr),I.map.depthTexture.name=z.name+".shadowMapDepth",I.map.depthTexture.format=ns,I.map.depthTexture.compareFunction=null,I.map.depthTexture.minFilter=fi,I.map.depthTexture.magFilter=fi}else z.isPointLight?(I.map=new G1(r.x),I.map.depthTexture=new HR(r.x,Sr)):(I.map=new vr(r.x,r.y),I.map.depthTexture=new Bc(r.x,r.y,Sr)),I.map.depthTexture.name=z.name+".shadowMap",I.map.depthTexture.format=ns,this.type===jh?(I.map.depthTexture.compareFunction=he?ug:lg,I.map.depthTexture.minFilter=Mi,I.map.depthTexture.magFilter=Mi):(I.map.depthTexture.compareFunction=null,I.map.depthTexture.minFilter=fi,I.map.depthTexture.magFilter=fi);I.camera.updateProjectionMatrix()}const H=I.map.isWebGLCubeRenderTarget?6:1;for(let F=0;F<H;F++){if(I.map.isWebGLCubeRenderTarget)o.setRenderTarget(I.map,F),o.clear();else{F===0&&(o.setRenderTarget(I.map),o.clear());const Q=I.getViewport(F);c.set(l.x*Q.x,l.y*Q.y,l.x*Q.z,l.y*Q.w),k.viewport(c)}if(z.isPointLight){const Q=I.camera,xe=I.matrix,Te=z.distance||Q.far;Te!==Q.far&&(Q.far=Te,Q.updateProjectionMatrix()),cc.setFromMatrixPosition(z.matrixWorld),Q.position.copy(cc),S_.copy(Q.position),S_.add(CD[F]),Q.up.copy(wD[F]),Q.lookAt(S_),Q.updateMatrixWorld(),xe.makeTranslation(-cc.x,-cc.y,-cc.z),bM.multiplyMatrices(Q.projectionMatrix,Q.matrixWorldInverse),I._frustum.setFromProjectionMatrix(bM,Q.coordinateSystem,Q.reversedDepth)}else I.updateMatrices(z);a=I.getFrustum(),C(L,T,I.camera,z,this.type)}I.isPointLightShadow!==!0&&this.type===pc&&R(I,T),I.needsUpdate=!1}S=this.type,y.needsUpdate=!1,o.setRenderTarget(w,q,G)};function R(P,L){const T=e.update(b);g.defines.VSM_SAMPLES!==P.blurSamples&&(g.defines.VSM_SAMPLES=P.blurSamples,x.defines.VSM_SAMPLES=P.blurSamples,g.needsUpdate=!0,x.needsUpdate=!0),P.mapPass===null&&(P.mapPass=new vr(r.x,r.y,{format:nu,type:ts})),g.uniforms.shadow_pass.value=P.map.depthTexture,g.uniforms.resolution.value=P.mapSize,g.uniforms.radius.value=P.radius,o.setRenderTarget(P.mapPass),o.clear(),o.renderBufferDirect(L,null,T,g,b,null),x.uniforms.shadow_pass.value=P.mapPass.texture,x.uniforms.resolution.value=P.mapSize,x.uniforms.radius.value=P.radius,o.setRenderTarget(P.map),o.clear(),o.renderBufferDirect(L,null,T,x,b,null)}function N(P,L,T,w){let q=null;const G=T.isPointLight===!0?P.customDistanceMaterial:P.customDepthMaterial;if(G!==void 0)q=G;else if(q=T.isPointLight===!0?p:f,o.localClippingEnabled&&L.clipShadows===!0&&Array.isArray(L.clippingPlanes)&&L.clippingPlanes.length!==0||L.displacementMap&&L.displacementScale!==0||L.alphaMap&&L.alphaTest>0||L.map&&L.alphaTest>0||L.alphaToCoverage===!0){const k=q.uuid,$=L.uuid;let te=d[k];te===void 0&&(te={},d[k]=te);let J=te[$];J===void 0&&(J=q.clone(),te[$]=J,L.addEventListener("dispose",O)),q=J}if(q.visible=L.visible,q.wireframe=L.wireframe,w===pc?q.side=L.shadowSide!==null?L.shadowSide:L.side:q.side=L.shadowSide!==null?L.shadowSide:v[L.side],q.alphaMap=L.alphaMap,q.alphaTest=L.alphaToCoverage===!0?.5:L.alphaTest,q.map=L.map,q.clipShadows=L.clipShadows,q.clippingPlanes=L.clippingPlanes,q.clipIntersection=L.clipIntersection,q.displacementMap=L.displacementMap,q.displacementScale=L.displacementScale,q.displacementBias=L.displacementBias,q.wireframeLinewidth=L.wireframeLinewidth,q.linewidth=L.linewidth,T.isPointLight===!0&&q.isMeshDistanceMaterial===!0){const k=o.properties.get(q);k.light=T}return q}function C(P,L,T,w,q){if(P.visible===!1)return;if(P.layers.test(L.layers)&&(P.isMesh||P.isLine||P.isPoints)&&(P.castShadow||P.receiveShadow&&q===pc)&&(!P.frustumCulled||a.intersectsObject(P))){P.modelViewMatrix.multiplyMatrices(T.matrixWorldInverse,P.matrixWorld);const $=e.update(P),te=P.material;if(Array.isArray(te)){const J=$.groups;for(let z=0,I=J.length;z<I;z++){const ie=J[z],he=te[ie.materialIndex];if(he&&he.visible){const H=N(P,he,w,q);P.onBeforeShadow(o,P,L,T,$,H,ie),o.renderBufferDirect(T,null,$,H,P,ie),P.onAfterShadow(o,P,L,T,$,H,ie)}}}else if(te.visible){const J=N(P,te,w,q);P.onBeforeShadow(o,P,L,T,$,J,null),o.renderBufferDirect(T,null,$,J,P,null),P.onAfterShadow(o,P,L,T,$,J,null)}}const k=P.children;for(let $=0,te=k.length;$<te;$++)C(k[$],L,T,w,q)}function O(P){P.target.removeEventListener("dispose",O);for(const T in d){const w=d[T],q=P.target.uuid;q in w&&(w[q].dispose(),delete w[q])}}}function ND(o,e){function n(){let V=!1;const De=new Pn;let Ce=null;const Le=new Pn(0,0,0,0);return{setMask:function(Ee){Ce!==Ee&&!V&&(o.colorMask(Ee,Ee,Ee,Ee),Ce=Ee)},setLocked:function(Ee){V=Ee},setClear:function(Ee,me,Xe,lt,Gt){Gt===!0&&(Ee*=lt,me*=lt,Xe*=lt),De.set(Ee,me,Xe,lt),Le.equals(De)===!1&&(o.clearColor(Ee,me,Xe,lt),Le.copy(De))},reset:function(){V=!1,Ce=null,Le.set(-1,0,0,0)}}}function a(){let V=!1,De=!1,Ce=null,Le=null,Ee=null;return{setReversed:function(me){if(De!==me){const Xe=e.get("EXT_clip_control");me?Xe.clipControlEXT(Xe.LOWER_LEFT_EXT,Xe.ZERO_TO_ONE_EXT):Xe.clipControlEXT(Xe.LOWER_LEFT_EXT,Xe.NEGATIVE_ONE_TO_ONE_EXT),De=me;const lt=Ee;Ee=null,this.setClear(lt)}},getReversed:function(){return De},setTest:function(me){me?_e(o.DEPTH_TEST):be(o.DEPTH_TEST)},setMask:function(me){Ce!==me&&!V&&(o.depthMask(me),Ce=me)},setFunc:function(me){if(De&&(me=dR[me]),Le!==me){switch(me){case B_:o.depthFunc(o.NEVER);break;case H_:o.depthFunc(o.ALWAYS);break;case G_:o.depthFunc(o.LESS);break;case eu:o.depthFunc(o.LEQUAL);break;case V_:o.depthFunc(o.EQUAL);break;case k_:o.depthFunc(o.GEQUAL);break;case X_:o.depthFunc(o.GREATER);break;case W_:o.depthFunc(o.NOTEQUAL);break;default:o.depthFunc(o.LEQUAL)}Le=me}},setLocked:function(me){V=me},setClear:function(me){Ee!==me&&(Ee=me,De&&(me=1-me),o.clearDepth(me))},reset:function(){V=!1,Ce=null,Le=null,Ee=null,De=!1}}}function r(){let V=!1,De=null,Ce=null,Le=null,Ee=null,me=null,Xe=null,lt=null,Gt=null;return{setTest:function(Ve){V||(Ve?_e(o.STENCIL_TEST):be(o.STENCIL_TEST))},setMask:function(Ve){De!==Ve&&!V&&(o.stencilMask(Ve),De=Ve)},setFunc:function(Ve,Je,Et){(Ce!==Ve||Le!==Je||Ee!==Et)&&(o.stencilFunc(Ve,Je,Et),Ce=Ve,Le=Je,Ee=Et)},setOp:function(Ve,Je,Et){(me!==Ve||Xe!==Je||lt!==Et)&&(o.stencilOp(Ve,Je,Et),me=Ve,Xe=Je,lt=Et)},setLocked:function(Ve){V=Ve},setClear:function(Ve){Gt!==Ve&&(o.clearStencil(Ve),Gt=Ve)},reset:function(){V=!1,De=null,Ce=null,Le=null,Ee=null,me=null,Xe=null,lt=null,Gt=null}}}const l=new n,c=new a,f=new r,p=new WeakMap,d=new WeakMap;let _={},v={},g=new WeakMap,x=[],M=null,b=!1,y=null,S=null,R=null,N=null,C=null,O=null,P=null,L=new qt(0,0,0),T=0,w=!1,q=null,G=null,k=null,$=null,te=null;const J=o.getParameter(o.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let z=!1,I=0;const ie=o.getParameter(o.VERSION);ie.indexOf("WebGL")!==-1?(I=parseFloat(/^WebGL (\d)/.exec(ie)[1]),z=I>=1):ie.indexOf("OpenGL ES")!==-1&&(I=parseFloat(/^OpenGL ES (\d)/.exec(ie)[1]),z=I>=2);let he=null,H={};const F=o.getParameter(o.SCISSOR_BOX),Q=o.getParameter(o.VIEWPORT),xe=new Pn().fromArray(F),Te=new Pn().fromArray(Q);function Ne(V,De,Ce,Le){const Ee=new Uint8Array(4),me=o.createTexture();o.bindTexture(V,me),o.texParameteri(V,o.TEXTURE_MIN_FILTER,o.NEAREST),o.texParameteri(V,o.TEXTURE_MAG_FILTER,o.NEAREST);for(let Xe=0;Xe<Ce;Xe++)V===o.TEXTURE_3D||V===o.TEXTURE_2D_ARRAY?o.texImage3D(De,0,o.RGBA,1,1,Le,0,o.RGBA,o.UNSIGNED_BYTE,Ee):o.texImage2D(De+Xe,0,o.RGBA,1,1,0,o.RGBA,o.UNSIGNED_BYTE,Ee);return me}const ne={};ne[o.TEXTURE_2D]=Ne(o.TEXTURE_2D,o.TEXTURE_2D,1),ne[o.TEXTURE_CUBE_MAP]=Ne(o.TEXTURE_CUBE_MAP,o.TEXTURE_CUBE_MAP_POSITIVE_X,6),ne[o.TEXTURE_2D_ARRAY]=Ne(o.TEXTURE_2D_ARRAY,o.TEXTURE_2D_ARRAY,1,1),ne[o.TEXTURE_3D]=Ne(o.TEXTURE_3D,o.TEXTURE_3D,1,1),l.setClear(0,0,0,1),c.setClear(1),f.setClear(0),_e(o.DEPTH_TEST),c.setFunc(eu),st(!1),le(RS),_e(o.CULL_FACE),rt(Jr);function _e(V){_[V]!==!0&&(o.enable(V),_[V]=!0)}function be(V){_[V]!==!1&&(o.disable(V),_[V]=!1)}function ze(V,De){return v[V]!==De?(o.bindFramebuffer(V,De),v[V]=De,V===o.DRAW_FRAMEBUFFER&&(v[o.FRAMEBUFFER]=De),V===o.FRAMEBUFFER&&(v[o.DRAW_FRAMEBUFFER]=De),!0):!1}function tt(V,De){let Ce=x,Le=!1;if(V){Ce=g.get(De),Ce===void 0&&(Ce=[],g.set(De,Ce));const Ee=V.textures;if(Ce.length!==Ee.length||Ce[0]!==o.COLOR_ATTACHMENT0){for(let me=0,Xe=Ee.length;me<Xe;me++)Ce[me]=o.COLOR_ATTACHMENT0+me;Ce.length=Ee.length,Le=!0}}else Ce[0]!==o.BACK&&(Ce[0]=o.BACK,Le=!0);Le&&o.drawBuffers(Ce)}function Ke(V){return M!==V?(o.useProgram(V),M=V,!0):!1}const Ut={[Co]:o.FUNC_ADD,[PA]:o.FUNC_SUBTRACT,[zA]:o.FUNC_REVERSE_SUBTRACT};Ut[FA]=o.MIN,Ut[IA]=o.MAX;const qe={[BA]:o.ZERO,[HA]:o.ONE,[GA]:o.SRC_COLOR,[F_]:o.SRC_ALPHA,[qA]:o.SRC_ALPHA_SATURATE,[WA]:o.DST_COLOR,[kA]:o.DST_ALPHA,[VA]:o.ONE_MINUS_SRC_COLOR,[I_]:o.ONE_MINUS_SRC_ALPHA,[YA]:o.ONE_MINUS_DST_COLOR,[XA]:o.ONE_MINUS_DST_ALPHA,[jA]:o.CONSTANT_COLOR,[ZA]:o.ONE_MINUS_CONSTANT_COLOR,[KA]:o.CONSTANT_ALPHA,[QA]:o.ONE_MINUS_CONSTANT_ALPHA};function rt(V,De,Ce,Le,Ee,me,Xe,lt,Gt,Ve){if(V===Jr){b===!0&&(be(o.BLEND),b=!1);return}if(b===!1&&(_e(o.BLEND),b=!0),V!==OA){if(V!==y||Ve!==w){if((S!==Co||C!==Co)&&(o.blendEquation(o.FUNC_ADD),S=Co,C=Co),Ve)switch(V){case Yl:o.blendFuncSeparate(o.ONE,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case CS:o.blendFunc(o.ONE,o.ONE);break;case wS:o.blendFuncSeparate(o.ZERO,o.ONE_MINUS_SRC_COLOR,o.ZERO,o.ONE);break;case DS:o.blendFuncSeparate(o.DST_COLOR,o.ONE_MINUS_SRC_ALPHA,o.ZERO,o.ONE);break;default:Qt("WebGLState: Invalid blending: ",V);break}else switch(V){case Yl:o.blendFuncSeparate(o.SRC_ALPHA,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case CS:o.blendFuncSeparate(o.SRC_ALPHA,o.ONE,o.ONE,o.ONE);break;case wS:Qt("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case DS:Qt("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Qt("WebGLState: Invalid blending: ",V);break}R=null,N=null,O=null,P=null,L.set(0,0,0),T=0,y=V,w=Ve}return}Ee=Ee||De,me=me||Ce,Xe=Xe||Le,(De!==S||Ee!==C)&&(o.blendEquationSeparate(Ut[De],Ut[Ee]),S=De,C=Ee),(Ce!==R||Le!==N||me!==O||Xe!==P)&&(o.blendFuncSeparate(qe[Ce],qe[Le],qe[me],qe[Xe]),R=Ce,N=Le,O=me,P=Xe),(lt.equals(L)===!1||Gt!==T)&&(o.blendColor(lt.r,lt.g,lt.b,Gt),L.copy(lt),T=Gt),y=V,w=!1}function _t(V,De){V.side===jr?be(o.CULL_FACE):_e(o.CULL_FACE);let Ce=V.side===Yi;De&&(Ce=!Ce),st(Ce),V.blending===Yl&&V.transparent===!1?rt(Jr):rt(V.blending,V.blendEquation,V.blendSrc,V.blendDst,V.blendEquationAlpha,V.blendSrcAlpha,V.blendDstAlpha,V.blendColor,V.blendAlpha,V.premultipliedAlpha),c.setFunc(V.depthFunc),c.setTest(V.depthTest),c.setMask(V.depthWrite),l.setMask(V.colorWrite);const Le=V.stencilWrite;f.setTest(Le),Le&&(f.setMask(V.stencilWriteMask),f.setFunc(V.stencilFunc,V.stencilRef,V.stencilFuncMask),f.setOp(V.stencilFail,V.stencilZFail,V.stencilZPass)),Wt(V.polygonOffset,V.polygonOffsetFactor,V.polygonOffsetUnits),V.alphaToCoverage===!0?_e(o.SAMPLE_ALPHA_TO_COVERAGE):be(o.SAMPLE_ALPHA_TO_COVERAGE)}function st(V){q!==V&&(V?o.frontFace(o.CW):o.frontFace(o.CCW),q=V)}function le(V){V!==NA?(_e(o.CULL_FACE),V!==G&&(V===RS?o.cullFace(o.BACK):V===UA?o.cullFace(o.FRONT):o.cullFace(o.FRONT_AND_BACK))):be(o.CULL_FACE),G=V}function W(V){V!==k&&(z&&o.lineWidth(V),k=V)}function Wt(V,De,Ce){V?(_e(o.POLYGON_OFFSET_FILL),($!==De||te!==Ce)&&($=De,te=Ce,c.getReversed()&&(De=-De),o.polygonOffset(De,Ce))):be(o.POLYGON_OFFSET_FILL)}function bt(V){V?_e(o.SCISSOR_TEST):be(o.SCISSOR_TEST)}function ct(V){V===void 0&&(V=o.TEXTURE0+J-1),he!==V&&(o.activeTexture(V),he=V)}function We(V,De,Ce){Ce===void 0&&(he===null?Ce=o.TEXTURE0+J-1:Ce=he);let Le=H[Ce];Le===void 0&&(Le={type:void 0,texture:void 0},H[Ce]=Le),(Le.type!==V||Le.texture!==De)&&(he!==Ce&&(o.activeTexture(Ce),he=Ce),o.bindTexture(V,De||ne[V]),Le.type=V,Le.texture=De)}function B(){const V=H[he];V!==void 0&&V.type!==void 0&&(o.bindTexture(V.type,null),V.type=void 0,V.texture=void 0)}function A(){try{o.compressedTexImage2D(...arguments)}catch(V){Qt("WebGLState:",V)}}function Z(){try{o.compressedTexImage3D(...arguments)}catch(V){Qt("WebGLState:",V)}}function ge(){try{o.texSubImage2D(...arguments)}catch(V){Qt("WebGLState:",V)}}function ve(){try{o.texSubImage3D(...arguments)}catch(V){Qt("WebGLState:",V)}}function de(){try{o.compressedTexSubImage2D(...arguments)}catch(V){Qt("WebGLState:",V)}}function Ge(){try{o.compressedTexSubImage3D(...arguments)}catch(V){Qt("WebGLState:",V)}}function we(){try{o.texStorage2D(...arguments)}catch(V){Qt("WebGLState:",V)}}function it(){try{o.texStorage3D(...arguments)}catch(V){Qt("WebGLState:",V)}}function Ye(){try{o.texImage2D(...arguments)}catch(V){Qt("WebGLState:",V)}}function Re(){try{o.texImage3D(...arguments)}catch(V){Qt("WebGLState:",V)}}function Ae(V){xe.equals(V)===!1&&(o.scissor(V.x,V.y,V.z,V.w),xe.copy(V))}function He(V){Te.equals(V)===!1&&(o.viewport(V.x,V.y,V.z,V.w),Te.copy(V))}function Pe(V,De){let Ce=d.get(De);Ce===void 0&&(Ce=new WeakMap,d.set(De,Ce));let Le=Ce.get(V);Le===void 0&&(Le=o.getUniformBlockIndex(De,V.name),Ce.set(V,Le))}function Fe(V,De){const Le=d.get(De).get(V);p.get(De)!==Le&&(o.uniformBlockBinding(De,Le,V.__bindingPointIndex),p.set(De,Le))}function pt(){o.disable(o.BLEND),o.disable(o.CULL_FACE),o.disable(o.DEPTH_TEST),o.disable(o.POLYGON_OFFSET_FILL),o.disable(o.SCISSOR_TEST),o.disable(o.STENCIL_TEST),o.disable(o.SAMPLE_ALPHA_TO_COVERAGE),o.blendEquation(o.FUNC_ADD),o.blendFunc(o.ONE,o.ZERO),o.blendFuncSeparate(o.ONE,o.ZERO,o.ONE,o.ZERO),o.blendColor(0,0,0,0),o.colorMask(!0,!0,!0,!0),o.clearColor(0,0,0,0),o.depthMask(!0),o.depthFunc(o.LESS),c.setReversed(!1),o.clearDepth(1),o.stencilMask(4294967295),o.stencilFunc(o.ALWAYS,0,4294967295),o.stencilOp(o.KEEP,o.KEEP,o.KEEP),o.clearStencil(0),o.cullFace(o.BACK),o.frontFace(o.CCW),o.polygonOffset(0,0),o.activeTexture(o.TEXTURE0),o.bindFramebuffer(o.FRAMEBUFFER,null),o.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),o.bindFramebuffer(o.READ_FRAMEBUFFER,null),o.useProgram(null),o.lineWidth(1),o.scissor(0,0,o.canvas.width,o.canvas.height),o.viewport(0,0,o.canvas.width,o.canvas.height),_={},he=null,H={},v={},g=new WeakMap,x=[],M=null,b=!1,y=null,S=null,R=null,N=null,C=null,O=null,P=null,L=new qt(0,0,0),T=0,w=!1,q=null,G=null,k=null,$=null,te=null,xe.set(0,0,o.canvas.width,o.canvas.height),Te.set(0,0,o.canvas.width,o.canvas.height),l.reset(),c.reset(),f.reset()}return{buffers:{color:l,depth:c,stencil:f},enable:_e,disable:be,bindFramebuffer:ze,drawBuffers:tt,useProgram:Ke,setBlending:rt,setMaterial:_t,setFlipSided:st,setCullFace:le,setLineWidth:W,setPolygonOffset:Wt,setScissorTest:bt,activeTexture:ct,bindTexture:We,unbindTexture:B,compressedTexImage2D:A,compressedTexImage3D:Z,texImage2D:Ye,texImage3D:Re,updateUBOMapping:Pe,uniformBlockBinding:Fe,texStorage2D:we,texStorage3D:it,texSubImage2D:ge,texSubImage3D:ve,compressedTexSubImage2D:de,compressedTexSubImage3D:Ge,scissor:Ae,viewport:He,reset:pt}}function UD(o,e,n,a,r,l,c){const f=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,p=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),d=new fn,_=new WeakMap;let v;const g=new WeakMap;let x=!1;try{x=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function M(B,A){return x?new OffscreenCanvas(B,A):fd("canvas")}function b(B,A,Z){let ge=1;const ve=We(B);if((ve.width>Z||ve.height>Z)&&(ge=Z/Math.max(ve.width,ve.height)),ge<1)if(typeof HTMLImageElement<"u"&&B instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&B instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&B instanceof ImageBitmap||typeof VideoFrame<"u"&&B instanceof VideoFrame){const de=Math.floor(ge*ve.width),Ge=Math.floor(ge*ve.height);v===void 0&&(v=M(de,Ge));const we=A?M(de,Ge):v;return we.width=de,we.height=Ge,we.getContext("2d").drawImage(B,0,0,de,Ge),Mt("WebGLRenderer: Texture has been resized from ("+ve.width+"x"+ve.height+") to ("+de+"x"+Ge+")."),we}else return"data"in B&&Mt("WebGLRenderer: Image in DataTexture is too big ("+ve.width+"x"+ve.height+")."),B;return B}function y(B){return B.generateMipmaps}function S(B){o.generateMipmap(B)}function R(B){return B.isWebGLCubeRenderTarget?o.TEXTURE_CUBE_MAP:B.isWebGL3DRenderTarget?o.TEXTURE_3D:B.isWebGLArrayRenderTarget||B.isCompressedArrayTexture?o.TEXTURE_2D_ARRAY:o.TEXTURE_2D}function N(B,A,Z,ge,ve=!1){if(B!==null){if(o[B]!==void 0)return o[B];Mt("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+B+"'")}let de=A;if(A===o.RED&&(Z===o.FLOAT&&(de=o.R32F),Z===o.HALF_FLOAT&&(de=o.R16F),Z===o.UNSIGNED_BYTE&&(de=o.R8)),A===o.RED_INTEGER&&(Z===o.UNSIGNED_BYTE&&(de=o.R8UI),Z===o.UNSIGNED_SHORT&&(de=o.R16UI),Z===o.UNSIGNED_INT&&(de=o.R32UI),Z===o.BYTE&&(de=o.R8I),Z===o.SHORT&&(de=o.R16I),Z===o.INT&&(de=o.R32I)),A===o.RG&&(Z===o.FLOAT&&(de=o.RG32F),Z===o.HALF_FLOAT&&(de=o.RG16F),Z===o.UNSIGNED_BYTE&&(de=o.RG8)),A===o.RG_INTEGER&&(Z===o.UNSIGNED_BYTE&&(de=o.RG8UI),Z===o.UNSIGNED_SHORT&&(de=o.RG16UI),Z===o.UNSIGNED_INT&&(de=o.RG32UI),Z===o.BYTE&&(de=o.RG8I),Z===o.SHORT&&(de=o.RG16I),Z===o.INT&&(de=o.RG32I)),A===o.RGB_INTEGER&&(Z===o.UNSIGNED_BYTE&&(de=o.RGB8UI),Z===o.UNSIGNED_SHORT&&(de=o.RGB16UI),Z===o.UNSIGNED_INT&&(de=o.RGB32UI),Z===o.BYTE&&(de=o.RGB8I),Z===o.SHORT&&(de=o.RGB16I),Z===o.INT&&(de=o.RGB32I)),A===o.RGBA_INTEGER&&(Z===o.UNSIGNED_BYTE&&(de=o.RGBA8UI),Z===o.UNSIGNED_SHORT&&(de=o.RGBA16UI),Z===o.UNSIGNED_INT&&(de=o.RGBA32UI),Z===o.BYTE&&(de=o.RGBA8I),Z===o.SHORT&&(de=o.RGBA16I),Z===o.INT&&(de=o.RGBA32I)),A===o.RGB&&(Z===o.UNSIGNED_INT_5_9_9_9_REV&&(de=o.RGB9_E5),Z===o.UNSIGNED_INT_10F_11F_11F_REV&&(de=o.R11F_G11F_B10F)),A===o.RGBA){const Ge=ve?ud:Yt.getTransfer(ge);Z===o.FLOAT&&(de=o.RGBA32F),Z===o.HALF_FLOAT&&(de=o.RGBA16F),Z===o.UNSIGNED_BYTE&&(de=Ge===an?o.SRGB8_ALPHA8:o.RGBA8),Z===o.UNSIGNED_SHORT_4_4_4_4&&(de=o.RGBA4),Z===o.UNSIGNED_SHORT_5_5_5_1&&(de=o.RGB5_A1)}return(de===o.R16F||de===o.R32F||de===o.RG16F||de===o.RG32F||de===o.RGBA16F||de===o.RGBA32F)&&e.get("EXT_color_buffer_float"),de}function C(B,A){let Z;return B?A===null||A===Sr||A===Ic?Z=o.DEPTH24_STENCIL8:A===dr?Z=o.DEPTH32F_STENCIL8:A===Fc&&(Z=o.DEPTH24_STENCIL8,Mt("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):A===null||A===Sr||A===Ic?Z=o.DEPTH_COMPONENT24:A===dr?Z=o.DEPTH_COMPONENT32F:A===Fc&&(Z=o.DEPTH_COMPONENT16),Z}function O(B,A){return y(B)===!0||B.isFramebufferTexture&&B.minFilter!==fi&&B.minFilter!==Mi?Math.log2(Math.max(A.width,A.height))+1:B.mipmaps!==void 0&&B.mipmaps.length>0?B.mipmaps.length:B.isCompressedTexture&&Array.isArray(B.image)?A.mipmaps.length:1}function P(B){const A=B.target;A.removeEventListener("dispose",P),T(A),A.isVideoTexture&&_.delete(A)}function L(B){const A=B.target;A.removeEventListener("dispose",L),q(A)}function T(B){const A=a.get(B);if(A.__webglInit===void 0)return;const Z=B.source,ge=g.get(Z);if(ge){const ve=ge[A.__cacheKey];ve.usedTimes--,ve.usedTimes===0&&w(B),Object.keys(ge).length===0&&g.delete(Z)}a.remove(B)}function w(B){const A=a.get(B);o.deleteTexture(A.__webglTexture);const Z=B.source,ge=g.get(Z);delete ge[A.__cacheKey],c.memory.textures--}function q(B){const A=a.get(B);if(B.depthTexture&&(B.depthTexture.dispose(),a.remove(B.depthTexture)),B.isWebGLCubeRenderTarget)for(let ge=0;ge<6;ge++){if(Array.isArray(A.__webglFramebuffer[ge]))for(let ve=0;ve<A.__webglFramebuffer[ge].length;ve++)o.deleteFramebuffer(A.__webglFramebuffer[ge][ve]);else o.deleteFramebuffer(A.__webglFramebuffer[ge]);A.__webglDepthbuffer&&o.deleteRenderbuffer(A.__webglDepthbuffer[ge])}else{if(Array.isArray(A.__webglFramebuffer))for(let ge=0;ge<A.__webglFramebuffer.length;ge++)o.deleteFramebuffer(A.__webglFramebuffer[ge]);else o.deleteFramebuffer(A.__webglFramebuffer);if(A.__webglDepthbuffer&&o.deleteRenderbuffer(A.__webglDepthbuffer),A.__webglMultisampledFramebuffer&&o.deleteFramebuffer(A.__webglMultisampledFramebuffer),A.__webglColorRenderbuffer)for(let ge=0;ge<A.__webglColorRenderbuffer.length;ge++)A.__webglColorRenderbuffer[ge]&&o.deleteRenderbuffer(A.__webglColorRenderbuffer[ge]);A.__webglDepthRenderbuffer&&o.deleteRenderbuffer(A.__webglDepthRenderbuffer)}const Z=B.textures;for(let ge=0,ve=Z.length;ge<ve;ge++){const de=a.get(Z[ge]);de.__webglTexture&&(o.deleteTexture(de.__webglTexture),c.memory.textures--),a.remove(Z[ge])}a.remove(B)}let G=0;function k(){G=0}function $(){const B=G;return B>=r.maxTextures&&Mt("WebGLTextures: Trying to use "+B+" texture units while this GPU supports only "+r.maxTextures),G+=1,B}function te(B){const A=[];return A.push(B.wrapS),A.push(B.wrapT),A.push(B.wrapR||0),A.push(B.magFilter),A.push(B.minFilter),A.push(B.anisotropy),A.push(B.internalFormat),A.push(B.format),A.push(B.type),A.push(B.generateMipmaps),A.push(B.premultiplyAlpha),A.push(B.flipY),A.push(B.unpackAlignment),A.push(B.colorSpace),A.join()}function J(B,A){const Z=a.get(B);if(B.isVideoTexture&&bt(B),B.isRenderTargetTexture===!1&&B.isExternalTexture!==!0&&B.version>0&&Z.__version!==B.version){const ge=B.image;if(ge===null)Mt("WebGLRenderer: Texture marked for update but no image data found.");else if(ge.complete===!1)Mt("WebGLRenderer: Texture marked for update but image is incomplete");else{ne(Z,B,A);return}}else B.isExternalTexture&&(Z.__webglTexture=B.sourceTexture?B.sourceTexture:null);n.bindTexture(o.TEXTURE_2D,Z.__webglTexture,o.TEXTURE0+A)}function z(B,A){const Z=a.get(B);if(B.isRenderTargetTexture===!1&&B.version>0&&Z.__version!==B.version){ne(Z,B,A);return}else B.isExternalTexture&&(Z.__webglTexture=B.sourceTexture?B.sourceTexture:null);n.bindTexture(o.TEXTURE_2D_ARRAY,Z.__webglTexture,o.TEXTURE0+A)}function I(B,A){const Z=a.get(B);if(B.isRenderTargetTexture===!1&&B.version>0&&Z.__version!==B.version){ne(Z,B,A);return}n.bindTexture(o.TEXTURE_3D,Z.__webglTexture,o.TEXTURE0+A)}function ie(B,A){const Z=a.get(B);if(B.isCubeDepthTexture!==!0&&B.version>0&&Z.__version!==B.version){_e(Z,B,A);return}n.bindTexture(o.TEXTURE_CUBE_MAP,Z.__webglTexture,o.TEXTURE0+A)}const he={[Y_]:o.REPEAT,[Kr]:o.CLAMP_TO_EDGE,[q_]:o.MIRRORED_REPEAT},H={[fi]:o.NEAREST,[eR]:o.NEAREST_MIPMAP_NEAREST,[ch]:o.NEAREST_MIPMAP_LINEAR,[Mi]:o.LINEAR,[Wm]:o.LINEAR_MIPMAP_NEAREST,[Do]:o.LINEAR_MIPMAP_LINEAR},F={[aR]:o.NEVER,[uR]:o.ALWAYS,[rR]:o.LESS,[lg]:o.LEQUAL,[sR]:o.EQUAL,[ug]:o.GEQUAL,[oR]:o.GREATER,[lR]:o.NOTEQUAL};function Q(B,A){if(A.type===dr&&e.has("OES_texture_float_linear")===!1&&(A.magFilter===Mi||A.magFilter===Wm||A.magFilter===ch||A.magFilter===Do||A.minFilter===Mi||A.minFilter===Wm||A.minFilter===ch||A.minFilter===Do)&&Mt("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),o.texParameteri(B,o.TEXTURE_WRAP_S,he[A.wrapS]),o.texParameteri(B,o.TEXTURE_WRAP_T,he[A.wrapT]),(B===o.TEXTURE_3D||B===o.TEXTURE_2D_ARRAY)&&o.texParameteri(B,o.TEXTURE_WRAP_R,he[A.wrapR]),o.texParameteri(B,o.TEXTURE_MAG_FILTER,H[A.magFilter]),o.texParameteri(B,o.TEXTURE_MIN_FILTER,H[A.minFilter]),A.compareFunction&&(o.texParameteri(B,o.TEXTURE_COMPARE_MODE,o.COMPARE_REF_TO_TEXTURE),o.texParameteri(B,o.TEXTURE_COMPARE_FUNC,F[A.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(A.magFilter===fi||A.minFilter!==ch&&A.minFilter!==Do||A.type===dr&&e.has("OES_texture_float_linear")===!1)return;if(A.anisotropy>1||a.get(A).__currentAnisotropy){const Z=e.get("EXT_texture_filter_anisotropic");o.texParameterf(B,Z.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(A.anisotropy,r.getMaxAnisotropy())),a.get(A).__currentAnisotropy=A.anisotropy}}}function xe(B,A){let Z=!1;B.__webglInit===void 0&&(B.__webglInit=!0,A.addEventListener("dispose",P));const ge=A.source;let ve=g.get(ge);ve===void 0&&(ve={},g.set(ge,ve));const de=te(A);if(de!==B.__cacheKey){ve[de]===void 0&&(ve[de]={texture:o.createTexture(),usedTimes:0},c.memory.textures++,Z=!0),ve[de].usedTimes++;const Ge=ve[B.__cacheKey];Ge!==void 0&&(ve[B.__cacheKey].usedTimes--,Ge.usedTimes===0&&w(A)),B.__cacheKey=de,B.__webglTexture=ve[de].texture}return Z}function Te(B,A,Z){return Math.floor(Math.floor(B/Z)/A)}function Ne(B,A,Z,ge){const de=B.updateRanges;if(de.length===0)n.texSubImage2D(o.TEXTURE_2D,0,0,0,A.width,A.height,Z,ge,A.data);else{de.sort((Re,Ae)=>Re.start-Ae.start);let Ge=0;for(let Re=1;Re<de.length;Re++){const Ae=de[Ge],He=de[Re],Pe=Ae.start+Ae.count,Fe=Te(He.start,A.width,4),pt=Te(Ae.start,A.width,4);He.start<=Pe+1&&Fe===pt&&Te(He.start+He.count-1,A.width,4)===Fe?Ae.count=Math.max(Ae.count,He.start+He.count-Ae.start):(++Ge,de[Ge]=He)}de.length=Ge+1;const we=o.getParameter(o.UNPACK_ROW_LENGTH),it=o.getParameter(o.UNPACK_SKIP_PIXELS),Ye=o.getParameter(o.UNPACK_SKIP_ROWS);o.pixelStorei(o.UNPACK_ROW_LENGTH,A.width);for(let Re=0,Ae=de.length;Re<Ae;Re++){const He=de[Re],Pe=Math.floor(He.start/4),Fe=Math.ceil(He.count/4),pt=Pe%A.width,V=Math.floor(Pe/A.width),De=Fe,Ce=1;o.pixelStorei(o.UNPACK_SKIP_PIXELS,pt),o.pixelStorei(o.UNPACK_SKIP_ROWS,V),n.texSubImage2D(o.TEXTURE_2D,0,pt,V,De,Ce,Z,ge,A.data)}B.clearUpdateRanges(),o.pixelStorei(o.UNPACK_ROW_LENGTH,we),o.pixelStorei(o.UNPACK_SKIP_PIXELS,it),o.pixelStorei(o.UNPACK_SKIP_ROWS,Ye)}}function ne(B,A,Z){let ge=o.TEXTURE_2D;(A.isDataArrayTexture||A.isCompressedArrayTexture)&&(ge=o.TEXTURE_2D_ARRAY),A.isData3DTexture&&(ge=o.TEXTURE_3D);const ve=xe(B,A),de=A.source;n.bindTexture(ge,B.__webglTexture,o.TEXTURE0+Z);const Ge=a.get(de);if(de.version!==Ge.__version||ve===!0){n.activeTexture(o.TEXTURE0+Z);const we=Yt.getPrimaries(Yt.workingColorSpace),it=A.colorSpace===Fs?null:Yt.getPrimaries(A.colorSpace),Ye=A.colorSpace===Fs||we===it?o.NONE:o.BROWSER_DEFAULT_WEBGL;o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,A.flipY),o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),o.pixelStorei(o.UNPACK_ALIGNMENT,A.unpackAlignment),o.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,Ye);let Re=b(A.image,!1,r.maxTextureSize);Re=ct(A,Re);const Ae=l.convert(A.format,A.colorSpace),He=l.convert(A.type);let Pe=N(A.internalFormat,Ae,He,A.colorSpace,A.isVideoTexture);Q(ge,A);let Fe;const pt=A.mipmaps,V=A.isVideoTexture!==!0,De=Ge.__version===void 0||ve===!0,Ce=de.dataReady,Le=O(A,Re);if(A.isDepthTexture)Pe=C(A.format===No,A.type),De&&(V?n.texStorage2D(o.TEXTURE_2D,1,Pe,Re.width,Re.height):n.texImage2D(o.TEXTURE_2D,0,Pe,Re.width,Re.height,0,Ae,He,null));else if(A.isDataTexture)if(pt.length>0){V&&De&&n.texStorage2D(o.TEXTURE_2D,Le,Pe,pt[0].width,pt[0].height);for(let Ee=0,me=pt.length;Ee<me;Ee++)Fe=pt[Ee],V?Ce&&n.texSubImage2D(o.TEXTURE_2D,Ee,0,0,Fe.width,Fe.height,Ae,He,Fe.data):n.texImage2D(o.TEXTURE_2D,Ee,Pe,Fe.width,Fe.height,0,Ae,He,Fe.data);A.generateMipmaps=!1}else V?(De&&n.texStorage2D(o.TEXTURE_2D,Le,Pe,Re.width,Re.height),Ce&&Ne(A,Re,Ae,He)):n.texImage2D(o.TEXTURE_2D,0,Pe,Re.width,Re.height,0,Ae,He,Re.data);else if(A.isCompressedTexture)if(A.isCompressedArrayTexture){V&&De&&n.texStorage3D(o.TEXTURE_2D_ARRAY,Le,Pe,pt[0].width,pt[0].height,Re.depth);for(let Ee=0,me=pt.length;Ee<me;Ee++)if(Fe=pt[Ee],A.format!==Ja)if(Ae!==null)if(V){if(Ce)if(A.layerUpdates.size>0){const Xe=eM(Fe.width,Fe.height,A.format,A.type);for(const lt of A.layerUpdates){const Gt=Fe.data.subarray(lt*Xe/Fe.data.BYTES_PER_ELEMENT,(lt+1)*Xe/Fe.data.BYTES_PER_ELEMENT);n.compressedTexSubImage3D(o.TEXTURE_2D_ARRAY,Ee,0,0,lt,Fe.width,Fe.height,1,Ae,Gt)}A.clearLayerUpdates()}else n.compressedTexSubImage3D(o.TEXTURE_2D_ARRAY,Ee,0,0,0,Fe.width,Fe.height,Re.depth,Ae,Fe.data)}else n.compressedTexImage3D(o.TEXTURE_2D_ARRAY,Ee,Pe,Fe.width,Fe.height,Re.depth,0,Fe.data,0,0);else Mt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else V?Ce&&n.texSubImage3D(o.TEXTURE_2D_ARRAY,Ee,0,0,0,Fe.width,Fe.height,Re.depth,Ae,He,Fe.data):n.texImage3D(o.TEXTURE_2D_ARRAY,Ee,Pe,Fe.width,Fe.height,Re.depth,0,Ae,He,Fe.data)}else{V&&De&&n.texStorage2D(o.TEXTURE_2D,Le,Pe,pt[0].width,pt[0].height);for(let Ee=0,me=pt.length;Ee<me;Ee++)Fe=pt[Ee],A.format!==Ja?Ae!==null?V?Ce&&n.compressedTexSubImage2D(o.TEXTURE_2D,Ee,0,0,Fe.width,Fe.height,Ae,Fe.data):n.compressedTexImage2D(o.TEXTURE_2D,Ee,Pe,Fe.width,Fe.height,0,Fe.data):Mt("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):V?Ce&&n.texSubImage2D(o.TEXTURE_2D,Ee,0,0,Fe.width,Fe.height,Ae,He,Fe.data):n.texImage2D(o.TEXTURE_2D,Ee,Pe,Fe.width,Fe.height,0,Ae,He,Fe.data)}else if(A.isDataArrayTexture)if(V){if(De&&n.texStorage3D(o.TEXTURE_2D_ARRAY,Le,Pe,Re.width,Re.height,Re.depth),Ce)if(A.layerUpdates.size>0){const Ee=eM(Re.width,Re.height,A.format,A.type);for(const me of A.layerUpdates){const Xe=Re.data.subarray(me*Ee/Re.data.BYTES_PER_ELEMENT,(me+1)*Ee/Re.data.BYTES_PER_ELEMENT);n.texSubImage3D(o.TEXTURE_2D_ARRAY,0,0,0,me,Re.width,Re.height,1,Ae,He,Xe)}A.clearLayerUpdates()}else n.texSubImage3D(o.TEXTURE_2D_ARRAY,0,0,0,0,Re.width,Re.height,Re.depth,Ae,He,Re.data)}else n.texImage3D(o.TEXTURE_2D_ARRAY,0,Pe,Re.width,Re.height,Re.depth,0,Ae,He,Re.data);else if(A.isData3DTexture)V?(De&&n.texStorage3D(o.TEXTURE_3D,Le,Pe,Re.width,Re.height,Re.depth),Ce&&n.texSubImage3D(o.TEXTURE_3D,0,0,0,0,Re.width,Re.height,Re.depth,Ae,He,Re.data)):n.texImage3D(o.TEXTURE_3D,0,Pe,Re.width,Re.height,Re.depth,0,Ae,He,Re.data);else if(A.isFramebufferTexture){if(De)if(V)n.texStorage2D(o.TEXTURE_2D,Le,Pe,Re.width,Re.height);else{let Ee=Re.width,me=Re.height;for(let Xe=0;Xe<Le;Xe++)n.texImage2D(o.TEXTURE_2D,Xe,Pe,Ee,me,0,Ae,He,null),Ee>>=1,me>>=1}}else if(pt.length>0){if(V&&De){const Ee=We(pt[0]);n.texStorage2D(o.TEXTURE_2D,Le,Pe,Ee.width,Ee.height)}for(let Ee=0,me=pt.length;Ee<me;Ee++)Fe=pt[Ee],V?Ce&&n.texSubImage2D(o.TEXTURE_2D,Ee,0,0,Ae,He,Fe):n.texImage2D(o.TEXTURE_2D,Ee,Pe,Ae,He,Fe);A.generateMipmaps=!1}else if(V){if(De){const Ee=We(Re);n.texStorage2D(o.TEXTURE_2D,Le,Pe,Ee.width,Ee.height)}Ce&&n.texSubImage2D(o.TEXTURE_2D,0,0,0,Ae,He,Re)}else n.texImage2D(o.TEXTURE_2D,0,Pe,Ae,He,Re);y(A)&&S(ge),Ge.__version=de.version,A.onUpdate&&A.onUpdate(A)}B.__version=A.version}function _e(B,A,Z){if(A.image.length!==6)return;const ge=xe(B,A),ve=A.source;n.bindTexture(o.TEXTURE_CUBE_MAP,B.__webglTexture,o.TEXTURE0+Z);const de=a.get(ve);if(ve.version!==de.__version||ge===!0){n.activeTexture(o.TEXTURE0+Z);const Ge=Yt.getPrimaries(Yt.workingColorSpace),we=A.colorSpace===Fs?null:Yt.getPrimaries(A.colorSpace),it=A.colorSpace===Fs||Ge===we?o.NONE:o.BROWSER_DEFAULT_WEBGL;o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,A.flipY),o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),o.pixelStorei(o.UNPACK_ALIGNMENT,A.unpackAlignment),o.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,it);const Ye=A.isCompressedTexture||A.image[0].isCompressedTexture,Re=A.image[0]&&A.image[0].isDataTexture,Ae=[];for(let me=0;me<6;me++)!Ye&&!Re?Ae[me]=b(A.image[me],!0,r.maxCubemapSize):Ae[me]=Re?A.image[me].image:A.image[me],Ae[me]=ct(A,Ae[me]);const He=Ae[0],Pe=l.convert(A.format,A.colorSpace),Fe=l.convert(A.type),pt=N(A.internalFormat,Pe,Fe,A.colorSpace),V=A.isVideoTexture!==!0,De=de.__version===void 0||ge===!0,Ce=ve.dataReady;let Le=O(A,He);Q(o.TEXTURE_CUBE_MAP,A);let Ee;if(Ye){V&&De&&n.texStorage2D(o.TEXTURE_CUBE_MAP,Le,pt,He.width,He.height);for(let me=0;me<6;me++){Ee=Ae[me].mipmaps;for(let Xe=0;Xe<Ee.length;Xe++){const lt=Ee[Xe];A.format!==Ja?Pe!==null?V?Ce&&n.compressedTexSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+me,Xe,0,0,lt.width,lt.height,Pe,lt.data):n.compressedTexImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+me,Xe,pt,lt.width,lt.height,0,lt.data):Mt("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):V?Ce&&n.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+me,Xe,0,0,lt.width,lt.height,Pe,Fe,lt.data):n.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+me,Xe,pt,lt.width,lt.height,0,Pe,Fe,lt.data)}}}else{if(Ee=A.mipmaps,V&&De){Ee.length>0&&Le++;const me=We(Ae[0]);n.texStorage2D(o.TEXTURE_CUBE_MAP,Le,pt,me.width,me.height)}for(let me=0;me<6;me++)if(Re){V?Ce&&n.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+me,0,0,0,Ae[me].width,Ae[me].height,Pe,Fe,Ae[me].data):n.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+me,0,pt,Ae[me].width,Ae[me].height,0,Pe,Fe,Ae[me].data);for(let Xe=0;Xe<Ee.length;Xe++){const Gt=Ee[Xe].image[me].image;V?Ce&&n.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+me,Xe+1,0,0,Gt.width,Gt.height,Pe,Fe,Gt.data):n.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+me,Xe+1,pt,Gt.width,Gt.height,0,Pe,Fe,Gt.data)}}else{V?Ce&&n.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+me,0,0,0,Pe,Fe,Ae[me]):n.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+me,0,pt,Pe,Fe,Ae[me]);for(let Xe=0;Xe<Ee.length;Xe++){const lt=Ee[Xe];V?Ce&&n.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+me,Xe+1,0,0,Pe,Fe,lt.image[me]):n.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+me,Xe+1,pt,Pe,Fe,lt.image[me])}}}y(A)&&S(o.TEXTURE_CUBE_MAP),de.__version=ve.version,A.onUpdate&&A.onUpdate(A)}B.__version=A.version}function be(B,A,Z,ge,ve,de){const Ge=l.convert(Z.format,Z.colorSpace),we=l.convert(Z.type),it=N(Z.internalFormat,Ge,we,Z.colorSpace),Ye=a.get(A),Re=a.get(Z);if(Re.__renderTarget=A,!Ye.__hasExternalTextures){const Ae=Math.max(1,A.width>>de),He=Math.max(1,A.height>>de);ve===o.TEXTURE_3D||ve===o.TEXTURE_2D_ARRAY?n.texImage3D(ve,de,it,Ae,He,A.depth,0,Ge,we,null):n.texImage2D(ve,de,it,Ae,He,0,Ge,we,null)}n.bindFramebuffer(o.FRAMEBUFFER,B),Wt(A)?f.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,ge,ve,Re.__webglTexture,0,W(A)):(ve===o.TEXTURE_2D||ve>=o.TEXTURE_CUBE_MAP_POSITIVE_X&&ve<=o.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&o.framebufferTexture2D(o.FRAMEBUFFER,ge,ve,Re.__webglTexture,de),n.bindFramebuffer(o.FRAMEBUFFER,null)}function ze(B,A,Z){if(o.bindRenderbuffer(o.RENDERBUFFER,B),A.depthBuffer){const ge=A.depthTexture,ve=ge&&ge.isDepthTexture?ge.type:null,de=C(A.stencilBuffer,ve),Ge=A.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT;Wt(A)?f.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,W(A),de,A.width,A.height):Z?o.renderbufferStorageMultisample(o.RENDERBUFFER,W(A),de,A.width,A.height):o.renderbufferStorage(o.RENDERBUFFER,de,A.width,A.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,Ge,o.RENDERBUFFER,B)}else{const ge=A.textures;for(let ve=0;ve<ge.length;ve++){const de=ge[ve],Ge=l.convert(de.format,de.colorSpace),we=l.convert(de.type),it=N(de.internalFormat,Ge,we,de.colorSpace);Wt(A)?f.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,W(A),it,A.width,A.height):Z?o.renderbufferStorageMultisample(o.RENDERBUFFER,W(A),it,A.width,A.height):o.renderbufferStorage(o.RENDERBUFFER,it,A.width,A.height)}}o.bindRenderbuffer(o.RENDERBUFFER,null)}function tt(B,A,Z){const ge=A.isWebGLCubeRenderTarget===!0;if(n.bindFramebuffer(o.FRAMEBUFFER,B),!(A.depthTexture&&A.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const ve=a.get(A.depthTexture);if(ve.__renderTarget=A,(!ve.__webglTexture||A.depthTexture.image.width!==A.width||A.depthTexture.image.height!==A.height)&&(A.depthTexture.image.width=A.width,A.depthTexture.image.height=A.height,A.depthTexture.needsUpdate=!0),ge){if(ve.__webglInit===void 0&&(ve.__webglInit=!0,A.depthTexture.addEventListener("dispose",P)),ve.__webglTexture===void 0){ve.__webglTexture=o.createTexture(),n.bindTexture(o.TEXTURE_CUBE_MAP,ve.__webglTexture),Q(o.TEXTURE_CUBE_MAP,A.depthTexture);const Ye=l.convert(A.depthTexture.format),Re=l.convert(A.depthTexture.type);let Ae;A.depthTexture.format===ns?Ae=o.DEPTH_COMPONENT24:A.depthTexture.format===No&&(Ae=o.DEPTH24_STENCIL8);for(let He=0;He<6;He++)o.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+He,0,Ae,A.width,A.height,0,Ye,Re,null)}}else J(A.depthTexture,0);const de=ve.__webglTexture,Ge=W(A),we=ge?o.TEXTURE_CUBE_MAP_POSITIVE_X+Z:o.TEXTURE_2D,it=A.depthTexture.format===No?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT;if(A.depthTexture.format===ns)Wt(A)?f.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,it,we,de,0,Ge):o.framebufferTexture2D(o.FRAMEBUFFER,it,we,de,0);else if(A.depthTexture.format===No)Wt(A)?f.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,it,we,de,0,Ge):o.framebufferTexture2D(o.FRAMEBUFFER,it,we,de,0);else throw new Error("Unknown depthTexture format")}function Ke(B){const A=a.get(B),Z=B.isWebGLCubeRenderTarget===!0;if(A.__boundDepthTexture!==B.depthTexture){const ge=B.depthTexture;if(A.__depthDisposeCallback&&A.__depthDisposeCallback(),ge){const ve=()=>{delete A.__boundDepthTexture,delete A.__depthDisposeCallback,ge.removeEventListener("dispose",ve)};ge.addEventListener("dispose",ve),A.__depthDisposeCallback=ve}A.__boundDepthTexture=ge}if(B.depthTexture&&!A.__autoAllocateDepthBuffer)if(Z)for(let ge=0;ge<6;ge++)tt(A.__webglFramebuffer[ge],B,ge);else{const ge=B.texture.mipmaps;ge&&ge.length>0?tt(A.__webglFramebuffer[0],B,0):tt(A.__webglFramebuffer,B,0)}else if(Z){A.__webglDepthbuffer=[];for(let ge=0;ge<6;ge++)if(n.bindFramebuffer(o.FRAMEBUFFER,A.__webglFramebuffer[ge]),A.__webglDepthbuffer[ge]===void 0)A.__webglDepthbuffer[ge]=o.createRenderbuffer(),ze(A.__webglDepthbuffer[ge],B,!1);else{const ve=B.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,de=A.__webglDepthbuffer[ge];o.bindRenderbuffer(o.RENDERBUFFER,de),o.framebufferRenderbuffer(o.FRAMEBUFFER,ve,o.RENDERBUFFER,de)}}else{const ge=B.texture.mipmaps;if(ge&&ge.length>0?n.bindFramebuffer(o.FRAMEBUFFER,A.__webglFramebuffer[0]):n.bindFramebuffer(o.FRAMEBUFFER,A.__webglFramebuffer),A.__webglDepthbuffer===void 0)A.__webglDepthbuffer=o.createRenderbuffer(),ze(A.__webglDepthbuffer,B,!1);else{const ve=B.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,de=A.__webglDepthbuffer;o.bindRenderbuffer(o.RENDERBUFFER,de),o.framebufferRenderbuffer(o.FRAMEBUFFER,ve,o.RENDERBUFFER,de)}}n.bindFramebuffer(o.FRAMEBUFFER,null)}function Ut(B,A,Z){const ge=a.get(B);A!==void 0&&be(ge.__webglFramebuffer,B,B.texture,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,0),Z!==void 0&&Ke(B)}function qe(B){const A=B.texture,Z=a.get(B),ge=a.get(A);B.addEventListener("dispose",L);const ve=B.textures,de=B.isWebGLCubeRenderTarget===!0,Ge=ve.length>1;if(Ge||(ge.__webglTexture===void 0&&(ge.__webglTexture=o.createTexture()),ge.__version=A.version,c.memory.textures++),de){Z.__webglFramebuffer=[];for(let we=0;we<6;we++)if(A.mipmaps&&A.mipmaps.length>0){Z.__webglFramebuffer[we]=[];for(let it=0;it<A.mipmaps.length;it++)Z.__webglFramebuffer[we][it]=o.createFramebuffer()}else Z.__webglFramebuffer[we]=o.createFramebuffer()}else{if(A.mipmaps&&A.mipmaps.length>0){Z.__webglFramebuffer=[];for(let we=0;we<A.mipmaps.length;we++)Z.__webglFramebuffer[we]=o.createFramebuffer()}else Z.__webglFramebuffer=o.createFramebuffer();if(Ge)for(let we=0,it=ve.length;we<it;we++){const Ye=a.get(ve[we]);Ye.__webglTexture===void 0&&(Ye.__webglTexture=o.createTexture(),c.memory.textures++)}if(B.samples>0&&Wt(B)===!1){Z.__webglMultisampledFramebuffer=o.createFramebuffer(),Z.__webglColorRenderbuffer=[],n.bindFramebuffer(o.FRAMEBUFFER,Z.__webglMultisampledFramebuffer);for(let we=0;we<ve.length;we++){const it=ve[we];Z.__webglColorRenderbuffer[we]=o.createRenderbuffer(),o.bindRenderbuffer(o.RENDERBUFFER,Z.__webglColorRenderbuffer[we]);const Ye=l.convert(it.format,it.colorSpace),Re=l.convert(it.type),Ae=N(it.internalFormat,Ye,Re,it.colorSpace,B.isXRRenderTarget===!0),He=W(B);o.renderbufferStorageMultisample(o.RENDERBUFFER,He,Ae,B.width,B.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+we,o.RENDERBUFFER,Z.__webglColorRenderbuffer[we])}o.bindRenderbuffer(o.RENDERBUFFER,null),B.depthBuffer&&(Z.__webglDepthRenderbuffer=o.createRenderbuffer(),ze(Z.__webglDepthRenderbuffer,B,!0)),n.bindFramebuffer(o.FRAMEBUFFER,null)}}if(de){n.bindTexture(o.TEXTURE_CUBE_MAP,ge.__webglTexture),Q(o.TEXTURE_CUBE_MAP,A);for(let we=0;we<6;we++)if(A.mipmaps&&A.mipmaps.length>0)for(let it=0;it<A.mipmaps.length;it++)be(Z.__webglFramebuffer[we][it],B,A,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+we,it);else be(Z.__webglFramebuffer[we],B,A,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+we,0);y(A)&&S(o.TEXTURE_CUBE_MAP),n.unbindTexture()}else if(Ge){for(let we=0,it=ve.length;we<it;we++){const Ye=ve[we],Re=a.get(Ye);let Ae=o.TEXTURE_2D;(B.isWebGL3DRenderTarget||B.isWebGLArrayRenderTarget)&&(Ae=B.isWebGL3DRenderTarget?o.TEXTURE_3D:o.TEXTURE_2D_ARRAY),n.bindTexture(Ae,Re.__webglTexture),Q(Ae,Ye),be(Z.__webglFramebuffer,B,Ye,o.COLOR_ATTACHMENT0+we,Ae,0),y(Ye)&&S(Ae)}n.unbindTexture()}else{let we=o.TEXTURE_2D;if((B.isWebGL3DRenderTarget||B.isWebGLArrayRenderTarget)&&(we=B.isWebGL3DRenderTarget?o.TEXTURE_3D:o.TEXTURE_2D_ARRAY),n.bindTexture(we,ge.__webglTexture),Q(we,A),A.mipmaps&&A.mipmaps.length>0)for(let it=0;it<A.mipmaps.length;it++)be(Z.__webglFramebuffer[it],B,A,o.COLOR_ATTACHMENT0,we,it);else be(Z.__webglFramebuffer,B,A,o.COLOR_ATTACHMENT0,we,0);y(A)&&S(we),n.unbindTexture()}B.depthBuffer&&Ke(B)}function rt(B){const A=B.textures;for(let Z=0,ge=A.length;Z<ge;Z++){const ve=A[Z];if(y(ve)){const de=R(B),Ge=a.get(ve).__webglTexture;n.bindTexture(de,Ge),S(de),n.unbindTexture()}}}const _t=[],st=[];function le(B){if(B.samples>0){if(Wt(B)===!1){const A=B.textures,Z=B.width,ge=B.height;let ve=o.COLOR_BUFFER_BIT;const de=B.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,Ge=a.get(B),we=A.length>1;if(we)for(let Ye=0;Ye<A.length;Ye++)n.bindFramebuffer(o.FRAMEBUFFER,Ge.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Ye,o.RENDERBUFFER,null),n.bindFramebuffer(o.FRAMEBUFFER,Ge.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+Ye,o.TEXTURE_2D,null,0);n.bindFramebuffer(o.READ_FRAMEBUFFER,Ge.__webglMultisampledFramebuffer);const it=B.texture.mipmaps;it&&it.length>0?n.bindFramebuffer(o.DRAW_FRAMEBUFFER,Ge.__webglFramebuffer[0]):n.bindFramebuffer(o.DRAW_FRAMEBUFFER,Ge.__webglFramebuffer);for(let Ye=0;Ye<A.length;Ye++){if(B.resolveDepthBuffer&&(B.depthBuffer&&(ve|=o.DEPTH_BUFFER_BIT),B.stencilBuffer&&B.resolveStencilBuffer&&(ve|=o.STENCIL_BUFFER_BIT)),we){o.framebufferRenderbuffer(o.READ_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.RENDERBUFFER,Ge.__webglColorRenderbuffer[Ye]);const Re=a.get(A[Ye]).__webglTexture;o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,Re,0)}o.blitFramebuffer(0,0,Z,ge,0,0,Z,ge,ve,o.NEAREST),p===!0&&(_t.length=0,st.length=0,_t.push(o.COLOR_ATTACHMENT0+Ye),B.depthBuffer&&B.resolveDepthBuffer===!1&&(_t.push(de),st.push(de),o.invalidateFramebuffer(o.DRAW_FRAMEBUFFER,st)),o.invalidateFramebuffer(o.READ_FRAMEBUFFER,_t))}if(n.bindFramebuffer(o.READ_FRAMEBUFFER,null),n.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),we)for(let Ye=0;Ye<A.length;Ye++){n.bindFramebuffer(o.FRAMEBUFFER,Ge.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Ye,o.RENDERBUFFER,Ge.__webglColorRenderbuffer[Ye]);const Re=a.get(A[Ye]).__webglTexture;n.bindFramebuffer(o.FRAMEBUFFER,Ge.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+Ye,o.TEXTURE_2D,Re,0)}n.bindFramebuffer(o.DRAW_FRAMEBUFFER,Ge.__webglMultisampledFramebuffer)}else if(B.depthBuffer&&B.resolveDepthBuffer===!1&&p){const A=B.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT;o.invalidateFramebuffer(o.DRAW_FRAMEBUFFER,[A])}}}function W(B){return Math.min(r.maxSamples,B.samples)}function Wt(B){const A=a.get(B);return B.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&A.__useRenderToTexture!==!1}function bt(B){const A=c.render.frame;_.get(B)!==A&&(_.set(B,A),B.update())}function ct(B,A){const Z=B.colorSpace,ge=B.format,ve=B.type;return B.isCompressedTexture===!0||B.isVideoTexture===!0||Z!==iu&&Z!==Fs&&(Yt.getTransfer(Z)===an?(ge!==Ja||ve!==za)&&Mt("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Qt("WebGLTextures: Unsupported texture color space:",Z)),A}function We(B){return typeof HTMLImageElement<"u"&&B instanceof HTMLImageElement?(d.width=B.naturalWidth||B.width,d.height=B.naturalHeight||B.height):typeof VideoFrame<"u"&&B instanceof VideoFrame?(d.width=B.displayWidth,d.height=B.displayHeight):(d.width=B.width,d.height=B.height),d}this.allocateTextureUnit=$,this.resetTextureUnits=k,this.setTexture2D=J,this.setTexture2DArray=z,this.setTexture3D=I,this.setTextureCube=ie,this.rebindTextures=Ut,this.setupRenderTarget=qe,this.updateRenderTargetMipmap=rt,this.updateMultisampleRenderTarget=le,this.setupDepthRenderbuffer=Ke,this.setupFrameBufferTexture=be,this.useMultisampledRTT=Wt,this.isReversedDepthBuffer=function(){return n.buffers.depth.getReversed()}}function LD(o,e){function n(a,r=Fs){let l;const c=Yt.getTransfer(r);if(a===za)return o.UNSIGNED_BYTE;if(a===ig)return o.UNSIGNED_SHORT_4_4_4_4;if(a===ag)return o.UNSIGNED_SHORT_5_5_5_1;if(a===M1)return o.UNSIGNED_INT_5_9_9_9_REV;if(a===b1)return o.UNSIGNED_INT_10F_11F_11F_REV;if(a===y1)return o.BYTE;if(a===S1)return o.SHORT;if(a===Fc)return o.UNSIGNED_SHORT;if(a===ng)return o.INT;if(a===Sr)return o.UNSIGNED_INT;if(a===dr)return o.FLOAT;if(a===ts)return o.HALF_FLOAT;if(a===E1)return o.ALPHA;if(a===T1)return o.RGB;if(a===Ja)return o.RGBA;if(a===ns)return o.DEPTH_COMPONENT;if(a===No)return o.DEPTH_STENCIL;if(a===A1)return o.RED;if(a===rg)return o.RED_INTEGER;if(a===nu)return o.RG;if(a===sg)return o.RG_INTEGER;if(a===og)return o.RGBA_INTEGER;if(a===Zh||a===Kh||a===Qh||a===Jh)if(c===an)if(l=e.get("WEBGL_compressed_texture_s3tc_srgb"),l!==null){if(a===Zh)return l.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(a===Kh)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(a===Qh)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(a===Jh)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(l=e.get("WEBGL_compressed_texture_s3tc"),l!==null){if(a===Zh)return l.COMPRESSED_RGB_S3TC_DXT1_EXT;if(a===Kh)return l.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(a===Qh)return l.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(a===Jh)return l.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(a===j_||a===Z_||a===K_||a===Q_)if(l=e.get("WEBGL_compressed_texture_pvrtc"),l!==null){if(a===j_)return l.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(a===Z_)return l.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(a===K_)return l.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(a===Q_)return l.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(a===J_||a===$_||a===e0||a===t0||a===n0||a===i0||a===a0)if(l=e.get("WEBGL_compressed_texture_etc"),l!==null){if(a===J_||a===$_)return c===an?l.COMPRESSED_SRGB8_ETC2:l.COMPRESSED_RGB8_ETC2;if(a===e0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:l.COMPRESSED_RGBA8_ETC2_EAC;if(a===t0)return l.COMPRESSED_R11_EAC;if(a===n0)return l.COMPRESSED_SIGNED_R11_EAC;if(a===i0)return l.COMPRESSED_RG11_EAC;if(a===a0)return l.COMPRESSED_SIGNED_RG11_EAC}else return null;if(a===r0||a===s0||a===o0||a===l0||a===u0||a===c0||a===f0||a===h0||a===d0||a===p0||a===m0||a===_0||a===g0||a===v0)if(l=e.get("WEBGL_compressed_texture_astc"),l!==null){if(a===r0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:l.COMPRESSED_RGBA_ASTC_4x4_KHR;if(a===s0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:l.COMPRESSED_RGBA_ASTC_5x4_KHR;if(a===o0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:l.COMPRESSED_RGBA_ASTC_5x5_KHR;if(a===l0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:l.COMPRESSED_RGBA_ASTC_6x5_KHR;if(a===u0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:l.COMPRESSED_RGBA_ASTC_6x6_KHR;if(a===c0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:l.COMPRESSED_RGBA_ASTC_8x5_KHR;if(a===f0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:l.COMPRESSED_RGBA_ASTC_8x6_KHR;if(a===h0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:l.COMPRESSED_RGBA_ASTC_8x8_KHR;if(a===d0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:l.COMPRESSED_RGBA_ASTC_10x5_KHR;if(a===p0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:l.COMPRESSED_RGBA_ASTC_10x6_KHR;if(a===m0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:l.COMPRESSED_RGBA_ASTC_10x8_KHR;if(a===_0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:l.COMPRESSED_RGBA_ASTC_10x10_KHR;if(a===g0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:l.COMPRESSED_RGBA_ASTC_12x10_KHR;if(a===v0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:l.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(a===x0||a===y0||a===S0)if(l=e.get("EXT_texture_compression_bptc"),l!==null){if(a===x0)return c===an?l.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:l.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(a===y0)return l.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(a===S0)return l.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(a===M0||a===b0||a===E0||a===T0)if(l=e.get("EXT_texture_compression_rgtc"),l!==null){if(a===M0)return l.COMPRESSED_RED_RGTC1_EXT;if(a===b0)return l.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(a===E0)return l.COMPRESSED_RED_GREEN_RGTC2_EXT;if(a===T0)return l.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return a===Ic?o.UNSIGNED_INT_24_8:o[a]!==void 0?o[a]:null}return{convert:n}}const OD=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,PD=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class zD{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,n){if(this.texture===null){const a=new z1(e.texture);(e.depthNear!==n.depthNear||e.depthFar!==n.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=a}}getMesh(e){if(this.texture!==null&&this.mesh===null){const n=e.cameras[0].viewport,a=new Ga({vertexShader:OD,fragmentShader:PD,uniforms:{depthColor:{value:this.texture},depthWidth:{value:n.z},depthHeight:{value:n.w}}});this.mesh=new $a(new Rd(20,20),a)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class FD extends hu{constructor(e,n){super();const a=this;let r=null,l=1,c=null,f="local-floor",p=1,d=null,_=null,v=null,g=null,x=null,M=null;const b=typeof XRWebGLBinding<"u",y=new zD,S={},R=n.getContextAttributes();let N=null,C=null;const O=[],P=[],L=new fn;let T=null;const w=new La;w.viewport=new Pn;const q=new La;q.viewport=new Pn;const G=[w,q],k=new ZR;let $=null,te=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(ne){let _e=O[ne];return _e===void 0&&(_e=new $m,O[ne]=_e),_e.getTargetRaySpace()},this.getControllerGrip=function(ne){let _e=O[ne];return _e===void 0&&(_e=new $m,O[ne]=_e),_e.getGripSpace()},this.getHand=function(ne){let _e=O[ne];return _e===void 0&&(_e=new $m,O[ne]=_e),_e.getHandSpace()};function J(ne){const _e=P.indexOf(ne.inputSource);if(_e===-1)return;const be=O[_e];be!==void 0&&(be.update(ne.inputSource,ne.frame,d||c),be.dispatchEvent({type:ne.type,data:ne.inputSource}))}function z(){r.removeEventListener("select",J),r.removeEventListener("selectstart",J),r.removeEventListener("selectend",J),r.removeEventListener("squeeze",J),r.removeEventListener("squeezestart",J),r.removeEventListener("squeezeend",J),r.removeEventListener("end",z),r.removeEventListener("inputsourceschange",I);for(let ne=0;ne<O.length;ne++){const _e=P[ne];_e!==null&&(P[ne]=null,O[ne].disconnect(_e))}$=null,te=null,y.reset();for(const ne in S)delete S[ne];e.setRenderTarget(N),x=null,g=null,v=null,r=null,C=null,Ne.stop(),a.isPresenting=!1,e.setPixelRatio(T),e.setSize(L.width,L.height,!1),a.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(ne){l=ne,a.isPresenting===!0&&Mt("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(ne){f=ne,a.isPresenting===!0&&Mt("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return d||c},this.setReferenceSpace=function(ne){d=ne},this.getBaseLayer=function(){return g!==null?g:x},this.getBinding=function(){return v===null&&b&&(v=new XRWebGLBinding(r,n)),v},this.getFrame=function(){return M},this.getSession=function(){return r},this.setSession=async function(ne){if(r=ne,r!==null){if(N=e.getRenderTarget(),r.addEventListener("select",J),r.addEventListener("selectstart",J),r.addEventListener("selectend",J),r.addEventListener("squeeze",J),r.addEventListener("squeezestart",J),r.addEventListener("squeezeend",J),r.addEventListener("end",z),r.addEventListener("inputsourceschange",I),R.xrCompatible!==!0&&await n.makeXRCompatible(),T=e.getPixelRatio(),e.getSize(L),b&&"createProjectionLayer"in XRWebGLBinding.prototype){let be=null,ze=null,tt=null;R.depth&&(tt=R.stencil?n.DEPTH24_STENCIL8:n.DEPTH_COMPONENT24,be=R.stencil?No:ns,ze=R.stencil?Ic:Sr);const Ke={colorFormat:n.RGBA8,depthFormat:tt,scaleFactor:l};v=this.getBinding(),g=v.createProjectionLayer(Ke),r.updateRenderState({layers:[g]}),e.setPixelRatio(1),e.setSize(g.textureWidth,g.textureHeight,!1),C=new vr(g.textureWidth,g.textureHeight,{format:Ja,type:za,depthTexture:new Bc(g.textureWidth,g.textureHeight,ze,void 0,void 0,void 0,void 0,void 0,void 0,be),stencilBuffer:R.stencil,colorSpace:e.outputColorSpace,samples:R.antialias?4:0,resolveDepthBuffer:g.ignoreDepthValues===!1,resolveStencilBuffer:g.ignoreDepthValues===!1})}else{const be={antialias:R.antialias,alpha:!0,depth:R.depth,stencil:R.stencil,framebufferScaleFactor:l};x=new XRWebGLLayer(r,n,be),r.updateRenderState({baseLayer:x}),e.setPixelRatio(1),e.setSize(x.framebufferWidth,x.framebufferHeight,!1),C=new vr(x.framebufferWidth,x.framebufferHeight,{format:Ja,type:za,colorSpace:e.outputColorSpace,stencilBuffer:R.stencil,resolveDepthBuffer:x.ignoreDepthValues===!1,resolveStencilBuffer:x.ignoreDepthValues===!1})}C.isXRRenderTarget=!0,this.setFoveation(p),d=null,c=await r.requestReferenceSpace(f),Ne.setContext(r),Ne.start(),a.isPresenting=!0,a.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return y.getDepthTexture()};function I(ne){for(let _e=0;_e<ne.removed.length;_e++){const be=ne.removed[_e],ze=P.indexOf(be);ze>=0&&(P[ze]=null,O[ze].disconnect(be))}for(let _e=0;_e<ne.added.length;_e++){const be=ne.added[_e];let ze=P.indexOf(be);if(ze===-1){for(let Ke=0;Ke<O.length;Ke++)if(Ke>=P.length){P.push(be),ze=Ke;break}else if(P[Ke]===null){P[Ke]=be,ze=Ke;break}if(ze===-1)break}const tt=O[ze];tt&&tt.connect(be)}}const ie=new fe,he=new fe;function H(ne,_e,be){ie.setFromMatrixPosition(_e.matrixWorld),he.setFromMatrixPosition(be.matrixWorld);const ze=ie.distanceTo(he),tt=_e.projectionMatrix.elements,Ke=be.projectionMatrix.elements,Ut=tt[14]/(tt[10]-1),qe=tt[14]/(tt[10]+1),rt=(tt[9]+1)/tt[5],_t=(tt[9]-1)/tt[5],st=(tt[8]-1)/tt[0],le=(Ke[8]+1)/Ke[0],W=Ut*st,Wt=Ut*le,bt=ze/(-st+le),ct=bt*-st;if(_e.matrixWorld.decompose(ne.position,ne.quaternion,ne.scale),ne.translateX(ct),ne.translateZ(bt),ne.matrixWorld.compose(ne.position,ne.quaternion,ne.scale),ne.matrixWorldInverse.copy(ne.matrixWorld).invert(),tt[10]===-1)ne.projectionMatrix.copy(_e.projectionMatrix),ne.projectionMatrixInverse.copy(_e.projectionMatrixInverse);else{const We=Ut+bt,B=qe+bt,A=W-ct,Z=Wt+(ze-ct),ge=rt*qe/B*We,ve=_t*qe/B*We;ne.projectionMatrix.makePerspective(A,Z,ge,ve,We,B),ne.projectionMatrixInverse.copy(ne.projectionMatrix).invert()}}function F(ne,_e){_e===null?ne.matrixWorld.copy(ne.matrix):ne.matrixWorld.multiplyMatrices(_e.matrixWorld,ne.matrix),ne.matrixWorldInverse.copy(ne.matrixWorld).invert()}this.updateCamera=function(ne){if(r===null)return;let _e=ne.near,be=ne.far;y.texture!==null&&(y.depthNear>0&&(_e=y.depthNear),y.depthFar>0&&(be=y.depthFar)),k.near=q.near=w.near=_e,k.far=q.far=w.far=be,($!==k.near||te!==k.far)&&(r.updateRenderState({depthNear:k.near,depthFar:k.far}),$=k.near,te=k.far),k.layers.mask=ne.layers.mask|6,w.layers.mask=k.layers.mask&-5,q.layers.mask=k.layers.mask&-3;const ze=ne.parent,tt=k.cameras;F(k,ze);for(let Ke=0;Ke<tt.length;Ke++)F(tt[Ke],ze);tt.length===2?H(k,w,q):k.projectionMatrix.copy(w.projectionMatrix),Q(ne,k,ze)};function Q(ne,_e,be){be===null?ne.matrix.copy(_e.matrixWorld):(ne.matrix.copy(be.matrixWorld),ne.matrix.invert(),ne.matrix.multiply(_e.matrixWorld)),ne.matrix.decompose(ne.position,ne.quaternion,ne.scale),ne.updateMatrixWorld(!0),ne.projectionMatrix.copy(_e.projectionMatrix),ne.projectionMatrixInverse.copy(_e.projectionMatrixInverse),ne.isPerspectiveCamera&&(ne.fov=A0*2*Math.atan(1/ne.projectionMatrix.elements[5]),ne.zoom=1)}this.getCamera=function(){return k},this.getFoveation=function(){if(!(g===null&&x===null))return p},this.setFoveation=function(ne){p=ne,g!==null&&(g.fixedFoveation=ne),x!==null&&x.fixedFoveation!==void 0&&(x.fixedFoveation=ne)},this.hasDepthSensing=function(){return y.texture!==null},this.getDepthSensingMesh=function(){return y.getMesh(k)},this.getCameraTexture=function(ne){return S[ne]};let xe=null;function Te(ne,_e){if(_=_e.getViewerPose(d||c),M=_e,_!==null){const be=_.views;x!==null&&(e.setRenderTargetFramebuffer(C,x.framebuffer),e.setRenderTarget(C));let ze=!1;be.length!==k.cameras.length&&(k.cameras.length=0,ze=!0);for(let qe=0;qe<be.length;qe++){const rt=be[qe];let _t=null;if(x!==null)_t=x.getViewport(rt);else{const le=v.getViewSubImage(g,rt);_t=le.viewport,qe===0&&(e.setRenderTargetTextures(C,le.colorTexture,le.depthStencilTexture),e.setRenderTarget(C))}let st=G[qe];st===void 0&&(st=new La,st.layers.enable(qe),st.viewport=new Pn,G[qe]=st),st.matrix.fromArray(rt.transform.matrix),st.matrix.decompose(st.position,st.quaternion,st.scale),st.projectionMatrix.fromArray(rt.projectionMatrix),st.projectionMatrixInverse.copy(st.projectionMatrix).invert(),st.viewport.set(_t.x,_t.y,_t.width,_t.height),qe===0&&(k.matrix.copy(st.matrix),k.matrix.decompose(k.position,k.quaternion,k.scale)),ze===!0&&k.cameras.push(st)}const tt=r.enabledFeatures;if(tt&&tt.includes("depth-sensing")&&r.depthUsage=="gpu-optimized"&&b){v=a.getBinding();const qe=v.getDepthInformation(be[0]);qe&&qe.isValid&&qe.texture&&y.init(qe,r.renderState)}if(tt&&tt.includes("camera-access")&&b){e.state.unbindTexture(),v=a.getBinding();for(let qe=0;qe<be.length;qe++){const rt=be[qe].camera;if(rt){let _t=S[rt];_t||(_t=new z1,S[rt]=_t);const st=v.getCameraImage(rt);_t.sourceTexture=st}}}}for(let be=0;be<O.length;be++){const ze=P[be],tt=O[be];ze!==null&&tt!==void 0&&tt.update(ze,_e,d||c)}xe&&xe(ne,_e),_e.detectedPlanes&&a.dispatchEvent({type:"planesdetected",data:_e}),M=null}const Ne=new H1;Ne.setAnimationLoop(Te),this.setAnimationLoop=function(ne){xe=ne},this.dispose=function(){}}}const So=new is,ID=new Fn;function BD(o,e){function n(y,S){y.matrixAutoUpdate===!0&&y.updateMatrix(),S.value.copy(y.matrix)}function a(y,S){S.color.getRGB(y.fogColor.value,F1(o)),S.isFog?(y.fogNear.value=S.near,y.fogFar.value=S.far):S.isFogExp2&&(y.fogDensity.value=S.density)}function r(y,S,R,N,C){S.isMeshBasicMaterial?l(y,S):S.isMeshLambertMaterial?(l(y,S),S.envMap&&(y.envMapIntensity.value=S.envMapIntensity)):S.isMeshToonMaterial?(l(y,S),v(y,S)):S.isMeshPhongMaterial?(l(y,S),_(y,S),S.envMap&&(y.envMapIntensity.value=S.envMapIntensity)):S.isMeshStandardMaterial?(l(y,S),g(y,S),S.isMeshPhysicalMaterial&&x(y,S,C)):S.isMeshMatcapMaterial?(l(y,S),M(y,S)):S.isMeshDepthMaterial?l(y,S):S.isMeshDistanceMaterial?(l(y,S),b(y,S)):S.isMeshNormalMaterial?l(y,S):S.isLineBasicMaterial?(c(y,S),S.isLineDashedMaterial&&f(y,S)):S.isPointsMaterial?p(y,S,R,N):S.isSpriteMaterial?d(y,S):S.isShadowMaterial?(y.color.value.copy(S.color),y.opacity.value=S.opacity):S.isShaderMaterial&&(S.uniformsNeedUpdate=!1)}function l(y,S){y.opacity.value=S.opacity,S.color&&y.diffuse.value.copy(S.color),S.emissive&&y.emissive.value.copy(S.emissive).multiplyScalar(S.emissiveIntensity),S.map&&(y.map.value=S.map,n(S.map,y.mapTransform)),S.alphaMap&&(y.alphaMap.value=S.alphaMap,n(S.alphaMap,y.alphaMapTransform)),S.bumpMap&&(y.bumpMap.value=S.bumpMap,n(S.bumpMap,y.bumpMapTransform),y.bumpScale.value=S.bumpScale,S.side===Yi&&(y.bumpScale.value*=-1)),S.normalMap&&(y.normalMap.value=S.normalMap,n(S.normalMap,y.normalMapTransform),y.normalScale.value.copy(S.normalScale),S.side===Yi&&y.normalScale.value.negate()),S.displacementMap&&(y.displacementMap.value=S.displacementMap,n(S.displacementMap,y.displacementMapTransform),y.displacementScale.value=S.displacementScale,y.displacementBias.value=S.displacementBias),S.emissiveMap&&(y.emissiveMap.value=S.emissiveMap,n(S.emissiveMap,y.emissiveMapTransform)),S.specularMap&&(y.specularMap.value=S.specularMap,n(S.specularMap,y.specularMapTransform)),S.alphaTest>0&&(y.alphaTest.value=S.alphaTest);const R=e.get(S),N=R.envMap,C=R.envMapRotation;N&&(y.envMap.value=N,So.copy(C),So.x*=-1,So.y*=-1,So.z*=-1,N.isCubeTexture&&N.isRenderTargetTexture===!1&&(So.y*=-1,So.z*=-1),y.envMapRotation.value.setFromMatrix4(ID.makeRotationFromEuler(So)),y.flipEnvMap.value=N.isCubeTexture&&N.isRenderTargetTexture===!1?-1:1,y.reflectivity.value=S.reflectivity,y.ior.value=S.ior,y.refractionRatio.value=S.refractionRatio),S.lightMap&&(y.lightMap.value=S.lightMap,y.lightMapIntensity.value=S.lightMapIntensity,n(S.lightMap,y.lightMapTransform)),S.aoMap&&(y.aoMap.value=S.aoMap,y.aoMapIntensity.value=S.aoMapIntensity,n(S.aoMap,y.aoMapTransform))}function c(y,S){y.diffuse.value.copy(S.color),y.opacity.value=S.opacity,S.map&&(y.map.value=S.map,n(S.map,y.mapTransform))}function f(y,S){y.dashSize.value=S.dashSize,y.totalSize.value=S.dashSize+S.gapSize,y.scale.value=S.scale}function p(y,S,R,N){y.diffuse.value.copy(S.color),y.opacity.value=S.opacity,y.size.value=S.size*R,y.scale.value=N*.5,S.map&&(y.map.value=S.map,n(S.map,y.uvTransform)),S.alphaMap&&(y.alphaMap.value=S.alphaMap,n(S.alphaMap,y.alphaMapTransform)),S.alphaTest>0&&(y.alphaTest.value=S.alphaTest)}function d(y,S){y.diffuse.value.copy(S.color),y.opacity.value=S.opacity,y.rotation.value=S.rotation,S.map&&(y.map.value=S.map,n(S.map,y.mapTransform)),S.alphaMap&&(y.alphaMap.value=S.alphaMap,n(S.alphaMap,y.alphaMapTransform)),S.alphaTest>0&&(y.alphaTest.value=S.alphaTest)}function _(y,S){y.specular.value.copy(S.specular),y.shininess.value=Math.max(S.shininess,1e-4)}function v(y,S){S.gradientMap&&(y.gradientMap.value=S.gradientMap)}function g(y,S){y.metalness.value=S.metalness,S.metalnessMap&&(y.metalnessMap.value=S.metalnessMap,n(S.metalnessMap,y.metalnessMapTransform)),y.roughness.value=S.roughness,S.roughnessMap&&(y.roughnessMap.value=S.roughnessMap,n(S.roughnessMap,y.roughnessMapTransform)),S.envMap&&(y.envMapIntensity.value=S.envMapIntensity)}function x(y,S,R){y.ior.value=S.ior,S.sheen>0&&(y.sheenColor.value.copy(S.sheenColor).multiplyScalar(S.sheen),y.sheenRoughness.value=S.sheenRoughness,S.sheenColorMap&&(y.sheenColorMap.value=S.sheenColorMap,n(S.sheenColorMap,y.sheenColorMapTransform)),S.sheenRoughnessMap&&(y.sheenRoughnessMap.value=S.sheenRoughnessMap,n(S.sheenRoughnessMap,y.sheenRoughnessMapTransform))),S.clearcoat>0&&(y.clearcoat.value=S.clearcoat,y.clearcoatRoughness.value=S.clearcoatRoughness,S.clearcoatMap&&(y.clearcoatMap.value=S.clearcoatMap,n(S.clearcoatMap,y.clearcoatMapTransform)),S.clearcoatRoughnessMap&&(y.clearcoatRoughnessMap.value=S.clearcoatRoughnessMap,n(S.clearcoatRoughnessMap,y.clearcoatRoughnessMapTransform)),S.clearcoatNormalMap&&(y.clearcoatNormalMap.value=S.clearcoatNormalMap,n(S.clearcoatNormalMap,y.clearcoatNormalMapTransform),y.clearcoatNormalScale.value.copy(S.clearcoatNormalScale),S.side===Yi&&y.clearcoatNormalScale.value.negate())),S.dispersion>0&&(y.dispersion.value=S.dispersion),S.iridescence>0&&(y.iridescence.value=S.iridescence,y.iridescenceIOR.value=S.iridescenceIOR,y.iridescenceThicknessMinimum.value=S.iridescenceThicknessRange[0],y.iridescenceThicknessMaximum.value=S.iridescenceThicknessRange[1],S.iridescenceMap&&(y.iridescenceMap.value=S.iridescenceMap,n(S.iridescenceMap,y.iridescenceMapTransform)),S.iridescenceThicknessMap&&(y.iridescenceThicknessMap.value=S.iridescenceThicknessMap,n(S.iridescenceThicknessMap,y.iridescenceThicknessMapTransform))),S.transmission>0&&(y.transmission.value=S.transmission,y.transmissionSamplerMap.value=R.texture,y.transmissionSamplerSize.value.set(R.width,R.height),S.transmissionMap&&(y.transmissionMap.value=S.transmissionMap,n(S.transmissionMap,y.transmissionMapTransform)),y.thickness.value=S.thickness,S.thicknessMap&&(y.thicknessMap.value=S.thicknessMap,n(S.thicknessMap,y.thicknessMapTransform)),y.attenuationDistance.value=S.attenuationDistance,y.attenuationColor.value.copy(S.attenuationColor)),S.anisotropy>0&&(y.anisotropyVector.value.set(S.anisotropy*Math.cos(S.anisotropyRotation),S.anisotropy*Math.sin(S.anisotropyRotation)),S.anisotropyMap&&(y.anisotropyMap.value=S.anisotropyMap,n(S.anisotropyMap,y.anisotropyMapTransform))),y.specularIntensity.value=S.specularIntensity,y.specularColor.value.copy(S.specularColor),S.specularColorMap&&(y.specularColorMap.value=S.specularColorMap,n(S.specularColorMap,y.specularColorMapTransform)),S.specularIntensityMap&&(y.specularIntensityMap.value=S.specularIntensityMap,n(S.specularIntensityMap,y.specularIntensityMapTransform))}function M(y,S){S.matcap&&(y.matcap.value=S.matcap)}function b(y,S){const R=e.get(S).light;y.referencePosition.value.setFromMatrixPosition(R.matrixWorld),y.nearDistance.value=R.shadow.camera.near,y.farDistance.value=R.shadow.camera.far}return{refreshFogUniforms:a,refreshMaterialUniforms:r}}function HD(o,e,n,a){let r={},l={},c=[];const f=o.getParameter(o.MAX_UNIFORM_BUFFER_BINDINGS);function p(R,N){const C=N.program;a.uniformBlockBinding(R,C)}function d(R,N){let C=r[R.id];C===void 0&&(M(R),C=_(R),r[R.id]=C,R.addEventListener("dispose",y));const O=N.program;a.updateUBOMapping(R,O);const P=e.render.frame;l[R.id]!==P&&(g(R),l[R.id]=P)}function _(R){const N=v();R.__bindingPointIndex=N;const C=o.createBuffer(),O=R.__size,P=R.usage;return o.bindBuffer(o.UNIFORM_BUFFER,C),o.bufferData(o.UNIFORM_BUFFER,O,P),o.bindBuffer(o.UNIFORM_BUFFER,null),o.bindBufferBase(o.UNIFORM_BUFFER,N,C),C}function v(){for(let R=0;R<f;R++)if(c.indexOf(R)===-1)return c.push(R),R;return Qt("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function g(R){const N=r[R.id],C=R.uniforms,O=R.__cache;o.bindBuffer(o.UNIFORM_BUFFER,N);for(let P=0,L=C.length;P<L;P++){const T=Array.isArray(C[P])?C[P]:[C[P]];for(let w=0,q=T.length;w<q;w++){const G=T[w];if(x(G,P,w,O)===!0){const k=G.__offset,$=Array.isArray(G.value)?G.value:[G.value];let te=0;for(let J=0;J<$.length;J++){const z=$[J],I=b(z);typeof z=="number"||typeof z=="boolean"?(G.__data[0]=z,o.bufferSubData(o.UNIFORM_BUFFER,k+te,G.__data)):z.isMatrix3?(G.__data[0]=z.elements[0],G.__data[1]=z.elements[1],G.__data[2]=z.elements[2],G.__data[3]=0,G.__data[4]=z.elements[3],G.__data[5]=z.elements[4],G.__data[6]=z.elements[5],G.__data[7]=0,G.__data[8]=z.elements[6],G.__data[9]=z.elements[7],G.__data[10]=z.elements[8],G.__data[11]=0):(z.toArray(G.__data,te),te+=I.storage/Float32Array.BYTES_PER_ELEMENT)}o.bufferSubData(o.UNIFORM_BUFFER,k,G.__data)}}}o.bindBuffer(o.UNIFORM_BUFFER,null)}function x(R,N,C,O){const P=R.value,L=N+"_"+C;if(O[L]===void 0)return typeof P=="number"||typeof P=="boolean"?O[L]=P:O[L]=P.clone(),!0;{const T=O[L];if(typeof P=="number"||typeof P=="boolean"){if(T!==P)return O[L]=P,!0}else if(T.equals(P)===!1)return T.copy(P),!0}return!1}function M(R){const N=R.uniforms;let C=0;const O=16;for(let L=0,T=N.length;L<T;L++){const w=Array.isArray(N[L])?N[L]:[N[L]];for(let q=0,G=w.length;q<G;q++){const k=w[q],$=Array.isArray(k.value)?k.value:[k.value];for(let te=0,J=$.length;te<J;te++){const z=$[te],I=b(z),ie=C%O,he=ie%I.boundary,H=ie+he;C+=he,H!==0&&O-H<I.storage&&(C+=O-H),k.__data=new Float32Array(I.storage/Float32Array.BYTES_PER_ELEMENT),k.__offset=C,C+=I.storage}}}const P=C%O;return P>0&&(C+=O-P),R.__size=C,R.__cache={},this}function b(R){const N={boundary:0,storage:0};return typeof R=="number"||typeof R=="boolean"?(N.boundary=4,N.storage=4):R.isVector2?(N.boundary=8,N.storage=8):R.isVector3||R.isColor?(N.boundary=16,N.storage=12):R.isVector4?(N.boundary=16,N.storage=16):R.isMatrix3?(N.boundary=48,N.storage=48):R.isMatrix4?(N.boundary=64,N.storage=64):R.isTexture?Mt("WebGLRenderer: Texture samplers can not be part of an uniforms group."):Mt("WebGLRenderer: Unsupported uniform value type.",R),N}function y(R){const N=R.target;N.removeEventListener("dispose",y);const C=c.indexOf(N.__bindingPointIndex);c.splice(C,1),o.deleteBuffer(r[N.id]),delete r[N.id],delete l[N.id]}function S(){for(const R in r)o.deleteBuffer(r[R]);c=[],r={},l={}}return{bind:p,update:d,dispose:S}}const GD=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let sr=null;function VD(){return sr===null&&(sr=new OR(GD,16,16,nu,ts),sr.name="DFG_LUT",sr.minFilter=Mi,sr.magFilter=Mi,sr.wrapS=Kr,sr.wrapT=Kr,sr.generateMipmaps=!1,sr.needsUpdate=!0),sr}class kD{constructor(e={}){const{canvas:n=fR(),context:a=null,depth:r=!0,stencil:l=!1,alpha:c=!1,antialias:f=!1,premultipliedAlpha:p=!0,preserveDrawingBuffer:d=!1,powerPreference:_="default",failIfMajorPerformanceCaveat:v=!1,reversedDepthBuffer:g=!1,outputBufferType:x=za}=e;this.isWebGLRenderer=!0;let M;if(a!==null){if(typeof WebGLRenderingContext<"u"&&a instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");M=a.getContextAttributes().alpha}else M=c;const b=x,y=new Set([og,sg,rg]),S=new Set([za,Sr,Fc,Ic,ig,ag]),R=new Uint32Array(4),N=new Int32Array(4);let C=null,O=null;const P=[],L=[];let T=null;this.domElement=n,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=gr,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const w=this;let q=!1;this._outputColorSpace=Ua;let G=0,k=0,$=null,te=-1,J=null;const z=new Pn,I=new Pn;let ie=null;const he=new qt(0);let H=0,F=n.width,Q=n.height,xe=1,Te=null,Ne=null;const ne=new Pn(0,0,F,Q),_e=new Pn(0,0,F,Q);let be=!1;const ze=new O1;let tt=!1,Ke=!1;const Ut=new Fn,qe=new fe,rt=new Pn,_t={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let st=!1;function le(){return $===null?xe:1}let W=a;function Wt(D,Y){return n.getContext(D,Y)}try{const D={alpha:!0,depth:r,stencil:l,antialias:f,premultipliedAlpha:p,preserveDrawingBuffer:d,powerPreference:_,failIfMajorPerformanceCaveat:v};if("setAttribute"in n&&n.setAttribute("data-engine",`three.js r${tg}`),n.addEventListener("webglcontextlost",Xe,!1),n.addEventListener("webglcontextrestored",lt,!1),n.addEventListener("webglcontextcreationerror",Gt,!1),W===null){const Y="webgl2";if(W=Wt(Y,D),W===null)throw Wt(Y)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(D){throw Qt("WebGLRenderer: "+D.message),D}let bt,ct,We,B,A,Z,ge,ve,de,Ge,we,it,Ye,Re,Ae,He,Pe,Fe,pt,V,De,Ce,Le;function Ee(){bt=new kw(W),bt.init(),De=new LD(W,bt),ct=new Pw(W,bt,e,De),We=new ND(W,bt),ct.reversedDepthBuffer&&g&&We.buffers.depth.setReversed(!0),B=new Yw(W),A=new gD,Z=new UD(W,bt,We,A,ct,De,B),ge=new Vw(w),ve=new QR(W),Ce=new Lw(W,ve),de=new Xw(W,ve,B,Ce),Ge=new jw(W,de,ve,Ce,B),Fe=new qw(W,ct,Z),Ae=new zw(A),we=new _D(w,ge,bt,ct,Ce,Ae),it=new BD(w,A),Ye=new xD,Re=new TD(bt),Pe=new Uw(w,ge,We,Ge,M,p),He=new DD(w,Ge,ct),Le=new HD(W,B,ct,We),pt=new Ow(W,bt,B),V=new Ww(W,bt,B),B.programs=we.programs,w.capabilities=ct,w.extensions=bt,w.properties=A,w.renderLists=Ye,w.shadowMap=He,w.state=We,w.info=B}Ee(),b!==za&&(T=new Kw(b,n.width,n.height,r,l));const me=new FD(w,W);this.xr=me,this.getContext=function(){return W},this.getContextAttributes=function(){return W.getContextAttributes()},this.forceContextLoss=function(){const D=bt.get("WEBGL_lose_context");D&&D.loseContext()},this.forceContextRestore=function(){const D=bt.get("WEBGL_lose_context");D&&D.restoreContext()},this.getPixelRatio=function(){return xe},this.setPixelRatio=function(D){D!==void 0&&(xe=D,this.setSize(F,Q,!1))},this.getSize=function(D){return D.set(F,Q)},this.setSize=function(D,Y,ue=!0){if(me.isPresenting){Mt("WebGLRenderer: Can't change size while VR device is presenting.");return}F=D,Q=Y,n.width=Math.floor(D*xe),n.height=Math.floor(Y*xe),ue===!0&&(n.style.width=D+"px",n.style.height=Y+"px"),T!==null&&T.setSize(n.width,n.height),this.setViewport(0,0,D,Y)},this.getDrawingBufferSize=function(D){return D.set(F*xe,Q*xe).floor()},this.setDrawingBufferSize=function(D,Y,ue){F=D,Q=Y,xe=ue,n.width=Math.floor(D*ue),n.height=Math.floor(Y*ue),this.setViewport(0,0,D,Y)},this.setEffects=function(D){if(b===za){console.error("THREE.WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(D){for(let Y=0;Y<D.length;Y++)if(D[Y].isOutputPass===!0){console.warn("THREE.WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}T.setEffects(D||[])},this.getCurrentViewport=function(D){return D.copy(z)},this.getViewport=function(D){return D.copy(ne)},this.setViewport=function(D,Y,ue,se){D.isVector4?ne.set(D.x,D.y,D.z,D.w):ne.set(D,Y,ue,se),We.viewport(z.copy(ne).multiplyScalar(xe).round())},this.getScissor=function(D){return D.copy(_e)},this.setScissor=function(D,Y,ue,se){D.isVector4?_e.set(D.x,D.y,D.z,D.w):_e.set(D,Y,ue,se),We.scissor(I.copy(_e).multiplyScalar(xe).round())},this.getScissorTest=function(){return be},this.setScissorTest=function(D){We.setScissorTest(be=D)},this.setOpaqueSort=function(D){Te=D},this.setTransparentSort=function(D){Ne=D},this.getClearColor=function(D){return D.copy(Pe.getClearColor())},this.setClearColor=function(){Pe.setClearColor(...arguments)},this.getClearAlpha=function(){return Pe.getClearAlpha()},this.setClearAlpha=function(){Pe.setClearAlpha(...arguments)},this.clear=function(D=!0,Y=!0,ue=!0){let se=0;if(D){let ae=!1;if($!==null){const Ue=$.texture.format;ae=y.has(Ue)}if(ae){const Ue=$.texture.type,Be=S.has(Ue),Oe=Pe.getClearColor(),je=Pe.getClearAlpha(),Ze=Oe.r,mt=Oe.g,yt=Oe.b;Be?(R[0]=Ze,R[1]=mt,R[2]=yt,R[3]=je,W.clearBufferuiv(W.COLOR,0,R)):(N[0]=Ze,N[1]=mt,N[2]=yt,N[3]=je,W.clearBufferiv(W.COLOR,0,N))}else se|=W.COLOR_BUFFER_BIT}Y&&(se|=W.DEPTH_BUFFER_BIT),ue&&(se|=W.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),se!==0&&W.clear(se)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){n.removeEventListener("webglcontextlost",Xe,!1),n.removeEventListener("webglcontextrestored",lt,!1),n.removeEventListener("webglcontextcreationerror",Gt,!1),Pe.dispose(),Ye.dispose(),Re.dispose(),A.dispose(),ge.dispose(),Ge.dispose(),Ce.dispose(),Le.dispose(),we.dispose(),me.dispose(),me.removeEventListener("sessionstart",dt),me.removeEventListener("sessionend",_n),gt.stop()};function Xe(D){D.preventDefault(),PS("WebGLRenderer: Context Lost."),q=!0}function lt(){PS("WebGLRenderer: Context Restored."),q=!1;const D=B.autoReset,Y=He.enabled,ue=He.autoUpdate,se=He.needsUpdate,ae=He.type;Ee(),B.autoReset=D,He.enabled=Y,He.autoUpdate=ue,He.needsUpdate=se,He.type=ae}function Gt(D){Qt("WebGLRenderer: A WebGL context could not be created. Reason: ",D.statusMessage)}function Ve(D){const Y=D.target;Y.removeEventListener("dispose",Ve),Je(Y)}function Je(D){Et(D),A.remove(D)}function Et(D){const Y=A.get(D).programs;Y!==void 0&&(Y.forEach(function(ue){we.releaseProgram(ue)}),D.isShaderMaterial&&we.releaseShaderCache(D))}this.renderBufferDirect=function(D,Y,ue,se,ae,Ue){Y===null&&(Y=_t);const Be=ae.isMesh&&ae.matrixWorld.determinant()<0,Oe=Ei(D,Y,ue,se,ae);We.setMaterial(se,Be);let je=ue.index,Ze=1;if(se.wireframe===!0){if(je=de.getWireframeAttribute(ue),je===void 0)return;Ze=2}const mt=ue.drawRange,yt=ue.attributes.position;let Qe=mt.start*Ze,Rt=(mt.start+mt.count)*Ze;Ue!==null&&(Qe=Math.max(Qe,Ue.start*Ze),Rt=Math.min(Rt,(Ue.start+Ue.count)*Ze)),je!==null?(Qe=Math.max(Qe,0),Rt=Math.min(Rt,je.count)):yt!=null&&(Qe=Math.max(Qe,0),Rt=Math.min(Rt,yt.count));const Sn=Rt-Qe;if(Sn<0||Sn===1/0)return;Ce.setup(ae,se,Oe,ue,je);let Mn,jt=pt;if(je!==null&&(Mn=ve.get(je),jt=V,jt.setIndex(Mn)),ae.isMesh)se.wireframe===!0?(We.setLineWidth(se.wireframeLinewidth*le()),jt.setMode(W.LINES)):jt.setMode(W.TRIANGLES);else if(ae.isLine){let jn=se.linewidth;jn===void 0&&(jn=1),We.setLineWidth(jn*le()),ae.isLineSegments?jt.setMode(W.LINES):ae.isLineLoop?jt.setMode(W.LINE_LOOP):jt.setMode(W.LINE_STRIP)}else ae.isPoints?jt.setMode(W.POINTS):ae.isSprite&&jt.setMode(W.TRIANGLES);if(ae.isBatchedMesh)if(ae._multiDrawInstances!==null)hd("WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),jt.renderMultiDrawInstances(ae._multiDrawStarts,ae._multiDrawCounts,ae._multiDrawCount,ae._multiDrawInstances);else if(bt.get("WEBGL_multi_draw"))jt.renderMultiDraw(ae._multiDrawStarts,ae._multiDrawCounts,ae._multiDrawCount);else{const jn=ae._multiDrawStarts,nt=ae._multiDrawCounts,Ti=ae._multiDrawCount,vt=je?ve.get(je).bytesPerElement:1,Ai=A.get(se).currentProgram.getUniforms();for(let $i=0;$i<Ti;$i++)Ai.setValue(W,"_gl_DrawID",$i),jt.render(jn[$i]/vt,nt[$i])}else if(ae.isInstancedMesh)jt.renderInstances(Qe,Sn,ae.count);else if(ue.isInstancedBufferGeometry){const jn=ue._maxInstanceCount!==void 0?ue._maxInstanceCount:1/0,nt=Math.min(ue.instanceCount,jn);jt.renderInstances(Qe,Sn,nt)}else jt.render(Qe,Sn)};function Ie(D,Y,ue){D.transparent===!0&&D.side===jr&&D.forceSinglePass===!1?(D.side=Yi,D.needsUpdate=!0,In(D,Y,ue),D.side=qs,D.needsUpdate=!0,In(D,Y,ue),D.side=jr):In(D,Y,ue)}this.compile=function(D,Y,ue=null){ue===null&&(ue=D),O=Re.get(ue),O.init(Y),L.push(O),ue.traverseVisible(function(ae){ae.isLight&&ae.layers.test(Y.layers)&&(O.pushLight(ae),ae.castShadow&&O.pushShadow(ae))}),D!==ue&&D.traverseVisible(function(ae){ae.isLight&&ae.layers.test(Y.layers)&&(O.pushLight(ae),ae.castShadow&&O.pushShadow(ae))}),O.setupLights();const se=new Set;return D.traverse(function(ae){if(!(ae.isMesh||ae.isPoints||ae.isLine||ae.isSprite))return;const Ue=ae.material;if(Ue)if(Array.isArray(Ue))for(let Be=0;Be<Ue.length;Be++){const Oe=Ue[Be];Ie(Oe,ue,ae),se.add(Oe)}else Ie(Ue,ue,ae),se.add(Ue)}),O=L.pop(),se},this.compileAsync=function(D,Y,ue=null){const se=this.compile(D,Y,ue);return new Promise(ae=>{function Ue(){if(se.forEach(function(Be){A.get(Be).currentProgram.isReady()&&se.delete(Be)}),se.size===0){ae(D);return}setTimeout(Ue,10)}bt.get("KHR_parallel_shader_compile")!==null?Ue():setTimeout(Ue,10)})};let ht=null;function ot(D){ht&&ht(D)}function dt(){gt.stop()}function _n(){gt.start()}const gt=new H1;gt.setAnimationLoop(ot),typeof self<"u"&&gt.setContext(self),this.setAnimationLoop=function(D){ht=D,me.setAnimationLoop(D),D===null?gt.stop():gt.start()},me.addEventListener("sessionstart",dt),me.addEventListener("sessionend",_n),this.render=function(D,Y){if(Y!==void 0&&Y.isCamera!==!0){Qt("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(q===!0)return;const ue=me.enabled===!0&&me.isPresenting===!0,se=T!==null&&($===null||ue)&&T.begin(w,$);if(D.matrixWorldAutoUpdate===!0&&D.updateMatrixWorld(),Y.parent===null&&Y.matrixWorldAutoUpdate===!0&&Y.updateMatrixWorld(),me.enabled===!0&&me.isPresenting===!0&&(T===null||T.isCompositing()===!1)&&(me.cameraAutoUpdate===!0&&me.updateCamera(Y),Y=me.getCamera()),D.isScene===!0&&D.onBeforeRender(w,D,Y,$),O=Re.get(D,L.length),O.init(Y),L.push(O),Ut.multiplyMatrices(Y.projectionMatrix,Y.matrixWorldInverse),ze.setFromProjectionMatrix(Ut,pr,Y.reversedDepth),Ke=this.localClippingEnabled,tt=Ae.init(this.clippingPlanes,Ke),C=Ye.get(D,P.length),C.init(),P.push(C),me.enabled===!0&&me.isPresenting===!0){const Be=w.xr.getDepthSensingMesh();Be!==null&&rn(Be,Y,-1/0,w.sortObjects)}rn(D,Y,0,w.sortObjects),C.finish(),w.sortObjects===!0&&C.sort(Te,Ne),st=me.enabled===!1||me.isPresenting===!1||me.hasDepthSensing()===!1,st&&Pe.addToRenderList(C,D),this.info.render.frame++,tt===!0&&Ae.beginShadows();const ae=O.state.shadowsArray;if(He.render(ae,D,Y),tt===!0&&Ae.endShadows(),this.info.autoReset===!0&&this.info.reset(),(se&&T.hasRenderPass())===!1){const Be=C.opaque,Oe=C.transmissive;if(O.setupLights(),Y.isArrayCamera){const je=Y.cameras;if(Oe.length>0)for(let Ze=0,mt=je.length;Ze<mt;Ze++){const yt=je[Ze];Tt(Be,Oe,D,yt)}st&&Pe.render(D);for(let Ze=0,mt=je.length;Ze<mt;Ze++){const yt=je[Ze];sn(C,D,yt,yt.viewport)}}else Oe.length>0&&Tt(Be,Oe,D,Y),st&&Pe.render(D),sn(C,D,Y)}$!==null&&k===0&&(Z.updateMultisampleRenderTarget($),Z.updateRenderTargetMipmap($)),se&&T.end(w),D.isScene===!0&&D.onAfterRender(w,D,Y),Ce.resetDefaultState(),te=-1,J=null,L.pop(),L.length>0?(O=L[L.length-1],tt===!0&&Ae.setGlobalState(w.clippingPlanes,O.state.camera)):O=null,P.pop(),P.length>0?C=P[P.length-1]:C=null};function rn(D,Y,ue,se){if(D.visible===!1)return;if(D.layers.test(Y.layers)){if(D.isGroup)ue=D.renderOrder;else if(D.isLOD)D.autoUpdate===!0&&D.update(Y);else if(D.isLight)O.pushLight(D),D.castShadow&&O.pushShadow(D);else if(D.isSprite){if(!D.frustumCulled||ze.intersectsSprite(D)){se&&rt.setFromMatrixPosition(D.matrixWorld).applyMatrix4(Ut);const Be=Ge.update(D),Oe=D.material;Oe.visible&&C.push(D,Be,Oe,ue,rt.z,null)}}else if((D.isMesh||D.isLine||D.isPoints)&&(!D.frustumCulled||ze.intersectsObject(D))){const Be=Ge.update(D),Oe=D.material;if(se&&(D.boundingSphere!==void 0?(D.boundingSphere===null&&D.computeBoundingSphere(),rt.copy(D.boundingSphere.center)):(Be.boundingSphere===null&&Be.computeBoundingSphere(),rt.copy(Be.boundingSphere.center)),rt.applyMatrix4(D.matrixWorld).applyMatrix4(Ut)),Array.isArray(Oe)){const je=Be.groups;for(let Ze=0,mt=je.length;Ze<mt;Ze++){const yt=je[Ze],Qe=Oe[yt.materialIndex];Qe&&Qe.visible&&C.push(D,Be,Qe,ue,rt.z,yt)}}else Oe.visible&&C.push(D,Be,Oe,ue,rt.z,null)}}const Ue=D.children;for(let Be=0,Oe=Ue.length;Be<Oe;Be++)rn(Ue[Be],Y,ue,se)}function sn(D,Y,ue,se){const{opaque:ae,transmissive:Ue,transparent:Be}=D;O.setupLightsView(ue),tt===!0&&Ae.setGlobalState(w.clippingPlanes,ue),se&&We.viewport(z.copy(se)),ae.length>0&&xt(ae,Y,ue),Ue.length>0&&xt(Ue,Y,ue),Be.length>0&&xt(Be,Y,ue),We.buffers.depth.setTest(!0),We.buffers.depth.setMask(!0),We.buffers.color.setMask(!0),We.setPolygonOffset(!1)}function Tt(D,Y,ue,se){if((ue.isScene===!0?ue.overrideMaterial:null)!==null)return;if(O.state.transmissionRenderTarget[se.id]===void 0){const Qe=bt.has("EXT_color_buffer_half_float")||bt.has("EXT_color_buffer_float");O.state.transmissionRenderTarget[se.id]=new vr(1,1,{generateMipmaps:!0,type:Qe?ts:za,minFilter:Do,samples:Math.max(4,ct.samples),stencilBuffer:l,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Yt.workingColorSpace})}const Ue=O.state.transmissionRenderTarget[se.id],Be=se.viewport||z;Ue.setSize(Be.z*w.transmissionResolutionScale,Be.w*w.transmissionResolutionScale);const Oe=w.getRenderTarget(),je=w.getActiveCubeFace(),Ze=w.getActiveMipmapLevel();w.setRenderTarget(Ue),w.getClearColor(he),H=w.getClearAlpha(),H<1&&w.setClearColor(16777215,.5),w.clear(),st&&Pe.render(ue);const mt=w.toneMapping;w.toneMapping=gr;const yt=se.viewport;if(se.viewport!==void 0&&(se.viewport=void 0),O.setupLightsView(se),tt===!0&&Ae.setGlobalState(w.clippingPlanes,se),xt(D,ue,se),Z.updateMultisampleRenderTarget(Ue),Z.updateRenderTargetMipmap(Ue),bt.has("WEBGL_multisampled_render_to_texture")===!1){let Qe=!1;for(let Rt=0,Sn=Y.length;Rt<Sn;Rt++){const Mn=Y[Rt],{object:jt,geometry:jn,material:nt,group:Ti}=Mn;if(nt.side===jr&&jt.layers.test(se.layers)){const vt=nt.side;nt.side=Yi,nt.needsUpdate=!0,Pt(jt,ue,se,jn,nt,Ti),nt.side=vt,nt.needsUpdate=!0,Qe=!0}}Qe===!0&&(Z.updateMultisampleRenderTarget(Ue),Z.updateRenderTargetMipmap(Ue))}w.setRenderTarget(Oe,je,Ze),w.setClearColor(he,H),yt!==void 0&&(se.viewport=yt),w.toneMapping=mt}function xt(D,Y,ue){const se=Y.isScene===!0?Y.overrideMaterial:null;for(let ae=0,Ue=D.length;ae<Ue;ae++){const Be=D[ae],{object:Oe,geometry:je,group:Ze}=Be;let mt=Be.material;mt.allowOverride===!0&&se!==null&&(mt=se),Oe.layers.test(ue.layers)&&Pt(Oe,Y,ue,je,mt,Ze)}}function Pt(D,Y,ue,se,ae,Ue){D.onBeforeRender(w,Y,ue,se,ae,Ue),D.modelViewMatrix.multiplyMatrices(ue.matrixWorldInverse,D.matrixWorld),D.normalMatrix.getNormalMatrix(D.modelViewMatrix),ae.onBeforeRender(w,Y,ue,se,D,Ue),ae.transparent===!0&&ae.side===jr&&ae.forceSinglePass===!1?(ae.side=Yi,ae.needsUpdate=!0,w.renderBufferDirect(ue,Y,se,ae,D,Ue),ae.side=qs,ae.needsUpdate=!0,w.renderBufferDirect(ue,Y,se,ae,D,Ue),ae.side=jr):w.renderBufferDirect(ue,Y,se,ae,D,Ue),D.onAfterRender(w,Y,ue,se,ae,Ue)}function In(D,Y,ue){Y.isScene!==!0&&(Y=_t);const se=A.get(D),ae=O.state.lights,Ue=O.state.shadowsArray,Be=ae.state.version,Oe=we.getParameters(D,ae.state,Ue,Y,ue),je=we.getProgramCacheKey(Oe);let Ze=se.programs;se.environment=D.isMeshStandardMaterial||D.isMeshLambertMaterial||D.isMeshPhongMaterial?Y.environment:null,se.fog=Y.fog;const mt=D.isMeshStandardMaterial||D.isMeshLambertMaterial&&!D.envMap||D.isMeshPhongMaterial&&!D.envMap;se.envMap=ge.get(D.envMap||se.environment,mt),se.envMapRotation=se.environment!==null&&D.envMap===null?Y.environmentRotation:D.envMapRotation,Ze===void 0&&(D.addEventListener("dispose",Ve),Ze=new Map,se.programs=Ze);let yt=Ze.get(je);if(yt!==void 0){if(se.currentProgram===yt&&se.lightsStateVersion===Be)return ti(D,Oe),yt}else Oe.uniforms=we.getUniforms(D),D.onBeforeCompile(Oe,w),yt=we.acquireProgram(Oe,je),Ze.set(je,yt),se.uniforms=Oe.uniforms;const Qe=se.uniforms;return(!D.isShaderMaterial&&!D.isRawShaderMaterial||D.clipping===!0)&&(Qe.clippingPlanes=Ae.uniform),ti(D,Oe),se.needsLights=Tn(D),se.lightsStateVersion=Be,se.needsLights&&(Qe.ambientLightColor.value=ae.state.ambient,Qe.lightProbe.value=ae.state.probe,Qe.directionalLights.value=ae.state.directional,Qe.directionalLightShadows.value=ae.state.directionalShadow,Qe.spotLights.value=ae.state.spot,Qe.spotLightShadows.value=ae.state.spotShadow,Qe.rectAreaLights.value=ae.state.rectArea,Qe.ltc_1.value=ae.state.rectAreaLTC1,Qe.ltc_2.value=ae.state.rectAreaLTC2,Qe.pointLights.value=ae.state.point,Qe.pointLightShadows.value=ae.state.pointShadow,Qe.hemisphereLights.value=ae.state.hemi,Qe.directionalShadowMatrix.value=ae.state.directionalShadowMatrix,Qe.spotLightMatrix.value=ae.state.spotLightMatrix,Qe.spotLightMap.value=ae.state.spotLightMap,Qe.pointShadowMatrix.value=ae.state.pointShadowMatrix),se.currentProgram=yt,se.uniformsList=null,yt}function on(D){if(D.uniformsList===null){const Y=D.currentProgram.getUniforms();D.uniformsList=$h.seqWithValue(Y.seq,D.uniforms)}return D.uniformsList}function ti(D,Y){const ue=A.get(D);ue.outputColorSpace=Y.outputColorSpace,ue.batching=Y.batching,ue.batchingColor=Y.batchingColor,ue.instancing=Y.instancing,ue.instancingColor=Y.instancingColor,ue.instancingMorph=Y.instancingMorph,ue.skinning=Y.skinning,ue.morphTargets=Y.morphTargets,ue.morphNormals=Y.morphNormals,ue.morphColors=Y.morphColors,ue.morphTargetsCount=Y.morphTargetsCount,ue.numClippingPlanes=Y.numClippingPlanes,ue.numIntersection=Y.numClipIntersection,ue.vertexAlphas=Y.vertexAlphas,ue.vertexTangents=Y.vertexTangents,ue.toneMapping=Y.toneMapping}function Ei(D,Y,ue,se,ae){Y.isScene!==!0&&(Y=_t),Z.resetTextureUnits();const Ue=Y.fog,Be=se.isMeshStandardMaterial||se.isMeshLambertMaterial||se.isMeshPhongMaterial?Y.environment:null,Oe=$===null?w.outputColorSpace:$.isXRRenderTarget===!0?$.texture.colorSpace:iu,je=se.isMeshStandardMaterial||se.isMeshLambertMaterial&&!se.envMap||se.isMeshPhongMaterial&&!se.envMap,Ze=ge.get(se.envMap||Be,je),mt=se.vertexColors===!0&&!!ue.attributes.color&&ue.attributes.color.itemSize===4,yt=!!ue.attributes.tangent&&(!!se.normalMap||se.anisotropy>0),Qe=!!ue.morphAttributes.position,Rt=!!ue.morphAttributes.normal,Sn=!!ue.morphAttributes.color;let Mn=gr;se.toneMapped&&($===null||$.isXRRenderTarget===!0)&&(Mn=w.toneMapping);const jt=ue.morphAttributes.position||ue.morphAttributes.normal||ue.morphAttributes.color,jn=jt!==void 0?jt.length:0,nt=A.get(se),Ti=O.state.lights;if(tt===!0&&(Ke===!0||D!==J)){const Hn=D===J&&se.id===te;Ae.setState(se,D,Hn)}let vt=!1;se.version===nt.__version?(nt.needsLights&&nt.lightsStateVersion!==Ti.state.version||nt.outputColorSpace!==Oe||ae.isBatchedMesh&&nt.batching===!1||!ae.isBatchedMesh&&nt.batching===!0||ae.isBatchedMesh&&nt.batchingColor===!0&&ae.colorTexture===null||ae.isBatchedMesh&&nt.batchingColor===!1&&ae.colorTexture!==null||ae.isInstancedMesh&&nt.instancing===!1||!ae.isInstancedMesh&&nt.instancing===!0||ae.isSkinnedMesh&&nt.skinning===!1||!ae.isSkinnedMesh&&nt.skinning===!0||ae.isInstancedMesh&&nt.instancingColor===!0&&ae.instanceColor===null||ae.isInstancedMesh&&nt.instancingColor===!1&&ae.instanceColor!==null||ae.isInstancedMesh&&nt.instancingMorph===!0&&ae.morphTexture===null||ae.isInstancedMesh&&nt.instancingMorph===!1&&ae.morphTexture!==null||nt.envMap!==Ze||se.fog===!0&&nt.fog!==Ue||nt.numClippingPlanes!==void 0&&(nt.numClippingPlanes!==Ae.numPlanes||nt.numIntersection!==Ae.numIntersection)||nt.vertexAlphas!==mt||nt.vertexTangents!==yt||nt.morphTargets!==Qe||nt.morphNormals!==Rt||nt.morphColors!==Sn||nt.toneMapping!==Mn||nt.morphTargetsCount!==jn)&&(vt=!0):(vt=!0,nt.__version=se.version);let Ai=nt.currentProgram;vt===!0&&(Ai=In(se,Y,ae));let $i=!1,Va=!1,ea=!1;const $t=Ai.getUniforms(),Bn=nt.uniforms;if(We.useProgram(Ai.program)&&($i=!0,Va=!0,ea=!0),se.id!==te&&(te=se.id,Va=!0),$i||J!==D){We.buffers.depth.getReversed()&&D.reversedDepth!==!0&&(D._reversedDepth=!0,D.updateProjectionMatrix()),$t.setValue(W,"projectionMatrix",D.projectionMatrix),$t.setValue(W,"viewMatrix",D.matrixWorldInverse);const ka=$t.map.cameraPosition;ka!==void 0&&ka.setValue(W,qe.setFromMatrixPosition(D.matrixWorld)),ct.logarithmicDepthBuffer&&$t.setValue(W,"logDepthBufFC",2/(Math.log(D.far+1)/Math.LN2)),(se.isMeshPhongMaterial||se.isMeshToonMaterial||se.isMeshLambertMaterial||se.isMeshBasicMaterial||se.isMeshStandardMaterial||se.isShaderMaterial)&&$t.setValue(W,"isOrthographic",D.isOrthographicCamera===!0),J!==D&&(J=D,Va=!0,ea=!0)}if(nt.needsLights&&(Ti.state.directionalShadowMap.length>0&&$t.setValue(W,"directionalShadowMap",Ti.state.directionalShadowMap,Z),Ti.state.spotShadowMap.length>0&&$t.setValue(W,"spotShadowMap",Ti.state.spotShadowMap,Z),Ti.state.pointShadowMap.length>0&&$t.setValue(W,"pointShadowMap",Ti.state.pointShadowMap,Z)),ae.isSkinnedMesh){$t.setOptional(W,ae,"bindMatrix"),$t.setOptional(W,ae,"bindMatrixInverse");const Hn=ae.skeleton;Hn&&(Hn.boneTexture===null&&Hn.computeBoneTexture(),$t.setValue(W,"boneTexture",Hn.boneTexture,Z))}ae.isBatchedMesh&&($t.setOptional(W,ae,"batchingTexture"),$t.setValue(W,"batchingTexture",ae._matricesTexture,Z),$t.setOptional(W,ae,"batchingIdTexture"),$t.setValue(W,"batchingIdTexture",ae._indirectTexture,Z),$t.setOptional(W,ae,"batchingColorTexture"),ae._colorsTexture!==null&&$t.setValue(W,"batchingColorTexture",ae._colorsTexture,Z));const Ri=ue.morphAttributes;if((Ri.position!==void 0||Ri.normal!==void 0||Ri.color!==void 0)&&Fe.update(ae,ue,Ai),(Va||nt.receiveShadow!==ae.receiveShadow)&&(nt.receiveShadow=ae.receiveShadow,$t.setValue(W,"receiveShadow",ae.receiveShadow)),(se.isMeshStandardMaterial||se.isMeshLambertMaterial||se.isMeshPhongMaterial)&&se.envMap===null&&Y.environment!==null&&(Bn.envMapIntensity.value=Y.environmentIntensity),Bn.dfgLUT!==void 0&&(Bn.dfgLUT.value=VD()),Va&&($t.setValue(W,"toneMappingExposure",w.toneMappingExposure),nt.needsLights&&gn(Bn,ea),Ue&&se.fog===!0&&it.refreshFogUniforms(Bn,Ue),it.refreshMaterialUniforms(Bn,se,xe,Q,O.state.transmissionRenderTarget[D.id]),$h.upload(W,on(nt),Bn,Z)),se.isShaderMaterial&&se.uniformsNeedUpdate===!0&&($h.upload(W,on(nt),Bn,Z),se.uniformsNeedUpdate=!1),se.isSpriteMaterial&&$t.setValue(W,"center",ae.center),$t.setValue(W,"modelViewMatrix",ae.modelViewMatrix),$t.setValue(W,"normalMatrix",ae.normalMatrix),$t.setValue(W,"modelMatrix",ae.matrixWorld),se.isShaderMaterial||se.isRawShaderMaterial){const Hn=se.uniformsGroups;for(let ka=0,br=Hn.length;ka<br;ka++){const Yo=Hn[ka];Le.update(Yo,Ai),Le.bind(Yo,Ai)}}return Ai}function gn(D,Y){D.ambientLightColor.needsUpdate=Y,D.lightProbe.needsUpdate=Y,D.directionalLights.needsUpdate=Y,D.directionalLightShadows.needsUpdate=Y,D.pointLights.needsUpdate=Y,D.pointLightShadows.needsUpdate=Y,D.spotLights.needsUpdate=Y,D.spotLightShadows.needsUpdate=Y,D.rectAreaLights.needsUpdate=Y,D.hemisphereLights.needsUpdate=Y}function Tn(D){return D.isMeshLambertMaterial||D.isMeshToonMaterial||D.isMeshPhongMaterial||D.isMeshStandardMaterial||D.isShadowMaterial||D.isShaderMaterial&&D.lights===!0}this.getActiveCubeFace=function(){return G},this.getActiveMipmapLevel=function(){return k},this.getRenderTarget=function(){return $},this.setRenderTargetTextures=function(D,Y,ue){const se=A.get(D);se.__autoAllocateDepthBuffer=D.resolveDepthBuffer===!1,se.__autoAllocateDepthBuffer===!1&&(se.__useRenderToTexture=!1),A.get(D.texture).__webglTexture=Y,A.get(D.depthTexture).__webglTexture=se.__autoAllocateDepthBuffer?void 0:ue,se.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(D,Y){const ue=A.get(D);ue.__webglFramebuffer=Y,ue.__useDefaultFramebuffer=Y===void 0};const vn=W.createFramebuffer();this.setRenderTarget=function(D,Y=0,ue=0){$=D,G=Y,k=ue;let se=null,ae=!1,Ue=!1;if(D){const Oe=A.get(D);if(Oe.__useDefaultFramebuffer!==void 0){We.bindFramebuffer(W.FRAMEBUFFER,Oe.__webglFramebuffer),z.copy(D.viewport),I.copy(D.scissor),ie=D.scissorTest,We.viewport(z),We.scissor(I),We.setScissorTest(ie),te=-1;return}else if(Oe.__webglFramebuffer===void 0)Z.setupRenderTarget(D);else if(Oe.__hasExternalTextures)Z.rebindTextures(D,A.get(D.texture).__webglTexture,A.get(D.depthTexture).__webglTexture);else if(D.depthBuffer){const mt=D.depthTexture;if(Oe.__boundDepthTexture!==mt){if(mt!==null&&A.has(mt)&&(D.width!==mt.image.width||D.height!==mt.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");Z.setupDepthRenderbuffer(D)}}const je=D.texture;(je.isData3DTexture||je.isDataArrayTexture||je.isCompressedArrayTexture)&&(Ue=!0);const Ze=A.get(D).__webglFramebuffer;D.isWebGLCubeRenderTarget?(Array.isArray(Ze[Y])?se=Ze[Y][ue]:se=Ze[Y],ae=!0):D.samples>0&&Z.useMultisampledRTT(D)===!1?se=A.get(D).__webglMultisampledFramebuffer:Array.isArray(Ze)?se=Ze[ue]:se=Ze,z.copy(D.viewport),I.copy(D.scissor),ie=D.scissorTest}else z.copy(ne).multiplyScalar(xe).floor(),I.copy(_e).multiplyScalar(xe).floor(),ie=be;if(ue!==0&&(se=vn),We.bindFramebuffer(W.FRAMEBUFFER,se)&&We.drawBuffers(D,se),We.viewport(z),We.scissor(I),We.setScissorTest(ie),ae){const Oe=A.get(D.texture);W.framebufferTexture2D(W.FRAMEBUFFER,W.COLOR_ATTACHMENT0,W.TEXTURE_CUBE_MAP_POSITIVE_X+Y,Oe.__webglTexture,ue)}else if(Ue){const Oe=Y;for(let je=0;je<D.textures.length;je++){const Ze=A.get(D.textures[je]);W.framebufferTextureLayer(W.FRAMEBUFFER,W.COLOR_ATTACHMENT0+je,Ze.__webglTexture,ue,Oe)}}else if(D!==null&&ue!==0){const Oe=A.get(D.texture);W.framebufferTexture2D(W.FRAMEBUFFER,W.COLOR_ATTACHMENT0,W.TEXTURE_2D,Oe.__webglTexture,ue)}te=-1},this.readRenderTargetPixels=function(D,Y,ue,se,ae,Ue,Be,Oe=0){if(!(D&&D.isWebGLRenderTarget)){Qt("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let je=A.get(D).__webglFramebuffer;if(D.isWebGLCubeRenderTarget&&Be!==void 0&&(je=je[Be]),je){We.bindFramebuffer(W.FRAMEBUFFER,je);try{const Ze=D.textures[Oe],mt=Ze.format,yt=Ze.type;if(D.textures.length>1&&W.readBuffer(W.COLOR_ATTACHMENT0+Oe),!ct.textureFormatReadable(mt)){Qt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!ct.textureTypeReadable(yt)){Qt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}Y>=0&&Y<=D.width-se&&ue>=0&&ue<=D.height-ae&&W.readPixels(Y,ue,se,ae,De.convert(mt),De.convert(yt),Ue)}finally{const Ze=$!==null?A.get($).__webglFramebuffer:null;We.bindFramebuffer(W.FRAMEBUFFER,Ze)}}},this.readRenderTargetPixelsAsync=async function(D,Y,ue,se,ae,Ue,Be,Oe=0){if(!(D&&D.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let je=A.get(D).__webglFramebuffer;if(D.isWebGLCubeRenderTarget&&Be!==void 0&&(je=je[Be]),je)if(Y>=0&&Y<=D.width-se&&ue>=0&&ue<=D.height-ae){We.bindFramebuffer(W.FRAMEBUFFER,je);const Ze=D.textures[Oe],mt=Ze.format,yt=Ze.type;if(D.textures.length>1&&W.readBuffer(W.COLOR_ATTACHMENT0+Oe),!ct.textureFormatReadable(mt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!ct.textureTypeReadable(yt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Qe=W.createBuffer();W.bindBuffer(W.PIXEL_PACK_BUFFER,Qe),W.bufferData(W.PIXEL_PACK_BUFFER,Ue.byteLength,W.STREAM_READ),W.readPixels(Y,ue,se,ae,De.convert(mt),De.convert(yt),0);const Rt=$!==null?A.get($).__webglFramebuffer:null;We.bindFramebuffer(W.FRAMEBUFFER,Rt);const Sn=W.fenceSync(W.SYNC_GPU_COMMANDS_COMPLETE,0);return W.flush(),await hR(W,Sn,4),W.bindBuffer(W.PIXEL_PACK_BUFFER,Qe),W.getBufferSubData(W.PIXEL_PACK_BUFFER,0,Ue),W.deleteBuffer(Qe),W.deleteSync(Sn),Ue}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(D,Y=null,ue=0){const se=Math.pow(2,-ue),ae=Math.floor(D.image.width*se),Ue=Math.floor(D.image.height*se),Be=Y!==null?Y.x:0,Oe=Y!==null?Y.y:0;Z.setTexture2D(D,0),W.copyTexSubImage2D(W.TEXTURE_2D,ue,0,0,Be,Oe,ae,Ue),We.unbindTexture()};const pi=W.createFramebuffer(),Sa=W.createFramebuffer();this.copyTextureToTexture=function(D,Y,ue=null,se=null,ae=0,Ue=0){let Be,Oe,je,Ze,mt,yt,Qe,Rt,Sn;const Mn=D.isCompressedTexture?D.mipmaps[Ue]:D.image;if(ue!==null)Be=ue.max.x-ue.min.x,Oe=ue.max.y-ue.min.y,je=ue.isBox3?ue.max.z-ue.min.z:1,Ze=ue.min.x,mt=ue.min.y,yt=ue.isBox3?ue.min.z:0;else{const Bn=Math.pow(2,-ae);Be=Math.floor(Mn.width*Bn),Oe=Math.floor(Mn.height*Bn),D.isDataArrayTexture?je=Mn.depth:D.isData3DTexture?je=Math.floor(Mn.depth*Bn):je=1,Ze=0,mt=0,yt=0}se!==null?(Qe=se.x,Rt=se.y,Sn=se.z):(Qe=0,Rt=0,Sn=0);const jt=De.convert(Y.format),jn=De.convert(Y.type);let nt;Y.isData3DTexture?(Z.setTexture3D(Y,0),nt=W.TEXTURE_3D):Y.isDataArrayTexture||Y.isCompressedArrayTexture?(Z.setTexture2DArray(Y,0),nt=W.TEXTURE_2D_ARRAY):(Z.setTexture2D(Y,0),nt=W.TEXTURE_2D),W.pixelStorei(W.UNPACK_FLIP_Y_WEBGL,Y.flipY),W.pixelStorei(W.UNPACK_PREMULTIPLY_ALPHA_WEBGL,Y.premultiplyAlpha),W.pixelStorei(W.UNPACK_ALIGNMENT,Y.unpackAlignment);const Ti=W.getParameter(W.UNPACK_ROW_LENGTH),vt=W.getParameter(W.UNPACK_IMAGE_HEIGHT),Ai=W.getParameter(W.UNPACK_SKIP_PIXELS),$i=W.getParameter(W.UNPACK_SKIP_ROWS),Va=W.getParameter(W.UNPACK_SKIP_IMAGES);W.pixelStorei(W.UNPACK_ROW_LENGTH,Mn.width),W.pixelStorei(W.UNPACK_IMAGE_HEIGHT,Mn.height),W.pixelStorei(W.UNPACK_SKIP_PIXELS,Ze),W.pixelStorei(W.UNPACK_SKIP_ROWS,mt),W.pixelStorei(W.UNPACK_SKIP_IMAGES,yt);const ea=D.isDataArrayTexture||D.isData3DTexture,$t=Y.isDataArrayTexture||Y.isData3DTexture;if(D.isDepthTexture){const Bn=A.get(D),Ri=A.get(Y),Hn=A.get(Bn.__renderTarget),ka=A.get(Ri.__renderTarget);We.bindFramebuffer(W.READ_FRAMEBUFFER,Hn.__webglFramebuffer),We.bindFramebuffer(W.DRAW_FRAMEBUFFER,ka.__webglFramebuffer);for(let br=0;br<je;br++)ea&&(W.framebufferTextureLayer(W.READ_FRAMEBUFFER,W.COLOR_ATTACHMENT0,A.get(D).__webglTexture,ae,yt+br),W.framebufferTextureLayer(W.DRAW_FRAMEBUFFER,W.COLOR_ATTACHMENT0,A.get(Y).__webglTexture,Ue,Sn+br)),W.blitFramebuffer(Ze,mt,Be,Oe,Qe,Rt,Be,Oe,W.DEPTH_BUFFER_BIT,W.NEAREST);We.bindFramebuffer(W.READ_FRAMEBUFFER,null),We.bindFramebuffer(W.DRAW_FRAMEBUFFER,null)}else if(ae!==0||D.isRenderTargetTexture||A.has(D)){const Bn=A.get(D),Ri=A.get(Y);We.bindFramebuffer(W.READ_FRAMEBUFFER,pi),We.bindFramebuffer(W.DRAW_FRAMEBUFFER,Sa);for(let Hn=0;Hn<je;Hn++)ea?W.framebufferTextureLayer(W.READ_FRAMEBUFFER,W.COLOR_ATTACHMENT0,Bn.__webglTexture,ae,yt+Hn):W.framebufferTexture2D(W.READ_FRAMEBUFFER,W.COLOR_ATTACHMENT0,W.TEXTURE_2D,Bn.__webglTexture,ae),$t?W.framebufferTextureLayer(W.DRAW_FRAMEBUFFER,W.COLOR_ATTACHMENT0,Ri.__webglTexture,Ue,Sn+Hn):W.framebufferTexture2D(W.DRAW_FRAMEBUFFER,W.COLOR_ATTACHMENT0,W.TEXTURE_2D,Ri.__webglTexture,Ue),ae!==0?W.blitFramebuffer(Ze,mt,Be,Oe,Qe,Rt,Be,Oe,W.COLOR_BUFFER_BIT,W.NEAREST):$t?W.copyTexSubImage3D(nt,Ue,Qe,Rt,Sn+Hn,Ze,mt,Be,Oe):W.copyTexSubImage2D(nt,Ue,Qe,Rt,Ze,mt,Be,Oe);We.bindFramebuffer(W.READ_FRAMEBUFFER,null),We.bindFramebuffer(W.DRAW_FRAMEBUFFER,null)}else $t?D.isDataTexture||D.isData3DTexture?W.texSubImage3D(nt,Ue,Qe,Rt,Sn,Be,Oe,je,jt,jn,Mn.data):Y.isCompressedArrayTexture?W.compressedTexSubImage3D(nt,Ue,Qe,Rt,Sn,Be,Oe,je,jt,Mn.data):W.texSubImage3D(nt,Ue,Qe,Rt,Sn,Be,Oe,je,jt,jn,Mn):D.isDataTexture?W.texSubImage2D(W.TEXTURE_2D,Ue,Qe,Rt,Be,Oe,jt,jn,Mn.data):D.isCompressedTexture?W.compressedTexSubImage2D(W.TEXTURE_2D,Ue,Qe,Rt,Mn.width,Mn.height,jt,Mn.data):W.texSubImage2D(W.TEXTURE_2D,Ue,Qe,Rt,Be,Oe,jt,jn,Mn);W.pixelStorei(W.UNPACK_ROW_LENGTH,Ti),W.pixelStorei(W.UNPACK_IMAGE_HEIGHT,vt),W.pixelStorei(W.UNPACK_SKIP_PIXELS,Ai),W.pixelStorei(W.UNPACK_SKIP_ROWS,$i),W.pixelStorei(W.UNPACK_SKIP_IMAGES,Va),Ue===0&&Y.generateMipmaps&&W.generateMipmap(nt),We.unbindTexture()},this.initRenderTarget=function(D){A.get(D).__webglFramebuffer===void 0&&Z.setupRenderTarget(D)},this.initTexture=function(D){D.isCubeTexture?Z.setTextureCube(D,0):D.isData3DTexture?Z.setTexture3D(D,0):D.isDataArrayTexture||D.isCompressedArrayTexture?Z.setTexture2DArray(D,0):Z.setTexture2D(D,0),We.unbindTexture()},this.resetState=function(){G=0,k=0,$=null,We.reset(),Ce.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return pr}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const n=this.getContext();n.drawingBufferColorSpace=Yt._getDrawingBufferColorSpace(e),n.unpackColorSpace=Yt._getUnpackColorSpace()}}function XD(){const o=Jn.useRef(null);return Jn.useEffect(()=>{if(!o.current)return;const e=o.current,n=window.innerWidth<768,a=new CR,r=new La(45,e.clientWidth/e.clientHeight,.1,1e3);r.position.z=4;const l=new kD({antialias:!n,alpha:!0});l.setSize(e.clientWidth,e.clientHeight),l.setPixelRatio(n?1:Math.min(window.devicePixelRatio,2)),e.appendChild(l.domElement);const c=new mc;a.add(c);const f=new dd(1.3,n?6:10,n?4:6),p=new Ga({uniforms:{color1:{value:new qt("#2196f3")},color2:{value:new qt("#b145e9")}},vertexShader:`
            varying vec3 vPos;
            void main() {
                vPos = position;
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
        `,fragmentShader:`
            uniform vec3 color1;
            uniform vec3 color2;
            varying vec3 vPos;
            void main() {
                // Gradient scaled to match the new 1.3 radius
                float mixValue = (vPos.y + 1.3) / 2.6; 
                gl_FragColor = vec4(mix(color1, color2, mixValue), 0.85); 
            }
        `,wireframe:!0,transparent:!0}),d=new Ga({uniforms:{color1:{value:new qt("#2196f3")},color2:{value:new qt("#b145e9")}},vertexShader:`
            varying vec3 vPos;
            void main() {
                vPos = position;
                vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
                // Node size reduced by ~45% (from 25.0 to 13.75)
                gl_PointSize = 13.75 * (5.0 / -mvPosition.z); 
                gl_Position = projectionMatrix * mvPosition;
            }
        `,fragmentShader:`
            uniform vec3 color1;
            uniform vec3 color2;
            varying vec3 vPos;
            void main() {
                // Draw a perfect circle mathematically
                vec2 cxy = 2.0 * gl_PointCoord - 1.0;
                if (dot(cxy, cxy) > 1.0) discard;
                
                float mixValue = (vPos.y + 1.3) / 2.6;
                gl_FragColor = vec4(mix(color1, color2, mixValue), 1.0);
            }
        `,transparent:!0}),_=new $a(f,p),v=new BR(f,d);c.add(_),c.add(v);const g=new dd(.3,16,16),x=new fg({color:58879}),M=new $a(g,x);c.add(M),c.rotation.z=.2,c.rotation.x=.3;let b,y=!0;const S=new IntersectionObserver(C=>{C.forEach(O=>{y=O.isIntersecting})});S.observe(e);function R(){b=requestAnimationFrame(R),y&&(c.rotation.y+=.003,c.rotation.x+=.001,l.render(a,r))}R();const N=()=>{e&&(r.aspect=e.clientWidth/e.clientHeight,r.updateProjectionMatrix(),l.setSize(e.clientWidth,e.clientHeight))};return window.addEventListener("resize",N),()=>{S.disconnect(),window.removeEventListener("resize",N),cancelAnimationFrame(b),e&&e.contains(l.domElement)&&e.removeChild(l.domElement),f.dispose(),g.dispose(),p.dispose(),d.dispose(),x.dispose(),l.dispose()}},[]),j.jsx("div",{ref:o,className:"w-full h-full absolute inset-0 pointer-events-none",style:{filter:"drop-shadow(0 0 30px rgba(176, 38, 255, 0.15))"}})}/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const WD=o=>o.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),YD=o=>o.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,n,a)=>a?a.toUpperCase():n.toLowerCase()),EM=o=>{const e=YD(o);return e.charAt(0).toUpperCase()+e.slice(1)},Y1=(...o)=>o.filter((e,n,a)=>!!e&&e.trim()!==""&&a.indexOf(e)===n).join(" ").trim(),qD=o=>{for(const e in o)if(e.startsWith("aria-")||e==="role"||e==="title")return!0};/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var jD={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ZD=Jn.forwardRef(({color:o="currentColor",size:e=24,strokeWidth:n=2,absoluteStrokeWidth:a,className:r="",children:l,iconNode:c,...f},p)=>Jn.createElement("svg",{ref:p,...jD,width:e,height:e,stroke:o,strokeWidth:a?Number(n)*24/Number(e):n,className:Y1("lucide",r),...!l&&!qD(f)&&{"aria-hidden":"true"},...f},[...c.map(([d,_])=>Jn.createElement(d,_)),...Array.isArray(l)?l:[l]]));/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ss=(o,e)=>{const n=Jn.forwardRef(({className:a,...r},l)=>Jn.createElement(ZD,{ref:l,iconNode:e,className:Y1(`lucide-${WD(EM(o))}`,`lucide-${o}`,a),...r}));return n.displayName=EM(o),n};/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const KD=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],TM=ss("arrow-right",KD);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const QD=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],JD=ss("chevron-right",QD);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const $D=[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]],eN=ss("code-xml",$D);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const tN=[["path",{d:"M4 5h16",key:"1tepv9"}],["path",{d:"M4 12h16",key:"1lakjw"}],["path",{d:"M4 19h16",key:"1djgab"}]],nN=ss("menu",tN);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const iN=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],aN=ss("shield-check",iN);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const rN=[["path",{d:"M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",key:"r04s7s"}]],or=ss("star",rN);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const sN=[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]],oN=ss("trending-up",sN);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const lN=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],AM=ss("x",lN);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const uN=[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]],cN=ss("zap",uN);function Yr(o){if(o===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return o}function q1(o,e){o.prototype=Object.create(e.prototype),o.prototype.constructor=o,o.__proto__=e}/*!
 * GSAP 3.14.2
 * https://gsap.com
 *
 * @license Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
*/var va={autoSleep:120,force3D:"auto",nullTargetWarn:1,units:{lineHeight:""}},ru={duration:.5,overwrite:!1,delay:0},hg,di,En,Fa=1e8,pn=1/Fa,D0=Math.PI*2,fN=D0/4,hN=0,j1=Math.sqrt,dN=Math.cos,pN=Math.sin,si=function(e){return typeof e=="string"},Nn=function(e){return typeof e=="function"},as=function(e){return typeof e=="number"},dg=function(e){return typeof e>"u"},Mr=function(e){return typeof e=="object"},ji=function(e){return e!==!1},pg=function(){return typeof window<"u"},Oh=function(e){return Nn(e)||si(e)},Z1=typeof ArrayBuffer=="function"&&ArrayBuffer.isView||function(){},bi=Array.isArray,mN=/random\([^)]+\)/g,_N=/,\s*/g,RM=/(?:-?\.?\d|\.)+/gi,K1=/[-+=.]*\d+[.e\-+]*\d*[e\-+]*\d*/g,kl=/[-+=.]*\d+[.e-]*\d*[a-z%]*/g,M_=/[-+=.]*\d+\.?\d*(?:e-|e\+)?\d*/gi,Q1=/[+-]=-?[.\d]+/,gN=/[^,'"\[\]\s]+/gi,vN=/^[+\-=e\s\d]*\d+[.\d]*([a-z]*|%)\s*$/i,Rn,lr,N0,mg,xa={},pd={},J1,$1=function(e){return(pd=su(e,xa))&&Ji},_g=function(e,n){return console.warn("Invalid property",e,"set to",n,"Missing plugin? gsap.registerPlugin()")},Hc=function(e,n){return!n&&console.warn(e)},eb=function(e,n){return e&&(xa[e]=n)&&pd&&(pd[e]=n)||xa},Gc=function(){return 0},xN={suppressEvents:!0,isStart:!0,kill:!1},ed={suppressEvents:!0,kill:!1},yN={suppressEvents:!0},gg={},Xs=[],U0={},tb,ha={},b_={},CM=30,td=[],vg="",xg=function(e){var n=e[0],a,r;if(Mr(n)||Nn(n)||(e=[e]),!(a=(n._gsap||{}).harness)){for(r=td.length;r--&&!td[r].targetTest(n););a=td[r]}for(r=e.length;r--;)e[r]&&(e[r]._gsap||(e[r]._gsap=new Tb(e[r],a)))||e.splice(r,1);return e},Oo=function(e){return e._gsap||xg(Ia(e))[0]._gsap},nb=function(e,n,a){return(a=e[n])&&Nn(a)?e[n]():dg(a)&&e.getAttribute&&e.getAttribute(n)||a},Zi=function(e,n){return(e=e.split(",")).forEach(n)||e},On=function(e){return Math.round(e*1e5)/1e5||0},An=function(e){return Math.round(e*1e7)/1e7||0},jl=function(e,n){var a=n.charAt(0),r=parseFloat(n.substr(2));return e=parseFloat(e),a==="+"?e+r:a==="-"?e-r:a==="*"?e*r:e/r},SN=function(e,n){for(var a=n.length,r=0;e.indexOf(n[r])<0&&++r<a;);return r<a},md=function(){var e=Xs.length,n=Xs.slice(0),a,r;for(U0={},Xs.length=0,a=0;a<e;a++)r=n[a],r&&r._lazy&&(r.render(r._lazy[0],r._lazy[1],!0)._lazy=0)},yg=function(e){return!!(e._initted||e._startAt||e.add)},ib=function(e,n,a,r){Xs.length&&!di&&md(),e.render(n,a,!!(di&&n<0&&yg(e))),Xs.length&&!di&&md()},ab=function(e){var n=parseFloat(e);return(n||n===0)&&(e+"").match(gN).length<2?n:si(e)?e.trim():e},rb=function(e){return e},ya=function(e,n){for(var a in n)a in e||(e[a]=n[a]);return e},MN=function(e){return function(n,a){for(var r in a)r in n||r==="duration"&&e||r==="ease"||(n[r]=a[r])}},su=function(e,n){for(var a in n)e[a]=n[a];return e},wM=function o(e,n){for(var a in n)a!=="__proto__"&&a!=="constructor"&&a!=="prototype"&&(e[a]=Mr(n[a])?o(e[a]||(e[a]={}),n[a]):n[a]);return e},_d=function(e,n){var a={},r;for(r in e)r in n||(a[r]=e[r]);return a},Ec=function(e){var n=e.parent||Rn,a=e.keyframes?MN(bi(e.keyframes)):ya;if(ji(e.inherit))for(;n;)a(e,n.vars.defaults),n=n.parent||n._dp;return e},bN=function(e,n){for(var a=e.length,r=a===n.length;r&&a--&&e[a]===n[a];);return a<0},sb=function(e,n,a,r,l){var c=e[r],f;if(l)for(f=n[l];c&&c[l]>f;)c=c._prev;return c?(n._next=c._next,c._next=n):(n._next=e[a],e[a]=n),n._next?n._next._prev=n:e[r]=n,n._prev=c,n.parent=n._dp=e,n},Dd=function(e,n,a,r){a===void 0&&(a="_first"),r===void 0&&(r="_last");var l=n._prev,c=n._next;l?l._next=c:e[a]===n&&(e[a]=c),c?c._prev=l:e[r]===n&&(e[r]=l),n._next=n._prev=n.parent=null},js=function(e,n){e.parent&&(!n||e.parent.autoRemoveChildren)&&e.parent.remove&&e.parent.remove(e),e._act=0},Po=function(e,n){if(e&&(!n||n._end>e._dur||n._start<0))for(var a=e;a;)a._dirty=1,a=a.parent;return e},EN=function(e){for(var n=e.parent;n&&n.parent;)n._dirty=1,n.totalDuration(),n=n.parent;return e},L0=function(e,n,a,r){return e._startAt&&(di?e._startAt.revert(ed):e.vars.immediateRender&&!e.vars.autoRevert||e._startAt.render(n,!0,r))},TN=function o(e){return!e||e._ts&&o(e.parent)},DM=function(e){return e._repeat?ou(e._tTime,e=e.duration()+e._rDelay)*e:0},ou=function(e,n){var a=Math.floor(e=An(e/n));return e&&a===e?a-1:a},gd=function(e,n){return(e-n._start)*n._ts+(n._ts>=0?0:n._dirty?n.totalDuration():n._tDur)},Nd=function(e){return e._end=An(e._start+(e._tDur/Math.abs(e._ts||e._rts||pn)||0))},Ud=function(e,n){var a=e._dp;return a&&a.smoothChildTiming&&e._ts&&(e._start=An(a._time-(e._ts>0?n/e._ts:((e._dirty?e.totalDuration():e._tDur)-n)/-e._ts)),Nd(e),a._dirty||Po(a,e)),e},ob=function(e,n){var a;if((n._time||!n._dur&&n._initted||n._start<e._time&&(n._dur||!n.add))&&(a=gd(e.rawTime(),n),(!n._dur||$c(0,n.totalDuration(),a)-n._tTime>pn)&&n.render(a,!0)),Po(e,n)._dp&&e._initted&&e._time>=e._dur&&e._ts){if(e._dur<e.duration())for(a=e;a._dp;)a.rawTime()>=0&&a.totalTime(a._tTime),a=a._dp;e._zTime=-pn}},hr=function(e,n,a,r){return n.parent&&js(n),n._start=An((as(a)?a:a||e!==Rn?Na(e,a,n):e._time)+n._delay),n._end=An(n._start+(n.totalDuration()/Math.abs(n.timeScale())||0)),sb(e,n,"_first","_last",e._sort?"_start":0),O0(n)||(e._recent=n),r||ob(e,n),e._ts<0&&Ud(e,e._tTime),e},lb=function(e,n){return(xa.ScrollTrigger||_g("scrollTrigger",n))&&xa.ScrollTrigger.create(n,e)},ub=function(e,n,a,r,l){if(Mg(e,n,l),!e._initted)return 1;if(!a&&e._pt&&!di&&(e._dur&&e.vars.lazy!==!1||!e._dur&&e.vars.lazy)&&tb!==pa.frame)return Xs.push(e),e._lazy=[l,r],1},AN=function o(e){var n=e.parent;return n&&n._ts&&n._initted&&!n._lock&&(n.rawTime()<0||o(n))},O0=function(e){var n=e.data;return n==="isFromStart"||n==="isStart"},RN=function(e,n,a,r){var l=e.ratio,c=n<0||!n&&(!e._start&&AN(e)&&!(!e._initted&&O0(e))||(e._ts<0||e._dp._ts<0)&&!O0(e))?0:1,f=e._rDelay,p=0,d,_,v;if(f&&e._repeat&&(p=$c(0,e._tDur,n),_=ou(p,f),e._yoyo&&_&1&&(c=1-c),_!==ou(e._tTime,f)&&(l=1-c,e.vars.repeatRefresh&&e._initted&&e.invalidate())),c!==l||di||r||e._zTime===pn||!n&&e._zTime){if(!e._initted&&ub(e,n,r,a,p))return;for(v=e._zTime,e._zTime=n||(a?pn:0),a||(a=n&&!v),e.ratio=c,e._from&&(c=1-c),e._time=0,e._tTime=p,d=e._pt;d;)d.r(c,d.d),d=d._next;n<0&&L0(e,n,a,!0),e._onUpdate&&!a&&_a(e,"onUpdate"),p&&e._repeat&&!a&&e.parent&&_a(e,"onRepeat"),(n>=e._tDur||n<0)&&e.ratio===c&&(c&&js(e,1),!a&&!di&&(_a(e,c?"onComplete":"onReverseComplete",!0),e._prom&&e._prom()))}else e._zTime||(e._zTime=n)},CN=function(e,n,a){var r;if(a>n)for(r=e._first;r&&r._start<=a;){if(r.data==="isPause"&&r._start>n)return r;r=r._next}else for(r=e._last;r&&r._start>=a;){if(r.data==="isPause"&&r._start<n)return r;r=r._prev}},lu=function(e,n,a,r){var l=e._repeat,c=An(n)||0,f=e._tTime/e._tDur;return f&&!r&&(e._time*=c/e._dur),e._dur=c,e._tDur=l?l<0?1e10:An(c*(l+1)+e._rDelay*l):c,f>0&&!r&&Ud(e,e._tTime=e._tDur*f),e.parent&&Nd(e),a||Po(e.parent,e),e},NM=function(e){return e instanceof Pi?Po(e):lu(e,e._dur)},wN={_start:0,endTime:Gc,totalDuration:Gc},Na=function o(e,n,a){var r=e.labels,l=e._recent||wN,c=e.duration()>=Fa?l.endTime(!1):e._dur,f,p,d;return si(n)&&(isNaN(n)||n in r)?(p=n.charAt(0),d=n.substr(-1)==="%",f=n.indexOf("="),p==="<"||p===">"?(f>=0&&(n=n.replace(/=/,"")),(p==="<"?l._start:l.endTime(l._repeat>=0))+(parseFloat(n.substr(1))||0)*(d?(f<0?l:a).totalDuration()/100:1)):f<0?(n in r||(r[n]=c),r[n]):(p=parseFloat(n.charAt(f-1)+n.substr(f+1)),d&&a&&(p=p/100*(bi(a)?a[0]:a).totalDuration()),f>1?o(e,n.substr(0,f-1),a)+p:c+p)):n==null?c:+n},Tc=function(e,n,a){var r=as(n[1]),l=(r?2:1)+(e<2?0:1),c=n[l],f,p;if(r&&(c.duration=n[1]),c.parent=a,e){for(f=c,p=a;p&&!("immediateRender"in f);)f=p.vars.defaults||{},p=ji(p.vars.inherit)&&p.parent;c.immediateRender=ji(f.immediateRender),e<2?c.runBackwards=1:c.startAt=n[l-1]}return new qn(n[0],c,n[l+1])},Js=function(e,n){return e||e===0?n(e):n},$c=function(e,n,a){return a<e?e:a>n?n:a},yi=function(e,n){return!si(e)||!(n=vN.exec(e))?"":n[1]},DN=function(e,n,a){return Js(a,function(r){return $c(e,n,r)})},P0=[].slice,cb=function(e,n){return e&&Mr(e)&&"length"in e&&(!n&&!e.length||e.length-1 in e&&Mr(e[0]))&&!e.nodeType&&e!==lr},NN=function(e,n,a){return a===void 0&&(a=[]),e.forEach(function(r){var l;return si(r)&&!n||cb(r,1)?(l=a).push.apply(l,Ia(r)):a.push(r)})||a},Ia=function(e,n,a){return En&&!n&&En.selector?En.selector(e):si(e)&&!a&&(N0||!uu())?P0.call((n||mg).querySelectorAll(e),0):bi(e)?NN(e,a):cb(e)?P0.call(e,0):e?[e]:[]},z0=function(e){return e=Ia(e)[0]||Hc("Invalid scope")||{},function(n){var a=e.current||e.nativeElement||e;return Ia(n,a.querySelectorAll?a:a===e?Hc("Invalid scope")||mg.createElement("div"):e)}},fb=function(e){return e.sort(function(){return .5-Math.random()})},hb=function(e){if(Nn(e))return e;var n=Mr(e)?e:{each:e},a=zo(n.ease),r=n.from||0,l=parseFloat(n.base)||0,c={},f=r>0&&r<1,p=isNaN(r)||f,d=n.axis,_=r,v=r;return si(r)?_=v={center:.5,edges:.5,end:1}[r]||0:!f&&p&&(_=r[0],v=r[1]),function(g,x,M){var b=(M||n).length,y=c[b],S,R,N,C,O,P,L,T,w;if(!y){if(w=n.grid==="auto"?0:(n.grid||[1,Fa])[1],!w){for(L=-Fa;L<(L=M[w++].getBoundingClientRect().left)&&w<b;);w<b&&w--}for(y=c[b]=[],S=p?Math.min(w,b)*_-.5:r%w,R=w===Fa?0:p?b*v/w-.5:r/w|0,L=0,T=Fa,P=0;P<b;P++)N=P%w-S,C=R-(P/w|0),y[P]=O=d?Math.abs(d==="y"?C:N):j1(N*N+C*C),O>L&&(L=O),O<T&&(T=O);r==="random"&&fb(y),y.max=L-T,y.min=T,y.v=b=(parseFloat(n.amount)||parseFloat(n.each)*(w>b?b-1:d?d==="y"?b/w:w:Math.max(w,b/w))||0)*(r==="edges"?-1:1),y.b=b<0?l-b:l,y.u=yi(n.amount||n.each)||0,a=a&&b<0?Mb(a):a}return b=(y[g]-y.min)/y.max||0,An(y.b+(a?a(b):b)*y.v)+y.u}},F0=function(e){var n=Math.pow(10,((e+"").split(".")[1]||"").length);return function(a){var r=An(Math.round(parseFloat(a)/e)*e*n);return(r-r%1)/n+(as(a)?0:yi(a))}},db=function(e,n){var a=bi(e),r,l;return!a&&Mr(e)&&(r=a=e.radius||Fa,e.values?(e=Ia(e.values),(l=!as(e[0]))&&(r*=r)):e=F0(e.increment)),Js(n,a?Nn(e)?function(c){return l=e(c),Math.abs(l-c)<=r?l:c}:function(c){for(var f=parseFloat(l?c.x:c),p=parseFloat(l?c.y:0),d=Fa,_=0,v=e.length,g,x;v--;)l?(g=e[v].x-f,x=e[v].y-p,g=g*g+x*x):g=Math.abs(e[v]-f),g<d&&(d=g,_=v);return _=!r||d<=r?e[_]:c,l||_===c||as(c)?_:_+yi(c)}:F0(e))},pb=function(e,n,a,r){return Js(bi(e)?!n:a===!0?!!(a=0):!r,function(){return bi(e)?e[~~(Math.random()*e.length)]:(a=a||1e-5)&&(r=a<1?Math.pow(10,(a+"").length-2):1)&&Math.floor(Math.round((e-a/2+Math.random()*(n-e+a*.99))/a)*a*r)/r})},UN=function(){for(var e=arguments.length,n=new Array(e),a=0;a<e;a++)n[a]=arguments[a];return function(r){return n.reduce(function(l,c){return c(l)},r)}},LN=function(e,n){return function(a){return e(parseFloat(a))+(n||yi(a))}},ON=function(e,n,a){return _b(e,n,0,1,a)},mb=function(e,n,a){return Js(a,function(r){return e[~~n(r)]})},PN=function o(e,n,a){var r=n-e;return bi(e)?mb(e,o(0,e.length),n):Js(a,function(l){return(r+(l-e)%r)%r+e})},zN=function o(e,n,a){var r=n-e,l=r*2;return bi(e)?mb(e,o(0,e.length-1),n):Js(a,function(c){return c=(l+(c-e)%l)%l||0,e+(c>r?l-c:c)})},Vc=function(e){return e.replace(mN,function(n){var a=n.indexOf("[")+1,r=n.substring(a||7,a?n.indexOf("]"):n.length-1).split(_N);return pb(a?r:+r[0],a?0:+r[1],+r[2]||1e-5)})},_b=function(e,n,a,r,l){var c=n-e,f=r-a;return Js(l,function(p){return a+((p-e)/c*f||0)})},FN=function o(e,n,a,r){var l=isNaN(e+n)?0:function(x){return(1-x)*e+x*n};if(!l){var c=si(e),f={},p,d,_,v,g;if(a===!0&&(r=1)&&(a=null),c)e={p:e},n={p:n};else if(bi(e)&&!bi(n)){for(_=[],v=e.length,g=v-2,d=1;d<v;d++)_.push(o(e[d-1],e[d]));v--,l=function(M){M*=v;var b=Math.min(g,~~M);return _[b](M-b)},a=n}else r||(e=su(bi(e)?[]:{},e));if(!_){for(p in n)Sg.call(f,e,p,"get",n[p]);l=function(M){return Tg(M,f)||(c?e.p:e)}}}return Js(a,l)},UM=function(e,n,a){var r=e.labels,l=Fa,c,f,p;for(c in r)f=r[c]-n,f<0==!!a&&f&&l>(f=Math.abs(f))&&(p=c,l=f);return p},_a=function(e,n,a){var r=e.vars,l=r[n],c=En,f=e._ctx,p,d,_;if(l)return p=r[n+"Params"],d=r.callbackScope||e,a&&Xs.length&&md(),f&&(En=f),_=p?l.apply(d,p):l.call(d),En=c,_},gc=function(e){return js(e),e.scrollTrigger&&e.scrollTrigger.kill(!!di),e.progress()<1&&_a(e,"onInterrupt"),e},Xl,gb=[],vb=function(e){if(e)if(e=!e.name&&e.default||e,pg()||e.headless){var n=e.name,a=Nn(e),r=n&&!a&&e.init?function(){this._props=[]}:e,l={init:Gc,render:Tg,add:Sg,kill:$N,modifier:JN,rawVars:0},c={targetTest:0,get:0,getSetter:Eg,aliases:{},register:0};if(uu(),e!==r){if(ha[n])return;ya(r,ya(_d(e,l),c)),su(r.prototype,su(l,_d(e,c))),ha[r.prop=n]=r,e.targetTest&&(td.push(r),gg[n]=1),n=(n==="css"?"CSS":n.charAt(0).toUpperCase()+n.substr(1))+"Plugin"}eb(n,r),e.register&&e.register(Ji,r,Ki)}else gb.push(e)},dn=255,vc={aqua:[0,dn,dn],lime:[0,dn,0],silver:[192,192,192],black:[0,0,0],maroon:[128,0,0],teal:[0,128,128],blue:[0,0,dn],navy:[0,0,128],white:[dn,dn,dn],olive:[128,128,0],yellow:[dn,dn,0],orange:[dn,165,0],gray:[128,128,128],purple:[128,0,128],green:[0,128,0],red:[dn,0,0],pink:[dn,192,203],cyan:[0,dn,dn],transparent:[dn,dn,dn,0]},E_=function(e,n,a){return e+=e<0?1:e>1?-1:0,(e*6<1?n+(a-n)*e*6:e<.5?a:e*3<2?n+(a-n)*(2/3-e)*6:n)*dn+.5|0},xb=function(e,n,a){var r=e?as(e)?[e>>16,e>>8&dn,e&dn]:0:vc.black,l,c,f,p,d,_,v,g,x,M;if(!r){if(e.substr(-1)===","&&(e=e.substr(0,e.length-1)),vc[e])r=vc[e];else if(e.charAt(0)==="#"){if(e.length<6&&(l=e.charAt(1),c=e.charAt(2),f=e.charAt(3),e="#"+l+l+c+c+f+f+(e.length===5?e.charAt(4)+e.charAt(4):"")),e.length===9)return r=parseInt(e.substr(1,6),16),[r>>16,r>>8&dn,r&dn,parseInt(e.substr(7),16)/255];e=parseInt(e.substr(1),16),r=[e>>16,e>>8&dn,e&dn]}else if(e.substr(0,3)==="hsl"){if(r=M=e.match(RM),!n)p=+r[0]%360/360,d=+r[1]/100,_=+r[2]/100,c=_<=.5?_*(d+1):_+d-_*d,l=_*2-c,r.length>3&&(r[3]*=1),r[0]=E_(p+1/3,l,c),r[1]=E_(p,l,c),r[2]=E_(p-1/3,l,c);else if(~e.indexOf("="))return r=e.match(K1),a&&r.length<4&&(r[3]=1),r}else r=e.match(RM)||vc.transparent;r=r.map(Number)}return n&&!M&&(l=r[0]/dn,c=r[1]/dn,f=r[2]/dn,v=Math.max(l,c,f),g=Math.min(l,c,f),_=(v+g)/2,v===g?p=d=0:(x=v-g,d=_>.5?x/(2-v-g):x/(v+g),p=v===l?(c-f)/x+(c<f?6:0):v===c?(f-l)/x+2:(l-c)/x+4,p*=60),r[0]=~~(p+.5),r[1]=~~(d*100+.5),r[2]=~~(_*100+.5)),a&&r.length<4&&(r[3]=1),r},yb=function(e){var n=[],a=[],r=-1;return e.split(Ws).forEach(function(l){var c=l.match(kl)||[];n.push.apply(n,c),a.push(r+=c.length+1)}),n.c=a,n},LM=function(e,n,a){var r="",l=(e+r).match(Ws),c=n?"hsla(":"rgba(",f=0,p,d,_,v;if(!l)return e;if(l=l.map(function(g){return(g=xb(g,n,1))&&c+(n?g[0]+","+g[1]+"%,"+g[2]+"%,"+g[3]:g.join(","))+")"}),a&&(_=yb(e),p=a.c,p.join(r)!==_.c.join(r)))for(d=e.replace(Ws,"1").split(kl),v=d.length-1;f<v;f++)r+=d[f]+(~p.indexOf(f)?l.shift()||c+"0,0,0,0)":(_.length?_:l.length?l:a).shift());if(!d)for(d=e.split(Ws),v=d.length-1;f<v;f++)r+=d[f]+l[f];return r+d[v]},Ws=(function(){var o="(?:\\b(?:(?:rgb|rgba|hsl|hsla)\\(.+?\\))|\\B#(?:[0-9a-f]{3,4}){1,2}\\b",e;for(e in vc)o+="|"+e+"\\b";return new RegExp(o+")","gi")})(),IN=/hsl[a]?\(/,Sb=function(e){var n=e.join(" "),a;if(Ws.lastIndex=0,Ws.test(n))return a=IN.test(n),e[1]=LM(e[1],a),e[0]=LM(e[0],a,yb(e[1])),!0},kc,pa=(function(){var o=Date.now,e=500,n=33,a=o(),r=a,l=1e3/240,c=l,f=[],p,d,_,v,g,x,M=function b(y){var S=o()-r,R=y===!0,N,C,O,P;if((S>e||S<0)&&(a+=S-n),r+=S,O=r-a,N=O-c,(N>0||R)&&(P=++v.frame,g=O-v.time*1e3,v.time=O=O/1e3,c+=N+(N>=l?4:l-N),C=1),R||(p=d(b)),C)for(x=0;x<f.length;x++)f[x](O,g,P,y)};return v={time:0,frame:0,tick:function(){M(!0)},deltaRatio:function(y){return g/(1e3/(y||60))},wake:function(){J1&&(!N0&&pg()&&(lr=N0=window,mg=lr.document||{},xa.gsap=Ji,(lr.gsapVersions||(lr.gsapVersions=[])).push(Ji.version),$1(pd||lr.GreenSockGlobals||!lr.gsap&&lr||{}),gb.forEach(vb)),_=typeof requestAnimationFrame<"u"&&requestAnimationFrame,p&&v.sleep(),d=_||function(y){return setTimeout(y,c-v.time*1e3+1|0)},kc=1,M(2))},sleep:function(){(_?cancelAnimationFrame:clearTimeout)(p),kc=0,d=Gc},lagSmoothing:function(y,S){e=y||1/0,n=Math.min(S||33,e)},fps:function(y){l=1e3/(y||240),c=v.time*1e3+l},add:function(y,S,R){var N=S?function(C,O,P,L){y(C,O,P,L),v.remove(N)}:y;return v.remove(y),f[R?"unshift":"push"](N),uu(),N},remove:function(y,S){~(S=f.indexOf(y))&&f.splice(S,1)&&x>=S&&x--},_listeners:f},v})(),uu=function(){return!kc&&pa.wake()},Xt={},BN=/^[\d.\-M][\d.\-,\s]/,HN=/["']/g,GN=function(e){for(var n={},a=e.substr(1,e.length-3).split(":"),r=a[0],l=1,c=a.length,f,p,d;l<c;l++)p=a[l],f=l!==c-1?p.lastIndexOf(","):p.length,d=p.substr(0,f),n[r]=isNaN(d)?d.replace(HN,"").trim():+d,r=p.substr(f+1).trim();return n},VN=function(e){var n=e.indexOf("(")+1,a=e.indexOf(")"),r=e.indexOf("(",n);return e.substring(n,~r&&r<a?e.indexOf(")",a+1):a)},kN=function(e){var n=(e+"").split("("),a=Xt[n[0]];return a&&n.length>1&&a.config?a.config.apply(null,~e.indexOf("{")?[GN(n[1])]:VN(e).split(",").map(ab)):Xt._CE&&BN.test(e)?Xt._CE("",e):a},Mb=function(e){return function(n){return 1-e(1-n)}},bb=function o(e,n){for(var a=e._first,r;a;)a instanceof Pi?o(a,n):a.vars.yoyoEase&&(!a._yoyo||!a._repeat)&&a._yoyo!==n&&(a.timeline?o(a.timeline,n):(r=a._ease,a._ease=a._yEase,a._yEase=r,a._yoyo=n)),a=a._next},zo=function(e,n){return e&&(Nn(e)?e:Xt[e]||kN(e))||n},Wo=function(e,n,a,r){a===void 0&&(a=function(p){return 1-n(1-p)}),r===void 0&&(r=function(p){return p<.5?n(p*2)/2:1-n((1-p)*2)/2});var l={easeIn:n,easeOut:a,easeInOut:r},c;return Zi(e,function(f){Xt[f]=xa[f]=l,Xt[c=f.toLowerCase()]=a;for(var p in l)Xt[c+(p==="easeIn"?".in":p==="easeOut"?".out":".inOut")]=Xt[f+"."+p]=l[p]}),l},Eb=function(e){return function(n){return n<.5?(1-e(1-n*2))/2:.5+e((n-.5)*2)/2}},T_=function o(e,n,a){var r=n>=1?n:1,l=(a||(e?.3:.45))/(n<1?n:1),c=l/D0*(Math.asin(1/r)||0),f=function(_){return _===1?1:r*Math.pow(2,-10*_)*pN((_-c)*l)+1},p=e==="out"?f:e==="in"?function(d){return 1-f(1-d)}:Eb(f);return l=D0/l,p.config=function(d,_){return o(e,d,_)},p},A_=function o(e,n){n===void 0&&(n=1.70158);var a=function(c){return c?--c*c*((n+1)*c+n)+1:0},r=e==="out"?a:e==="in"?function(l){return 1-a(1-l)}:Eb(a);return r.config=function(l){return o(e,l)},r};Zi("Linear,Quad,Cubic,Quart,Quint,Strong",function(o,e){var n=e<5?e+1:e;Wo(o+",Power"+(n-1),e?function(a){return Math.pow(a,n)}:function(a){return a},function(a){return 1-Math.pow(1-a,n)},function(a){return a<.5?Math.pow(a*2,n)/2:1-Math.pow((1-a)*2,n)/2})});Xt.Linear.easeNone=Xt.none=Xt.Linear.easeIn;Wo("Elastic",T_("in"),T_("out"),T_());(function(o,e){var n=1/e,a=2*n,r=2.5*n,l=function(f){return f<n?o*f*f:f<a?o*Math.pow(f-1.5/e,2)+.75:f<r?o*(f-=2.25/e)*f+.9375:o*Math.pow(f-2.625/e,2)+.984375};Wo("Bounce",function(c){return 1-l(1-c)},l)})(7.5625,2.75);Wo("Expo",function(o){return Math.pow(2,10*(o-1))*o+o*o*o*o*o*o*(1-o)});Wo("Circ",function(o){return-(j1(1-o*o)-1)});Wo("Sine",function(o){return o===1?1:-dN(o*fN)+1});Wo("Back",A_("in"),A_("out"),A_());Xt.SteppedEase=Xt.steps=xa.SteppedEase={config:function(e,n){e===void 0&&(e=1);var a=1/e,r=e+(n?0:1),l=n?1:0,c=1-pn;return function(f){return((r*$c(0,c,f)|0)+l)*a}}};ru.ease=Xt["quad.out"];Zi("onComplete,onUpdate,onStart,onRepeat,onReverseComplete,onInterrupt",function(o){return vg+=o+","+o+"Params,"});var Tb=function(e,n){this.id=hN++,e._gsap=this,this.target=e,this.harness=n,this.get=n?n.get:nb,this.set=n?n.getSetter:Eg},Xc=(function(){function o(n){this.vars=n,this._delay=+n.delay||0,(this._repeat=n.repeat===1/0?-2:n.repeat||0)&&(this._rDelay=n.repeatDelay||0,this._yoyo=!!n.yoyo||!!n.yoyoEase),this._ts=1,lu(this,+n.duration,1,1),this.data=n.data,En&&(this._ctx=En,En.data.push(this)),kc||pa.wake()}var e=o.prototype;return e.delay=function(a){return a||a===0?(this.parent&&this.parent.smoothChildTiming&&this.startTime(this._start+a-this._delay),this._delay=a,this):this._delay},e.duration=function(a){return arguments.length?this.totalDuration(this._repeat>0?a+(a+this._rDelay)*this._repeat:a):this.totalDuration()&&this._dur},e.totalDuration=function(a){return arguments.length?(this._dirty=0,lu(this,this._repeat<0?a:(a-this._repeat*this._rDelay)/(this._repeat+1))):this._tDur},e.totalTime=function(a,r){if(uu(),!arguments.length)return this._tTime;var l=this._dp;if(l&&l.smoothChildTiming&&this._ts){for(Ud(this,a),!l._dp||l.parent||ob(l,this);l&&l.parent;)l.parent._time!==l._start+(l._ts>=0?l._tTime/l._ts:(l.totalDuration()-l._tTime)/-l._ts)&&l.totalTime(l._tTime,!0),l=l.parent;!this.parent&&this._dp.autoRemoveChildren&&(this._ts>0&&a<this._tDur||this._ts<0&&a>0||!this._tDur&&!a)&&hr(this._dp,this,this._start-this._delay)}return(this._tTime!==a||!this._dur&&!r||this._initted&&Math.abs(this._zTime)===pn||!this._initted&&this._dur&&a||!a&&!this._initted&&(this.add||this._ptLookup))&&(this._ts||(this._pTime=a),ib(this,a,r)),this},e.time=function(a,r){return arguments.length?this.totalTime(Math.min(this.totalDuration(),a+DM(this))%(this._dur+this._rDelay)||(a?this._dur:0),r):this._time},e.totalProgress=function(a,r){return arguments.length?this.totalTime(this.totalDuration()*a,r):this.totalDuration()?Math.min(1,this._tTime/this._tDur):this.rawTime()>=0&&this._initted?1:0},e.progress=function(a,r){return arguments.length?this.totalTime(this.duration()*(this._yoyo&&!(this.iteration()&1)?1-a:a)+DM(this),r):this.duration()?Math.min(1,this._time/this._dur):this.rawTime()>0?1:0},e.iteration=function(a,r){var l=this.duration()+this._rDelay;return arguments.length?this.totalTime(this._time+(a-1)*l,r):this._repeat?ou(this._tTime,l)+1:1},e.timeScale=function(a,r){if(!arguments.length)return this._rts===-pn?0:this._rts;if(this._rts===a)return this;var l=this.parent&&this._ts?gd(this.parent._time,this):this._tTime;return this._rts=+a||0,this._ts=this._ps||a===-pn?0:this._rts,this.totalTime($c(-Math.abs(this._delay),this.totalDuration(),l),r!==!1),Nd(this),EN(this)},e.paused=function(a){return arguments.length?(this._ps!==a&&(this._ps=a,a?(this._pTime=this._tTime||Math.max(-this._delay,this.rawTime()),this._ts=this._act=0):(uu(),this._ts=this._rts,this.totalTime(this.parent&&!this.parent.smoothChildTiming?this.rawTime():this._tTime||this._pTime,this.progress()===1&&Math.abs(this._zTime)!==pn&&(this._tTime-=pn)))),this):this._ps},e.startTime=function(a){if(arguments.length){this._start=An(a);var r=this.parent||this._dp;return r&&(r._sort||!this.parent)&&hr(r,this,this._start-this._delay),this}return this._start},e.endTime=function(a){return this._start+(ji(a)?this.totalDuration():this.duration())/Math.abs(this._ts||1)},e.rawTime=function(a){var r=this.parent||this._dp;return r?a&&(!this._ts||this._repeat&&this._time&&this.totalProgress()<1)?this._tTime%(this._dur+this._rDelay):this._ts?gd(r.rawTime(a),this):this._tTime:this._tTime},e.revert=function(a){a===void 0&&(a=yN);var r=di;return di=a,yg(this)&&(this.timeline&&this.timeline.revert(a),this.totalTime(-.01,a.suppressEvents)),this.data!=="nested"&&a.kill!==!1&&this.kill(),di=r,this},e.globalTime=function(a){for(var r=this,l=arguments.length?a:r.rawTime();r;)l=r._start+l/(Math.abs(r._ts)||1),r=r._dp;return!this.parent&&this._sat?this._sat.globalTime(a):l},e.repeat=function(a){return arguments.length?(this._repeat=a===1/0?-2:a,NM(this)):this._repeat===-2?1/0:this._repeat},e.repeatDelay=function(a){if(arguments.length){var r=this._time;return this._rDelay=a,NM(this),r?this.time(r):this}return this._rDelay},e.yoyo=function(a){return arguments.length?(this._yoyo=a,this):this._yoyo},e.seek=function(a,r){return this.totalTime(Na(this,a),ji(r))},e.restart=function(a,r){return this.play().totalTime(a?-this._delay:0,ji(r)),this._dur||(this._zTime=-pn),this},e.play=function(a,r){return a!=null&&this.seek(a,r),this.reversed(!1).paused(!1)},e.reverse=function(a,r){return a!=null&&this.seek(a||this.totalDuration(),r),this.reversed(!0).paused(!1)},e.pause=function(a,r){return a!=null&&this.seek(a,r),this.paused(!0)},e.resume=function(){return this.paused(!1)},e.reversed=function(a){return arguments.length?(!!a!==this.reversed()&&this.timeScale(-this._rts||(a?-pn:0)),this):this._rts<0},e.invalidate=function(){return this._initted=this._act=0,this._zTime=-pn,this},e.isActive=function(){var a=this.parent||this._dp,r=this._start,l;return!!(!a||this._ts&&this._initted&&a.isActive()&&(l=a.rawTime(!0))>=r&&l<this.endTime(!0)-pn)},e.eventCallback=function(a,r,l){var c=this.vars;return arguments.length>1?(r?(c[a]=r,l&&(c[a+"Params"]=l),a==="onUpdate"&&(this._onUpdate=r)):delete c[a],this):c[a]},e.then=function(a){var r=this,l=r._prom;return new Promise(function(c){var f=Nn(a)?a:rb,p=function(){var _=r.then;r.then=null,l&&l(),Nn(f)&&(f=f(r))&&(f.then||f===r)&&(r.then=_),c(f),r.then=_};r._initted&&r.totalProgress()===1&&r._ts>=0||!r._tTime&&r._ts<0?p():r._prom=p})},e.kill=function(){gc(this)},o})();ya(Xc.prototype,{_time:0,_start:0,_end:0,_tTime:0,_tDur:0,_dirty:0,_repeat:0,_yoyo:!1,parent:null,_initted:!1,_rDelay:0,_ts:1,_dp:0,ratio:0,_zTime:-pn,_prom:0,_ps:!1,_rts:1});var Pi=(function(o){q1(e,o);function e(a,r){var l;return a===void 0&&(a={}),l=o.call(this,a)||this,l.labels={},l.smoothChildTiming=!!a.smoothChildTiming,l.autoRemoveChildren=!!a.autoRemoveChildren,l._sort=ji(a.sortChildren),Rn&&hr(a.parent||Rn,Yr(l),r),a.reversed&&l.reverse(),a.paused&&l.paused(!0),a.scrollTrigger&&lb(Yr(l),a.scrollTrigger),l}var n=e.prototype;return n.to=function(r,l,c){return Tc(0,arguments,this),this},n.from=function(r,l,c){return Tc(1,arguments,this),this},n.fromTo=function(r,l,c,f){return Tc(2,arguments,this),this},n.set=function(r,l,c){return l.duration=0,l.parent=this,Ec(l).repeatDelay||(l.repeat=0),l.immediateRender=!!l.immediateRender,new qn(r,l,Na(this,c),1),this},n.call=function(r,l,c){return hr(this,qn.delayedCall(0,r,l),c)},n.staggerTo=function(r,l,c,f,p,d,_){return c.duration=l,c.stagger=c.stagger||f,c.onComplete=d,c.onCompleteParams=_,c.parent=this,new qn(r,c,Na(this,p)),this},n.staggerFrom=function(r,l,c,f,p,d,_){return c.runBackwards=1,Ec(c).immediateRender=ji(c.immediateRender),this.staggerTo(r,l,c,f,p,d,_)},n.staggerFromTo=function(r,l,c,f,p,d,_,v){return f.startAt=c,Ec(f).immediateRender=ji(f.immediateRender),this.staggerTo(r,l,f,p,d,_,v)},n.render=function(r,l,c){var f=this._time,p=this._dirty?this.totalDuration():this._tDur,d=this._dur,_=r<=0?0:An(r),v=this._zTime<0!=r<0&&(this._initted||!d),g,x,M,b,y,S,R,N,C,O,P,L;if(this!==Rn&&_>p&&r>=0&&(_=p),_!==this._tTime||c||v){if(f!==this._time&&d&&(_+=this._time-f,r+=this._time-f),g=_,C=this._start,N=this._ts,S=!N,v&&(d||(f=this._zTime),(r||!l)&&(this._zTime=r)),this._repeat){if(P=this._yoyo,y=d+this._rDelay,this._repeat<-1&&r<0)return this.totalTime(y*100+r,l,c);if(g=An(_%y),_===p?(b=this._repeat,g=d):(O=An(_/y),b=~~O,b&&b===O&&(g=d,b--),g>d&&(g=d)),O=ou(this._tTime,y),!f&&this._tTime&&O!==b&&this._tTime-O*y-this._dur<=0&&(O=b),P&&b&1&&(g=d-g,L=1),b!==O&&!this._lock){var T=P&&O&1,w=T===(P&&b&1);if(b<O&&(T=!T),f=T?0:_%d?d:_,this._lock=1,this.render(f||(L?0:An(b*y)),l,!d)._lock=0,this._tTime=_,!l&&this.parent&&_a(this,"onRepeat"),this.vars.repeatRefresh&&!L&&(this.invalidate()._lock=1,O=b),f&&f!==this._time||S!==!this._ts||this.vars.onRepeat&&!this.parent&&!this._act)return this;if(d=this._dur,p=this._tDur,w&&(this._lock=2,f=T?d:-1e-4,this.render(f,!0),this.vars.repeatRefresh&&!L&&this.invalidate()),this._lock=0,!this._ts&&!S)return this;bb(this,L)}}if(this._hasPause&&!this._forcing&&this._lock<2&&(R=CN(this,An(f),An(g)),R&&(_-=g-(g=R._start))),this._tTime=_,this._time=g,this._act=!N,this._initted||(this._onUpdate=this.vars.onUpdate,this._initted=1,this._zTime=r,f=0),!f&&_&&d&&!l&&!O&&(_a(this,"onStart"),this._tTime!==_))return this;if(g>=f&&r>=0)for(x=this._first;x;){if(M=x._next,(x._act||g>=x._start)&&x._ts&&R!==x){if(x.parent!==this)return this.render(r,l,c);if(x.render(x._ts>0?(g-x._start)*x._ts:(x._dirty?x.totalDuration():x._tDur)+(g-x._start)*x._ts,l,c),g!==this._time||!this._ts&&!S){R=0,M&&(_+=this._zTime=-pn);break}}x=M}else{x=this._last;for(var q=r<0?r:g;x;){if(M=x._prev,(x._act||q<=x._end)&&x._ts&&R!==x){if(x.parent!==this)return this.render(r,l,c);if(x.render(x._ts>0?(q-x._start)*x._ts:(x._dirty?x.totalDuration():x._tDur)+(q-x._start)*x._ts,l,c||di&&yg(x)),g!==this._time||!this._ts&&!S){R=0,M&&(_+=this._zTime=q?-pn:pn);break}}x=M}}if(R&&!l&&(this.pause(),R.render(g>=f?0:-pn)._zTime=g>=f?1:-1,this._ts))return this._start=C,Nd(this),this.render(r,l,c);this._onUpdate&&!l&&_a(this,"onUpdate",!0),(_===p&&this._tTime>=this.totalDuration()||!_&&f)&&(C===this._start||Math.abs(N)!==Math.abs(this._ts))&&(this._lock||((r||!d)&&(_===p&&this._ts>0||!_&&this._ts<0)&&js(this,1),!l&&!(r<0&&!f)&&(_||f||!p)&&(_a(this,_===p&&r>=0?"onComplete":"onReverseComplete",!0),this._prom&&!(_<p&&this.timeScale()>0)&&this._prom())))}return this},n.add=function(r,l){var c=this;if(as(l)||(l=Na(this,l,r)),!(r instanceof Xc)){if(bi(r))return r.forEach(function(f){return c.add(f,l)}),this;if(si(r))return this.addLabel(r,l);if(Nn(r))r=qn.delayedCall(0,r);else return this}return this!==r?hr(this,r,l):this},n.getChildren=function(r,l,c,f){r===void 0&&(r=!0),l===void 0&&(l=!0),c===void 0&&(c=!0),f===void 0&&(f=-Fa);for(var p=[],d=this._first;d;)d._start>=f&&(d instanceof qn?l&&p.push(d):(c&&p.push(d),r&&p.push.apply(p,d.getChildren(!0,l,c)))),d=d._next;return p},n.getById=function(r){for(var l=this.getChildren(1,1,1),c=l.length;c--;)if(l[c].vars.id===r)return l[c]},n.remove=function(r){return si(r)?this.removeLabel(r):Nn(r)?this.killTweensOf(r):(r.parent===this&&Dd(this,r),r===this._recent&&(this._recent=this._last),Po(this))},n.totalTime=function(r,l){return arguments.length?(this._forcing=1,!this._dp&&this._ts&&(this._start=An(pa.time-(this._ts>0?r/this._ts:(this.totalDuration()-r)/-this._ts))),o.prototype.totalTime.call(this,r,l),this._forcing=0,this):this._tTime},n.addLabel=function(r,l){return this.labels[r]=Na(this,l),this},n.removeLabel=function(r){return delete this.labels[r],this},n.addPause=function(r,l,c){var f=qn.delayedCall(0,l||Gc,c);return f.data="isPause",this._hasPause=1,hr(this,f,Na(this,r))},n.removePause=function(r){var l=this._first;for(r=Na(this,r);l;)l._start===r&&l.data==="isPause"&&js(l),l=l._next},n.killTweensOf=function(r,l,c){for(var f=this.getTweensOf(r,c),p=f.length;p--;)Bs!==f[p]&&f[p].kill(r,l);return this},n.getTweensOf=function(r,l){for(var c=[],f=Ia(r),p=this._first,d=as(l),_;p;)p instanceof qn?SN(p._targets,f)&&(d?(!Bs||p._initted&&p._ts)&&p.globalTime(0)<=l&&p.globalTime(p.totalDuration())>l:!l||p.isActive())&&c.push(p):(_=p.getTweensOf(f,l)).length&&c.push.apply(c,_),p=p._next;return c},n.tweenTo=function(r,l){l=l||{};var c=this,f=Na(c,r),p=l,d=p.startAt,_=p.onStart,v=p.onStartParams,g=p.immediateRender,x,M=qn.to(c,ya({ease:l.ease||"none",lazy:!1,immediateRender:!1,time:f,overwrite:"auto",duration:l.duration||Math.abs((f-(d&&"time"in d?d.time:c._time))/c.timeScale())||pn,onStart:function(){if(c.pause(),!x){var y=l.duration||Math.abs((f-(d&&"time"in d?d.time:c._time))/c.timeScale());M._dur!==y&&lu(M,y,0,1).render(M._time,!0,!0),x=1}_&&_.apply(M,v||[])}},l));return g?M.render(0):M},n.tweenFromTo=function(r,l,c){return this.tweenTo(l,ya({startAt:{time:Na(this,r)}},c))},n.recent=function(){return this._recent},n.nextLabel=function(r){return r===void 0&&(r=this._time),UM(this,Na(this,r))},n.previousLabel=function(r){return r===void 0&&(r=this._time),UM(this,Na(this,r),1)},n.currentLabel=function(r){return arguments.length?this.seek(r,!0):this.previousLabel(this._time+pn)},n.shiftChildren=function(r,l,c){c===void 0&&(c=0);var f=this._first,p=this.labels,d;for(r=An(r);f;)f._start>=c&&(f._start+=r,f._end+=r),f=f._next;if(l)for(d in p)p[d]>=c&&(p[d]+=r);return Po(this)},n.invalidate=function(r){var l=this._first;for(this._lock=0;l;)l.invalidate(r),l=l._next;return o.prototype.invalidate.call(this,r)},n.clear=function(r){r===void 0&&(r=!0);for(var l=this._first,c;l;)c=l._next,this.remove(l),l=c;return this._dp&&(this._time=this._tTime=this._pTime=0),r&&(this.labels={}),Po(this)},n.totalDuration=function(r){var l=0,c=this,f=c._last,p=Fa,d,_,v;if(arguments.length)return c.timeScale((c._repeat<0?c.duration():c.totalDuration())/(c.reversed()?-r:r));if(c._dirty){for(v=c.parent;f;)d=f._prev,f._dirty&&f.totalDuration(),_=f._start,_>p&&c._sort&&f._ts&&!c._lock?(c._lock=1,hr(c,f,_-f._delay,1)._lock=0):p=_,_<0&&f._ts&&(l-=_,(!v&&!c._dp||v&&v.smoothChildTiming)&&(c._start+=An(_/c._ts),c._time-=_,c._tTime-=_),c.shiftChildren(-_,!1,-1/0),p=0),f._end>l&&f._ts&&(l=f._end),f=d;lu(c,c===Rn&&c._time>l?c._time:l,1,1),c._dirty=0}return c._tDur},e.updateRoot=function(r){if(Rn._ts&&(ib(Rn,gd(r,Rn)),tb=pa.frame),pa.frame>=CM){CM+=va.autoSleep||120;var l=Rn._first;if((!l||!l._ts)&&va.autoSleep&&pa._listeners.length<2){for(;l&&!l._ts;)l=l._next;l||pa.sleep()}}},e})(Xc);ya(Pi.prototype,{_lock:0,_hasPause:0,_forcing:0});var XN=function(e,n,a,r,l,c,f){var p=new Ki(this._pt,e,n,0,1,Nb,null,l),d=0,_=0,v,g,x,M,b,y,S,R;for(p.b=a,p.e=r,a+="",r+="",(S=~r.indexOf("random("))&&(r=Vc(r)),c&&(R=[a,r],c(R,e,n),a=R[0],r=R[1]),g=a.match(M_)||[];v=M_.exec(r);)M=v[0],b=r.substring(d,v.index),x?x=(x+1)%5:b.substr(-5)==="rgba("&&(x=1),M!==g[_++]&&(y=parseFloat(g[_-1])||0,p._pt={_next:p._pt,p:b||_===1?b:",",s:y,c:M.charAt(1)==="="?jl(y,M)-y:parseFloat(M)-y,m:x&&x<4?Math.round:0},d=M_.lastIndex);return p.c=d<r.length?r.substring(d,r.length):"",p.fp=f,(Q1.test(r)||S)&&(p.e=0),this._pt=p,p},Sg=function(e,n,a,r,l,c,f,p,d,_){Nn(r)&&(r=r(l||0,e,c));var v=e[n],g=a!=="get"?a:Nn(v)?d?e[n.indexOf("set")||!Nn(e["get"+n.substr(3)])?n:"get"+n.substr(3)](d):e[n]():v,x=Nn(v)?d?ZN:wb:bg,M;if(si(r)&&(~r.indexOf("random(")&&(r=Vc(r)),r.charAt(1)==="="&&(M=jl(g,r)+(yi(g)||0),(M||M===0)&&(r=M))),!_||g!==r||I0)return!isNaN(g*r)&&r!==""?(M=new Ki(this._pt,e,n,+g||0,r-(g||0),typeof v=="boolean"?QN:Db,0,x),d&&(M.fp=d),f&&M.modifier(f,this,e),this._pt=M):(!v&&!(n in e)&&_g(n,r),XN.call(this,e,n,g,r,x,p||va.stringFilter,d))},WN=function(e,n,a,r,l){if(Nn(e)&&(e=Ac(e,l,n,a,r)),!Mr(e)||e.style&&e.nodeType||bi(e)||Z1(e))return si(e)?Ac(e,l,n,a,r):e;var c={},f;for(f in e)c[f]=Ac(e[f],l,n,a,r);return c},Ab=function(e,n,a,r,l,c){var f,p,d,_;if(ha[e]&&(f=new ha[e]).init(l,f.rawVars?n[e]:WN(n[e],r,l,c,a),a,r,c)!==!1&&(a._pt=p=new Ki(a._pt,l,e,0,1,f.render,f,0,f.priority),a!==Xl))for(d=a._ptLookup[a._targets.indexOf(l)],_=f._props.length;_--;)d[f._props[_]]=p;return f},Bs,I0,Mg=function o(e,n,a){var r=e.vars,l=r.ease,c=r.startAt,f=r.immediateRender,p=r.lazy,d=r.onUpdate,_=r.runBackwards,v=r.yoyoEase,g=r.keyframes,x=r.autoRevert,M=e._dur,b=e._startAt,y=e._targets,S=e.parent,R=S&&S.data==="nested"?S.vars.targets:y,N=e._overwrite==="auto"&&!hg,C=e.timeline,O,P,L,T,w,q,G,k,$,te,J,z,I;if(C&&(!g||!l)&&(l="none"),e._ease=zo(l,ru.ease),e._yEase=v?Mb(zo(v===!0?l:v,ru.ease)):0,v&&e._yoyo&&!e._repeat&&(v=e._yEase,e._yEase=e._ease,e._ease=v),e._from=!C&&!!r.runBackwards,!C||g&&!r.stagger){if(k=y[0]?Oo(y[0]).harness:0,z=k&&r[k.prop],O=_d(r,gg),b&&(b._zTime<0&&b.progress(1),n<0&&_&&f&&!x?b.render(-1,!0):b.revert(_&&M?ed:xN),b._lazy=0),c){if(js(e._startAt=qn.set(y,ya({data:"isStart",overwrite:!1,parent:S,immediateRender:!0,lazy:!b&&ji(p),startAt:null,delay:0,onUpdate:d&&function(){return _a(e,"onUpdate")},stagger:0},c))),e._startAt._dp=0,e._startAt._sat=e,n<0&&(di||!f&&!x)&&e._startAt.revert(ed),f&&M&&n<=0&&a<=0){n&&(e._zTime=n);return}}else if(_&&M&&!b){if(n&&(f=!1),L=ya({overwrite:!1,data:"isFromStart",lazy:f&&!b&&ji(p),immediateRender:f,stagger:0,parent:S},O),z&&(L[k.prop]=z),js(e._startAt=qn.set(y,L)),e._startAt._dp=0,e._startAt._sat=e,n<0&&(di?e._startAt.revert(ed):e._startAt.render(-1,!0)),e._zTime=n,!f)o(e._startAt,pn,pn);else if(!n)return}for(e._pt=e._ptCache=0,p=M&&ji(p)||p&&!M,P=0;P<y.length;P++){if(w=y[P],G=w._gsap||xg(y)[P]._gsap,e._ptLookup[P]=te={},U0[G.id]&&Xs.length&&md(),J=R===y?P:R.indexOf(w),k&&($=new k).init(w,z||O,e,J,R)!==!1&&(e._pt=T=new Ki(e._pt,w,$.name,0,1,$.render,$,0,$.priority),$._props.forEach(function(ie){te[ie]=T}),$.priority&&(q=1)),!k||z)for(L in O)ha[L]&&($=Ab(L,O,e,J,w,R))?$.priority&&(q=1):te[L]=T=Sg.call(e,w,L,"get",O[L],J,R,0,r.stringFilter);e._op&&e._op[P]&&e.kill(w,e._op[P]),N&&e._pt&&(Bs=e,Rn.killTweensOf(w,te,e.globalTime(n)),I=!e.parent,Bs=0),e._pt&&p&&(U0[G.id]=1)}q&&Ub(e),e._onInit&&e._onInit(e)}e._onUpdate=d,e._initted=(!e._op||e._pt)&&!I,g&&n<=0&&C.render(Fa,!0,!0)},YN=function(e,n,a,r,l,c,f,p){var d=(e._pt&&e._ptCache||(e._ptCache={}))[n],_,v,g,x;if(!d)for(d=e._ptCache[n]=[],g=e._ptLookup,x=e._targets.length;x--;){if(_=g[x][n],_&&_.d&&_.d._pt)for(_=_.d._pt;_&&_.p!==n&&_.fp!==n;)_=_._next;if(!_)return I0=1,e.vars[n]="+=0",Mg(e,f),I0=0,p?Hc(n+" not eligible for reset"):1;d.push(_)}for(x=d.length;x--;)v=d[x],_=v._pt||v,_.s=(r||r===0)&&!l?r:_.s+(r||0)+c*_.c,_.c=a-_.s,v.e&&(v.e=On(a)+yi(v.e)),v.b&&(v.b=_.s+yi(v.b))},qN=function(e,n){var a=e[0]?Oo(e[0]).harness:0,r=a&&a.aliases,l,c,f,p;if(!r)return n;l=su({},n);for(c in r)if(c in l)for(p=r[c].split(","),f=p.length;f--;)l[p[f]]=l[c];return l},jN=function(e,n,a,r){var l=n.ease||r||"power1.inOut",c,f;if(bi(n))f=a[e]||(a[e]=[]),n.forEach(function(p,d){return f.push({t:d/(n.length-1)*100,v:p,e:l})});else for(c in n)f=a[c]||(a[c]=[]),c==="ease"||f.push({t:parseFloat(e),v:n[c],e:l})},Ac=function(e,n,a,r,l){return Nn(e)?e.call(n,a,r,l):si(e)&&~e.indexOf("random(")?Vc(e):e},Rb=vg+"repeat,repeatDelay,yoyo,repeatRefresh,yoyoEase,autoRevert",Cb={};Zi(Rb+",id,stagger,delay,duration,paused,scrollTrigger",function(o){return Cb[o]=1});var qn=(function(o){q1(e,o);function e(a,r,l,c){var f;typeof r=="number"&&(l.duration=r,r=l,l=null),f=o.call(this,c?r:Ec(r))||this;var p=f.vars,d=p.duration,_=p.delay,v=p.immediateRender,g=p.stagger,x=p.overwrite,M=p.keyframes,b=p.defaults,y=p.scrollTrigger,S=p.yoyoEase,R=r.parent||Rn,N=(bi(a)||Z1(a)?as(a[0]):"length"in r)?[a]:Ia(a),C,O,P,L,T,w,q,G;if(f._targets=N.length?xg(N):Hc("GSAP target "+a+" not found. https://gsap.com",!va.nullTargetWarn)||[],f._ptLookup=[],f._overwrite=x,M||g||Oh(d)||Oh(_)){if(r=f.vars,C=f.timeline=new Pi({data:"nested",defaults:b||{},targets:R&&R.data==="nested"?R.vars.targets:N}),C.kill(),C.parent=C._dp=Yr(f),C._start=0,g||Oh(d)||Oh(_)){if(L=N.length,q=g&&hb(g),Mr(g))for(T in g)~Rb.indexOf(T)&&(G||(G={}),G[T]=g[T]);for(O=0;O<L;O++)P=_d(r,Cb),P.stagger=0,S&&(P.yoyoEase=S),G&&su(P,G),w=N[O],P.duration=+Ac(d,Yr(f),O,w,N),P.delay=(+Ac(_,Yr(f),O,w,N)||0)-f._delay,!g&&L===1&&P.delay&&(f._delay=_=P.delay,f._start+=_,P.delay=0),C.to(w,P,q?q(O,w,N):0),C._ease=Xt.none;C.duration()?d=_=0:f.timeline=0}else if(M){Ec(ya(C.vars.defaults,{ease:"none"})),C._ease=zo(M.ease||r.ease||"none");var k=0,$,te,J;if(bi(M))M.forEach(function(z){return C.to(N,z,">")}),C.duration();else{P={};for(T in M)T==="ease"||T==="easeEach"||jN(T,M[T],P,M.easeEach);for(T in P)for($=P[T].sort(function(z,I){return z.t-I.t}),k=0,O=0;O<$.length;O++)te=$[O],J={ease:te.e,duration:(te.t-(O?$[O-1].t:0))/100*d},J[T]=te.v,C.to(N,J,k),k+=J.duration;C.duration()<d&&C.to({},{duration:d-C.duration()})}}d||f.duration(d=C.duration())}else f.timeline=0;return x===!0&&!hg&&(Bs=Yr(f),Rn.killTweensOf(N),Bs=0),hr(R,Yr(f),l),r.reversed&&f.reverse(),r.paused&&f.paused(!0),(v||!d&&!M&&f._start===An(R._time)&&ji(v)&&TN(Yr(f))&&R.data!=="nested")&&(f._tTime=-pn,f.render(Math.max(0,-_)||0)),y&&lb(Yr(f),y),f}var n=e.prototype;return n.render=function(r,l,c){var f=this._time,p=this._tDur,d=this._dur,_=r<0,v=r>p-pn&&!_?p:r<pn?0:r,g,x,M,b,y,S,R,N,C;if(!d)RN(this,r,l,c);else if(v!==this._tTime||!r||c||!this._initted&&this._tTime||this._startAt&&this._zTime<0!==_||this._lazy){if(g=v,N=this.timeline,this._repeat){if(b=d+this._rDelay,this._repeat<-1&&_)return this.totalTime(b*100+r,l,c);if(g=An(v%b),v===p?(M=this._repeat,g=d):(y=An(v/b),M=~~y,M&&M===y?(g=d,M--):g>d&&(g=d)),S=this._yoyo&&M&1,S&&(C=this._yEase,g=d-g),y=ou(this._tTime,b),g===f&&!c&&this._initted&&M===y)return this._tTime=v,this;M!==y&&(N&&this._yEase&&bb(N,S),this.vars.repeatRefresh&&!S&&!this._lock&&g!==b&&this._initted&&(this._lock=c=1,this.render(An(b*M),!0).invalidate()._lock=0))}if(!this._initted){if(ub(this,_?r:g,c,l,v))return this._tTime=0,this;if(f!==this._time&&!(c&&this.vars.repeatRefresh&&M!==y))return this;if(d!==this._dur)return this.render(r,l,c)}if(this._tTime=v,this._time=g,!this._act&&this._ts&&(this._act=1,this._lazy=0),this.ratio=R=(C||this._ease)(g/d),this._from&&(this.ratio=R=1-R),!f&&v&&!l&&!y&&(_a(this,"onStart"),this._tTime!==v))return this;for(x=this._pt;x;)x.r(R,x.d),x=x._next;N&&N.render(r<0?r:N._dur*N._ease(g/this._dur),l,c)||this._startAt&&(this._zTime=r),this._onUpdate&&!l&&(_&&L0(this,r,l,c),_a(this,"onUpdate")),this._repeat&&M!==y&&this.vars.onRepeat&&!l&&this.parent&&_a(this,"onRepeat"),(v===this._tDur||!v)&&this._tTime===v&&(_&&!this._onUpdate&&L0(this,r,!0,!0),(r||!d)&&(v===this._tDur&&this._ts>0||!v&&this._ts<0)&&js(this,1),!l&&!(_&&!f)&&(v||f||S)&&(_a(this,v===p?"onComplete":"onReverseComplete",!0),this._prom&&!(v<p&&this.timeScale()>0)&&this._prom()))}return this},n.targets=function(){return this._targets},n.invalidate=function(r){return(!r||!this.vars.runBackwards)&&(this._startAt=0),this._pt=this._op=this._onUpdate=this._lazy=this.ratio=0,this._ptLookup=[],this.timeline&&this.timeline.invalidate(r),o.prototype.invalidate.call(this,r)},n.resetTo=function(r,l,c,f,p){kc||pa.wake(),this._ts||this.play();var d=Math.min(this._dur,(this._dp._time-this._start)*this._ts),_;return this._initted||Mg(this,d),_=this._ease(d/this._dur),YN(this,r,l,c,f,_,d,p)?this.resetTo(r,l,c,f,1):(Ud(this,0),this.parent||sb(this._dp,this,"_first","_last",this._dp._sort?"_start":0),this.render(0))},n.kill=function(r,l){if(l===void 0&&(l="all"),!r&&(!l||l==="all"))return this._lazy=this._pt=0,this.parent?gc(this):this.scrollTrigger&&this.scrollTrigger.kill(!!di),this;if(this.timeline){var c=this.timeline.totalDuration();return this.timeline.killTweensOf(r,l,Bs&&Bs.vars.overwrite!==!0)._first||gc(this),this.parent&&c!==this.timeline.totalDuration()&&lu(this,this._dur*this.timeline._tDur/c,0,1),this}var f=this._targets,p=r?Ia(r):f,d=this._ptLookup,_=this._pt,v,g,x,M,b,y,S;if((!l||l==="all")&&bN(f,p))return l==="all"&&(this._pt=0),gc(this);for(v=this._op=this._op||[],l!=="all"&&(si(l)&&(b={},Zi(l,function(R){return b[R]=1}),l=b),l=qN(f,l)),S=f.length;S--;)if(~p.indexOf(f[S])){g=d[S],l==="all"?(v[S]=l,M=g,x={}):(x=v[S]=v[S]||{},M=l);for(b in M)y=g&&g[b],y&&((!("kill"in y.d)||y.d.kill(b)===!0)&&Dd(this,y,"_pt"),delete g[b]),x!=="all"&&(x[b]=1)}return this._initted&&!this._pt&&_&&gc(this),this},e.to=function(r,l){return new e(r,l,arguments[2])},e.from=function(r,l){return Tc(1,arguments)},e.delayedCall=function(r,l,c,f){return new e(l,0,{immediateRender:!1,lazy:!1,overwrite:!1,delay:r,onComplete:l,onReverseComplete:l,onCompleteParams:c,onReverseCompleteParams:c,callbackScope:f})},e.fromTo=function(r,l,c){return Tc(2,arguments)},e.set=function(r,l){return l.duration=0,l.repeatDelay||(l.repeat=0),new e(r,l)},e.killTweensOf=function(r,l,c){return Rn.killTweensOf(r,l,c)},e})(Xc);ya(qn.prototype,{_targets:[],_lazy:0,_startAt:0,_op:0,_onInit:0});Zi("staggerTo,staggerFrom,staggerFromTo",function(o){qn[o]=function(){var e=new Pi,n=P0.call(arguments,0);return n.splice(o==="staggerFromTo"?5:4,0,0),e[o].apply(e,n)}});var bg=function(e,n,a){return e[n]=a},wb=function(e,n,a){return e[n](a)},ZN=function(e,n,a,r){return e[n](r.fp,a)},KN=function(e,n,a){return e.setAttribute(n,a)},Eg=function(e,n){return Nn(e[n])?wb:dg(e[n])&&e.setAttribute?KN:bg},Db=function(e,n){return n.set(n.t,n.p,Math.round((n.s+n.c*e)*1e6)/1e6,n)},QN=function(e,n){return n.set(n.t,n.p,!!(n.s+n.c*e),n)},Nb=function(e,n){var a=n._pt,r="";if(!e&&n.b)r=n.b;else if(e===1&&n.e)r=n.e;else{for(;a;)r=a.p+(a.m?a.m(a.s+a.c*e):Math.round((a.s+a.c*e)*1e4)/1e4)+r,a=a._next;r+=n.c}n.set(n.t,n.p,r,n)},Tg=function(e,n){for(var a=n._pt;a;)a.r(e,a.d),a=a._next},JN=function(e,n,a,r){for(var l=this._pt,c;l;)c=l._next,l.p===r&&l.modifier(e,n,a),l=c},$N=function(e){for(var n=this._pt,a,r;n;)r=n._next,n.p===e&&!n.op||n.op===e?Dd(this,n,"_pt"):n.dep||(a=1),n=r;return!a},eU=function(e,n,a,r){r.mSet(e,n,r.m.call(r.tween,a,r.mt),r)},Ub=function(e){for(var n=e._pt,a,r,l,c;n;){for(a=n._next,r=l;r&&r.pr>n.pr;)r=r._next;(n._prev=r?r._prev:c)?n._prev._next=n:l=n,(n._next=r)?r._prev=n:c=n,n=a}e._pt=l},Ki=(function(){function o(n,a,r,l,c,f,p,d,_){this.t=a,this.s=l,this.c=c,this.p=r,this.r=f||Db,this.d=p||this,this.set=d||bg,this.pr=_||0,this._next=n,n&&(n._prev=this)}var e=o.prototype;return e.modifier=function(a,r,l){this.mSet=this.mSet||this.set,this.set=eU,this.m=a,this.mt=l,this.tween=r},o})();Zi(vg+"parent,duration,ease,delay,overwrite,runBackwards,startAt,yoyo,immediateRender,repeat,repeatDelay,data,paused,reversed,lazy,callbackScope,stringFilter,id,yoyoEase,stagger,inherit,repeatRefresh,keyframes,autoRevert,scrollTrigger",function(o){return gg[o]=1});xa.TweenMax=xa.TweenLite=qn;xa.TimelineLite=xa.TimelineMax=Pi;Rn=new Pi({sortChildren:!1,defaults:ru,autoRemoveChildren:!0,id:"root",smoothChildTiming:!0});va.stringFilter=Sb;var Fo=[],nd={},tU=[],OM=0,nU=0,R_=function(e){return(nd[e]||tU).map(function(n){return n()})},B0=function(){var e=Date.now(),n=[];e-OM>2&&(R_("matchMediaInit"),Fo.forEach(function(a){var r=a.queries,l=a.conditions,c,f,p,d;for(f in r)c=lr.matchMedia(r[f]).matches,c&&(p=1),c!==l[f]&&(l[f]=c,d=1);d&&(a.revert(),p&&n.push(a))}),R_("matchMediaRevert"),n.forEach(function(a){return a.onMatch(a,function(r){return a.add(null,r)})}),OM=e,R_("matchMedia"))},Lb=(function(){function o(n,a){this.selector=a&&z0(a),this.data=[],this._r=[],this.isReverted=!1,this.id=nU++,n&&this.add(n)}var e=o.prototype;return e.add=function(a,r,l){Nn(a)&&(l=r,r=a,a=Nn);var c=this,f=function(){var d=En,_=c.selector,v;return d&&d!==c&&d.data.push(c),l&&(c.selector=z0(l)),En=c,v=r.apply(c,arguments),Nn(v)&&c._r.push(v),En=d,c.selector=_,c.isReverted=!1,v};return c.last=f,a===Nn?f(c,function(p){return c.add(null,p)}):a?c[a]=f:f},e.ignore=function(a){var r=En;En=null,a(this),En=r},e.getTweens=function(){var a=[];return this.data.forEach(function(r){return r instanceof o?a.push.apply(a,r.getTweens()):r instanceof qn&&!(r.parent&&r.parent.data==="nested")&&a.push(r)}),a},e.clear=function(){this._r.length=this.data.length=0},e.kill=function(a,r){var l=this;if(a?(function(){for(var f=l.getTweens(),p=l.data.length,d;p--;)d=l.data[p],d.data==="isFlip"&&(d.revert(),d.getChildren(!0,!0,!1).forEach(function(_){return f.splice(f.indexOf(_),1)}));for(f.map(function(_){return{g:_._dur||_._delay||_._sat&&!_._sat.vars.immediateRender?_.globalTime(0):-1/0,t:_}}).sort(function(_,v){return v.g-_.g||-1/0}).forEach(function(_){return _.t.revert(a)}),p=l.data.length;p--;)d=l.data[p],d instanceof Pi?d.data!=="nested"&&(d.scrollTrigger&&d.scrollTrigger.revert(),d.kill()):!(d instanceof qn)&&d.revert&&d.revert(a);l._r.forEach(function(_){return _(a,l)}),l.isReverted=!0})():this.data.forEach(function(f){return f.kill&&f.kill()}),this.clear(),r)for(var c=Fo.length;c--;)Fo[c].id===this.id&&Fo.splice(c,1)},e.revert=function(a){this.kill(a||{})},o})(),iU=(function(){function o(n){this.contexts=[],this.scope=n,En&&En.data.push(this)}var e=o.prototype;return e.add=function(a,r,l){Mr(a)||(a={matches:a});var c=new Lb(0,l||this.scope),f=c.conditions={},p,d,_;En&&!c.selector&&(c.selector=En.selector),this.contexts.push(c),r=c.add("onMatch",r),c.queries=a;for(d in a)d==="all"?_=1:(p=lr.matchMedia(a[d]),p&&(Fo.indexOf(c)<0&&Fo.push(c),(f[d]=p.matches)&&(_=1),p.addListener?p.addListener(B0):p.addEventListener("change",B0)));return _&&r(c,function(v){return c.add(null,v)}),this},e.revert=function(a){this.kill(a||{})},e.kill=function(a){this.contexts.forEach(function(r){return r.kill(a,!0)})},o})(),vd={registerPlugin:function(){for(var e=arguments.length,n=new Array(e),a=0;a<e;a++)n[a]=arguments[a];n.forEach(function(r){return vb(r)})},timeline:function(e){return new Pi(e)},getTweensOf:function(e,n){return Rn.getTweensOf(e,n)},getProperty:function(e,n,a,r){si(e)&&(e=Ia(e)[0]);var l=Oo(e||{}).get,c=a?rb:ab;return a==="native"&&(a=""),e&&(n?c((ha[n]&&ha[n].get||l)(e,n,a,r)):function(f,p,d){return c((ha[f]&&ha[f].get||l)(e,f,p,d))})},quickSetter:function(e,n,a){if(e=Ia(e),e.length>1){var r=e.map(function(_){return Ji.quickSetter(_,n,a)}),l=r.length;return function(_){for(var v=l;v--;)r[v](_)}}e=e[0]||{};var c=ha[n],f=Oo(e),p=f.harness&&(f.harness.aliases||{})[n]||n,d=c?function(_){var v=new c;Xl._pt=0,v.init(e,a?_+a:_,Xl,0,[e]),v.render(1,v),Xl._pt&&Tg(1,Xl)}:f.set(e,p);return c?d:function(_){return d(e,p,a?_+a:_,f,1)}},quickTo:function(e,n,a){var r,l=Ji.to(e,ya((r={},r[n]="+=0.1",r.paused=!0,r.stagger=0,r),a||{})),c=function(p,d,_){return l.resetTo(n,p,d,_)};return c.tween=l,c},isTweening:function(e){return Rn.getTweensOf(e,!0).length>0},defaults:function(e){return e&&e.ease&&(e.ease=zo(e.ease,ru.ease)),wM(ru,e||{})},config:function(e){return wM(va,e||{})},registerEffect:function(e){var n=e.name,a=e.effect,r=e.plugins,l=e.defaults,c=e.extendTimeline;(r||"").split(",").forEach(function(f){return f&&!ha[f]&&!xa[f]&&Hc(n+" effect requires "+f+" plugin.")}),b_[n]=function(f,p,d){return a(Ia(f),ya(p||{},l),d)},c&&(Pi.prototype[n]=function(f,p,d){return this.add(b_[n](f,Mr(p)?p:(d=p)&&{},this),d)})},registerEase:function(e,n){Xt[e]=zo(n)},parseEase:function(e,n){return arguments.length?zo(e,n):Xt},getById:function(e){return Rn.getById(e)},exportRoot:function(e,n){e===void 0&&(e={});var a=new Pi(e),r,l;for(a.smoothChildTiming=ji(e.smoothChildTiming),Rn.remove(a),a._dp=0,a._time=a._tTime=Rn._time,r=Rn._first;r;)l=r._next,(n||!(!r._dur&&r instanceof qn&&r.vars.onComplete===r._targets[0]))&&hr(a,r,r._start-r._delay),r=l;return hr(Rn,a,0),a},context:function(e,n){return e?new Lb(e,n):En},matchMedia:function(e){return new iU(e)},matchMediaRefresh:function(){return Fo.forEach(function(e){var n=e.conditions,a,r;for(r in n)n[r]&&(n[r]=!1,a=1);a&&e.revert()})||B0()},addEventListener:function(e,n){var a=nd[e]||(nd[e]=[]);~a.indexOf(n)||a.push(n)},removeEventListener:function(e,n){var a=nd[e],r=a&&a.indexOf(n);r>=0&&a.splice(r,1)},utils:{wrap:PN,wrapYoyo:zN,distribute:hb,random:pb,snap:db,normalize:ON,getUnit:yi,clamp:DN,splitColor:xb,toArray:Ia,selector:z0,mapRange:_b,pipe:UN,unitize:LN,interpolate:FN,shuffle:fb},install:$1,effects:b_,ticker:pa,updateRoot:Pi.updateRoot,plugins:ha,globalTimeline:Rn,core:{PropTween:Ki,globals:eb,Tween:qn,Timeline:Pi,Animation:Xc,getCache:Oo,_removeLinkedListItem:Dd,reverting:function(){return di},context:function(e){return e&&En&&(En.data.push(e),e._ctx=En),En},suppressOverwrites:function(e){return hg=e}}};Zi("to,from,fromTo,delayedCall,set,killTweensOf",function(o){return vd[o]=qn[o]});pa.add(Pi.updateRoot);Xl=vd.to({},{duration:0});var aU=function(e,n){for(var a=e._pt;a&&a.p!==n&&a.op!==n&&a.fp!==n;)a=a._next;return a},rU=function(e,n){var a=e._targets,r,l,c;for(r in n)for(l=a.length;l--;)c=e._ptLookup[l][r],c&&(c=c.d)&&(c._pt&&(c=aU(c,r)),c&&c.modifier&&c.modifier(n[r],e,a[l],r))},C_=function(e,n){return{name:e,headless:1,rawVars:1,init:function(r,l,c){c._onInit=function(f){var p,d;if(si(l)&&(p={},Zi(l,function(_){return p[_]=1}),l=p),n){p={};for(d in l)p[d]=n(l[d]);l=p}rU(f,l)}}}},Ji=vd.registerPlugin({name:"attr",init:function(e,n,a,r,l){var c,f,p;this.tween=a;for(c in n)p=e.getAttribute(c)||"",f=this.add(e,"setAttribute",(p||0)+"",n[c],r,l,0,0,c),f.op=c,f.b=p,this._props.push(c)},render:function(e,n){for(var a=n._pt;a;)di?a.set(a.t,a.p,a.b,a):a.r(e,a.d),a=a._next}},{name:"endArray",headless:1,init:function(e,n){for(var a=n.length;a--;)this.add(e,a,e[a]||0,n[a],0,0,0,0,0,1)}},C_("roundProps",F0),C_("modifiers"),C_("snap",db))||vd;qn.version=Pi.version=Ji.version="3.14.2";J1=1;pg()&&uu();Xt.Power0;Xt.Power1;Xt.Power2;Xt.Power3;Xt.Power4;Xt.Linear;Xt.Quad;Xt.Cubic;Xt.Quart;Xt.Quint;Xt.Strong;Xt.Elastic;Xt.Back;Xt.SteppedEase;Xt.Bounce;Xt.Sine;Xt.Expo;Xt.Circ;/*!
 * CSSPlugin 3.14.2
 * https://gsap.com
 *
 * Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
*/var PM,Hs,Zl,Ag,Uo,zM,Rg,sU=function(){return typeof window<"u"},rs={},To=180/Math.PI,Kl=Math.PI/180,Il=Math.atan2,FM=1e8,Cg=/([A-Z])/g,oU=/(left|right|width|margin|padding|x)/i,lU=/[\s,\(]\S/,mr={autoAlpha:"opacity,visibility",scale:"scaleX,scaleY",alpha:"opacity"},H0=function(e,n){return n.set(n.t,n.p,Math.round((n.s+n.c*e)*1e4)/1e4+n.u,n)},uU=function(e,n){return n.set(n.t,n.p,e===1?n.e:Math.round((n.s+n.c*e)*1e4)/1e4+n.u,n)},cU=function(e,n){return n.set(n.t,n.p,e?Math.round((n.s+n.c*e)*1e4)/1e4+n.u:n.b,n)},fU=function(e,n){return n.set(n.t,n.p,e===1?n.e:e?Math.round((n.s+n.c*e)*1e4)/1e4+n.u:n.b,n)},hU=function(e,n){var a=n.s+n.c*e;n.set(n.t,n.p,~~(a+(a<0?-.5:.5))+n.u,n)},Ob=function(e,n){return n.set(n.t,n.p,e?n.e:n.b,n)},Pb=function(e,n){return n.set(n.t,n.p,e!==1?n.b:n.e,n)},dU=function(e,n,a){return e.style[n]=a},pU=function(e,n,a){return e.style.setProperty(n,a)},mU=function(e,n,a){return e._gsap[n]=a},_U=function(e,n,a){return e._gsap.scaleX=e._gsap.scaleY=a},gU=function(e,n,a,r,l){var c=e._gsap;c.scaleX=c.scaleY=a,c.renderTransform(l,c)},vU=function(e,n,a,r,l){var c=e._gsap;c[n]=a,c.renderTransform(l,c)},Cn="transform",Qi=Cn+"Origin",xU=function o(e,n){var a=this,r=this.target,l=r.style,c=r._gsap;if(e in rs&&l){if(this.tfm=this.tfm||{},e!=="transform")e=mr[e]||e,~e.indexOf(",")?e.split(",").forEach(function(f){return a.tfm[f]=qr(r,f)}):this.tfm[e]=c.x?c[e]:qr(r,e),e===Qi&&(this.tfm.zOrigin=c.zOrigin);else return mr.transform.split(",").forEach(function(f){return o.call(a,f,n)});if(this.props.indexOf(Cn)>=0)return;c.svg&&(this.svgo=r.getAttribute("data-svg-origin"),this.props.push(Qi,n,"")),e=Cn}(l||n)&&this.props.push(e,n,l[e])},zb=function(e){e.translate&&(e.removeProperty("translate"),e.removeProperty("scale"),e.removeProperty("rotate"))},yU=function(){var e=this.props,n=this.target,a=n.style,r=n._gsap,l,c;for(l=0;l<e.length;l+=3)e[l+1]?e[l+1]===2?n[e[l]](e[l+2]):n[e[l]]=e[l+2]:e[l+2]?a[e[l]]=e[l+2]:a.removeProperty(e[l].substr(0,2)==="--"?e[l]:e[l].replace(Cg,"-$1").toLowerCase());if(this.tfm){for(c in this.tfm)r[c]=this.tfm[c];r.svg&&(r.renderTransform(),n.setAttribute("data-svg-origin",this.svgo||"")),l=Rg(),(!l||!l.isStart)&&!a[Cn]&&(zb(a),r.zOrigin&&a[Qi]&&(a[Qi]+=" "+r.zOrigin+"px",r.zOrigin=0,r.renderTransform()),r.uncache=1)}},Fb=function(e,n){var a={target:e,props:[],revert:yU,save:xU};return e._gsap||Ji.core.getCache(e),n&&e.style&&e.nodeType&&n.split(",").forEach(function(r){return a.save(r)}),a},Ib,G0=function(e,n){var a=Hs.createElementNS?Hs.createElementNS((n||"http://www.w3.org/1999/xhtml").replace(/^https/,"http"),e):Hs.createElement(e);return a&&a.style?a:Hs.createElement(e)},ga=function o(e,n,a){var r=getComputedStyle(e);return r[n]||r.getPropertyValue(n.replace(Cg,"-$1").toLowerCase())||r.getPropertyValue(n)||!a&&o(e,cu(n)||n,1)||""},IM="O,Moz,ms,Ms,Webkit".split(","),cu=function(e,n,a){var r=n||Uo,l=r.style,c=5;if(e in l&&!a)return e;for(e=e.charAt(0).toUpperCase()+e.substr(1);c--&&!(IM[c]+e in l););return c<0?null:(c===3?"ms":c>=0?IM[c]:"")+e},V0=function(){sU()&&window.document&&(PM=window,Hs=PM.document,Zl=Hs.documentElement,Uo=G0("div")||{style:{}},G0("div"),Cn=cu(Cn),Qi=Cn+"Origin",Uo.style.cssText="border-width:0;line-height:0;position:absolute;padding:0",Ib=!!cu("perspective"),Rg=Ji.core.reverting,Ag=1)},BM=function(e){var n=e.ownerSVGElement,a=G0("svg",n&&n.getAttribute("xmlns")||"http://www.w3.org/2000/svg"),r=e.cloneNode(!0),l;r.style.display="block",a.appendChild(r),Zl.appendChild(a);try{l=r.getBBox()}catch{}return a.removeChild(r),Zl.removeChild(a),l},HM=function(e,n){for(var a=n.length;a--;)if(e.hasAttribute(n[a]))return e.getAttribute(n[a])},Bb=function(e){var n,a;try{n=e.getBBox()}catch{n=BM(e),a=1}return n&&(n.width||n.height)||a||(n=BM(e)),n&&!n.width&&!n.x&&!n.y?{x:+HM(e,["x","cx","x1"])||0,y:+HM(e,["y","cy","y1"])||0,width:0,height:0}:n},Hb=function(e){return!!(e.getCTM&&(!e.parentNode||e.ownerSVGElement)&&Bb(e))},Zs=function(e,n){if(n){var a=e.style,r;n in rs&&n!==Qi&&(n=Cn),a.removeProperty?(r=n.substr(0,2),(r==="ms"||n.substr(0,6)==="webkit")&&(n="-"+n),a.removeProperty(r==="--"?n:n.replace(Cg,"-$1").toLowerCase())):a.removeAttribute(n)}},Gs=function(e,n,a,r,l,c){var f=new Ki(e._pt,n,a,0,1,c?Pb:Ob);return e._pt=f,f.b=r,f.e=l,e._props.push(a),f},GM={deg:1,rad:1,turn:1},SU={grid:1,flex:1},Ks=function o(e,n,a,r){var l=parseFloat(a)||0,c=(a+"").trim().substr((l+"").length)||"px",f=Uo.style,p=oU.test(n),d=e.tagName.toLowerCase()==="svg",_=(d?"client":"offset")+(p?"Width":"Height"),v=100,g=r==="px",x=r==="%",M,b,y,S;if(r===c||!l||GM[r]||GM[c])return l;if(c!=="px"&&!g&&(l=o(e,n,a,"px")),S=e.getCTM&&Hb(e),(x||c==="%")&&(rs[n]||~n.indexOf("adius")))return M=S?e.getBBox()[p?"width":"height"]:e[_],On(x?l/M*v:l/100*M);if(f[p?"width":"height"]=v+(g?c:r),b=r!=="rem"&&~n.indexOf("adius")||r==="em"&&e.appendChild&&!d?e:e.parentNode,S&&(b=(e.ownerSVGElement||{}).parentNode),(!b||b===Hs||!b.appendChild)&&(b=Hs.body),y=b._gsap,y&&x&&y.width&&p&&y.time===pa.time&&!y.uncache)return On(l/y.width*v);if(x&&(n==="height"||n==="width")){var R=e.style[n];e.style[n]=v+r,M=e[_],R?e.style[n]=R:Zs(e,n)}else(x||c==="%")&&!SU[ga(b,"display")]&&(f.position=ga(e,"position")),b===e&&(f.position="static"),b.appendChild(Uo),M=Uo[_],b.removeChild(Uo),f.position="absolute";return p&&x&&(y=Oo(b),y.time=pa.time,y.width=b[_]),On(g?M*l/v:M&&l?v/M*l:0)},qr=function(e,n,a,r){var l;return Ag||V0(),n in mr&&n!=="transform"&&(n=mr[n],~n.indexOf(",")&&(n=n.split(",")[0])),rs[n]&&n!=="transform"?(l=Yc(e,r),l=n!=="transformOrigin"?l[n]:l.svg?l.origin:yd(ga(e,Qi))+" "+l.zOrigin+"px"):(l=e.style[n],(!l||l==="auto"||r||~(l+"").indexOf("calc("))&&(l=xd[n]&&xd[n](e,n,a)||ga(e,n)||nb(e,n)||(n==="opacity"?1:0))),a&&!~(l+"").trim().indexOf(" ")?Ks(e,n,l,a)+a:l},MU=function(e,n,a,r){if(!a||a==="none"){var l=cu(n,e,1),c=l&&ga(e,l,1);c&&c!==a?(n=l,a=c):n==="borderColor"&&(a=ga(e,"borderTopColor"))}var f=new Ki(this._pt,e.style,n,0,1,Nb),p=0,d=0,_,v,g,x,M,b,y,S,R,N,C,O;if(f.b=a,f.e=r,a+="",r+="",r.substring(0,6)==="var(--"&&(r=ga(e,r.substring(4,r.indexOf(")")))),r==="auto"&&(b=e.style[n],e.style[n]=r,r=ga(e,n)||r,b?e.style[n]=b:Zs(e,n)),_=[a,r],Sb(_),a=_[0],r=_[1],g=a.match(kl)||[],O=r.match(kl)||[],O.length){for(;v=kl.exec(r);)y=v[0],R=r.substring(p,v.index),M?M=(M+1)%5:(R.substr(-5)==="rgba("||R.substr(-5)==="hsla(")&&(M=1),y!==(b=g[d++]||"")&&(x=parseFloat(b)||0,C=b.substr((x+"").length),y.charAt(1)==="="&&(y=jl(x,y)+C),S=parseFloat(y),N=y.substr((S+"").length),p=kl.lastIndex-N.length,N||(N=N||va.units[n]||C,p===r.length&&(r+=N,f.e+=N)),C!==N&&(x=Ks(e,n,b,N)||0),f._pt={_next:f._pt,p:R||d===1?R:",",s:x,c:S-x,m:M&&M<4||n==="zIndex"?Math.round:0});f.c=p<r.length?r.substring(p,r.length):""}else f.r=n==="display"&&r==="none"?Pb:Ob;return Q1.test(r)&&(f.e=0),this._pt=f,f},VM={top:"0%",bottom:"100%",left:"0%",right:"100%",center:"50%"},bU=function(e){var n=e.split(" "),a=n[0],r=n[1]||"50%";return(a==="top"||a==="bottom"||r==="left"||r==="right")&&(e=a,a=r,r=e),n[0]=VM[a]||a,n[1]=VM[r]||r,n.join(" ")},EU=function(e,n){if(n.tween&&n.tween._time===n.tween._dur){var a=n.t,r=a.style,l=n.u,c=a._gsap,f,p,d;if(l==="all"||l===!0)r.cssText="",p=1;else for(l=l.split(","),d=l.length;--d>-1;)f=l[d],rs[f]&&(p=1,f=f==="transformOrigin"?Qi:Cn),Zs(a,f);p&&(Zs(a,Cn),c&&(c.svg&&a.removeAttribute("transform"),r.scale=r.rotate=r.translate="none",Yc(a,1),c.uncache=1,zb(r)))}},xd={clearProps:function(e,n,a,r,l){if(l.data!=="isFromStart"){var c=e._pt=new Ki(e._pt,n,a,0,0,EU);return c.u=r,c.pr=-10,c.tween=l,e._props.push(a),1}}},Wc=[1,0,0,1,0,0],Gb={},Vb=function(e){return e==="matrix(1, 0, 0, 1, 0, 0)"||e==="none"||!e},kM=function(e){var n=ga(e,Cn);return Vb(n)?Wc:n.substr(7).match(K1).map(On)},wg=function(e,n){var a=e._gsap||Oo(e),r=e.style,l=kM(e),c,f,p,d;return a.svg&&e.getAttribute("transform")?(p=e.transform.baseVal.consolidate().matrix,l=[p.a,p.b,p.c,p.d,p.e,p.f],l.join(",")==="1,0,0,1,0,0"?Wc:l):(l===Wc&&!e.offsetParent&&e!==Zl&&!a.svg&&(p=r.display,r.display="block",c=e.parentNode,(!c||!e.offsetParent&&!e.getBoundingClientRect().width)&&(d=1,f=e.nextElementSibling,Zl.appendChild(e)),l=kM(e),p?r.display=p:Zs(e,"display"),d&&(f?c.insertBefore(e,f):c?c.appendChild(e):Zl.removeChild(e))),n&&l.length>6?[l[0],l[1],l[4],l[5],l[12],l[13]]:l)},k0=function(e,n,a,r,l,c){var f=e._gsap,p=l||wg(e,!0),d=f.xOrigin||0,_=f.yOrigin||0,v=f.xOffset||0,g=f.yOffset||0,x=p[0],M=p[1],b=p[2],y=p[3],S=p[4],R=p[5],N=n.split(" "),C=parseFloat(N[0])||0,O=parseFloat(N[1])||0,P,L,T,w;a?p!==Wc&&(L=x*y-M*b)&&(T=C*(y/L)+O*(-b/L)+(b*R-y*S)/L,w=C*(-M/L)+O*(x/L)-(x*R-M*S)/L,C=T,O=w):(P=Bb(e),C=P.x+(~N[0].indexOf("%")?C/100*P.width:C),O=P.y+(~(N[1]||N[0]).indexOf("%")?O/100*P.height:O)),r||r!==!1&&f.smooth?(S=C-d,R=O-_,f.xOffset=v+(S*x+R*b)-S,f.yOffset=g+(S*M+R*y)-R):f.xOffset=f.yOffset=0,f.xOrigin=C,f.yOrigin=O,f.smooth=!!r,f.origin=n,f.originIsAbsolute=!!a,e.style[Qi]="0px 0px",c&&(Gs(c,f,"xOrigin",d,C),Gs(c,f,"yOrigin",_,O),Gs(c,f,"xOffset",v,f.xOffset),Gs(c,f,"yOffset",g,f.yOffset)),e.setAttribute("data-svg-origin",C+" "+O)},Yc=function(e,n){var a=e._gsap||new Tb(e);if("x"in a&&!n&&!a.uncache)return a;var r=e.style,l=a.scaleX<0,c="px",f="deg",p=getComputedStyle(e),d=ga(e,Qi)||"0",_,v,g,x,M,b,y,S,R,N,C,O,P,L,T,w,q,G,k,$,te,J,z,I,ie,he,H,F,Q,xe,Te,Ne;return _=v=g=b=y=S=R=N=C=0,x=M=1,a.svg=!!(e.getCTM&&Hb(e)),p.translate&&((p.translate!=="none"||p.scale!=="none"||p.rotate!=="none")&&(r[Cn]=(p.translate!=="none"?"translate3d("+(p.translate+" 0 0").split(" ").slice(0,3).join(", ")+") ":"")+(p.rotate!=="none"?"rotate("+p.rotate+") ":"")+(p.scale!=="none"?"scale("+p.scale.split(" ").join(",")+") ":"")+(p[Cn]!=="none"?p[Cn]:"")),r.scale=r.rotate=r.translate="none"),L=wg(e,a.svg),a.svg&&(a.uncache?(ie=e.getBBox(),d=a.xOrigin-ie.x+"px "+(a.yOrigin-ie.y)+"px",I=""):I=!n&&e.getAttribute("data-svg-origin"),k0(e,I||d,!!I||a.originIsAbsolute,a.smooth!==!1,L)),O=a.xOrigin||0,P=a.yOrigin||0,L!==Wc&&(G=L[0],k=L[1],$=L[2],te=L[3],_=J=L[4],v=z=L[5],L.length===6?(x=Math.sqrt(G*G+k*k),M=Math.sqrt(te*te+$*$),b=G||k?Il(k,G)*To:0,R=$||te?Il($,te)*To+b:0,R&&(M*=Math.abs(Math.cos(R*Kl))),a.svg&&(_-=O-(O*G+P*$),v-=P-(O*k+P*te))):(Ne=L[6],xe=L[7],H=L[8],F=L[9],Q=L[10],Te=L[11],_=L[12],v=L[13],g=L[14],T=Il(Ne,Q),y=T*To,T&&(w=Math.cos(-T),q=Math.sin(-T),I=J*w+H*q,ie=z*w+F*q,he=Ne*w+Q*q,H=J*-q+H*w,F=z*-q+F*w,Q=Ne*-q+Q*w,Te=xe*-q+Te*w,J=I,z=ie,Ne=he),T=Il(-$,Q),S=T*To,T&&(w=Math.cos(-T),q=Math.sin(-T),I=G*w-H*q,ie=k*w-F*q,he=$*w-Q*q,Te=te*q+Te*w,G=I,k=ie,$=he),T=Il(k,G),b=T*To,T&&(w=Math.cos(T),q=Math.sin(T),I=G*w+k*q,ie=J*w+z*q,k=k*w-G*q,z=z*w-J*q,G=I,J=ie),y&&Math.abs(y)+Math.abs(b)>359.9&&(y=b=0,S=180-S),x=On(Math.sqrt(G*G+k*k+$*$)),M=On(Math.sqrt(z*z+Ne*Ne)),T=Il(J,z),R=Math.abs(T)>2e-4?T*To:0,C=Te?1/(Te<0?-Te:Te):0),a.svg&&(I=e.getAttribute("transform"),a.forceCSS=e.setAttribute("transform","")||!Vb(ga(e,Cn)),I&&e.setAttribute("transform",I))),Math.abs(R)>90&&Math.abs(R)<270&&(l?(x*=-1,R+=b<=0?180:-180,b+=b<=0?180:-180):(M*=-1,R+=R<=0?180:-180)),n=n||a.uncache,a.x=_-((a.xPercent=_&&(!n&&a.xPercent||(Math.round(e.offsetWidth/2)===Math.round(-_)?-50:0)))?e.offsetWidth*a.xPercent/100:0)+c,a.y=v-((a.yPercent=v&&(!n&&a.yPercent||(Math.round(e.offsetHeight/2)===Math.round(-v)?-50:0)))?e.offsetHeight*a.yPercent/100:0)+c,a.z=g+c,a.scaleX=On(x),a.scaleY=On(M),a.rotation=On(b)+f,a.rotationX=On(y)+f,a.rotationY=On(S)+f,a.skewX=R+f,a.skewY=N+f,a.transformPerspective=C+c,(a.zOrigin=parseFloat(d.split(" ")[2])||!n&&a.zOrigin||0)&&(r[Qi]=yd(d)),a.xOffset=a.yOffset=0,a.force3D=va.force3D,a.renderTransform=a.svg?AU:Ib?kb:TU,a.uncache=0,a},yd=function(e){return(e=e.split(" "))[0]+" "+e[1]},w_=function(e,n,a){var r=yi(n);return On(parseFloat(n)+parseFloat(Ks(e,"x",a+"px",r)))+r},TU=function(e,n){n.z="0px",n.rotationY=n.rotationX="0deg",n.force3D=0,kb(e,n)},Mo="0deg",fc="0px",bo=") ",kb=function(e,n){var a=n||this,r=a.xPercent,l=a.yPercent,c=a.x,f=a.y,p=a.z,d=a.rotation,_=a.rotationY,v=a.rotationX,g=a.skewX,x=a.skewY,M=a.scaleX,b=a.scaleY,y=a.transformPerspective,S=a.force3D,R=a.target,N=a.zOrigin,C="",O=S==="auto"&&e&&e!==1||S===!0;if(N&&(v!==Mo||_!==Mo)){var P=parseFloat(_)*Kl,L=Math.sin(P),T=Math.cos(P),w;P=parseFloat(v)*Kl,w=Math.cos(P),c=w_(R,c,L*w*-N),f=w_(R,f,-Math.sin(P)*-N),p=w_(R,p,T*w*-N+N)}y!==fc&&(C+="perspective("+y+bo),(r||l)&&(C+="translate("+r+"%, "+l+"%) "),(O||c!==fc||f!==fc||p!==fc)&&(C+=p!==fc||O?"translate3d("+c+", "+f+", "+p+") ":"translate("+c+", "+f+bo),d!==Mo&&(C+="rotate("+d+bo),_!==Mo&&(C+="rotateY("+_+bo),v!==Mo&&(C+="rotateX("+v+bo),(g!==Mo||x!==Mo)&&(C+="skew("+g+", "+x+bo),(M!==1||b!==1)&&(C+="scale("+M+", "+b+bo),R.style[Cn]=C||"translate(0, 0)"},AU=function(e,n){var a=n||this,r=a.xPercent,l=a.yPercent,c=a.x,f=a.y,p=a.rotation,d=a.skewX,_=a.skewY,v=a.scaleX,g=a.scaleY,x=a.target,M=a.xOrigin,b=a.yOrigin,y=a.xOffset,S=a.yOffset,R=a.forceCSS,N=parseFloat(c),C=parseFloat(f),O,P,L,T,w;p=parseFloat(p),d=parseFloat(d),_=parseFloat(_),_&&(_=parseFloat(_),d+=_,p+=_),p||d?(p*=Kl,d*=Kl,O=Math.cos(p)*v,P=Math.sin(p)*v,L=Math.sin(p-d)*-g,T=Math.cos(p-d)*g,d&&(_*=Kl,w=Math.tan(d-_),w=Math.sqrt(1+w*w),L*=w,T*=w,_&&(w=Math.tan(_),w=Math.sqrt(1+w*w),O*=w,P*=w)),O=On(O),P=On(P),L=On(L),T=On(T)):(O=v,T=g,P=L=0),(N&&!~(c+"").indexOf("px")||C&&!~(f+"").indexOf("px"))&&(N=Ks(x,"x",c,"px"),C=Ks(x,"y",f,"px")),(M||b||y||S)&&(N=On(N+M-(M*O+b*L)+y),C=On(C+b-(M*P+b*T)+S)),(r||l)&&(w=x.getBBox(),N=On(N+r/100*w.width),C=On(C+l/100*w.height)),w="matrix("+O+","+P+","+L+","+T+","+N+","+C+")",x.setAttribute("transform",w),R&&(x.style[Cn]=w)},RU=function(e,n,a,r,l){var c=360,f=si(l),p=parseFloat(l)*(f&&~l.indexOf("rad")?To:1),d=p-r,_=r+d+"deg",v,g;return f&&(v=l.split("_")[1],v==="short"&&(d%=c,d!==d%(c/2)&&(d+=d<0?c:-c)),v==="cw"&&d<0?d=(d+c*FM)%c-~~(d/c)*c:v==="ccw"&&d>0&&(d=(d-c*FM)%c-~~(d/c)*c)),e._pt=g=new Ki(e._pt,n,a,r,d,uU),g.e=_,g.u="deg",e._props.push(a),g},XM=function(e,n){for(var a in n)e[a]=n[a];return e},CU=function(e,n,a){var r=XM({},a._gsap),l="perspective,force3D,transformOrigin,svgOrigin",c=a.style,f,p,d,_,v,g,x,M;r.svg?(d=a.getAttribute("transform"),a.setAttribute("transform",""),c[Cn]=n,f=Yc(a,1),Zs(a,Cn),a.setAttribute("transform",d)):(d=getComputedStyle(a)[Cn],c[Cn]=n,f=Yc(a,1),c[Cn]=d);for(p in rs)d=r[p],_=f[p],d!==_&&l.indexOf(p)<0&&(x=yi(d),M=yi(_),v=x!==M?Ks(a,p,d,M):parseFloat(d),g=parseFloat(_),e._pt=new Ki(e._pt,f,p,v,g-v,H0),e._pt.u=M||0,e._props.push(p));XM(f,r)};Zi("padding,margin,Width,Radius",function(o,e){var n="Top",a="Right",r="Bottom",l="Left",c=(e<3?[n,a,r,l]:[n+l,n+a,r+a,r+l]).map(function(f){return e<2?o+f:"border"+f+o});xd[e>1?"border"+o:o]=function(f,p,d,_,v){var g,x;if(arguments.length<4)return g=c.map(function(M){return qr(f,M,d)}),x=g.join(" "),x.split(g[0]).length===5?g[0]:x;g=(_+"").split(" "),x={},c.forEach(function(M,b){return x[M]=g[b]=g[b]||g[(b-1)/2|0]}),f.init(p,x,v)}});var Xb={name:"css",register:V0,targetTest:function(e){return e.style&&e.nodeType},init:function(e,n,a,r,l){var c=this._props,f=e.style,p=a.vars.startAt,d,_,v,g,x,M,b,y,S,R,N,C,O,P,L,T,w;Ag||V0(),this.styles=this.styles||Fb(e),T=this.styles.props,this.tween=a;for(b in n)if(b!=="autoRound"&&(_=n[b],!(ha[b]&&Ab(b,n,a,r,e,l)))){if(x=typeof _,M=xd[b],x==="function"&&(_=_.call(a,r,e,l),x=typeof _),x==="string"&&~_.indexOf("random(")&&(_=Vc(_)),M)M(this,e,b,_,a)&&(L=1);else if(b.substr(0,2)==="--")d=(getComputedStyle(e).getPropertyValue(b)+"").trim(),_+="",Ws.lastIndex=0,Ws.test(d)||(y=yi(d),S=yi(_),S?y!==S&&(d=Ks(e,b,d,S)+S):y&&(_+=y)),this.add(f,"setProperty",d,_,r,l,0,0,b),c.push(b),T.push(b,0,f[b]);else if(x!=="undefined"){if(p&&b in p?(d=typeof p[b]=="function"?p[b].call(a,r,e,l):p[b],si(d)&&~d.indexOf("random(")&&(d=Vc(d)),yi(d+"")||d==="auto"||(d+=va.units[b]||yi(qr(e,b))||""),(d+"").charAt(1)==="="&&(d=qr(e,b))):d=qr(e,b),g=parseFloat(d),R=x==="string"&&_.charAt(1)==="="&&_.substr(0,2),R&&(_=_.substr(2)),v=parseFloat(_),b in mr&&(b==="autoAlpha"&&(g===1&&qr(e,"visibility")==="hidden"&&v&&(g=0),T.push("visibility",0,f.visibility),Gs(this,f,"visibility",g?"inherit":"hidden",v?"inherit":"hidden",!v)),b!=="scale"&&b!=="transform"&&(b=mr[b],~b.indexOf(",")&&(b=b.split(",")[0]))),N=b in rs,N){if(this.styles.save(b),w=_,x==="string"&&_.substring(0,6)==="var(--"){if(_=ga(e,_.substring(4,_.indexOf(")"))),_.substring(0,5)==="calc("){var q=e.style.perspective;e.style.perspective=_,_=ga(e,"perspective"),q?e.style.perspective=q:Zs(e,"perspective")}v=parseFloat(_)}if(C||(O=e._gsap,O.renderTransform&&!n.parseTransform||Yc(e,n.parseTransform),P=n.smoothOrigin!==!1&&O.smooth,C=this._pt=new Ki(this._pt,f,Cn,0,1,O.renderTransform,O,0,-1),C.dep=1),b==="scale")this._pt=new Ki(this._pt,O,"scaleY",O.scaleY,(R?jl(O.scaleY,R+v):v)-O.scaleY||0,H0),this._pt.u=0,c.push("scaleY",b),b+="X";else if(b==="transformOrigin"){T.push(Qi,0,f[Qi]),_=bU(_),O.svg?k0(e,_,0,P,0,this):(S=parseFloat(_.split(" ")[2])||0,S!==O.zOrigin&&Gs(this,O,"zOrigin",O.zOrigin,S),Gs(this,f,b,yd(d),yd(_)));continue}else if(b==="svgOrigin"){k0(e,_,1,P,0,this);continue}else if(b in Gb){RU(this,O,b,g,R?jl(g,R+_):_);continue}else if(b==="smoothOrigin"){Gs(this,O,"smooth",O.smooth,_);continue}else if(b==="force3D"){O[b]=_;continue}else if(b==="transform"){CU(this,_,e);continue}}else b in f||(b=cu(b)||b);if(N||(v||v===0)&&(g||g===0)&&!lU.test(_)&&b in f)y=(d+"").substr((g+"").length),v||(v=0),S=yi(_)||(b in va.units?va.units[b]:y),y!==S&&(g=Ks(e,b,d,S)),this._pt=new Ki(this._pt,N?O:f,b,g,(R?jl(g,R+v):v)-g,!N&&(S==="px"||b==="zIndex")&&n.autoRound!==!1?hU:H0),this._pt.u=S||0,N&&w!==_?(this._pt.b=d,this._pt.e=w,this._pt.r=fU):y!==S&&S!=="%"&&(this._pt.b=d,this._pt.r=cU);else if(b in f)MU.call(this,e,b,d,R?R+_:_);else if(b in e)this.add(e,b,d||e[b],R?R+_:_,r,l);else if(b!=="parseTransform"){_g(b,_);continue}N||(b in f?T.push(b,0,f[b]):typeof e[b]=="function"?T.push(b,2,e[b]()):T.push(b,1,d||e[b])),c.push(b)}}L&&Ub(this)},render:function(e,n){if(n.tween._time||!Rg())for(var a=n._pt;a;)a.r(e,a.d),a=a._next;else n.styles.revert()},get:qr,aliases:mr,getSetter:function(e,n,a){var r=mr[n];return r&&r.indexOf(",")<0&&(n=r),n in rs&&n!==Qi&&(e._gsap.x||qr(e,"x"))?a&&zM===a?n==="scale"?_U:mU:(zM=a||{})&&(n==="scale"?gU:vU):e.style&&!dg(e.style[n])?dU:~n.indexOf("-")?pU:Eg(e,n)},core:{_removeProperty:Zs,_getMatrix:wg}};Ji.utils.checkPrefix=cu;Ji.core.getStyleSaver=Fb;(function(o,e,n,a){var r=Zi(o+","+e+","+n,function(l){rs[l]=1});Zi(e,function(l){va.units[l]="deg",Gb[l]=1}),mr[r[13]]=o+","+e,Zi(a,function(l){var c=l.split(":");mr[c[1]]=r[c[0]]})})("x,y,z,scale,scaleX,scaleY,xPercent,yPercent","rotation,rotationX,rotationY,skewX,skewY","transform,transformOrigin,svgOrigin,force3D,smoothOrigin,transformPerspective","0:translateX,1:translateY,2:translateZ,8:rotate,8:rotationZ,8:rotateZ,9:rotateX,10:rotateY");Zi("x,y,z,top,right,bottom,left,width,height,fontSize,padding,margin,perspective",function(o){va.units[o]="px"});Ji.registerPlugin(Xb);var ur=Ji.registerPlugin(Xb)||Ji;ur.core.Tween;function wU(o,e){for(var n=0;n<e.length;n++){var a=e[n];a.enumerable=a.enumerable||!1,a.configurable=!0,"value"in a&&(a.writable=!0),Object.defineProperty(o,a.key,a)}}function DU(o,e,n){return e&&wU(o.prototype,e),o}/*!
 * Observer 3.14.2
 * https://gsap.com
 *
 * @license Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
*/var hi,id,ma,Vs,ks,Ql,Wb,Ao,Rc,Yb,Qr,Ka,qb,jb=function(){return hi||typeof window<"u"&&(hi=window.gsap)&&hi.registerPlugin&&hi},Zb=1,Wl=[],Ot=[],yr=[],Cc=Date.now,X0=function(e,n){return n},NU=function(){var e=Rc.core,n=e.bridge||{},a=e._scrollers,r=e._proxies;a.push.apply(a,Ot),r.push.apply(r,yr),Ot=a,yr=r,X0=function(c,f){return n[c](f)}},Ys=function(e,n){return~yr.indexOf(e)&&yr[yr.indexOf(e)+1][n]},wc=function(e){return!!~Yb.indexOf(e)},Di=function(e,n,a,r,l){return e.addEventListener(n,a,{passive:r!==!1,capture:!!l})},wi=function(e,n,a,r){return e.removeEventListener(n,a,!!r)},Ph="scrollLeft",zh="scrollTop",W0=function(){return Qr&&Qr.isPressed||Ot.cache++},Sd=function(e,n){var a=function r(l){if(l||l===0){Zb&&(ma.history.scrollRestoration="manual");var c=Qr&&Qr.isPressed;l=r.v=Math.round(l)||(Qr&&Qr.iOS?1:0),e(l),r.cacheID=Ot.cache,c&&X0("ss",l)}else(n||Ot.cache!==r.cacheID||X0("ref"))&&(r.cacheID=Ot.cache,r.v=e());return r.v+r.offset};return a.offset=0,e&&a},zi={s:Ph,p:"left",p2:"Left",os:"right",os2:"Right",d:"width",d2:"Width",a:"x",sc:Sd(function(o){return arguments.length?ma.scrollTo(o,Qn.sc()):ma.pageXOffset||Vs[Ph]||ks[Ph]||Ql[Ph]||0})},Qn={s:zh,p:"top",p2:"Top",os:"bottom",os2:"Bottom",d:"height",d2:"Height",a:"y",op:zi,sc:Sd(function(o){return arguments.length?ma.scrollTo(zi.sc(),o):ma.pageYOffset||Vs[zh]||ks[zh]||Ql[zh]||0})},Wi=function(e,n){return(n&&n._ctx&&n._ctx.selector||hi.utils.toArray)(e)[0]||(typeof e=="string"&&hi.config().nullTargetWarn!==!1?console.warn("Element not found:",e):null)},UU=function(e,n){for(var a=n.length;a--;)if(n[a]===e||n[a].contains(e))return!0;return!1},Qs=function(e,n){var a=n.s,r=n.sc;wc(e)&&(e=Vs.scrollingElement||ks);var l=Ot.indexOf(e),c=r===Qn.sc?1:2;!~l&&(l=Ot.push(e)-1),Ot[l+c]||Di(e,"scroll",W0);var f=Ot[l+c],p=f||(Ot[l+c]=Sd(Ys(e,a),!0)||(wc(e)?r:Sd(function(d){return arguments.length?e[a]=d:e[a]})));return p.target=e,f||(p.smooth=hi.getProperty(e,"scrollBehavior")==="smooth"),p},Y0=function(e,n,a){var r=e,l=e,c=Cc(),f=c,p=n||50,d=Math.max(500,p*3),_=function(M,b){var y=Cc();b||y-c>p?(l=r,r=M,f=c,c=y):a?r+=M:r=l+(M-l)/(y-f)*(c-f)},v=function(){l=r=a?0:r,f=c=0},g=function(M){var b=f,y=l,S=Cc();return(M||M===0)&&M!==r&&_(M),c===f||S-f>d?0:(r+(a?y:-y))/((a?S:c)-b)*1e3};return{update:_,reset:v,getVelocity:g}},hc=function(e,n){return n&&!e._gsapAllow&&e.preventDefault(),e.changedTouches?e.changedTouches[0]:e},WM=function(e){var n=Math.max.apply(Math,e),a=Math.min.apply(Math,e);return Math.abs(n)>=Math.abs(a)?n:a},Kb=function(){Rc=hi.core.globals().ScrollTrigger,Rc&&Rc.core&&NU()},Qb=function(e){return hi=e||jb(),!id&&hi&&typeof document<"u"&&document.body&&(ma=window,Vs=document,ks=Vs.documentElement,Ql=Vs.body,Yb=[ma,Vs,ks,Ql],hi.utils.clamp,qb=hi.core.context||function(){},Ao="onpointerenter"in Ql?"pointer":"mouse",Wb=zn.isTouch=ma.matchMedia&&ma.matchMedia("(hover: none), (pointer: coarse)").matches?1:"ontouchstart"in ma||navigator.maxTouchPoints>0||navigator.msMaxTouchPoints>0?2:0,Ka=zn.eventTypes=("ontouchstart"in ks?"touchstart,touchmove,touchcancel,touchend":"onpointerdown"in ks?"pointerdown,pointermove,pointercancel,pointerup":"mousedown,mousemove,mouseup,mouseup").split(","),setTimeout(function(){return Zb=0},500),Kb(),id=1),id};zi.op=Qn;Ot.cache=0;var zn=(function(){function o(n){this.init(n)}var e=o.prototype;return e.init=function(a){id||Qb(hi)||console.warn("Please gsap.registerPlugin(Observer)"),Rc||Kb();var r=a.tolerance,l=a.dragMinimum,c=a.type,f=a.target,p=a.lineHeight,d=a.debounce,_=a.preventDefault,v=a.onStop,g=a.onStopDelay,x=a.ignore,M=a.wheelSpeed,b=a.event,y=a.onDragStart,S=a.onDragEnd,R=a.onDrag,N=a.onPress,C=a.onRelease,O=a.onRight,P=a.onLeft,L=a.onUp,T=a.onDown,w=a.onChangeX,q=a.onChangeY,G=a.onChange,k=a.onToggleX,$=a.onToggleY,te=a.onHover,J=a.onHoverEnd,z=a.onMove,I=a.ignoreCheck,ie=a.isNormalizer,he=a.onGestureStart,H=a.onGestureEnd,F=a.onWheel,Q=a.onEnable,xe=a.onDisable,Te=a.onClick,Ne=a.scrollSpeed,ne=a.capture,_e=a.allowClicks,be=a.lockAxis,ze=a.onLockAxis;this.target=f=Wi(f)||ks,this.vars=a,x&&(x=hi.utils.toArray(x)),r=r||1e-9,l=l||0,M=M||1,Ne=Ne||1,c=c||"wheel,touch,pointer",d=d!==!1,p||(p=parseFloat(ma.getComputedStyle(Ql).lineHeight)||22);var tt,Ke,Ut,qe,rt,_t,st,le=this,W=0,Wt=0,bt=a.passive||!_&&a.passive!==!1,ct=Qs(f,zi),We=Qs(f,Qn),B=ct(),A=We(),Z=~c.indexOf("touch")&&!~c.indexOf("pointer")&&Ka[0]==="pointerdown",ge=wc(f),ve=f.ownerDocument||Vs,de=[0,0,0],Ge=[0,0,0],we=0,it=function(){return we=Cc()},Ye=function(Je,Et){return(le.event=Je)&&x&&UU(Je.target,x)||Et&&Z&&Je.pointerType!=="touch"||I&&I(Je,Et)},Re=function(){le._vx.reset(),le._vy.reset(),Ke.pause(),v&&v(le)},Ae=function(){var Je=le.deltaX=WM(de),Et=le.deltaY=WM(Ge),Ie=Math.abs(Je)>=r,ht=Math.abs(Et)>=r;G&&(Ie||ht)&&G(le,Je,Et,de,Ge),Ie&&(O&&le.deltaX>0&&O(le),P&&le.deltaX<0&&P(le),w&&w(le),k&&le.deltaX<0!=W<0&&k(le),W=le.deltaX,de[0]=de[1]=de[2]=0),ht&&(T&&le.deltaY>0&&T(le),L&&le.deltaY<0&&L(le),q&&q(le),$&&le.deltaY<0!=Wt<0&&$(le),Wt=le.deltaY,Ge[0]=Ge[1]=Ge[2]=0),(qe||Ut)&&(z&&z(le),Ut&&(y&&Ut===1&&y(le),R&&R(le),Ut=0),qe=!1),_t&&!(_t=!1)&&ze&&ze(le),rt&&(F(le),rt=!1),tt=0},He=function(Je,Et,Ie){de[Ie]+=Je,Ge[Ie]+=Et,le._vx.update(Je),le._vy.update(Et),d?tt||(tt=requestAnimationFrame(Ae)):Ae()},Pe=function(Je,Et){be&&!st&&(le.axis=st=Math.abs(Je)>Math.abs(Et)?"x":"y",_t=!0),st!=="y"&&(de[2]+=Je,le._vx.update(Je,!0)),st!=="x"&&(Ge[2]+=Et,le._vy.update(Et,!0)),d?tt||(tt=requestAnimationFrame(Ae)):Ae()},Fe=function(Je){if(!Ye(Je,1)){Je=hc(Je,_);var Et=Je.clientX,Ie=Je.clientY,ht=Et-le.x,ot=Ie-le.y,dt=le.isDragging;le.x=Et,le.y=Ie,(dt||(ht||ot)&&(Math.abs(le.startX-Et)>=l||Math.abs(le.startY-Ie)>=l))&&(Ut||(Ut=dt?2:1),dt||(le.isDragging=!0),Pe(ht,ot))}},pt=le.onPress=function(Ve){Ye(Ve,1)||Ve&&Ve.button||(le.axis=st=null,Ke.pause(),le.isPressed=!0,Ve=hc(Ve),W=Wt=0,le.startX=le.x=Ve.clientX,le.startY=le.y=Ve.clientY,le._vx.reset(),le._vy.reset(),Di(ie?f:ve,Ka[1],Fe,bt,!0),le.deltaX=le.deltaY=0,N&&N(le))},V=le.onRelease=function(Ve){if(!Ye(Ve,1)){wi(ie?f:ve,Ka[1],Fe,!0);var Je=!isNaN(le.y-le.startY),Et=le.isDragging,Ie=Et&&(Math.abs(le.x-le.startX)>3||Math.abs(le.y-le.startY)>3),ht=hc(Ve);!Ie&&Je&&(le._vx.reset(),le._vy.reset(),_&&_e&&hi.delayedCall(.08,function(){if(Cc()-we>300&&!Ve.defaultPrevented){if(Ve.target.click)Ve.target.click();else if(ve.createEvent){var ot=ve.createEvent("MouseEvents");ot.initMouseEvent("click",!0,!0,ma,1,ht.screenX,ht.screenY,ht.clientX,ht.clientY,!1,!1,!1,!1,0,null),Ve.target.dispatchEvent(ot)}}})),le.isDragging=le.isGesturing=le.isPressed=!1,v&&Et&&!ie&&Ke.restart(!0),Ut&&Ae(),S&&Et&&S(le),C&&C(le,Ie)}},De=function(Je){return Je.touches&&Je.touches.length>1&&(le.isGesturing=!0)&&he(Je,le.isDragging)},Ce=function(){return(le.isGesturing=!1)||H(le)},Le=function(Je){if(!Ye(Je)){var Et=ct(),Ie=We();He((Et-B)*Ne,(Ie-A)*Ne,1),B=Et,A=Ie,v&&Ke.restart(!0)}},Ee=function(Je){if(!Ye(Je)){Je=hc(Je,_),F&&(rt=!0);var Et=(Je.deltaMode===1?p:Je.deltaMode===2?ma.innerHeight:1)*M;He(Je.deltaX*Et,Je.deltaY*Et,0),v&&!ie&&Ke.restart(!0)}},me=function(Je){if(!Ye(Je)){var Et=Je.clientX,Ie=Je.clientY,ht=Et-le.x,ot=Ie-le.y;le.x=Et,le.y=Ie,qe=!0,v&&Ke.restart(!0),(ht||ot)&&Pe(ht,ot)}},Xe=function(Je){le.event=Je,te(le)},lt=function(Je){le.event=Je,J(le)},Gt=function(Je){return Ye(Je)||hc(Je,_)&&Te(le)};Ke=le._dc=hi.delayedCall(g||.25,Re).pause(),le.deltaX=le.deltaY=0,le._vx=Y0(0,50,!0),le._vy=Y0(0,50,!0),le.scrollX=ct,le.scrollY=We,le.isDragging=le.isGesturing=le.isPressed=!1,qb(this),le.enable=function(Ve){return le.isEnabled||(Di(ge?ve:f,"scroll",W0),c.indexOf("scroll")>=0&&Di(ge?ve:f,"scroll",Le,bt,ne),c.indexOf("wheel")>=0&&Di(f,"wheel",Ee,bt,ne),(c.indexOf("touch")>=0&&Wb||c.indexOf("pointer")>=0)&&(Di(f,Ka[0],pt,bt,ne),Di(ve,Ka[2],V),Di(ve,Ka[3],V),_e&&Di(f,"click",it,!0,!0),Te&&Di(f,"click",Gt),he&&Di(ve,"gesturestart",De),H&&Di(ve,"gestureend",Ce),te&&Di(f,Ao+"enter",Xe),J&&Di(f,Ao+"leave",lt),z&&Di(f,Ao+"move",me)),le.isEnabled=!0,le.isDragging=le.isGesturing=le.isPressed=qe=Ut=!1,le._vx.reset(),le._vy.reset(),B=ct(),A=We(),Ve&&Ve.type&&pt(Ve),Q&&Q(le)),le},le.disable=function(){le.isEnabled&&(Wl.filter(function(Ve){return Ve!==le&&wc(Ve.target)}).length||wi(ge?ve:f,"scroll",W0),le.isPressed&&(le._vx.reset(),le._vy.reset(),wi(ie?f:ve,Ka[1],Fe,!0)),wi(ge?ve:f,"scroll",Le,ne),wi(f,"wheel",Ee,ne),wi(f,Ka[0],pt,ne),wi(ve,Ka[2],V),wi(ve,Ka[3],V),wi(f,"click",it,!0),wi(f,"click",Gt),wi(ve,"gesturestart",De),wi(ve,"gestureend",Ce),wi(f,Ao+"enter",Xe),wi(f,Ao+"leave",lt),wi(f,Ao+"move",me),le.isEnabled=le.isPressed=le.isDragging=!1,xe&&xe(le))},le.kill=le.revert=function(){le.disable();var Ve=Wl.indexOf(le);Ve>=0&&Wl.splice(Ve,1),Qr===le&&(Qr=0)},Wl.push(le),ie&&wc(f)&&(Qr=le),le.enable(b)},DU(o,[{key:"velocityX",get:function(){return this._vx.getVelocity()}},{key:"velocityY",get:function(){return this._vy.getVelocity()}}]),o})();zn.version="3.14.2";zn.create=function(o){return new zn(o)};zn.register=Qb;zn.getAll=function(){return Wl.slice()};zn.getById=function(o){return Wl.filter(function(e){return e.vars.id===o})[0]};jb()&&hi.registerPlugin(zn);/*!
 * ScrollTrigger 3.14.2
 * https://gsap.com
 *
 * @license Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
*/var et,Gl,Lt,mn,da,en,Dg,Md,qc,Dc,xc,Fh,vi,Ld,q0,Li,YM,qM,Vl,Jb,D_,$b,Ui,j0,eE,tE,zs,Z0,Ng,Jl,Ug,Nc,K0,N_,Ih=1,xi=Date.now,U_=xi(),Ha=0,yc=0,jM=function(e,n,a){var r=fa(e)&&(e.substr(0,6)==="clamp("||e.indexOf("max")>-1);return a["_"+n+"Clamp"]=r,r?e.substr(6,e.length-7):e},ZM=function(e,n){return n&&(!fa(e)||e.substr(0,6)!=="clamp(")?"clamp("+e+")":e},LU=function o(){return yc&&requestAnimationFrame(o)},KM=function(){return Ld=1},QM=function(){return Ld=0},cr=function(e){return e},Sc=function(e){return Math.round(e*1e5)/1e5||0},nE=function(){return typeof window<"u"},iE=function(){return et||nE()&&(et=window.gsap)&&et.registerPlugin&&et},Vo=function(e){return!!~Dg.indexOf(e)},aE=function(e){return(e==="Height"?Ug:Lt["inner"+e])||da["client"+e]||en["client"+e]},rE=function(e){return Ys(e,"getBoundingClientRect")||(Vo(e)?function(){return ld.width=Lt.innerWidth,ld.height=Ug,ld}:function(){return Zr(e)})},OU=function(e,n,a){var r=a.d,l=a.d2,c=a.a;return(c=Ys(e,"getBoundingClientRect"))?function(){return c()[r]}:function(){return(n?aE(l):e["client"+l])||0}},PU=function(e,n){return!n||~yr.indexOf(e)?rE(e):function(){return ld}},_r=function(e,n){var a=n.s,r=n.d2,l=n.d,c=n.a;return Math.max(0,(a="scroll"+r)&&(c=Ys(e,a))?c()-rE(e)()[l]:Vo(e)?(da[a]||en[a])-aE(r):e[a]-e["offset"+r])},Bh=function(e,n){for(var a=0;a<Vl.length;a+=3)(!n||~n.indexOf(Vl[a+1]))&&e(Vl[a],Vl[a+1],Vl[a+2])},fa=function(e){return typeof e=="string"},Si=function(e){return typeof e=="function"},Mc=function(e){return typeof e=="number"},Ro=function(e){return typeof e=="object"},dc=function(e,n,a){return e&&e.progress(n?0:1)&&a&&e.pause()},L_=function(e,n){if(e.enabled){var a=e._ctx?e._ctx.add(function(){return n(e)}):n(e);a&&a.totalTime&&(e.callbackAnimation=a)}},Bl=Math.abs,sE="left",oE="top",Lg="right",Og="bottom",Io="width",Bo="height",Uc="Right",Lc="Left",Oc="Top",Pc="Bottom",Yn="padding",Oa="margin",fu="Width",Pg="Height",Kn="px",Pa=function(e){return Lt.getComputedStyle(e)},zU=function(e){var n=Pa(e).position;e.style.position=n==="absolute"||n==="fixed"?n:"relative"},JM=function(e,n){for(var a in n)a in e||(e[a]=n[a]);return e},Zr=function(e,n){var a=n&&Pa(e)[q0]!=="matrix(1, 0, 0, 1, 0, 0)"&&et.to(e,{x:0,y:0,xPercent:0,yPercent:0,rotation:0,rotationX:0,rotationY:0,scale:1,skewX:0,skewY:0}).progress(1),r=e.getBoundingClientRect();return a&&a.progress(0).kill(),r},bd=function(e,n){var a=n.d2;return e["offset"+a]||e["client"+a]||0},lE=function(e){var n=[],a=e.labels,r=e.duration(),l;for(l in a)n.push(a[l]/r);return n},FU=function(e){return function(n){return et.utils.snap(lE(e),n)}},zg=function(e){var n=et.utils.snap(e),a=Array.isArray(e)&&e.slice(0).sort(function(r,l){return r-l});return a?function(r,l,c){c===void 0&&(c=.001);var f;if(!l)return n(r);if(l>0){for(r-=c,f=0;f<a.length;f++)if(a[f]>=r)return a[f];return a[f-1]}else for(f=a.length,r+=c;f--;)if(a[f]<=r)return a[f];return a[0]}:function(r,l,c){c===void 0&&(c=.001);var f=n(r);return!l||Math.abs(f-r)<c||f-r<0==l<0?f:n(l<0?r-e:r+e)}},IU=function(e){return function(n,a){return zg(lE(e))(n,a.direction)}},Hh=function(e,n,a,r){return a.split(",").forEach(function(l){return e(n,l,r)})},ri=function(e,n,a,r,l){return e.addEventListener(n,a,{passive:!r,capture:!!l})},ai=function(e,n,a,r){return e.removeEventListener(n,a,!!r)},Gh=function(e,n,a){a=a&&a.wheelHandler,a&&(e(n,"wheel",a),e(n,"touchmove",a))},$M={startColor:"green",endColor:"red",indent:0,fontSize:"16px",fontWeight:"normal"},Vh={toggleActions:"play",anticipatePin:0},Ed={top:0,left:0,center:.5,bottom:1,right:1},ad=function(e,n){if(fa(e)){var a=e.indexOf("="),r=~a?+(e.charAt(a-1)+1)*parseFloat(e.substr(a+1)):0;~a&&(e.indexOf("%")>a&&(r*=n/100),e=e.substr(0,a-1)),e=r+(e in Ed?Ed[e]*n:~e.indexOf("%")?parseFloat(e)*n/100:parseFloat(e)||0)}return e},kh=function(e,n,a,r,l,c,f,p){var d=l.startColor,_=l.endColor,v=l.fontSize,g=l.indent,x=l.fontWeight,M=mn.createElement("div"),b=Vo(a)||Ys(a,"pinType")==="fixed",y=e.indexOf("scroller")!==-1,S=b?en:a,R=e.indexOf("start")!==-1,N=R?d:_,C="border-color:"+N+";font-size:"+v+";color:"+N+";font-weight:"+x+";pointer-events:none;white-space:nowrap;font-family:sans-serif,Arial;z-index:1000;padding:4px 8px;border-width:0;border-style:solid;";return C+="position:"+((y||p)&&b?"fixed;":"absolute;"),(y||p||!b)&&(C+=(r===Qn?Lg:Og)+":"+(c+parseFloat(g))+"px;"),f&&(C+="box-sizing:border-box;text-align:left;width:"+f.offsetWidth+"px;"),M._isStart=R,M.setAttribute("class","gsap-marker-"+e+(n?" marker-"+n:"")),M.style.cssText=C,M.innerText=n||n===0?e+"-"+n:e,S.children[0]?S.insertBefore(M,S.children[0]):S.appendChild(M),M._offset=M["offset"+r.op.d2],rd(M,0,r,R),M},rd=function(e,n,a,r){var l={display:"block"},c=a[r?"os2":"p2"],f=a[r?"p2":"os2"];e._isFlipped=r,l[a.a+"Percent"]=r?-100:0,l[a.a]=r?"1px":0,l["border"+c+fu]=1,l["border"+f+fu]=0,l[a.p]=n+"px",et.set(e,l)},Nt=[],Q0={},jc,e1=function(){return xi()-Ha>34&&(jc||(jc=requestAnimationFrame(es)))},Hl=function(){(!Ui||!Ui.isPressed||Ui.startX>en.clientWidth)&&(Ot.cache++,Ui?jc||(jc=requestAnimationFrame(es)):es(),Ha||Xo("scrollStart"),Ha=xi())},O_=function(){tE=Lt.innerWidth,eE=Lt.innerHeight},bc=function(e){Ot.cache++,(e===!0||!vi&&!$b&&!mn.fullscreenElement&&!mn.webkitFullscreenElement&&(!j0||tE!==Lt.innerWidth||Math.abs(Lt.innerHeight-eE)>Lt.innerHeight*.25))&&Md.restart(!0)},ko={},BU=[],uE=function o(){return ai(It,"scrollEnd",o)||Lo(!0)},Xo=function(e){return ko[e]&&ko[e].map(function(n){return n()})||BU},ca=[],cE=function(e){for(var n=0;n<ca.length;n+=5)(!e||ca[n+4]&&ca[n+4].query===e)&&(ca[n].style.cssText=ca[n+1],ca[n].getBBox&&ca[n].setAttribute("transform",ca[n+2]||""),ca[n+3].uncache=1)},fE=function(){return Ot.forEach(function(e){return Si(e)&&++e.cacheID&&(e.rec=e())})},Fg=function(e,n){var a;for(Li=0;Li<Nt.length;Li++)a=Nt[Li],a&&(!n||a._ctx===n)&&(e?a.kill(1):a.revert(!0,!0));Nc=!0,n&&cE(n),n||Xo("revert")},hE=function(e,n){Ot.cache++,(n||!Oi)&&Ot.forEach(function(a){return Si(a)&&a.cacheID++&&(a.rec=0)}),fa(e)&&(Lt.history.scrollRestoration=Ng=e)},Oi,Ho=0,t1,HU=function(){if(t1!==Ho){var e=t1=Ho;requestAnimationFrame(function(){return e===Ho&&Lo(!0)})}},dE=function(){en.appendChild(Jl),Ug=!Ui&&Jl.offsetHeight||Lt.innerHeight,en.removeChild(Jl)},n1=function(e){return qc(".gsap-marker-start, .gsap-marker-end, .gsap-marker-scroller-start, .gsap-marker-scroller-end").forEach(function(n){return n.style.display=e?"none":"block"})},Lo=function(e,n){if(da=mn.documentElement,en=mn.body,Dg=[Lt,mn,da,en],Ha&&!e&&!Nc){ri(It,"scrollEnd",uE);return}dE(),Oi=It.isRefreshing=!0,Nc||fE();var a=Xo("refreshInit");Jb&&It.sort(),n||Fg(),Ot.forEach(function(r){Si(r)&&(r.smooth&&(r.target.style.scrollBehavior="auto"),r(0))}),Nt.slice(0).forEach(function(r){return r.refresh()}),Nc=!1,Nt.forEach(function(r){if(r._subPinOffset&&r.pin){var l=r.vars.horizontal?"offsetWidth":"offsetHeight",c=r.pin[l];r.revert(!0,1),r.adjustPinSpacing(r.pin[l]-c),r.refresh()}}),K0=1,n1(!0),Nt.forEach(function(r){var l=_r(r.scroller,r._dir),c=r.vars.end==="max"||r._endClamp&&r.end>l,f=r._startClamp&&r.start>=l;(c||f)&&r.setPositions(f?l-1:r.start,c?Math.max(f?l:r.start+1,l):r.end,!0)}),n1(!1),K0=0,a.forEach(function(r){return r&&r.render&&r.render(-1)}),Ot.forEach(function(r){Si(r)&&(r.smooth&&requestAnimationFrame(function(){return r.target.style.scrollBehavior="smooth"}),r.rec&&r(r.rec))}),hE(Ng,1),Md.pause(),Ho++,Oi=2,es(2),Nt.forEach(function(r){return Si(r.vars.onRefresh)&&r.vars.onRefresh(r)}),Oi=It.isRefreshing=!1,Xo("refresh")},J0=0,sd=1,zc,es=function(e){if(e===2||!Oi&&!Nc){It.isUpdating=!0,zc&&zc.update(0);var n=Nt.length,a=xi(),r=a-U_>=50,l=n&&Nt[0].scroll();if(sd=J0>l?-1:1,Oi||(J0=l),r&&(Ha&&!Ld&&a-Ha>200&&(Ha=0,Xo("scrollEnd")),xc=U_,U_=a),sd<0){for(Li=n;Li-- >0;)Nt[Li]&&Nt[Li].update(0,r);sd=1}else for(Li=0;Li<n;Li++)Nt[Li]&&Nt[Li].update(0,r);It.isUpdating=!1}jc=0},$0=[sE,oE,Og,Lg,Oa+Pc,Oa+Uc,Oa+Oc,Oa+Lc,"display","flexShrink","float","zIndex","gridColumnStart","gridColumnEnd","gridRowStart","gridRowEnd","gridArea","justifySelf","alignSelf","placeSelf","order"],od=$0.concat([Io,Bo,"boxSizing","max"+fu,"max"+Pg,"position",Oa,Yn,Yn+Oc,Yn+Uc,Yn+Pc,Yn+Lc]),GU=function(e,n,a){$l(a);var r=e._gsap;if(r.spacerIsNative)$l(r.spacerState);else if(e._gsap.swappedIn){var l=n.parentNode;l&&(l.insertBefore(e,n),l.removeChild(n))}e._gsap.swappedIn=!1},P_=function(e,n,a,r){if(!e._gsap.swappedIn){for(var l=$0.length,c=n.style,f=e.style,p;l--;)p=$0[l],c[p]=a[p];c.position=a.position==="absolute"?"absolute":"relative",a.display==="inline"&&(c.display="inline-block"),f[Og]=f[Lg]="auto",c.flexBasis=a.flexBasis||"auto",c.overflow="visible",c.boxSizing="border-box",c[Io]=bd(e,zi)+Kn,c[Bo]=bd(e,Qn)+Kn,c[Yn]=f[Oa]=f[oE]=f[sE]="0",$l(r),f[Io]=f["max"+fu]=a[Io],f[Bo]=f["max"+Pg]=a[Bo],f[Yn]=a[Yn],e.parentNode!==n&&(e.parentNode.insertBefore(n,e),n.appendChild(e)),e._gsap.swappedIn=!0}},VU=/([A-Z])/g,$l=function(e){if(e){var n=e.t.style,a=e.length,r=0,l,c;for((e.t._gsap||et.core.getCache(e.t)).uncache=1;r<a;r+=2)c=e[r+1],l=e[r],c?n[l]=c:n[l]&&n.removeProperty(l.replace(VU,"-$1").toLowerCase())}},Xh=function(e){for(var n=od.length,a=e.style,r=[],l=0;l<n;l++)r.push(od[l],a[od[l]]);return r.t=e,r},kU=function(e,n,a){for(var r=[],l=e.length,c=a?8:0,f;c<l;c+=2)f=e[c],r.push(f,f in n?n[f]:e[c+1]);return r.t=e.t,r},ld={left:0,top:0},i1=function(e,n,a,r,l,c,f,p,d,_,v,g,x,M){Si(e)&&(e=e(p)),fa(e)&&e.substr(0,3)==="max"&&(e=g+(e.charAt(4)==="="?ad("0"+e.substr(3),a):0));var b=x?x.time():0,y,S,R;if(x&&x.seek(0),isNaN(e)||(e=+e),Mc(e))x&&(e=et.utils.mapRange(x.scrollTrigger.start,x.scrollTrigger.end,0,g,e)),f&&rd(f,a,r,!0);else{Si(n)&&(n=n(p));var N=(e||"0").split(" "),C,O,P,L;R=Wi(n,p)||en,C=Zr(R)||{},(!C||!C.left&&!C.top)&&Pa(R).display==="none"&&(L=R.style.display,R.style.display="block",C=Zr(R),L?R.style.display=L:R.style.removeProperty("display")),O=ad(N[0],C[r.d]),P=ad(N[1]||"0",a),e=C[r.p]-d[r.p]-_+O+l-P,f&&rd(f,P,r,a-P<20||f._isStart&&P>20),a-=a-P}if(M&&(p[M]=e||-.001,e<0&&(e=0)),c){var T=e+a,w=c._isStart;y="scroll"+r.d2,rd(c,T,r,w&&T>20||!w&&(v?Math.max(en[y],da[y]):c.parentNode[y])<=T+1),v&&(d=Zr(f),v&&(c.style[r.op.p]=d[r.op.p]-r.op.m-c._offset+Kn))}return x&&R&&(y=Zr(R),x.seek(g),S=Zr(R),x._caScrollDist=y[r.p]-S[r.p],e=e/x._caScrollDist*g),x&&x.seek(b),x?e:Math.round(e)},XU=/(webkit|moz|length|cssText|inset)/i,a1=function(e,n,a,r){if(e.parentNode!==n){var l=e.style,c,f;if(n===en){e._stOrig=l.cssText,f=Pa(e);for(c in f)!+c&&!XU.test(c)&&f[c]&&typeof l[c]=="string"&&c!=="0"&&(l[c]=f[c]);l.top=a,l.left=r}else l.cssText=e._stOrig;et.core.getCache(e).uncache=1,n.appendChild(e)}},pE=function(e,n,a){var r=n,l=r;return function(c){var f=Math.round(e());return f!==r&&f!==l&&Math.abs(f-r)>3&&Math.abs(f-l)>3&&(c=f,a&&a()),l=r,r=Math.round(c),r}},Wh=function(e,n,a){var r={};r[n.p]="+="+a,et.set(e,r)},r1=function(e,n){var a=Qs(e,n),r="_scroll"+n.p2,l=function c(f,p,d,_,v){var g=c.tween,x=p.onComplete,M={};d=d||a();var b=pE(a,d,function(){g.kill(),c.tween=0});return v=_&&v||0,_=_||f-d,g&&g.kill(),p[r]=f,p.inherit=!1,p.modifiers=M,M[r]=function(){return b(d+_*g.ratio+v*g.ratio*g.ratio)},p.onUpdate=function(){Ot.cache++,c.tween&&es()},p.onComplete=function(){c.tween=0,x&&x.call(g)},g=c.tween=et.to(e,p),g};return e[r]=a,a.wheelHandler=function(){return l.tween&&l.tween.kill()&&(l.tween=0)},ri(e,"wheel",a.wheelHandler),It.isTouch&&ri(e,"touchmove",a.wheelHandler),l},It=(function(){function o(n,a){Gl||o.register(et)||console.warn("Please gsap.registerPlugin(ScrollTrigger)"),Z0(this),this.init(n,a)}var e=o.prototype;return e.init=function(a,r){if(this.progress=this.start=0,this.vars&&this.kill(!0,!0),!yc){this.update=this.refresh=this.kill=cr;return}a=JM(fa(a)||Mc(a)||a.nodeType?{trigger:a}:a,Vh);var l=a,c=l.onUpdate,f=l.toggleClass,p=l.id,d=l.onToggle,_=l.onRefresh,v=l.scrub,g=l.trigger,x=l.pin,M=l.pinSpacing,b=l.invalidateOnRefresh,y=l.anticipatePin,S=l.onScrubComplete,R=l.onSnapComplete,N=l.once,C=l.snap,O=l.pinReparent,P=l.pinSpacer,L=l.containerAnimation,T=l.fastScrollEnd,w=l.preventOverlaps,q=a.horizontal||a.containerAnimation&&a.horizontal!==!1?zi:Qn,G=!v&&v!==0,k=Wi(a.scroller||Lt),$=et.core.getCache(k),te=Vo(k),J=("pinType"in a?a.pinType:Ys(k,"pinType")||te&&"fixed")==="fixed",z=[a.onEnter,a.onLeave,a.onEnterBack,a.onLeaveBack],I=G&&a.toggleActions.split(" "),ie="markers"in a?a.markers:Vh.markers,he=te?0:parseFloat(Pa(k)["border"+q.p2+fu])||0,H=this,F=a.onRefreshInit&&function(){return a.onRefreshInit(H)},Q=OU(k,te,q),xe=PU(k,te),Te=0,Ne=0,ne=0,_e=Qs(k,q),be,ze,tt,Ke,Ut,qe,rt,_t,st,le,W,Wt,bt,ct,We,B,A,Z,ge,ve,de,Ge,we,it,Ye,Re,Ae,He,Pe,Fe,pt,V,De,Ce,Le,Ee,me,Xe,lt;if(H._startClamp=H._endClamp=!1,H._dir=q,y*=45,H.scroller=k,H.scroll=L?L.time.bind(L):_e,Ke=_e(),H.vars=a,r=r||a.animation,"refreshPriority"in a&&(Jb=1,a.refreshPriority===-9999&&(zc=H)),$.tweenScroll=$.tweenScroll||{top:r1(k,Qn),left:r1(k,zi)},H.tweenTo=be=$.tweenScroll[q.p],H.scrubDuration=function(Ie){De=Mc(Ie)&&Ie,De?V?V.duration(Ie):V=et.to(r,{ease:"expo",totalProgress:"+=0",inherit:!1,duration:De,paused:!0,onComplete:function(){return S&&S(H)}}):(V&&V.progress(1).kill(),V=0)},r&&(r.vars.lazy=!1,r._initted&&!H.isReverted||r.vars.immediateRender!==!1&&a.immediateRender!==!1&&r.duration()&&r.render(0,!0,!0),H.animation=r.pause(),r.scrollTrigger=H,H.scrubDuration(v),Fe=0,p||(p=r.vars.id)),C&&((!Ro(C)||C.push)&&(C={snapTo:C}),"scrollBehavior"in en.style&&et.set(te?[en,da]:k,{scrollBehavior:"auto"}),Ot.forEach(function(Ie){return Si(Ie)&&Ie.target===(te?mn.scrollingElement||da:k)&&(Ie.smooth=!1)}),tt=Si(C.snapTo)?C.snapTo:C.snapTo==="labels"?FU(r):C.snapTo==="labelsDirectional"?IU(r):C.directional!==!1?function(Ie,ht){return zg(C.snapTo)(Ie,xi()-Ne<500?0:ht.direction)}:et.utils.snap(C.snapTo),Ce=C.duration||{min:.1,max:2},Ce=Ro(Ce)?Dc(Ce.min,Ce.max):Dc(Ce,Ce),Le=et.delayedCall(C.delay||De/2||.1,function(){var Ie=_e(),ht=xi()-Ne<500,ot=be.tween;if((ht||Math.abs(H.getVelocity())<10)&&!ot&&!Ld&&Te!==Ie){var dt=(Ie-qe)/ct,_n=r&&!G?r.totalProgress():dt,gt=ht?0:(_n-pt)/(xi()-xc)*1e3||0,rn=et.utils.clamp(-dt,1-dt,Bl(gt/2)*gt/.185),sn=dt+(C.inertia===!1?0:rn),Tt,xt,Pt=C,In=Pt.onStart,on=Pt.onInterrupt,ti=Pt.onComplete;if(Tt=tt(sn,H),Mc(Tt)||(Tt=sn),xt=Math.max(0,Math.round(qe+Tt*ct)),Ie<=rt&&Ie>=qe&&xt!==Ie){if(ot&&!ot._initted&&ot.data<=Bl(xt-Ie))return;C.inertia===!1&&(rn=Tt-dt),be(xt,{duration:Ce(Bl(Math.max(Bl(sn-_n),Bl(Tt-_n))*.185/gt/.05||0)),ease:C.ease||"power3",data:Bl(xt-Ie),onInterrupt:function(){return Le.restart(!0)&&on&&on(H)},onComplete:function(){H.update(),Te=_e(),r&&!G&&(V?V.resetTo("totalProgress",Tt,r._tTime/r._tDur):r.progress(Tt)),Fe=pt=r&&!G?r.totalProgress():H.progress,R&&R(H),ti&&ti(H)}},Ie,rn*ct,xt-Ie-rn*ct),In&&In(H,be.tween)}}else H.isActive&&Te!==Ie&&Le.restart(!0)}).pause()),p&&(Q0[p]=H),g=H.trigger=Wi(g||x!==!0&&x),lt=g&&g._gsap&&g._gsap.stRevert,lt&&(lt=lt(H)),x=x===!0?g:Wi(x),fa(f)&&(f={targets:g,className:f}),x&&(M===!1||M===Oa||(M=!M&&x.parentNode&&x.parentNode.style&&Pa(x.parentNode).display==="flex"?!1:Yn),H.pin=x,ze=et.core.getCache(x),ze.spacer?We=ze.pinState:(P&&(P=Wi(P),P&&!P.nodeType&&(P=P.current||P.nativeElement),ze.spacerIsNative=!!P,P&&(ze.spacerState=Xh(P))),ze.spacer=Z=P||mn.createElement("div"),Z.classList.add("pin-spacer"),p&&Z.classList.add("pin-spacer-"+p),ze.pinState=We=Xh(x)),a.force3D!==!1&&et.set(x,{force3D:!0}),H.spacer=Z=ze.spacer,Pe=Pa(x),it=Pe[M+q.os2],ve=et.getProperty(x),de=et.quickSetter(x,q.a,Kn),P_(x,Z,Pe),A=Xh(x)),ie){Wt=Ro(ie)?JM(ie,$M):$M,le=kh("scroller-start",p,k,q,Wt,0),W=kh("scroller-end",p,k,q,Wt,0,le),ge=le["offset"+q.op.d2];var Gt=Wi(Ys(k,"content")||k);_t=this.markerStart=kh("start",p,Gt,q,Wt,ge,0,L),st=this.markerEnd=kh("end",p,Gt,q,Wt,ge,0,L),L&&(Xe=et.quickSetter([_t,st],q.a,Kn)),!J&&!(yr.length&&Ys(k,"fixedMarkers")===!0)&&(zU(te?en:k),et.set([le,W],{force3D:!0}),Re=et.quickSetter(le,q.a,Kn),He=et.quickSetter(W,q.a,Kn))}if(L){var Ve=L.vars.onUpdate,Je=L.vars.onUpdateParams;L.eventCallback("onUpdate",function(){H.update(0,0,1),Ve&&Ve.apply(L,Je||[])})}if(H.previous=function(){return Nt[Nt.indexOf(H)-1]},H.next=function(){return Nt[Nt.indexOf(H)+1]},H.revert=function(Ie,ht){if(!ht)return H.kill(!0);var ot=Ie!==!1||!H.enabled,dt=vi;ot!==H.isReverted&&(ot&&(Ee=Math.max(_e(),H.scroll.rec||0),ne=H.progress,me=r&&r.progress()),_t&&[_t,st,le,W].forEach(function(_n){return _n.style.display=ot?"none":"block"}),ot&&(vi=H,H.update(ot)),x&&(!O||!H.isActive)&&(ot?GU(x,Z,We):P_(x,Z,Pa(x),Ye)),ot||H.update(ot),vi=dt,H.isReverted=ot)},H.refresh=function(Ie,ht,ot,dt){if(!((vi||!H.enabled)&&!ht)){if(x&&Ie&&Ha){ri(o,"scrollEnd",uE);return}!Oi&&F&&F(H),vi=H,be.tween&&!ot&&(be.tween.kill(),be.tween=0),V&&V.pause(),b&&r&&(r.revert({kill:!1}).invalidate(),r.getChildren?r.getChildren(!0,!0,!1).forEach(function(Ze){return Ze.vars.immediateRender&&Ze.render(0,!0,!0)}):r.vars.immediateRender&&r.render(0,!0,!0)),H.isReverted||H.revert(!0,!0),H._subPinOffset=!1;var _n=Q(),gt=xe(),rn=L?L.duration():_r(k,q),sn=ct<=.01||!ct,Tt=0,xt=dt||0,Pt=Ro(ot)?ot.end:a.end,In=a.endTrigger||g,on=Ro(ot)?ot.start:a.start||(a.start===0||!g?0:x?"0 0":"0 100%"),ti=H.pinnedContainer=a.pinnedContainer&&Wi(a.pinnedContainer,H),Ei=g&&Math.max(0,Nt.indexOf(H))||0,gn=Ei,Tn,vn,pi,Sa,D,Y,ue,se,ae,Ue,Be,Oe,je;for(ie&&Ro(ot)&&(Oe=et.getProperty(le,q.p),je=et.getProperty(W,q.p));gn-- >0;)Y=Nt[gn],Y.end||Y.refresh(0,1)||(vi=H),ue=Y.pin,ue&&(ue===g||ue===x||ue===ti)&&!Y.isReverted&&(Ue||(Ue=[]),Ue.unshift(Y),Y.revert(!0,!0)),Y!==Nt[gn]&&(Ei--,gn--);for(Si(on)&&(on=on(H)),on=jM(on,"start",H),qe=i1(on,g,_n,q,_e(),_t,le,H,gt,he,J,rn,L,H._startClamp&&"_startClamp")||(x?-.001:0),Si(Pt)&&(Pt=Pt(H)),fa(Pt)&&!Pt.indexOf("+=")&&(~Pt.indexOf(" ")?Pt=(fa(on)?on.split(" ")[0]:"")+Pt:(Tt=ad(Pt.substr(2),_n),Pt=fa(on)?on:(L?et.utils.mapRange(0,L.duration(),L.scrollTrigger.start,L.scrollTrigger.end,qe):qe)+Tt,In=g)),Pt=jM(Pt,"end",H),rt=Math.max(qe,i1(Pt||(In?"100% 0":rn),In,_n,q,_e()+Tt,st,W,H,gt,he,J,rn,L,H._endClamp&&"_endClamp"))||-.001,Tt=0,gn=Ei;gn--;)Y=Nt[gn]||{},ue=Y.pin,ue&&Y.start-Y._pinPush<=qe&&!L&&Y.end>0&&(Tn=Y.end-(H._startClamp?Math.max(0,Y.start):Y.start),(ue===g&&Y.start-Y._pinPush<qe||ue===ti)&&isNaN(on)&&(Tt+=Tn*(1-Y.progress)),ue===x&&(xt+=Tn));if(qe+=Tt,rt+=Tt,H._startClamp&&(H._startClamp+=Tt),H._endClamp&&!Oi&&(H._endClamp=rt||-.001,rt=Math.min(rt,_r(k,q))),ct=rt-qe||(qe-=.01)&&.001,sn&&(ne=et.utils.clamp(0,1,et.utils.normalize(qe,rt,Ee))),H._pinPush=xt,_t&&Tt&&(Tn={},Tn[q.a]="+="+Tt,ti&&(Tn[q.p]="-="+_e()),et.set([_t,st],Tn)),x&&!(K0&&H.end>=_r(k,q)))Tn=Pa(x),Sa=q===Qn,pi=_e(),Ge=parseFloat(ve(q.a))+xt,!rn&&rt>1&&(Be=(te?mn.scrollingElement||da:k).style,Be={style:Be,value:Be["overflow"+q.a.toUpperCase()]},te&&Pa(en)["overflow"+q.a.toUpperCase()]!=="scroll"&&(Be.style["overflow"+q.a.toUpperCase()]="scroll")),P_(x,Z,Tn),A=Xh(x),vn=Zr(x,!0),se=J&&Qs(k,Sa?zi:Qn)(),M?(Ye=[M+q.os2,ct+xt+Kn],Ye.t=Z,gn=M===Yn?bd(x,q)+ct+xt:0,gn&&(Ye.push(q.d,gn+Kn),Z.style.flexBasis!=="auto"&&(Z.style.flexBasis=gn+Kn)),$l(Ye),ti&&Nt.forEach(function(Ze){Ze.pin===ti&&Ze.vars.pinSpacing!==!1&&(Ze._subPinOffset=!0)}),J&&_e(Ee)):(gn=bd(x,q),gn&&Z.style.flexBasis!=="auto"&&(Z.style.flexBasis=gn+Kn)),J&&(D={top:vn.top+(Sa?pi-qe:se)+Kn,left:vn.left+(Sa?se:pi-qe)+Kn,boxSizing:"border-box",position:"fixed"},D[Io]=D["max"+fu]=Math.ceil(vn.width)+Kn,D[Bo]=D["max"+Pg]=Math.ceil(vn.height)+Kn,D[Oa]=D[Oa+Oc]=D[Oa+Uc]=D[Oa+Pc]=D[Oa+Lc]="0",D[Yn]=Tn[Yn],D[Yn+Oc]=Tn[Yn+Oc],D[Yn+Uc]=Tn[Yn+Uc],D[Yn+Pc]=Tn[Yn+Pc],D[Yn+Lc]=Tn[Yn+Lc],B=kU(We,D,O),Oi&&_e(0)),r?(ae=r._initted,D_(1),r.render(r.duration(),!0,!0),we=ve(q.a)-Ge+ct+xt,Ae=Math.abs(ct-we)>1,J&&Ae&&B.splice(B.length-2,2),r.render(0,!0,!0),ae||r.invalidate(!0),r.parent||r.totalTime(r.totalTime()),D_(0)):we=ct,Be&&(Be.value?Be.style["overflow"+q.a.toUpperCase()]=Be.value:Be.style.removeProperty("overflow-"+q.a));else if(g&&_e()&&!L)for(vn=g.parentNode;vn&&vn!==en;)vn._pinOffset&&(qe-=vn._pinOffset,rt-=vn._pinOffset),vn=vn.parentNode;Ue&&Ue.forEach(function(Ze){return Ze.revert(!1,!0)}),H.start=qe,H.end=rt,Ke=Ut=Oi?Ee:_e(),!L&&!Oi&&(Ke<Ee&&_e(Ee),H.scroll.rec=0),H.revert(!1,!0),Ne=xi(),Le&&(Te=-1,Le.restart(!0)),vi=0,r&&G&&(r._initted||me)&&r.progress()!==me&&r.progress(me||0,!0).render(r.time(),!0,!0),(sn||ne!==H.progress||L||b||r&&!r._initted)&&(r&&!G&&(r._initted||ne||r.vars.immediateRender!==!1)&&r.totalProgress(L&&qe<-.001&&!ne?et.utils.normalize(qe,rt,0):ne,!0),H.progress=sn||(Ke-qe)/ct===ne?0:ne),x&&M&&(Z._pinOffset=Math.round(H.progress*we)),V&&V.invalidate(),isNaN(Oe)||(Oe-=et.getProperty(le,q.p),je-=et.getProperty(W,q.p),Wh(le,q,Oe),Wh(_t,q,Oe-(dt||0)),Wh(W,q,je),Wh(st,q,je-(dt||0))),sn&&!Oi&&H.update(),_&&!Oi&&!bt&&(bt=!0,_(H),bt=!1)}},H.getVelocity=function(){return(_e()-Ut)/(xi()-xc)*1e3||0},H.endAnimation=function(){dc(H.callbackAnimation),r&&(V?V.progress(1):r.paused()?G||dc(r,H.direction<0,1):dc(r,r.reversed()))},H.labelToScroll=function(Ie){return r&&r.labels&&(qe||H.refresh()||qe)+r.labels[Ie]/r.duration()*ct||0},H.getTrailing=function(Ie){var ht=Nt.indexOf(H),ot=H.direction>0?Nt.slice(0,ht).reverse():Nt.slice(ht+1);return(fa(Ie)?ot.filter(function(dt){return dt.vars.preventOverlaps===Ie}):ot).filter(function(dt){return H.direction>0?dt.end<=qe:dt.start>=rt})},H.update=function(Ie,ht,ot){if(!(L&&!ot&&!Ie)){var dt=Oi===!0?Ee:H.scroll(),_n=Ie?0:(dt-qe)/ct,gt=_n<0?0:_n>1?1:_n||0,rn=H.progress,sn,Tt,xt,Pt,In,on,ti,Ei;if(ht&&(Ut=Ke,Ke=L?_e():dt,C&&(pt=Fe,Fe=r&&!G?r.totalProgress():gt)),y&&x&&!vi&&!Ih&&Ha&&(!gt&&qe<dt+(dt-Ut)/(xi()-xc)*y?gt=1e-4:gt===1&&rt>dt+(dt-Ut)/(xi()-xc)*y&&(gt=.9999)),gt!==rn&&H.enabled){if(sn=H.isActive=!!gt&&gt<1,Tt=!!rn&&rn<1,on=sn!==Tt,In=on||!!gt!=!!rn,H.direction=gt>rn?1:-1,H.progress=gt,In&&!vi&&(xt=gt&&!rn?0:gt===1?1:rn===1?2:3,G&&(Pt=!on&&I[xt+1]!=="none"&&I[xt+1]||I[xt],Ei=r&&(Pt==="complete"||Pt==="reset"||Pt in r))),w&&(on||Ei)&&(Ei||v||!r)&&(Si(w)?w(H):H.getTrailing(w).forEach(function(pi){return pi.endAnimation()})),G||(V&&!vi&&!Ih?(V._dp._time-V._start!==V._time&&V.render(V._dp._time-V._start),V.resetTo?V.resetTo("totalProgress",gt,r._tTime/r._tDur):(V.vars.totalProgress=gt,V.invalidate().restart())):r&&r.totalProgress(gt,!!(vi&&(Ne||Ie)))),x){if(Ie&&M&&(Z.style[M+q.os2]=it),!J)de(Sc(Ge+we*gt));else if(In){if(ti=!Ie&&gt>rn&&rt+1>dt&&dt+1>=_r(k,q),O)if(!Ie&&(sn||ti)){var gn=Zr(x,!0),Tn=dt-qe;a1(x,en,gn.top+(q===Qn?Tn:0)+Kn,gn.left+(q===Qn?0:Tn)+Kn)}else a1(x,Z);$l(sn||ti?B:A),Ae&&gt<1&&sn||de(Ge+(gt===1&&!ti?we:0))}}C&&!be.tween&&!vi&&!Ih&&Le.restart(!0),f&&(on||N&&gt&&(gt<1||!N_))&&qc(f.targets).forEach(function(pi){return pi.classList[sn||N?"add":"remove"](f.className)}),c&&!G&&!Ie&&c(H),In&&!vi?(G&&(Ei&&(Pt==="complete"?r.pause().totalProgress(1):Pt==="reset"?r.restart(!0).pause():Pt==="restart"?r.restart(!0):r[Pt]()),c&&c(H)),(on||!N_)&&(d&&on&&L_(H,d),z[xt]&&L_(H,z[xt]),N&&(gt===1?H.kill(!1,1):z[xt]=0),on||(xt=gt===1?1:3,z[xt]&&L_(H,z[xt]))),T&&!sn&&Math.abs(H.getVelocity())>(Mc(T)?T:2500)&&(dc(H.callbackAnimation),V?V.progress(1):dc(r,Pt==="reverse"?1:!gt,1))):G&&c&&!vi&&c(H)}if(He){var vn=L?dt/L.duration()*(L._caScrollDist||0):dt;Re(vn+(le._isFlipped?1:0)),He(vn)}Xe&&Xe(-dt/L.duration()*(L._caScrollDist||0))}},H.enable=function(Ie,ht){H.enabled||(H.enabled=!0,ri(k,"resize",bc),te||ri(k,"scroll",Hl),F&&ri(o,"refreshInit",F),Ie!==!1&&(H.progress=ne=0,Ke=Ut=Te=_e()),ht!==!1&&H.refresh())},H.getTween=function(Ie){return Ie&&be?be.tween:V},H.setPositions=function(Ie,ht,ot,dt){if(L){var _n=L.scrollTrigger,gt=L.duration(),rn=_n.end-_n.start;Ie=_n.start+rn*Ie/gt,ht=_n.start+rn*ht/gt}H.refresh(!1,!1,{start:ZM(Ie,ot&&!!H._startClamp),end:ZM(ht,ot&&!!H._endClamp)},dt),H.update()},H.adjustPinSpacing=function(Ie){if(Ye&&Ie){var ht=Ye.indexOf(q.d)+1;Ye[ht]=parseFloat(Ye[ht])+Ie+Kn,Ye[1]=parseFloat(Ye[1])+Ie+Kn,$l(Ye)}},H.disable=function(Ie,ht){if(Ie!==!1&&H.revert(!0,!0),H.enabled&&(H.enabled=H.isActive=!1,ht||V&&V.pause(),Ee=0,ze&&(ze.uncache=1),F&&ai(o,"refreshInit",F),Le&&(Le.pause(),be.tween&&be.tween.kill()&&(be.tween=0)),!te)){for(var ot=Nt.length;ot--;)if(Nt[ot].scroller===k&&Nt[ot]!==H)return;ai(k,"resize",bc),te||ai(k,"scroll",Hl)}},H.kill=function(Ie,ht){H.disable(Ie,ht),V&&!ht&&V.kill(),p&&delete Q0[p];var ot=Nt.indexOf(H);ot>=0&&Nt.splice(ot,1),ot===Li&&sd>0&&Li--,ot=0,Nt.forEach(function(dt){return dt.scroller===H.scroller&&(ot=1)}),ot||Oi||(H.scroll.rec=0),r&&(r.scrollTrigger=null,Ie&&r.revert({kill:!1}),ht||r.kill()),_t&&[_t,st,le,W].forEach(function(dt){return dt.parentNode&&dt.parentNode.removeChild(dt)}),zc===H&&(zc=0),x&&(ze&&(ze.uncache=1),ot=0,Nt.forEach(function(dt){return dt.pin===x&&ot++}),ot||(ze.spacer=0)),a.onKill&&a.onKill(H)},Nt.push(H),H.enable(!1,!1),lt&&lt(H),r&&r.add&&!ct){var Et=H.update;H.update=function(){H.update=Et,Ot.cache++,qe||rt||H.refresh()},et.delayedCall(.01,H.update),ct=.01,qe=rt=0}else H.refresh();x&&HU()},o.register=function(a){return Gl||(et=a||iE(),nE()&&window.document&&o.enable(),Gl=yc),Gl},o.defaults=function(a){if(a)for(var r in a)Vh[r]=a[r];return Vh},o.disable=function(a,r){yc=0,Nt.forEach(function(c){return c[r?"kill":"disable"](a)}),ai(Lt,"wheel",Hl),ai(mn,"scroll",Hl),clearInterval(Fh),ai(mn,"touchcancel",cr),ai(en,"touchstart",cr),Hh(ai,mn,"pointerdown,touchstart,mousedown",KM),Hh(ai,mn,"pointerup,touchend,mouseup",QM),Md.kill(),Bh(ai);for(var l=0;l<Ot.length;l+=3)Gh(ai,Ot[l],Ot[l+1]),Gh(ai,Ot[l],Ot[l+2])},o.enable=function(){if(Lt=window,mn=document,da=mn.documentElement,en=mn.body,et&&(qc=et.utils.toArray,Dc=et.utils.clamp,Z0=et.core.context||cr,D_=et.core.suppressOverwrites||cr,Ng=Lt.history.scrollRestoration||"auto",J0=Lt.pageYOffset||0,et.core.globals("ScrollTrigger",o),en)){yc=1,Jl=document.createElement("div"),Jl.style.height="100vh",Jl.style.position="absolute",dE(),LU(),zn.register(et),o.isTouch=zn.isTouch,zs=zn.isTouch&&/(iPad|iPhone|iPod|Mac)/g.test(navigator.userAgent),j0=zn.isTouch===1,ri(Lt,"wheel",Hl),Dg=[Lt,mn,da,en],et.matchMedia?(o.matchMedia=function(d){var _=et.matchMedia(),v;for(v in d)_.add(v,d[v]);return _},et.addEventListener("matchMediaInit",function(){fE(),Fg()}),et.addEventListener("matchMediaRevert",function(){return cE()}),et.addEventListener("matchMedia",function(){Lo(0,1),Xo("matchMedia")}),et.matchMedia().add("(orientation: portrait)",function(){return O_(),O_})):console.warn("Requires GSAP 3.11.0 or later"),O_(),ri(mn,"scroll",Hl);var a=en.hasAttribute("style"),r=en.style,l=r.borderTopStyle,c=et.core.Animation.prototype,f,p;for(c.revert||Object.defineProperty(c,"revert",{value:function(){return this.time(-.01,!0)}}),r.borderTopStyle="solid",f=Zr(en),Qn.m=Math.round(f.top+Qn.sc())||0,zi.m=Math.round(f.left+zi.sc())||0,l?r.borderTopStyle=l:r.removeProperty("border-top-style"),a||(en.setAttribute("style",""),en.removeAttribute("style")),Fh=setInterval(e1,250),et.delayedCall(.5,function(){return Ih=0}),ri(mn,"touchcancel",cr),ri(en,"touchstart",cr),Hh(ri,mn,"pointerdown,touchstart,mousedown",KM),Hh(ri,mn,"pointerup,touchend,mouseup",QM),q0=et.utils.checkPrefix("transform"),od.push(q0),Gl=xi(),Md=et.delayedCall(.2,Lo).pause(),Vl=[mn,"visibilitychange",function(){var d=Lt.innerWidth,_=Lt.innerHeight;mn.hidden?(YM=d,qM=_):(YM!==d||qM!==_)&&bc()},mn,"DOMContentLoaded",Lo,Lt,"load",Lo,Lt,"resize",bc],Bh(ri),Nt.forEach(function(d){return d.enable(0,1)}),p=0;p<Ot.length;p+=3)Gh(ai,Ot[p],Ot[p+1]),Gh(ai,Ot[p],Ot[p+2])}},o.config=function(a){"limitCallbacks"in a&&(N_=!!a.limitCallbacks);var r=a.syncInterval;r&&clearInterval(Fh)||(Fh=r)&&setInterval(e1,r),"ignoreMobileResize"in a&&(j0=o.isTouch===1&&a.ignoreMobileResize),"autoRefreshEvents"in a&&(Bh(ai)||Bh(ri,a.autoRefreshEvents||"none"),$b=(a.autoRefreshEvents+"").indexOf("resize")===-1)},o.scrollerProxy=function(a,r){var l=Wi(a),c=Ot.indexOf(l),f=Vo(l);~c&&Ot.splice(c,f?6:2),r&&(f?yr.unshift(Lt,r,en,r,da,r):yr.unshift(l,r))},o.clearMatchMedia=function(a){Nt.forEach(function(r){return r._ctx&&r._ctx.query===a&&r._ctx.kill(!0,!0)})},o.isInViewport=function(a,r,l){var c=(fa(a)?Wi(a):a).getBoundingClientRect(),f=c[l?Io:Bo]*r||0;return l?c.right-f>0&&c.left+f<Lt.innerWidth:c.bottom-f>0&&c.top+f<Lt.innerHeight},o.positionInViewport=function(a,r,l){fa(a)&&(a=Wi(a));var c=a.getBoundingClientRect(),f=c[l?Io:Bo],p=r==null?f/2:r in Ed?Ed[r]*f:~r.indexOf("%")?parseFloat(r)*f/100:parseFloat(r)||0;return l?(c.left+p)/Lt.innerWidth:(c.top+p)/Lt.innerHeight},o.killAll=function(a){if(Nt.slice(0).forEach(function(l){return l.vars.id!=="ScrollSmoother"&&l.kill()}),a!==!0){var r=ko.killAll||[];ko={},r.forEach(function(l){return l()})}},o})();It.version="3.14.2";It.saveStyles=function(o){return o?qc(o).forEach(function(e){if(e&&e.style){var n=ca.indexOf(e);n>=0&&ca.splice(n,5),ca.push(e,e.style.cssText,e.getBBox&&e.getAttribute("transform"),et.core.getCache(e),Z0())}}):ca};It.revert=function(o,e){return Fg(!o,e)};It.create=function(o,e){return new It(o,e)};It.refresh=function(o){return o?bc(!0):(Gl||It.register())&&Lo(!0)};It.update=function(o){return++Ot.cache&&es(o===!0?2:0)};It.clearScrollMemory=hE;It.maxScroll=function(o,e){return _r(o,e?zi:Qn)};It.getScrollFunc=function(o,e){return Qs(Wi(o),e?zi:Qn)};It.getById=function(o){return Q0[o]};It.getAll=function(){return Nt.filter(function(o){return o.vars.id!=="ScrollSmoother"})};It.isScrolling=function(){return!!Ha};It.snapDirectional=zg;It.addEventListener=function(o,e){var n=ko[o]||(ko[o]=[]);~n.indexOf(e)||n.push(e)};It.removeEventListener=function(o,e){var n=ko[o],a=n&&n.indexOf(e);a>=0&&n.splice(a,1)};It.batch=function(o,e){var n=[],a={},r=e.interval||.016,l=e.batchMax||1e9,c=function(d,_){var v=[],g=[],x=et.delayedCall(r,function(){_(v,g),v=[],g=[]}).pause();return function(M){v.length||x.restart(!0),v.push(M.trigger),g.push(M),l<=v.length&&x.progress(1)}},f;for(f in e)a[f]=f.substr(0,2)==="on"&&Si(e[f])&&f!=="onRefreshInit"?c(f,e[f]):e[f];return Si(l)&&(l=l(),ri(It,"refresh",function(){return l=e.batchMax()})),qc(o).forEach(function(p){var d={};for(f in a)d[f]=a[f];d.trigger=p,n.push(It.create(d))}),n};var s1=function(e,n,a,r){return n>r?e(r):n<0&&e(0),a>r?(r-n)/(a-n):a<0?n/(n-a):1},z_=function o(e,n){n===!0?e.style.removeProperty("touch-action"):e.style.touchAction=n===!0?"auto":n?"pan-"+n+(zn.isTouch?" pinch-zoom":""):"none",e===da&&o(en,n)},Yh={auto:1,scroll:1},WU=function(e){var n=e.event,a=e.target,r=e.axis,l=(n.changedTouches?n.changedTouches[0]:n).target,c=l._gsap||et.core.getCache(l),f=xi(),p;if(!c._isScrollT||f-c._isScrollT>2e3){for(;l&&l!==en&&(l.scrollHeight<=l.clientHeight&&l.scrollWidth<=l.clientWidth||!(Yh[(p=Pa(l)).overflowY]||Yh[p.overflowX]));)l=l.parentNode;c._isScroll=l&&l!==a&&!Vo(l)&&(Yh[(p=Pa(l)).overflowY]||Yh[p.overflowX]),c._isScrollT=f}(c._isScroll||r==="x")&&(n.stopPropagation(),n._gsapAllow=!0)},mE=function(e,n,a,r){return zn.create({target:e,capture:!0,debounce:!1,lockAxis:!0,type:n,onWheel:r=r&&WU,onPress:r,onDrag:r,onScroll:r,onEnable:function(){return a&&ri(mn,zn.eventTypes[0],l1,!1,!0)},onDisable:function(){return ai(mn,zn.eventTypes[0],l1,!0)}})},YU=/(input|label|select|textarea)/i,o1,l1=function(e){var n=YU.test(e.target.tagName);(n||o1)&&(e._gsapAllow=!0,o1=n)},qU=function(e){Ro(e)||(e={}),e.preventDefault=e.isNormalizer=e.allowClicks=!0,e.type||(e.type="wheel,touch"),e.debounce=!!e.debounce,e.id=e.id||"normalizer";var n=e,a=n.normalizeScrollX,r=n.momentum,l=n.allowNestedScroll,c=n.onRelease,f,p,d=Wi(e.target)||da,_=et.core.globals().ScrollSmoother,v=_&&_.get(),g=zs&&(e.content&&Wi(e.content)||v&&e.content!==!1&&!v.smooth()&&v.content()),x=Qs(d,Qn),M=Qs(d,zi),b=1,y=(zn.isTouch&&Lt.visualViewport?Lt.visualViewport.scale*Lt.visualViewport.width:Lt.outerWidth)/Lt.innerWidth,S=0,R=Si(r)?function(){return r(f)}:function(){return r||2.8},N,C,O=mE(d,e.type,!0,l),P=function(){return C=!1},L=cr,T=cr,w=function(){p=_r(d,Qn),T=Dc(zs?1:0,p),a&&(L=Dc(0,_r(d,zi))),N=Ho},q=function(){g._gsap.y=Sc(parseFloat(g._gsap.y)+x.offset)+"px",g.style.transform="matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, "+parseFloat(g._gsap.y)+", 0, 1)",x.offset=x.cacheID=0},G=function(){if(C){requestAnimationFrame(P);var ie=Sc(f.deltaY/2),he=T(x.v-ie);if(g&&he!==x.v+x.offset){x.offset=he-x.v;var H=Sc((parseFloat(g&&g._gsap.y)||0)-x.offset);g.style.transform="matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, "+H+", 0, 1)",g._gsap.y=H+"px",x.cacheID=Ot.cache,es()}return!0}x.offset&&q(),C=!0},k,$,te,J,z=function(){w(),k.isActive()&&k.vars.scrollY>p&&(x()>p?k.progress(1)&&x(p):k.resetTo("scrollY",p))};return g&&et.set(g,{y:"+=0"}),e.ignoreCheck=function(I){return zs&&I.type==="touchmove"&&G()||b>1.05&&I.type!=="touchstart"||f.isGesturing||I.touches&&I.touches.length>1},e.onPress=function(){C=!1;var I=b;b=Sc((Lt.visualViewport&&Lt.visualViewport.scale||1)/y),k.pause(),I!==b&&z_(d,b>1.01?!0:a?!1:"x"),$=M(),te=x(),w(),N=Ho},e.onRelease=e.onGestureStart=function(I,ie){if(x.offset&&q(),!ie)J.restart(!0);else{Ot.cache++;var he=R(),H,F;a&&(H=M(),F=H+he*.05*-I.velocityX/.227,he*=s1(M,H,F,_r(d,zi)),k.vars.scrollX=L(F)),H=x(),F=H+he*.05*-I.velocityY/.227,he*=s1(x,H,F,_r(d,Qn)),k.vars.scrollY=T(F),k.invalidate().duration(he).play(.01),(zs&&k.vars.scrollY>=p||H>=p-1)&&et.to({},{onUpdate:z,duration:he})}c&&c(I)},e.onWheel=function(){k._ts&&k.pause(),xi()-S>1e3&&(N=0,S=xi())},e.onChange=function(I,ie,he,H,F){if(Ho!==N&&w(),ie&&a&&M(L(H[2]===ie?$+(I.startX-I.x):M()+ie-H[1])),he){x.offset&&q();var Q=F[2]===he,xe=Q?te+I.startY-I.y:x()+he-F[1],Te=T(xe);Q&&xe!==Te&&(te+=Te-xe),x(Te)}(he||ie)&&es()},e.onEnable=function(){z_(d,a?!1:"x"),It.addEventListener("refresh",z),ri(Lt,"resize",z),x.smooth&&(x.target.style.scrollBehavior="auto",x.smooth=M.smooth=!1),O.enable()},e.onDisable=function(){z_(d,!0),ai(Lt,"resize",z),It.removeEventListener("refresh",z),O.kill()},e.lockAxis=e.lockAxis!==!1,f=new zn(e),f.iOS=zs,zs&&!x()&&x(1),zs&&et.ticker.add(cr),J=f._dc,k=et.to(f,{ease:"power4",paused:!0,inherit:!1,scrollX:a?"+=0.1":"+=0",scrollY:"+=0.1",modifiers:{scrollY:pE(x,x(),function(){return k.pause()})},onUpdate:es,onComplete:J.vars.onComplete}),f};It.sort=function(o){if(Si(o))return Nt.sort(o);var e=Lt.pageYOffset||0;return It.getAll().forEach(function(n){return n._sortY=n.trigger?e+n.trigger.getBoundingClientRect().top:n.start+Lt.innerHeight}),Nt.sort(o||function(n,a){return(n.vars.refreshPriority||0)*-1e6+(n.vars.containerAnimation?1e6:n._sortY)-((a.vars.containerAnimation?1e6:a._sortY)+(a.vars.refreshPriority||0)*-1e6)})};It.observe=function(o){return new zn(o)};It.normalizeScroll=function(o){if(typeof o>"u")return Ui;if(o===!0&&Ui)return Ui.enable();if(o===!1){Ui&&Ui.kill(),Ui=o;return}var e=o instanceof zn?o:qU(o);return Ui&&Ui.target===e.target&&Ui.kill(),Vo(e.target)&&(Ui=e),e};It.core={_getVelocityProp:Y0,_inputObserver:mE,_scrollers:Ot,_proxies:yr,bridge:{ss:function(){Ha||Xo("scrollStart"),Ha=xi()},ref:function(){return vi}}};iE()&&et.registerPlugin(It);/*!
 * @gsap/react 2.1.2
 * https://gsap.com
 *
 * Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license or for
 * Club GSAP members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
*/let u1=typeof document<"u"?Jn.useLayoutEffect:Jn.useEffect,c1=o=>o&&!Array.isArray(o)&&typeof o=="object",qh=[],jU={},_E=ur;const Ig=(o,e=qh)=>{let n=jU;c1(o)?(n=o,o=null,e="dependencies"in n?n.dependencies:qh):c1(e)&&(n=e,e="dependencies"in n?n.dependencies:qh),o&&typeof o!="function"&&console.warn("First parameter must be a function or config object");const{scope:a,revertOnUpdate:r}=n,l=Jn.useRef(!1),c=Jn.useRef(_E.context(()=>{},a)),f=Jn.useRef(d=>c.current.add(null,d)),p=e&&e.length&&!r;return p&&u1(()=>(l.current=!0,()=>c.current.revert()),qh),u1(()=>{if(o&&c.current.add(o,a),!p||!l.current)return()=>c.current.revert()},e),{context:c.current,contextSafe:f.current}};Ig.register=o=>{_E=o};Ig.headless=!0;ur.registerPlugin(It);function ZU(){const[o,e]=Jn.useState(!1),[n,a]=Jn.useState(!1),[r,l]=Jn.useState({name:"",phone:"",email:"",countryCode:"+91"}),c=Jn.useRef(null),f=Jn.useRef(null),p=Jn.useRef([]);Ig(()=>{let v=ur.matchMedia();return v.add("(min-width: 768px)",()=>{if(c.current){const g=c.current.querySelectorAll(".hero-anim");ur.from(g,{y:30,opacity:0,stagger:.2,duration:1,ease:"power3.out",delay:.2})}if(f.current){const g=f.current.querySelectorAll(".process-step");ur.from(g,{scrollTrigger:{trigger:f.current,start:"top 80%",toggleActions:"play none none none"},y:40,opacity:0,duration:.8,stagger:.2,ease:"power2.out"})}p.current.forEach(g=>{g&&ur.from(g,{scrollTrigger:{trigger:g,start:"top 90%"},opacity:0,duration:1.5,ease:"power2.inOut"})})}),v.add("(max-width: 767px)",()=>{if(c.current){const g=c.current.querySelectorAll(".hero-anim");ur.from(g,{y:20,opacity:0,stagger:.1,duration:.8,ease:"power3.out",delay:.1})}if(f.current){const g=f.current.querySelectorAll(".process-step");ur.from(g,{scrollTrigger:{trigger:f.current,start:"top 90%",toggleActions:"play none none none"},y:20,opacity:0,duration:.6,stagger:.1,ease:"power2.out"})}p.current.forEach(g=>{g&&ur.from(g,{scrollTrigger:{trigger:g,start:"top 90%"},opacity:0,duration:1,ease:"power2.inOut"})})}),()=>v.revert()},[]);const d=v=>{v&&!p.current.includes(v)&&p.current.push(v)},_=v=>{v.preventDefault();const g="918660819023",x=`*New Project Inquiry*%0A%0A*Name:* ${r.name}%0A*Phone:* ${r.countryCode} ${r.phone}%0A*Email:* ${r.email}`;window.open(`https://wa.me/${g}?text=${x}`,"_blank"),a(!1)};return j.jsxs("div",{className:"min-h-screen bg-midnight text-white selection:bg-magenta/30 selection:text-white",children:[j.jsx("nav",{className:"fixed top-0 left-0 right-0 z-50 px-6 py-4",children:j.jsxs("div",{className:"max-w-7xl mx-auto glass-panel rounded-2xl px-6 py-3 flex items-center justify-between relative",children:[j.jsxs("div",{className:"flex items-center gap-3 z-50",children:[j.jsxs("svg",{width:"36",height:"36",viewBox:"0 0 100 100",className:"overflow-visible",children:[j.jsxs("defs",{children:[j.jsxs("linearGradient",{id:"logoGrad",x1:"0%",y1:"100%",x2:"100%",y2:"0%",children:[j.jsx("stop",{offset:"0%",stopColor:"#00F0FF"}),j.jsx("stop",{offset:"100%",stopColor:"#B026FF"})]}),j.jsxs("filter",{id:"glow",children:[j.jsx("feGaussianBlur",{stdDeviation:"2",result:"coloredBlur"}),j.jsxs("feMerge",{children:[j.jsx("feMergeNode",{in:"coloredBlur"}),j.jsx("feMergeNode",{in:"SourceGraphic"})]})]})]}),j.jsxs("g",{stroke:"url(#logoGrad)",strokeWidth:"2",fill:"none",children:[j.jsx("circle",{cx:"50",cy:"50",r:"40"}),j.jsx("circle",{cx:"50",cy:"50",r:"20"}),j.jsx("line",{x1:"50",y1:"10",x2:"50",y2:"90"}),j.jsx("line",{x1:"10",y1:"50",x2:"90",y2:"50"}),j.jsx("line",{x1:"21.7",y1:"21.7",x2:"78.3",y2:"78.3"}),j.jsx("line",{x1:"21.7",y1:"78.3",x2:"78.3",y2:"21.7"}),j.jsx("ellipse",{cx:"50",cy:"50",rx:"40",ry:"15"}),j.jsx("ellipse",{cx:"50",cy:"50",rx:"15",ry:"40"})]}),j.jsxs("g",{fill:"url(#logoGrad)",children:[j.jsx("circle",{cx:"50",cy:"10",r:"3"}),j.jsx("circle",{cx:"50",cy:"90",r:"3"}),j.jsx("circle",{cx:"10",cy:"50",r:"3"}),j.jsx("circle",{cx:"90",cy:"50",r:"3"}),j.jsx("circle",{cx:"21.7",cy:"21.7",r:"3"}),j.jsx("circle",{cx:"78.3",cy:"78.3",r:"3"}),j.jsx("circle",{cx:"21.7",cy:"78.3",r:"3"}),j.jsx("circle",{cx:"78.3",cy:"21.7",r:"3"}),j.jsx("circle",{cx:"50",cy:"30",r:"2.5"}),j.jsx("circle",{cx:"50",cy:"70",r:"2.5"}),j.jsx("circle",{cx:"30",cy:"50",r:"2.5"}),j.jsx("circle",{cx:"70",cy:"50",r:"2.5"}),j.jsx("circle",{cx:"35.8",cy:"35.8",r:"2.5"}),j.jsx("circle",{cx:"64.2",cy:"64.2",r:"2.5"}),j.jsx("circle",{cx:"35.8",cy:"64.2",r:"2.5"}),j.jsx("circle",{cx:"64.2",cy:"35.8",r:"2.5"})]}),j.jsx("circle",{cx:"50",cy:"50",r:"4",fill:"#00F0FF",filter:"url(#glow)"})]}),j.jsx("span",{className:"font-display font-bold text-xl tracking-widest uppercase relative z-50",children:"Uncoded Hub"})]}),j.jsxs("div",{className:"hidden md:flex items-center gap-8",children:[j.jsx("a",{href:"#about",className:"text-sm font-semibold tracking-wide hover:text-cyan transition-colors",children:"ABOUT"}),j.jsx("a",{href:"#contact",className:"text-sm font-semibold tracking-wide hover:text-cyan transition-colors",children:"CONTACT"}),j.jsxs("button",{onClick:()=>a(!0),className:"cyan-energy-btn !py-2.5 !px-6 !text-sm !font-medium shrink-0",children:["Start a Project",j.jsx(TM,{className:"w-4 h-4"})]})]}),j.jsxs("div",{className:"flex md:hidden items-center gap-4 z-50",children:[j.jsx("button",{onClick:()=>a(!0),className:"cyan-energy-btn !py-1.5 !px-4 !text-xs !font-medium shrink-0 rounded-lg",children:"Start"}),j.jsx("button",{onClick:()=>e(!o),className:"text-white hover:text-cyan transition-colors",children:o?j.jsx(AM,{className:"w-7 h-7"}):j.jsx(nN,{className:"w-7 h-7"})})]}),j.jsxs("div",{className:`absolute top-full left-0 right-0 mt-2 glass-panel rounded-2xl p-4 flex flex-col gap-4 text-center transition-all origin-top duration-300 md:hidden ${o?"scale-y-100 opacity-100 visible":"scale-y-0 opacity-0 invisible"}`,children:[j.jsx("a",{href:"#about",onClick:()=>e(!1),className:"text-lg font-semibold py-2 hover:text-cyan border-b border-white/5",children:"ABOUT"}),j.jsx("a",{href:"#contact",onClick:()=>e(!1),className:"text-lg font-semibold py-2 hover:text-cyan border-b border-white/5",children:"CONTACT"}),j.jsx("button",{onClick:()=>{a(!0),e(!1)},className:"text-lg font-semibold py-2 text-cyan",children:"START A PROJECT"})]})]})}),j.jsxs("section",{className:"relative pt-40 pb-24 px-6 overflow-hidden min-h-[90vh] flex items-center",children:[j.jsx("div",{className:"absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-magenta/10 rounded-full blur-[120px] pointer-events-none"}),j.jsx("div",{className:"absolute top-1/2 left-1/4 -translate-y-1/2 w-[600px] h-[600px] bg-cyan/10 rounded-full blur-[100px] pointer-events-none"}),j.jsxs("div",{className:"max-w-7xl mx-auto flex flex-col lg:flex-row items-center relative z-10 w-full min-h-[600px]",ref:c,children:[j.jsxs("div",{className:"w-full lg:w-[55%] space-y-8 relative z-20 pt-10 lg:pt-0",children:[j.jsxs("h1",{className:"hero-anim font-display text-5xl md:text-7xl font-bold leading-[1.1] tracking-tight text-white drop-shadow-2xl",children:["Your Business Deserves to be Online. ",j.jsx("br",{}),j.jsx("span",{className:"text-gradient",children:"We Make it Happen in 5 Days."})]}),j.jsx("p",{className:"hero-anim text-lg md:text-xl text-steel max-w-xl leading-relaxed drop-shadow-md",children:"Stop losing customers to competitors who have a website. Get a fully functional, professional digital storefront built for revenue, not just looks."}),j.jsxs("div",{className:"hero-anim flex flex-col items-start gap-4 pt-4",children:[j.jsxs("button",{onClick:()=>a(!0),className:"cyan-energy-btn !text-lg !px-8 !py-4",children:["Claim Your 5-Day Build ",j.jsx(JD,{className:"w-5 h-5"})]}),j.jsx("div",{className:"mt-6 border-l-2 border-cyan/30 pl-4",ref:d,children:j.jsx("p",{className:"italic text-white/90 text-sm max-w-md drop-shadow-md",children:'"A business without a website is a business that sleeps. Your website is the only salesman that works 24/7, 365 days a year without asking for a raise."'})})]})]}),j.jsx("div",{className:"absolute top-0 right-0 w-full h-[350px] md:h-[500px] opacity-30 -z-10 lg:relative lg:w-[50%] lg:h-[700px] lg:opacity-100 lg:z-10 lg:-ml-[5%] pointer-events-none flex justify-center items-center",children:j.jsx(XD,{})})]})]}),j.jsx("section",{className:"py-24 px-6 relative z-10 bg-cyber/30 border-t border-white/5",children:j.jsxs("div",{className:"max-w-4xl mx-auto",ref:f,children:[j.jsxs("div",{className:"text-center mb-16",children:[j.jsx("h2",{className:"font-display text-3xl md:text-5xl font-bold mb-4",children:"From Idea to Live in 120 Hours."}),j.jsx("p",{className:"text-steel text-lg",children:"Here is How:"})]}),j.jsxs("div",{className:"relative",children:[j.jsx("div",{className:"absolute left-[28px] md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-cyan via-magenta to-transparent md:-translate-x-1/2"}),j.jsx("div",{className:"space-y-12",children:[{day:"1",title:"Strategy & Architecture",desc:"We learn your business and map the blueprint."},{day:"2-3",title:"Design & Development",desc:"We build the engine and design the interface."},{day:"4",title:"Review & Refine",desc:"You review, we perfect it."},{day:"5",title:"Launch & Handover",desc:"You go live to the world."}].map((v,g)=>j.jsxs("div",{className:`process-step relative flex flex-col md:flex-row items-start md:items-center gap-8 group ${g%2===0?"md:flex-row-reverse":""}`,children:[j.jsx("div",{className:"absolute left-0 md:left-1/2 w-14 h-14 rounded-full bg-midnight border-2 border-cyber flex items-center justify-center md:-translate-x-1/2 z-10 group-hover:border-cyan transition-colors duration-300 shadow-[0_0_10px_rgba(0,0,0,0.5)]",children:j.jsxs("span",{className:"font-mono font-bold text-sm text-white group-hover:text-cyan transition-colors",children:["D",v.day]})}),j.jsx("div",{className:`ml-20 md:ml-0 md:w-1/2 ${g%2===0?"md:pl-16":"md:pr-16 md:text-right"}`,children:j.jsxs("div",{className:"frosted-glass p-6 rounded-2xl transition-all duration-500 group-hover:-translate-y-2 group-hover:shadow-[0_15px_40px_rgba(0,229,255,0.1)] group-hover:border-white/30",children:[j.jsxs("h4",{className:"font-display text-xl font-bold mb-2 text-white group-hover:text-cyan transition-colors duration-300",children:["Day ",v.day,": ",v.title]}),j.jsx("p",{className:"text-white/80 text-sm leading-relaxed",children:v.desc})]})})]},v.day))})]}),j.jsx("div",{className:"mt-20 max-w-2xl mx-auto text-center",ref:d,children:j.jsxs("div",{className:"bg-cyber/40 border border-white/10 rounded-2xl p-8 relative overflow-hidden",children:[j.jsx("div",{className:"absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan to-magenta"}),j.jsx("p",{className:"font-display text-xl md:text-2xl italic text-white/90 leading-relaxed",children:'"Speed is the currency of modern business. While your competitors spend months debating colors, you could be closing sales."'})]})})]})}),j.jsx("section",{className:"py-24 px-6 relative z-10",children:j.jsxs("div",{className:"max-w-7xl mx-auto",children:[j.jsx("div",{className:"text-center mb-16",children:j.jsx("h2",{className:"font-display text-3xl md:text-5xl font-bold mb-4",children:"Built to Convert. Designed to Impress."})}),j.jsxs("div",{className:"grid md:grid-cols-3 gap-8",children:[j.jsxs("div",{className:"portfolio-card rounded-2xl border border-white/10 bg-cyber/50 group cursor-pointer",children:[j.jsxs("div",{className:"h-48 overflow-hidden relative",children:[j.jsx("img",{src:"https://picsum.photos/seed/retail/600/400",alt:"Local Retail & Services",className:"w-full h-full object-cover",referrerPolicy:"no-referrer"}),j.jsx("div",{className:"absolute inset-0 bg-midnight/20 group-hover:bg-transparent transition-colors duration-300"})]}),j.jsxs("div",{className:"p-6",children:[j.jsx("h3",{className:"font-display text-xl font-bold mb-2",children:"Local Retail & Services"}),j.jsx("p",{className:"text-steel text-sm",children:"Optimized for local SEO and foot traffic conversion."})]})]}),j.jsxs("div",{className:"portfolio-card rounded-2xl border border-white/10 bg-cyber/50 group cursor-pointer",children:[j.jsxs("div",{className:"h-48 overflow-hidden relative",children:[j.jsx("img",{src:"https://picsum.photos/seed/portfolio/600/400",alt:"Professional Portfolios",className:"w-full h-full object-cover",referrerPolicy:"no-referrer"}),j.jsx("div",{className:"absolute inset-0 bg-midnight/20 group-hover:bg-transparent transition-colors duration-300"})]}),j.jsxs("div",{className:"p-6",children:[j.jsx("h3",{className:"font-display text-xl font-bold mb-2",children:"Professional Portfolios"}),j.jsx("p",{className:"text-steel text-sm",children:"Sleek, authoritative designs that build instant trust."})]})]}),j.jsxs("div",{className:"portfolio-card rounded-2xl border border-white/10 bg-cyber/50 group cursor-pointer",children:[j.jsxs("div",{className:"h-48 overflow-hidden relative",children:[j.jsx("img",{src:"https://picsum.photos/seed/ecommerce/600/400",alt:"E-commerce Hubs",className:"w-full h-full object-cover",referrerPolicy:"no-referrer"}),j.jsx("div",{className:"absolute inset-0 bg-midnight/20 group-hover:bg-transparent transition-colors duration-300"})]}),j.jsxs("div",{className:"p-6",children:[j.jsx("h3",{className:"font-display text-xl font-bold mb-2",children:"E-commerce Hubs"}),j.jsx("p",{className:"text-steel text-sm",children:"Frictionless checkout experiences designed to sell."})]})]})]}),j.jsx("div",{className:"mt-16 text-center",ref:d,children:j.jsx("p",{className:"italic text-steel text-lg max-w-3xl mx-auto",children:'"Design isn’t just how it looks; it’s how it converts. A confused visitor leaves, but a guided visitor buys."'})})]})}),j.jsx("section",{id:"about",className:"py-24 px-6 relative z-10 bg-cyber/30 border-t border-white/5",children:j.jsxs("div",{className:"max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center",children:[j.jsxs("div",{children:[j.jsx("h2",{className:"font-display text-3xl md:text-5xl font-bold mb-6",children:"The Uncoded Advantage."}),j.jsx("p",{className:"text-steel text-lg leading-relaxed mb-8",children:"We utilize advanced no-code architecture. What does that mean for you? Zero bloated code, lightning-fast load times, and a website you can easily understand and manage without hiring an expensive IT team."}),j.jsxs("ul",{className:"space-y-4 mb-8",children:[j.jsxs("li",{className:"flex items-center gap-3 text-white/90",children:[j.jsx(cN,{className:"w-5 h-5 text-cyan"})," Lightning-fast load times"]}),j.jsxs("li",{className:"flex items-center gap-3 text-white/90",children:[j.jsx(eN,{className:"w-5 h-5 text-magenta"})," Zero bloated code"]}),j.jsxs("li",{className:"flex items-center gap-3 text-white/90",children:[j.jsx(aN,{className:"w-5 h-5 text-cyan"})," Easy to manage & secure"]})]})]}),j.jsxs("div",{ref:d,className:"bg-midnight p-8 rounded-3xl border border-white/10 relative overflow-hidden",children:[j.jsx("div",{className:"absolute top-0 right-0 w-32 h-32 bg-magenta/10 rounded-full blur-[50px]"}),j.jsx("div",{className:"absolute bottom-0 left-0 w-32 h-32 bg-cyan/10 rounded-full blur-[50px]"}),j.jsx("p",{className:"font-display text-2xl italic text-white/90 leading-relaxed relative z-10",children:'"Complexity kills progress. The best technology is the kind that gets out of your way and lets you run your business."'})]})]})}),j.jsx("section",{className:"py-24 px-6 relative z-10",children:j.jsxs("div",{className:"max-w-7xl mx-auto",children:[j.jsx("div",{className:"text-center mb-16",children:j.jsx("h2",{className:"font-display text-3xl md:text-5xl font-bold mb-4",children:"Real Results & Our Growth Partnership"})}),j.jsxs("div",{className:"grid md:grid-cols-2 gap-8 mb-16",children:[j.jsxs("div",{className:"bg-cyber/50 p-8 rounded-2xl border border-white/5",children:[j.jsxs("div",{className:"flex text-cyan mb-4",children:[j.jsx(or,{className:"w-5 h-5 fill-current"}),j.jsx(or,{className:"w-5 h-5 fill-current"}),j.jsx(or,{className:"w-5 h-5 fill-current"}),j.jsx(or,{className:"w-5 h-5 fill-current"}),j.jsx(or,{className:"w-5 h-5 fill-current"})]}),j.jsx("p",{className:"text-lg text-white/90 mb-6",children:'"They delivered exactly what they promised in 5 days. Our conversion rate doubled in the first month."'}),j.jsxs("div",{className:"flex items-center gap-4",children:[j.jsx("div",{className:"w-10 h-10 rounded-full bg-white/10"}),j.jsxs("div",{children:[j.jsx("p",{className:"font-bold text-sm",children:"Sarah J."}),j.jsx("p",{className:"text-steel text-xs",children:"Local Retail Owner"})]})]})]}),j.jsxs("div",{className:"bg-cyber/50 p-8 rounded-2xl border border-white/5",children:[j.jsxs("div",{className:"flex text-cyan mb-4",children:[j.jsx(or,{className:"w-5 h-5 fill-current"}),j.jsx(or,{className:"w-5 h-5 fill-current"}),j.jsx(or,{className:"w-5 h-5 fill-current"}),j.jsx(or,{className:"w-5 h-5 fill-current"}),j.jsx(or,{className:"w-5 h-5 fill-current"})]}),j.jsx("p",{className:"text-lg text-white/90 mb-6",children:`"The speed is unmatched. I didn't have to wait months to get my portfolio online. Highly recommended."`}),j.jsxs("div",{className:"flex items-center gap-4",children:[j.jsx("div",{className:"w-10 h-10 rounded-full bg-white/10"}),j.jsxs("div",{children:[j.jsx("p",{className:"font-bold text-sm",children:"David M."}),j.jsx("p",{className:"text-steel text-xs",children:"Consultant"})]})]})]})]}),j.jsxs("div",{className:"bg-gradient-to-br from-cyber to-midnight p-8 md:p-12 rounded-3xl border border-white/10 flex flex-col md:flex-row gap-8 items-center",children:[j.jsx("div",{className:"w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center shrink-0 border border-white/10",children:j.jsx(oN,{className:"w-8 h-8 text-magenta"})}),j.jsxs("div",{children:[j.jsx("h3",{className:"font-display text-2xl font-bold mb-3",children:"The Partnership Pitch"}),j.jsx("p",{className:"text-steel leading-relaxed",children:"We don't just hand you the keys and leave. With our monthly Growth & Security Partnership, we maintain, secure, and update your site so you can focus entirely on your customers."})]})]}),j.jsx("div",{className:"mt-16 text-center",ref:d,children:j.jsx("p",{className:"italic text-steel text-lg max-w-3xl mx-auto",children:`"The cost of a professional website is an investment. The cost of a bad website—or no website at all—is every customer who couldn't find you."`})})]})}),j.jsxs("section",{id:"contact",className:"py-24 px-6 relative z-10 bg-cyber/80 border-t border-white/5 text-center",children:[j.jsx("div",{className:"absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-magenta/10 via-midnight to-midnight pointer-events-none"}),j.jsxs("div",{className:"max-w-3xl mx-auto relative z-10",children:[j.jsx("h2",{className:"font-display text-4xl md:text-6xl font-bold mb-8",children:"Ready to digitize your business this week?"}),j.jsxs("button",{onClick:()=>a(!0),className:"cyan-energy-btn !px-10 !py-5 !text-xl mx-auto w-full md:w-auto",children:["Book Your Strategy Call Now ",j.jsx(TM,{className:"w-6 h-6"})]})]})]}),j.jsx("footer",{className:"py-8 text-center border-t border-white/5 text-steel font-mono text-sm bg-midnight relative z-10",children:j.jsxs("p",{children:["© ",new Date().getFullYear()," Uncoded Hub. All systems operational."]})}),n&&j.jsxs("div",{className:"fixed inset-0 z-[100] flex items-center justify-center p-4",children:[j.jsx("div",{className:"absolute inset-0 bg-midnight/80 backdrop-blur-sm",onClick:()=>a(!1)}),j.jsxs("div",{className:"frosted-glass relative z-10 w-full max-w-md rounded-3xl p-8 shadow-2xl animate-in fade-in zoom-in duration-300",children:[j.jsx("button",{onClick:()=>a(!1),className:"absolute top-4 right-4 text-white hover:text-cyan transition-colors",children:j.jsx(AM,{className:"w-6 h-6"})}),j.jsx("h3",{className:"font-display text-2xl font-bold mb-2 text-white",children:"Let's Build It."}),j.jsx("p",{className:"text-steel text-sm mb-6",children:"Drop your details below and we will reach out immediately via WhatsApp."}),j.jsxs("form",{onSubmit:_,className:"space-y-4",children:[j.jsxs("div",{children:[j.jsx("label",{className:"block text-xs font-semibold text-steel uppercase tracking-wider mb-2",children:"Full Name"}),j.jsx("input",{type:"text",required:!0,value:r.name,onChange:v=>l({...r,name:v.target.value}),className:"w-full bg-midnight/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-cyan focus:ring-1 focus:ring-cyan transition-all",placeholder:"John Doe"})]}),j.jsxs("div",{children:[j.jsx("label",{className:"block text-xs font-semibold text-steel uppercase tracking-wider mb-2",children:"Phone Number"}),j.jsxs("div",{className:"flex gap-2",children:[j.jsxs("select",{value:r.countryCode,onChange:v=>l({...r,countryCode:v.target.value}),className:"w-[110px] bg-midnight/50 border border-white/10 rounded-xl px-3 py-3 text-white focus:outline-none focus:border-cyan focus:ring-1 focus:ring-cyan transition-all cursor-pointer",children:[j.jsx("option",{value:"+1",children:"+1 (US)"}),j.jsx("option",{value:"+44",children:"+44 (UK)"}),j.jsx("option",{value:"+91",children:"+91 (IN)"}),j.jsx("option",{value:"+971",children:"+971 (AE)"}),j.jsx("option",{value:"+61",children:"+61 (AU)"})]}),j.jsx("input",{type:"tel",required:!0,value:r.phone,onChange:v=>l({...r,phone:v.target.value}),className:"w-full bg-midnight/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-cyan focus:ring-1 focus:ring-cyan transition-all",placeholder:"8660819023"})]})]}),j.jsxs("div",{children:[j.jsx("label",{className:"block text-xs font-semibold text-steel uppercase tracking-wider mb-2",children:"Email Address"}),j.jsx("input",{type:"email",required:!0,value:r.email,onChange:v=>l({...r,email:v.target.value}),className:"w-full bg-midnight/50 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-cyan focus:ring-1 focus:ring-cyan transition-all",placeholder:"john@example.com"})]}),j.jsx("button",{type:"submit",className:"cyan-energy-btn w-full mt-6",children:"Send to WhatsApp"})]})]})]})]})}DA.createRoot(document.getElementById("root")).render(j.jsx(Jn.StrictMode,{children:j.jsx(ZU,{})}));
