(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))a(r);new MutationObserver(r=>{for(const l of r)if(l.type==="childList")for(const c of l.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&a(c)}).observe(document,{childList:!0,subtree:!0});function n(r){const l={};return r.integrity&&(l.integrity=r.integrity),r.referrerPolicy&&(l.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?l.credentials="include":r.crossOrigin==="anonymous"?l.credentials="omit":l.credentials="same-origin",l}function a(r){if(r.ep)return;r.ep=!0;const l=n(r);fetch(r.href,l)}})();var zm={exports:{}},nc={};/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var gS;function yA(){if(gS)return nc;gS=1;var o=Symbol.for("react.transitional.element"),t=Symbol.for("react.fragment");function n(a,r,l){var c=null;if(l!==void 0&&(c=""+l),r.key!==void 0&&(c=""+r.key),"key"in r){l={};for(var f in r)f!=="key"&&(l[f]=r[f])}else l=r;return r=l.ref,{$$typeof:o,type:a,key:c,ref:r!==void 0?r:null,props:l}}return nc.Fragment=t,nc.jsx=n,nc.jsxs=n,nc}var vS;function SA(){return vS||(vS=1,zm.exports=yA()),zm.exports}var tt=SA(),Im={exports:{}},Se={};/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var xS;function MA(){if(xS)return Se;xS=1;var o=Symbol.for("react.transitional.element"),t=Symbol.for("react.portal"),n=Symbol.for("react.fragment"),a=Symbol.for("react.strict_mode"),r=Symbol.for("react.profiler"),l=Symbol.for("react.consumer"),c=Symbol.for("react.context"),f=Symbol.for("react.forward_ref"),p=Symbol.for("react.suspense"),d=Symbol.for("react.memo"),_=Symbol.for("react.lazy"),v=Symbol.for("react.activity"),g=Symbol.iterator;function x(z){return z===null||typeof z!="object"?null:(z=g&&z[g]||z["@@iterator"],typeof z=="function"?z:null)}var M={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},E=Object.assign,y={};function S(z,K,xt){this.props=z,this.context=K,this.refs=y,this.updater=xt||M}S.prototype.isReactComponent={},S.prototype.setState=function(z,K){if(typeof z!="object"&&typeof z!="function"&&z!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,z,K,"setState")},S.prototype.forceUpdate=function(z){this.updater.enqueueForceUpdate(this,z,"forceUpdate")};function R(){}R.prototype=S.prototype;function U(z,K,xt){this.props=z,this.context=K,this.refs=y,this.updater=xt||M}var C=U.prototype=new R;C.constructor=U,E(C,S.prototype),C.isPureReactComponent=!0;var O=Array.isArray;function P(){}var L={H:null,A:null,T:null,S:null},T=Object.prototype.hasOwnProperty;function w(z,K,xt){var Tt=xt.ref;return{$$typeof:o,type:z,key:K,ref:Tt!==void 0?Tt:null,props:xt}}function q(z,K){return w(z.type,K,z.props)}function G(z){return typeof z=="object"&&z!==null&&z.$$typeof===o}function k(z){var K={"=":"=0",":":"=2"};return"$"+z.replace(/[=:]/g,function(xt){return K[xt]})}var J=/\/+/g;function et(z,K){return typeof z=="object"&&z!==null&&z.key!=null?k(""+z.key):K.toString(36)}function Q(z){switch(z.status){case"fulfilled":return z.value;case"rejected":throw z.reason;default:switch(typeof z.status=="string"?z.then(P,P):(z.status="pending",z.then(function(K){z.status==="pending"&&(z.status="fulfilled",z.value=K)},function(K){z.status==="pending"&&(z.status="rejected",z.reason=K)})),z.status){case"fulfilled":return z.value;case"rejected":throw z.reason}}throw z}function F(z,K,xt,Tt,Ut){var nt=typeof z;(nt==="undefined"||nt==="boolean")&&(z=null);var _t=!1;if(z===null)_t=!0;else switch(nt){case"bigint":case"string":case"number":_t=!0;break;case"object":switch(z.$$typeof){case o:case t:_t=!0;break;case _:return _t=z._init,F(_t(z._payload),K,xt,Tt,Ut)}}if(_t)return Ut=Ut(z),_t=Tt===""?"."+et(z,0):Tt,O(Ut)?(xt="",_t!=null&&(xt=_t.replace(J,"$&/")+"/"),F(Ut,K,xt,"",function(ee){return ee})):Ut!=null&&(G(Ut)&&(Ut=q(Ut,xt+(Ut.key==null||z&&z.key===Ut.key?"":(""+Ut.key).replace(J,"$&/")+"/")+_t)),K.push(Ut)),1;_t=0;var Et=Tt===""?".":Tt+":";if(O(z))for(var Ft=0;Ft<z.length;Ft++)Tt=z[Ft],nt=Et+et(Tt,Ft),_t+=F(Tt,K,xt,nt,Ut);else if(Ft=x(z),typeof Ft=="function")for(z=Ft.call(z),Ft=0;!(Tt=z.next()).done;)Tt=Tt.value,nt=Et+et(Tt,Ft++),_t+=F(Tt,K,xt,nt,Ut);else if(nt==="object"){if(typeof z.then=="function")return F(Q(z),K,xt,Tt,Ut);throw K=String(z),Error("Objects are not valid as a React child (found: "+(K==="[object Object]"?"object with keys {"+Object.keys(z).join(", ")+"}":K)+"). If you meant to render a collection of children, use an array instead.")}return _t}function I(z,K,xt){if(z==null)return z;var Tt=[],Ut=0;return F(z,Tt,"","",function(nt){return K.call(xt,nt,Ut++)}),Tt}function it(z){if(z._status===-1){var K=z._result;K=K(),K.then(function(xt){(z._status===0||z._status===-1)&&(z._status=1,z._result=xt)},function(xt){(z._status===0||z._status===-1)&&(z._status=2,z._result=xt)}),z._status===-1&&(z._status=0,z._result=K)}if(z._status===1)return z._result.default;throw z._result}var ht=typeof reportError=="function"?reportError:function(z){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var K=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof z=="object"&&z!==null&&typeof z.message=="string"?String(z.message):String(z),error:z});if(!window.dispatchEvent(K))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",z);return}console.error(z)},H={map:I,forEach:function(z,K,xt){I(z,function(){K.apply(this,arguments)},xt)},count:function(z){var K=0;return I(z,function(){K++}),K},toArray:function(z){return I(z,function(K){return K})||[]},only:function(z){if(!G(z))throw Error("React.Children.only expected to receive a single React element child.");return z}};return Se.Activity=v,Se.Children=H,Se.Component=S,Se.Fragment=n,Se.Profiler=r,Se.PureComponent=U,Se.StrictMode=a,Se.Suspense=p,Se.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=L,Se.__COMPILER_RUNTIME={__proto__:null,c:function(z){return L.H.useMemoCache(z)}},Se.cache=function(z){return function(){return z.apply(null,arguments)}},Se.cacheSignal=function(){return null},Se.cloneElement=function(z,K,xt){if(z==null)throw Error("The argument must be a React element, but you passed "+z+".");var Tt=E({},z.props),Ut=z.key;if(K!=null)for(nt in K.key!==void 0&&(Ut=""+K.key),K)!T.call(K,nt)||nt==="key"||nt==="__self"||nt==="__source"||nt==="ref"&&K.ref===void 0||(Tt[nt]=K[nt]);var nt=arguments.length-2;if(nt===1)Tt.children=xt;else if(1<nt){for(var _t=Array(nt),Et=0;Et<nt;Et++)_t[Et]=arguments[Et+2];Tt.children=_t}return w(z.type,Ut,Tt)},Se.createContext=function(z){return z={$$typeof:c,_currentValue:z,_currentValue2:z,_threadCount:0,Provider:null,Consumer:null},z.Provider=z,z.Consumer={$$typeof:l,_context:z},z},Se.createElement=function(z,K,xt){var Tt,Ut={},nt=null;if(K!=null)for(Tt in K.key!==void 0&&(nt=""+K.key),K)T.call(K,Tt)&&Tt!=="key"&&Tt!=="__self"&&Tt!=="__source"&&(Ut[Tt]=K[Tt]);var _t=arguments.length-2;if(_t===1)Ut.children=xt;else if(1<_t){for(var Et=Array(_t),Ft=0;Ft<_t;Ft++)Et[Ft]=arguments[Ft+2];Ut.children=Et}if(z&&z.defaultProps)for(Tt in _t=z.defaultProps,_t)Ut[Tt]===void 0&&(Ut[Tt]=_t[Tt]);return w(z,nt,Ut)},Se.createRef=function(){return{current:null}},Se.forwardRef=function(z){return{$$typeof:f,render:z}},Se.isValidElement=G,Se.lazy=function(z){return{$$typeof:_,_payload:{_status:-1,_result:z},_init:it}},Se.memo=function(z,K){return{$$typeof:d,type:z,compare:K===void 0?null:K}},Se.startTransition=function(z){var K=L.T,xt={};L.T=xt;try{var Tt=z(),Ut=L.S;Ut!==null&&Ut(xt,Tt),typeof Tt=="object"&&Tt!==null&&typeof Tt.then=="function"&&Tt.then(P,ht)}catch(nt){ht(nt)}finally{K!==null&&xt.types!==null&&(K.types=xt.types),L.T=K}},Se.unstable_useCacheRefresh=function(){return L.H.useCacheRefresh()},Se.use=function(z){return L.H.use(z)},Se.useActionState=function(z,K,xt){return L.H.useActionState(z,K,xt)},Se.useCallback=function(z,K){return L.H.useCallback(z,K)},Se.useContext=function(z){return L.H.useContext(z)},Se.useDebugValue=function(){},Se.useDeferredValue=function(z,K){return L.H.useDeferredValue(z,K)},Se.useEffect=function(z,K){return L.H.useEffect(z,K)},Se.useEffectEvent=function(z){return L.H.useEffectEvent(z)},Se.useId=function(){return L.H.useId()},Se.useImperativeHandle=function(z,K,xt){return L.H.useImperativeHandle(z,K,xt)},Se.useInsertionEffect=function(z,K){return L.H.useInsertionEffect(z,K)},Se.useLayoutEffect=function(z,K){return L.H.useLayoutEffect(z,K)},Se.useMemo=function(z,K){return L.H.useMemo(z,K)},Se.useOptimistic=function(z,K){return L.H.useOptimistic(z,K)},Se.useReducer=function(z,K,xt){return L.H.useReducer(z,K,xt)},Se.useRef=function(z){return L.H.useRef(z)},Se.useState=function(z){return L.H.useState(z)},Se.useSyncExternalStore=function(z,K,xt){return L.H.useSyncExternalStore(z,K,xt)},Se.useTransition=function(){return L.H.useTransition()},Se.version="19.2.4",Se}var yS;function tg(){return yS||(yS=1,Im.exports=MA()),Im.exports}var Mi=tg(),Bm={exports:{}},ic={},Hm={exports:{}},Gm={};/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var SS;function EA(){return SS||(SS=1,(function(o){function t(F,I){var it=F.length;F.push(I);t:for(;0<it;){var ht=it-1>>>1,H=F[ht];if(0<r(H,I))F[ht]=I,F[it]=H,it=ht;else break t}}function n(F){return F.length===0?null:F[0]}function a(F){if(F.length===0)return null;var I=F[0],it=F.pop();if(it!==I){F[0]=it;t:for(var ht=0,H=F.length,z=H>>>1;ht<z;){var K=2*(ht+1)-1,xt=F[K],Tt=K+1,Ut=F[Tt];if(0>r(xt,it))Tt<H&&0>r(Ut,xt)?(F[ht]=Ut,F[Tt]=it,ht=Tt):(F[ht]=xt,F[K]=it,ht=K);else if(Tt<H&&0>r(Ut,it))F[ht]=Ut,F[Tt]=it,ht=Tt;else break t}}return I}function r(F,I){var it=F.sortIndex-I.sortIndex;return it!==0?it:F.id-I.id}if(o.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var l=performance;o.unstable_now=function(){return l.now()}}else{var c=Date,f=c.now();o.unstable_now=function(){return c.now()-f}}var p=[],d=[],_=1,v=null,g=3,x=!1,M=!1,E=!1,y=!1,S=typeof setTimeout=="function"?setTimeout:null,R=typeof clearTimeout=="function"?clearTimeout:null,U=typeof setImmediate<"u"?setImmediate:null;function C(F){for(var I=n(d);I!==null;){if(I.callback===null)a(d);else if(I.startTime<=F)a(d),I.sortIndex=I.expirationTime,t(p,I);else break;I=n(d)}}function O(F){if(E=!1,C(F),!M)if(n(p)!==null)M=!0,P||(P=!0,k());else{var I=n(d);I!==null&&Q(O,I.startTime-F)}}var P=!1,L=-1,T=5,w=-1;function q(){return y?!0:!(o.unstable_now()-w<T)}function G(){if(y=!1,P){var F=o.unstable_now();w=F;var I=!0;try{t:{M=!1,E&&(E=!1,R(L),L=-1),x=!0;var it=g;try{e:{for(C(F),v=n(p);v!==null&&!(v.expirationTime>F&&q());){var ht=v.callback;if(typeof ht=="function"){v.callback=null,g=v.priorityLevel;var H=ht(v.expirationTime<=F);if(F=o.unstable_now(),typeof H=="function"){v.callback=H,C(F),I=!0;break e}v===n(p)&&a(p),C(F)}else a(p);v=n(p)}if(v!==null)I=!0;else{var z=n(d);z!==null&&Q(O,z.startTime-F),I=!1}}break t}finally{v=null,g=it,x=!1}I=void 0}}finally{I?k():P=!1}}}var k;if(typeof U=="function")k=function(){U(G)};else if(typeof MessageChannel<"u"){var J=new MessageChannel,et=J.port2;J.port1.onmessage=G,k=function(){et.postMessage(null)}}else k=function(){S(G,0)};function Q(F,I){L=S(function(){F(o.unstable_now())},I)}o.unstable_IdlePriority=5,o.unstable_ImmediatePriority=1,o.unstable_LowPriority=4,o.unstable_NormalPriority=3,o.unstable_Profiling=null,o.unstable_UserBlockingPriority=2,o.unstable_cancelCallback=function(F){F.callback=null},o.unstable_forceFrameRate=function(F){0>F||125<F?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):T=0<F?Math.floor(1e3/F):5},o.unstable_getCurrentPriorityLevel=function(){return g},o.unstable_next=function(F){switch(g){case 1:case 2:case 3:var I=3;break;default:I=g}var it=g;g=I;try{return F()}finally{g=it}},o.unstable_requestPaint=function(){y=!0},o.unstable_runWithPriority=function(F,I){switch(F){case 1:case 2:case 3:case 4:case 5:break;default:F=3}var it=g;g=F;try{return I()}finally{g=it}},o.unstable_scheduleCallback=function(F,I,it){var ht=o.unstable_now();switch(typeof it=="object"&&it!==null?(it=it.delay,it=typeof it=="number"&&0<it?ht+it:ht):it=ht,F){case 1:var H=-1;break;case 2:H=250;break;case 5:H=1073741823;break;case 4:H=1e4;break;default:H=5e3}return H=it+H,F={id:_++,callback:I,priorityLevel:F,startTime:it,expirationTime:H,sortIndex:-1},it>ht?(F.sortIndex=it,t(d,F),n(p)===null&&F===n(d)&&(E?(R(L),L=-1):E=!0,Q(O,it-ht))):(F.sortIndex=H,t(p,F),M||x||(M=!0,P||(P=!0,k()))),F},o.unstable_shouldYield=q,o.unstable_wrapCallback=function(F){var I=g;return function(){var it=g;g=I;try{return F.apply(this,arguments)}finally{g=it}}}})(Gm)),Gm}var MS;function bA(){return MS||(MS=1,Hm.exports=EA()),Hm.exports}var Vm={exports:{}},pi={};/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var ES;function TA(){if(ES)return pi;ES=1;var o=tg();function t(p){var d="https://react.dev/errors/"+p;if(1<arguments.length){d+="?args[]="+encodeURIComponent(arguments[1]);for(var _=2;_<arguments.length;_++)d+="&args[]="+encodeURIComponent(arguments[_])}return"Minified React error #"+p+"; visit "+d+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function n(){}var a={d:{f:n,r:function(){throw Error(t(522))},D:n,C:n,L:n,m:n,X:n,S:n,M:n},p:0,findDOMNode:null},r=Symbol.for("react.portal");function l(p,d,_){var v=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:r,key:v==null?null:""+v,children:p,containerInfo:d,implementation:_}}var c=o.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function f(p,d){if(p==="font")return"";if(typeof d=="string")return d==="use-credentials"?d:""}return pi.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=a,pi.createPortal=function(p,d){var _=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!d||d.nodeType!==1&&d.nodeType!==9&&d.nodeType!==11)throw Error(t(299));return l(p,d,null,_)},pi.flushSync=function(p){var d=c.T,_=a.p;try{if(c.T=null,a.p=2,p)return p()}finally{c.T=d,a.p=_,a.d.f()}},pi.preconnect=function(p,d){typeof p=="string"&&(d?(d=d.crossOrigin,d=typeof d=="string"?d==="use-credentials"?d:"":void 0):d=null,a.d.C(p,d))},pi.prefetchDNS=function(p){typeof p=="string"&&a.d.D(p)},pi.preinit=function(p,d){if(typeof p=="string"&&d&&typeof d.as=="string"){var _=d.as,v=f(_,d.crossOrigin),g=typeof d.integrity=="string"?d.integrity:void 0,x=typeof d.fetchPriority=="string"?d.fetchPriority:void 0;_==="style"?a.d.S(p,typeof d.precedence=="string"?d.precedence:void 0,{crossOrigin:v,integrity:g,fetchPriority:x}):_==="script"&&a.d.X(p,{crossOrigin:v,integrity:g,fetchPriority:x,nonce:typeof d.nonce=="string"?d.nonce:void 0})}},pi.preinitModule=function(p,d){if(typeof p=="string")if(typeof d=="object"&&d!==null){if(d.as==null||d.as==="script"){var _=f(d.as,d.crossOrigin);a.d.M(p,{crossOrigin:_,integrity:typeof d.integrity=="string"?d.integrity:void 0,nonce:typeof d.nonce=="string"?d.nonce:void 0})}}else d==null&&a.d.M(p)},pi.preload=function(p,d){if(typeof p=="string"&&typeof d=="object"&&d!==null&&typeof d.as=="string"){var _=d.as,v=f(_,d.crossOrigin);a.d.L(p,_,{crossOrigin:v,integrity:typeof d.integrity=="string"?d.integrity:void 0,nonce:typeof d.nonce=="string"?d.nonce:void 0,type:typeof d.type=="string"?d.type:void 0,fetchPriority:typeof d.fetchPriority=="string"?d.fetchPriority:void 0,referrerPolicy:typeof d.referrerPolicy=="string"?d.referrerPolicy:void 0,imageSrcSet:typeof d.imageSrcSet=="string"?d.imageSrcSet:void 0,imageSizes:typeof d.imageSizes=="string"?d.imageSizes:void 0,media:typeof d.media=="string"?d.media:void 0})}},pi.preloadModule=function(p,d){if(typeof p=="string")if(d){var _=f(d.as,d.crossOrigin);a.d.m(p,{as:typeof d.as=="string"&&d.as!=="script"?d.as:void 0,crossOrigin:_,integrity:typeof d.integrity=="string"?d.integrity:void 0})}else a.d.m(p)},pi.requestFormReset=function(p){a.d.r(p)},pi.unstable_batchedUpdates=function(p,d){return p(d)},pi.useFormState=function(p,d,_){return c.H.useFormState(p,d,_)},pi.useFormStatus=function(){return c.H.useHostTransitionStatus()},pi.version="19.2.4",pi}var bS;function AA(){if(bS)return Vm.exports;bS=1;function o(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(o)}catch(t){console.error(t)}}return o(),Vm.exports=TA(),Vm.exports}/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var TS;function RA(){if(TS)return ic;TS=1;var o=bA(),t=tg(),n=AA();function a(e){var i="https://react.dev/errors/"+e;if(1<arguments.length){i+="?args[]="+encodeURIComponent(arguments[1]);for(var s=2;s<arguments.length;s++)i+="&args[]="+encodeURIComponent(arguments[s])}return"Minified React error #"+e+"; visit "+i+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function r(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function l(e){var i=e,s=e;if(e.alternate)for(;i.return;)i=i.return;else{e=i;do i=e,(i.flags&4098)!==0&&(s=i.return),e=i.return;while(e)}return i.tag===3?s:null}function c(e){if(e.tag===13){var i=e.memoizedState;if(i===null&&(e=e.alternate,e!==null&&(i=e.memoizedState)),i!==null)return i.dehydrated}return null}function f(e){if(e.tag===31){var i=e.memoizedState;if(i===null&&(e=e.alternate,e!==null&&(i=e.memoizedState)),i!==null)return i.dehydrated}return null}function p(e){if(l(e)!==e)throw Error(a(188))}function d(e){var i=e.alternate;if(!i){if(i=l(e),i===null)throw Error(a(188));return i!==e?null:e}for(var s=e,u=i;;){var h=s.return;if(h===null)break;var m=h.alternate;if(m===null){if(u=h.return,u!==null){s=u;continue}break}if(h.child===m.child){for(m=h.child;m;){if(m===s)return p(h),e;if(m===u)return p(h),i;m=m.sibling}throw Error(a(188))}if(s.return!==u.return)s=h,u=m;else{for(var b=!1,N=h.child;N;){if(N===s){b=!0,s=h,u=m;break}if(N===u){b=!0,u=h,s=m;break}N=N.sibling}if(!b){for(N=m.child;N;){if(N===s){b=!0,s=m,u=h;break}if(N===u){b=!0,u=m,s=h;break}N=N.sibling}if(!b)throw Error(a(189))}}if(s.alternate!==u)throw Error(a(190))}if(s.tag!==3)throw Error(a(188));return s.stateNode.current===s?e:i}function _(e){var i=e.tag;if(i===5||i===26||i===27||i===6)return e;for(e=e.child;e!==null;){if(i=_(e),i!==null)return i;e=e.sibling}return null}var v=Object.assign,g=Symbol.for("react.element"),x=Symbol.for("react.transitional.element"),M=Symbol.for("react.portal"),E=Symbol.for("react.fragment"),y=Symbol.for("react.strict_mode"),S=Symbol.for("react.profiler"),R=Symbol.for("react.consumer"),U=Symbol.for("react.context"),C=Symbol.for("react.forward_ref"),O=Symbol.for("react.suspense"),P=Symbol.for("react.suspense_list"),L=Symbol.for("react.memo"),T=Symbol.for("react.lazy"),w=Symbol.for("react.activity"),q=Symbol.for("react.memo_cache_sentinel"),G=Symbol.iterator;function k(e){return e===null||typeof e!="object"?null:(e=G&&e[G]||e["@@iterator"],typeof e=="function"?e:null)}var J=Symbol.for("react.client.reference");function et(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===J?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case E:return"Fragment";case S:return"Profiler";case y:return"StrictMode";case O:return"Suspense";case P:return"SuspenseList";case w:return"Activity"}if(typeof e=="object")switch(e.$$typeof){case M:return"Portal";case U:return e.displayName||"Context";case R:return(e._context.displayName||"Context")+".Consumer";case C:var i=e.render;return e=e.displayName,e||(e=i.displayName||i.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case L:return i=e.displayName||null,i!==null?i:et(e.type)||"Memo";case T:i=e._payload,e=e._init;try{return et(e(i))}catch{}}return null}var Q=Array.isArray,F=t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,I=n.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,it={pending:!1,data:null,method:null,action:null},ht=[],H=-1;function z(e){return{current:e}}function K(e){0>H||(e.current=ht[H],ht[H]=null,H--)}function xt(e,i){H++,ht[H]=e.current,e.current=i}var Tt=z(null),Ut=z(null),nt=z(null),_t=z(null);function Et(e,i){switch(xt(nt,i),xt(Ut,e),xt(Tt,null),i.nodeType){case 9:case 11:e=(e=i.documentElement)&&(e=e.namespaceURI)?Hy(e):0;break;default:if(e=i.tagName,i=i.namespaceURI)i=Hy(i),e=Gy(i,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}K(Tt),xt(Tt,e)}function Ft(){K(Tt),K(Ut),K(nt)}function ee(e){e.memoizedState!==null&&xt(_t,e);var i=Tt.current,s=Gy(i,e.type);i!==s&&(xt(Ut,e),xt(Tt,s))}function Kt(e){Ut.current===e&&(K(Tt),K(Ut)),_t.current===e&&(K(_t),Ju._currentValue=it)}var Ne,qt;function re(e){if(Ne===void 0)try{throw Error()}catch(s){var i=s.stack.trim().match(/\n( *(at )?)/);Ne=i&&i[1]||"",qt=-1<s.stack.indexOf(`
    at`)?" (<anonymous>)":-1<s.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Ne+e+qt}var _e=!1;function se(e,i){if(!e||_e)return"";_e=!0;var s=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var u={DetermineComponentFrameRoot:function(){try{if(i){var Mt=function(){throw Error()};if(Object.defineProperty(Mt.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(Mt,[])}catch(pt){var ct=pt}Reflect.construct(e,[],Mt)}else{try{Mt.call()}catch(pt){ct=pt}e.call(Mt.prototype)}}else{try{throw Error()}catch(pt){ct=pt}(Mt=e())&&typeof Mt.catch=="function"&&Mt.catch(function(){})}}catch(pt){if(pt&&ct&&typeof pt.stack=="string")return[pt.stack,ct.stack]}return[null,null]}};u.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var h=Object.getOwnPropertyDescriptor(u.DetermineComponentFrameRoot,"name");h&&h.configurable&&Object.defineProperty(u.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var m=u.DetermineComponentFrameRoot(),b=m[0],N=m[1];if(b&&N){var X=b.split(`
`),ot=N.split(`
`);for(h=u=0;u<X.length&&!X[u].includes("DetermineComponentFrameRoot");)u++;for(;h<ot.length&&!ot[h].includes("DetermineComponentFrameRoot");)h++;if(u===X.length||h===ot.length)for(u=X.length-1,h=ot.length-1;1<=u&&0<=h&&X[u]!==ot[h];)h--;for(;1<=u&&0<=h;u--,h--)if(X[u]!==ot[h]){if(u!==1||h!==1)do if(u--,h--,0>h||X[u]!==ot[h]){var yt=`
`+X[u].replace(" at new "," at ");return e.displayName&&yt.includes("<anonymous>")&&(yt=yt.replace("<anonymous>",e.displayName)),yt}while(1<=u&&0<=h);break}}}finally{_e=!1,Error.prepareStackTrace=s}return(s=e?e.displayName||e.name:"")?re(s):""}function lt(e,i){switch(e.tag){case 26:case 27:case 5:return re(e.type);case 16:return re("Lazy");case 13:return e.child!==i&&i!==null?re("Suspense Fallback"):re("Suspense");case 19:return re("SuspenseList");case 0:case 15:return se(e.type,!1);case 11:return se(e.type.render,!1);case 1:return se(e.type,!0);case 31:return re("Activity");default:return""}}function W(e){try{var i="",s=null;do i+=lt(e,s),s=e,e=e.return;while(e);return i}catch(u){return`
Error generating stack: `+u.message+`
`+u.stack}}var We=Object.prototype.hasOwnProperty,Ee=o.unstable_scheduleCallback,ce=o.unstable_cancelCallback,Wt=o.unstable_shouldYield,B=o.unstable_requestPaint,A=o.unstable_now,j=o.unstable_getCurrentPriorityLevel,gt=o.unstable_ImmediatePriority,vt=o.unstable_UserBlockingPriority,dt=o.unstable_NormalPriority,Gt=o.unstable_LowPriority,wt=o.unstable_IdlePriority,ie=o.log,Yt=o.unstable_setDisableYieldValue,Rt=null,At=null;function Ht(e){if(typeof ie=="function"&&Yt(e),At&&typeof At.setStrictMode=="function")try{At.setStrictMode(Rt,e)}catch{}}var Pt=Math.clz32?Math.clz32:V,zt=Math.log,pe=Math.LN2;function V(e){return e>>>=0,e===0?32:31-(zt(e)/pe|0)|0}var Dt=256,Ct=262144,Lt=4194304;function bt(e){var i=e&42;if(i!==0)return i;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function mt(e,i,s){var u=e.pendingLanes;if(u===0)return 0;var h=0,m=e.suspendedLanes,b=e.pingedLanes;e=e.warmLanes;var N=u&134217727;return N!==0?(u=N&~m,u!==0?h=bt(u):(b&=N,b!==0?h=bt(b):s||(s=N&~e,s!==0&&(h=bt(s))))):(N=u&~m,N!==0?h=bt(N):b!==0?h=bt(b):s||(s=u&~e,s!==0&&(h=bt(s)))),h===0?0:i!==0&&i!==h&&(i&m)===0&&(m=h&-h,s=i&-i,m>=s||m===32&&(s&4194048)!==0)?i:h}function Xt(e,i){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&i)===0}function le(e,i){switch(e){case 1:case 2:case 4:case 8:case 64:return i+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return i+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Ge(){var e=Lt;return Lt<<=1,(Lt&62914560)===0&&(Lt=4194304),e}function Vt(e){for(var i=[],s=0;31>s;s++)i.push(e);return i}function Jt(e,i){e.pendingLanes|=i,i!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function be(e,i,s,u,h,m){var b=e.pendingLanes;e.pendingLanes=s,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=s,e.entangledLanes&=s,e.errorRecoveryDisabledLanes&=s,e.shellSuspendCounter=0;var N=e.entanglements,X=e.expirationTimes,ot=e.hiddenUpdates;for(s=b&~s;0<s;){var yt=31-Pt(s),Mt=1<<yt;N[yt]=0,X[yt]=-1;var ct=ot[yt];if(ct!==null)for(ot[yt]=null,yt=0;yt<ct.length;yt++){var pt=ct[yt];pt!==null&&(pt.lane&=-536870913)}s&=~Mt}u!==0&&It(e,u,0),m!==0&&h===0&&e.tag!==0&&(e.suspendedLanes|=m&~(b&~i))}function It(e,i,s){e.pendingLanes|=i,e.suspendedLanes&=~i;var u=31-Pt(i);e.entangledLanes|=i,e.entanglements[u]=e.entanglements[u]|1073741824|s&261930}function he(e,i){var s=e.entangledLanes|=i;for(e=e.entanglements;s;){var u=31-Pt(s),h=1<<u;h&i|e[u]&i&&(e[u]|=i),s&=~h}}function oe(e,i){var s=i&-i;return s=(s&42)!==0?1:de(s),(s&(e.suspendedLanes|i))!==0?0:s}function de(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function _n(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function ge(){var e=I.p;return e!==0?e:(e=window.event,e===void 0?32:cS(e.type))}function rn(e,i){var s=I.p;try{return I.p=e,i()}finally{I.p=s}}var sn=Math.random().toString(36).slice(2),Te="__reactFiber$"+sn,xe="__reactProps$"+sn,Pe="__reactContainer$"+sn,In="__reactEvents$"+sn,on="__reactListeners$"+sn,ti="__reactHandles$"+sn,bi="__reactResources$"+sn,gn="__reactMarker$"+sn;function Tn(e){delete e[Te],delete e[xe],delete e[In],delete e[on],delete e[ti]}function vn(e){var i=e[Te];if(i)return i;for(var s=e.parentNode;s;){if(i=s[Pe]||s[Te]){if(s=i.alternate,i.child!==null||s!==null&&s.child!==null)for(e=jy(e);e!==null;){if(s=e[Te])return s;e=jy(e)}return i}e=s,s=e.parentNode}return null}function di(e){if(e=e[Te]||e[Pe]){var i=e.tag;if(i===5||i===6||i===13||i===31||i===26||i===27||i===3)return e}return null}function Sa(e){var i=e.tag;if(i===5||i===26||i===27||i===6)return e.stateNode;throw Error(a(33))}function D(e){var i=e[bi];return i||(i=e[bi]={hoistableStyles:new Map,hoistableScripts:new Map}),i}function Y(e){e[gn]=!0}var ut=new Set,st={};function at(e,i){Nt(e,i),Nt(e+"Capture",i)}function Nt(e,i){for(st[e]=i,e=0;e<i.length;e++)ut.add(i[e])}var Bt=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),Ot={},jt={};function Zt(e){return We.call(jt,e)?!0:We.call(Ot,e)?!1:Bt.test(e)?jt[e]=!0:(Ot[e]=!0,!1)}function me(e,i,s){if(Zt(i))if(s===null)e.removeAttribute(i);else{switch(typeof s){case"undefined":case"function":case"symbol":e.removeAttribute(i);return;case"boolean":var u=i.toLowerCase().slice(0,5);if(u!=="data-"&&u!=="aria-"){e.removeAttribute(i);return}}e.setAttribute(i,""+s)}}function ye(e,i,s){if(s===null)e.removeAttribute(i);else{switch(typeof s){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(i);return}e.setAttribute(i,""+s)}}function Qt(e,i,s,u){if(u===null)e.removeAttribute(s);else{switch(typeof u){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(s);return}e.setAttributeNS(i,s,""+u)}}function Re(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Sn(e){var i=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(i==="checkbox"||i==="radio")}function Mn(e,i,s){var u=Object.getOwnPropertyDescriptor(e.constructor.prototype,i);if(!e.hasOwnProperty(i)&&typeof u<"u"&&typeof u.get=="function"&&typeof u.set=="function"){var h=u.get,m=u.set;return Object.defineProperty(e,i,{configurable:!0,get:function(){return h.call(this)},set:function(b){s=""+b,m.call(this,b)}}),Object.defineProperty(e,i,{enumerable:u.enumerable}),{getValue:function(){return s},setValue:function(b){s=""+b},stopTracking:function(){e._valueTracker=null,delete e[i]}}}}function je(e){if(!e._valueTracker){var i=Sn(e)?"checked":"value";e._valueTracker=Mn(e,i,""+e[i])}}function jn(e){if(!e)return!1;var i=e._valueTracker;if(!i)return!0;var s=i.getValue(),u="";return e&&(u=Sn(e)?e.checked?"true":"false":e.value),e=u,e!==s?(i.setValue(e),!0):!1}function ne(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}var Ti=/[\n"\\]/g;function ve(e){return e.replace(Ti,function(i){return"\\"+i.charCodeAt(0).toString(16)+" "})}function Ai(e,i,s,u,h,m,b,N){e.name="",b!=null&&typeof b!="function"&&typeof b!="symbol"&&typeof b!="boolean"?e.type=b:e.removeAttribute("type"),i!=null?b==="number"?(i===0&&e.value===""||e.value!=i)&&(e.value=""+Re(i)):e.value!==""+Re(i)&&(e.value=""+Re(i)):b!=="submit"&&b!=="reset"||e.removeAttribute("value"),i!=null?Va(e,b,Re(i)):s!=null?Va(e,b,Re(s)):u!=null&&e.removeAttribute("value"),h==null&&m!=null&&(e.defaultChecked=!!m),h!=null&&(e.checked=h&&typeof h!="function"&&typeof h!="symbol"),N!=null&&typeof N!="function"&&typeof N!="symbol"&&typeof N!="boolean"?e.name=""+Re(N):e.removeAttribute("name")}function $i(e,i,s,u,h,m,b,N){if(m!=null&&typeof m!="function"&&typeof m!="symbol"&&typeof m!="boolean"&&(e.type=m),i!=null||s!=null){if(!(m!=="submit"&&m!=="reset"||i!=null)){je(e);return}s=s!=null?""+Re(s):"",i=i!=null?""+Re(i):s,N||i===e.value||(e.value=i),e.defaultValue=i}u=u??h,u=typeof u!="function"&&typeof u!="symbol"&&!!u,e.checked=N?e.checked:!!u,e.defaultChecked=!!u,b!=null&&typeof b!="function"&&typeof b!="symbol"&&typeof b!="boolean"&&(e.name=b),je(e)}function Va(e,i,s){i==="number"&&ne(e.ownerDocument)===e||e.defaultValue===""+s||(e.defaultValue=""+s)}function ta(e,i,s,u){if(e=e.options,i){i={};for(var h=0;h<s.length;h++)i["$"+s[h]]=!0;for(s=0;s<e.length;s++)h=i.hasOwnProperty("$"+e[s].value),e[s].selected!==h&&(e[s].selected=h),h&&u&&(e[s].defaultSelected=!0)}else{for(s=""+Re(s),i=null,h=0;h<e.length;h++){if(e[h].value===s){e[h].selected=!0,u&&(e[h].defaultSelected=!0);return}i!==null||e[h].disabled||(i=e[h])}i!==null&&(i.selected=!0)}}function $e(e,i,s){if(i!=null&&(i=""+Re(i),i!==e.value&&(e.value=i),s==null)){e.defaultValue!==i&&(e.defaultValue=i);return}e.defaultValue=s!=null?""+Re(s):""}function Bn(e,i,s,u){if(i==null){if(u!=null){if(s!=null)throw Error(a(92));if(Q(u)){if(1<u.length)throw Error(a(93));u=u[0]}s=u}s==null&&(s=""),i=s}s=Re(i),e.defaultValue=s,u=e.textContent,u===s&&u!==""&&u!==null&&(e.value=u),je(e)}function Ri(e,i){if(i){var s=e.firstChild;if(s&&s===e.lastChild&&s.nodeType===3){s.nodeValue=i;return}}e.textContent=i}var Hn=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function ka(e,i,s){var u=i.indexOf("--")===0;s==null||typeof s=="boolean"||s===""?u?e.setProperty(i,""):i==="float"?e.cssFloat="":e[i]="":u?e.setProperty(i,s):typeof s!="number"||s===0||Hn.has(i)?i==="float"?e.cssFloat=s:e[i]=(""+s).trim():e[i]=s+"px"}function Er(e,i,s){if(i!=null&&typeof i!="object")throw Error(a(62));if(e=e.style,s!=null){for(var u in s)!s.hasOwnProperty(u)||i!=null&&i.hasOwnProperty(u)||(u.indexOf("--")===0?e.setProperty(u,""):u==="float"?e.cssFloat="":e[u]="");for(var h in i)u=i[h],i.hasOwnProperty(h)&&s[h]!==u&&ka(e,h,u)}else for(var m in i)i.hasOwnProperty(m)&&ka(e,m,i[m])}function Yo(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var _b=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),gb=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function tf(e){return gb.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function br(){}var Od=null;function Pd(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var qo=null,jo=null;function Bg(e){var i=di(e);if(i&&(e=i.stateNode)){var s=e[xe]||null;t:switch(e=i.stateNode,i.type){case"input":if(Ai(e,s.value,s.defaultValue,s.defaultValue,s.checked,s.defaultChecked,s.type,s.name),i=s.name,s.type==="radio"&&i!=null){for(s=e;s.parentNode;)s=s.parentNode;for(s=s.querySelectorAll('input[name="'+ve(""+i)+'"][type="radio"]'),i=0;i<s.length;i++){var u=s[i];if(u!==e&&u.form===e.form){var h=u[xe]||null;if(!h)throw Error(a(90));Ai(u,h.value,h.defaultValue,h.defaultValue,h.checked,h.defaultChecked,h.type,h.name)}}for(i=0;i<s.length;i++)u=s[i],u.form===e.form&&jn(u)}break t;case"textarea":$e(e,s.value,s.defaultValue);break t;case"select":i=s.value,i!=null&&ta(e,!!s.multiple,i,!1)}}}var Fd=!1;function Hg(e,i,s){if(Fd)return e(i,s);Fd=!0;try{var u=e(i);return u}finally{if(Fd=!1,(qo!==null||jo!==null)&&(Vf(),qo&&(i=qo,e=jo,jo=qo=null,Bg(i),e)))for(i=0;i<e.length;i++)Bg(e[i])}}function mu(e,i){var s=e.stateNode;if(s===null)return null;var u=s[xe]||null;if(u===null)return null;s=u[i];t:switch(i){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(u=!u.disabled)||(e=e.type,u=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!u;break t;default:e=!1}if(e)return null;if(s&&typeof s!="function")throw Error(a(231,i,typeof s));return s}var Tr=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),zd=!1;if(Tr)try{var _u={};Object.defineProperty(_u,"passive",{get:function(){zd=!0}}),window.addEventListener("test",_u,_u),window.removeEventListener("test",_u,_u)}catch{zd=!1}var ss=null,Id=null,ef=null;function Gg(){if(ef)return ef;var e,i=Id,s=i.length,u,h="value"in ss?ss.value:ss.textContent,m=h.length;for(e=0;e<s&&i[e]===h[e];e++);var b=s-e;for(u=1;u<=b&&i[s-u]===h[m-u];u++);return ef=h.slice(e,1<u?1-u:void 0)}function nf(e){var i=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&i===13&&(e=13)):e=i,e===10&&(e=13),32<=e||e===13?e:0}function af(){return!0}function Vg(){return!1}function Ii(e){function i(s,u,h,m,b){this._reactName=s,this._targetInst=h,this.type=u,this.nativeEvent=m,this.target=b,this.currentTarget=null;for(var N in e)e.hasOwnProperty(N)&&(s=e[N],this[N]=s?s(m):m[N]);return this.isDefaultPrevented=(m.defaultPrevented!=null?m.defaultPrevented:m.returnValue===!1)?af:Vg,this.isPropagationStopped=Vg,this}return v(i.prototype,{preventDefault:function(){this.defaultPrevented=!0;var s=this.nativeEvent;s&&(s.preventDefault?s.preventDefault():typeof s.returnValue!="unknown"&&(s.returnValue=!1),this.isDefaultPrevented=af)},stopPropagation:function(){var s=this.nativeEvent;s&&(s.stopPropagation?s.stopPropagation():typeof s.cancelBubble!="unknown"&&(s.cancelBubble=!0),this.isPropagationStopped=af)},persist:function(){},isPersistent:af}),i}var Js={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},rf=Ii(Js),gu=v({},Js,{view:0,detail:0}),vb=Ii(gu),Bd,Hd,vu,sf=v({},gu,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Vd,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==vu&&(vu&&e.type==="mousemove"?(Bd=e.screenX-vu.screenX,Hd=e.screenY-vu.screenY):Hd=Bd=0,vu=e),Bd)},movementY:function(e){return"movementY"in e?e.movementY:Hd}}),kg=Ii(sf),xb=v({},sf,{dataTransfer:0}),yb=Ii(xb),Sb=v({},gu,{relatedTarget:0}),Gd=Ii(Sb),Mb=v({},Js,{animationName:0,elapsedTime:0,pseudoElement:0}),Eb=Ii(Mb),bb=v({},Js,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),Tb=Ii(bb),Ab=v({},Js,{data:0}),Xg=Ii(Ab),Rb={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Cb={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},wb={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Db(e){var i=this.nativeEvent;return i.getModifierState?i.getModifierState(e):(e=wb[e])?!!i[e]:!1}function Vd(){return Db}var Ub=v({},gu,{key:function(e){if(e.key){var i=Rb[e.key]||e.key;if(i!=="Unidentified")return i}return e.type==="keypress"?(e=nf(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?Cb[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Vd,charCode:function(e){return e.type==="keypress"?nf(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?nf(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),Nb=Ii(Ub),Lb=v({},sf,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Wg=Ii(Lb),Ob=v({},gu,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Vd}),Pb=Ii(Ob),Fb=v({},Js,{propertyName:0,elapsedTime:0,pseudoElement:0}),zb=Ii(Fb),Ib=v({},sf,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),Bb=Ii(Ib),Hb=v({},Js,{newState:0,oldState:0}),Gb=Ii(Hb),Vb=[9,13,27,32],kd=Tr&&"CompositionEvent"in window,xu=null;Tr&&"documentMode"in document&&(xu=document.documentMode);var kb=Tr&&"TextEvent"in window&&!xu,Yg=Tr&&(!kd||xu&&8<xu&&11>=xu),qg=" ",jg=!1;function Zg(e,i){switch(e){case"keyup":return Vb.indexOf(i.keyCode)!==-1;case"keydown":return i.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Kg(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var Zo=!1;function Xb(e,i){switch(e){case"compositionend":return Kg(i);case"keypress":return i.which!==32?null:(jg=!0,qg);case"textInput":return e=i.data,e===qg&&jg?null:e;default:return null}}function Wb(e,i){if(Zo)return e==="compositionend"||!kd&&Zg(e,i)?(e=Gg(),ef=Id=ss=null,Zo=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(i.ctrlKey||i.altKey||i.metaKey)||i.ctrlKey&&i.altKey){if(i.char&&1<i.char.length)return i.char;if(i.which)return String.fromCharCode(i.which)}return null;case"compositionend":return Yg&&i.locale!=="ko"?null:i.data;default:return null}}var Yb={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Qg(e){var i=e&&e.nodeName&&e.nodeName.toLowerCase();return i==="input"?!!Yb[e.type]:i==="textarea"}function Jg(e,i,s,u){qo?jo?jo.push(u):jo=[u]:qo=u,i=Zf(i,"onChange"),0<i.length&&(s=new rf("onChange","change",null,s,u),e.push({event:s,listeners:i}))}var yu=null,Su=null;function qb(e){Oy(e,0)}function of(e){var i=Sa(e);if(jn(i))return e}function $g(e,i){if(e==="change")return i}var tv=!1;if(Tr){var Xd;if(Tr){var Wd="oninput"in document;if(!Wd){var ev=document.createElement("div");ev.setAttribute("oninput","return;"),Wd=typeof ev.oninput=="function"}Xd=Wd}else Xd=!1;tv=Xd&&(!document.documentMode||9<document.documentMode)}function nv(){yu&&(yu.detachEvent("onpropertychange",iv),Su=yu=null)}function iv(e){if(e.propertyName==="value"&&of(Su)){var i=[];Jg(i,Su,e,Pd(e)),Hg(qb,i)}}function jb(e,i,s){e==="focusin"?(nv(),yu=i,Su=s,yu.attachEvent("onpropertychange",iv)):e==="focusout"&&nv()}function Zb(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return of(Su)}function Kb(e,i){if(e==="click")return of(i)}function Qb(e,i){if(e==="input"||e==="change")return of(i)}function Jb(e,i){return e===i&&(e!==0||1/e===1/i)||e!==e&&i!==i}var ea=typeof Object.is=="function"?Object.is:Jb;function Mu(e,i){if(ea(e,i))return!0;if(typeof e!="object"||e===null||typeof i!="object"||i===null)return!1;var s=Object.keys(e),u=Object.keys(i);if(s.length!==u.length)return!1;for(u=0;u<s.length;u++){var h=s[u];if(!We.call(i,h)||!ea(e[h],i[h]))return!1}return!0}function av(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function rv(e,i){var s=av(e);e=0;for(var u;s;){if(s.nodeType===3){if(u=e+s.textContent.length,e<=i&&u>=i)return{node:s,offset:i-e};e=u}t:{for(;s;){if(s.nextSibling){s=s.nextSibling;break t}s=s.parentNode}s=void 0}s=av(s)}}function sv(e,i){return e&&i?e===i?!0:e&&e.nodeType===3?!1:i&&i.nodeType===3?sv(e,i.parentNode):"contains"in e?e.contains(i):e.compareDocumentPosition?!!(e.compareDocumentPosition(i)&16):!1:!1}function ov(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var i=ne(e.document);i instanceof e.HTMLIFrameElement;){try{var s=typeof i.contentWindow.location.href=="string"}catch{s=!1}if(s)e=i.contentWindow;else break;i=ne(e.document)}return i}function Yd(e){var i=e&&e.nodeName&&e.nodeName.toLowerCase();return i&&(i==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||i==="textarea"||e.contentEditable==="true")}var $b=Tr&&"documentMode"in document&&11>=document.documentMode,Ko=null,qd=null,Eu=null,jd=!1;function lv(e,i,s){var u=s.window===s?s.document:s.nodeType===9?s:s.ownerDocument;jd||Ko==null||Ko!==ne(u)||(u=Ko,"selectionStart"in u&&Yd(u)?u={start:u.selectionStart,end:u.selectionEnd}:(u=(u.ownerDocument&&u.ownerDocument.defaultView||window).getSelection(),u={anchorNode:u.anchorNode,anchorOffset:u.anchorOffset,focusNode:u.focusNode,focusOffset:u.focusOffset}),Eu&&Mu(Eu,u)||(Eu=u,u=Zf(qd,"onSelect"),0<u.length&&(i=new rf("onSelect","select",null,i,s),e.push({event:i,listeners:u}),i.target=Ko)))}function $s(e,i){var s={};return s[e.toLowerCase()]=i.toLowerCase(),s["Webkit"+e]="webkit"+i,s["Moz"+e]="moz"+i,s}var Qo={animationend:$s("Animation","AnimationEnd"),animationiteration:$s("Animation","AnimationIteration"),animationstart:$s("Animation","AnimationStart"),transitionrun:$s("Transition","TransitionRun"),transitionstart:$s("Transition","TransitionStart"),transitioncancel:$s("Transition","TransitionCancel"),transitionend:$s("Transition","TransitionEnd")},Zd={},uv={};Tr&&(uv=document.createElement("div").style,"AnimationEvent"in window||(delete Qo.animationend.animation,delete Qo.animationiteration.animation,delete Qo.animationstart.animation),"TransitionEvent"in window||delete Qo.transitionend.transition);function to(e){if(Zd[e])return Zd[e];if(!Qo[e])return e;var i=Qo[e],s;for(s in i)if(i.hasOwnProperty(s)&&s in uv)return Zd[e]=i[s];return e}var cv=to("animationend"),fv=to("animationiteration"),hv=to("animationstart"),tT=to("transitionrun"),eT=to("transitionstart"),nT=to("transitioncancel"),dv=to("transitionend"),pv=new Map,Kd="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Kd.push("scrollEnd");function Xa(e,i){pv.set(e,i),at(i,[e])}var lf=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var i=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(i))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},Ma=[],Jo=0,Qd=0;function uf(){for(var e=Jo,i=Qd=Jo=0;i<e;){var s=Ma[i];Ma[i++]=null;var u=Ma[i];Ma[i++]=null;var h=Ma[i];Ma[i++]=null;var m=Ma[i];if(Ma[i++]=null,u!==null&&h!==null){var b=u.pending;b===null?h.next=h:(h.next=b.next,b.next=h),u.pending=h}m!==0&&mv(s,h,m)}}function cf(e,i,s,u){Ma[Jo++]=e,Ma[Jo++]=i,Ma[Jo++]=s,Ma[Jo++]=u,Qd|=u,e.lanes|=u,e=e.alternate,e!==null&&(e.lanes|=u)}function Jd(e,i,s,u){return cf(e,i,s,u),ff(e)}function eo(e,i){return cf(e,null,null,i),ff(e)}function mv(e,i,s){e.lanes|=s;var u=e.alternate;u!==null&&(u.lanes|=s);for(var h=!1,m=e.return;m!==null;)m.childLanes|=s,u=m.alternate,u!==null&&(u.childLanes|=s),m.tag===22&&(e=m.stateNode,e===null||e._visibility&1||(h=!0)),e=m,m=m.return;return e.tag===3?(m=e.stateNode,h&&i!==null&&(h=31-Pt(s),e=m.hiddenUpdates,u=e[h],u===null?e[h]=[i]:u.push(i),i.lane=s|536870912),m):null}function ff(e){if(50<Wu)throw Wu=0,om=null,Error(a(185));for(var i=e.return;i!==null;)e=i,i=e.return;return e.tag===3?e.stateNode:null}var $o={};function iT(e,i,s,u){this.tag=e,this.key=s,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=i,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=u,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function na(e,i,s,u){return new iT(e,i,s,u)}function $d(e){return e=e.prototype,!(!e||!e.isReactComponent)}function Ar(e,i){var s=e.alternate;return s===null?(s=na(e.tag,i,e.key,e.mode),s.elementType=e.elementType,s.type=e.type,s.stateNode=e.stateNode,s.alternate=e,e.alternate=s):(s.pendingProps=i,s.type=e.type,s.flags=0,s.subtreeFlags=0,s.deletions=null),s.flags=e.flags&65011712,s.childLanes=e.childLanes,s.lanes=e.lanes,s.child=e.child,s.memoizedProps=e.memoizedProps,s.memoizedState=e.memoizedState,s.updateQueue=e.updateQueue,i=e.dependencies,s.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext},s.sibling=e.sibling,s.index=e.index,s.ref=e.ref,s.refCleanup=e.refCleanup,s}function _v(e,i){e.flags&=65011714;var s=e.alternate;return s===null?(e.childLanes=0,e.lanes=i,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=s.childLanes,e.lanes=s.lanes,e.child=s.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=s.memoizedProps,e.memoizedState=s.memoizedState,e.updateQueue=s.updateQueue,e.type=s.type,i=s.dependencies,e.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext}),e}function hf(e,i,s,u,h,m){var b=0;if(u=e,typeof e=="function")$d(e)&&(b=1);else if(typeof e=="string")b=lA(e,s,Tt.current)?26:e==="html"||e==="head"||e==="body"?27:5;else t:switch(e){case w:return e=na(31,s,i,h),e.elementType=w,e.lanes=m,e;case E:return no(s.children,h,m,i);case y:b=8,h|=24;break;case S:return e=na(12,s,i,h|2),e.elementType=S,e.lanes=m,e;case O:return e=na(13,s,i,h),e.elementType=O,e.lanes=m,e;case P:return e=na(19,s,i,h),e.elementType=P,e.lanes=m,e;default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case U:b=10;break t;case R:b=9;break t;case C:b=11;break t;case L:b=14;break t;case T:b=16,u=null;break t}b=29,s=Error(a(130,e===null?"null":typeof e,"")),u=null}return i=na(b,s,i,h),i.elementType=e,i.type=u,i.lanes=m,i}function no(e,i,s,u){return e=na(7,e,u,i),e.lanes=s,e}function tp(e,i,s){return e=na(6,e,null,i),e.lanes=s,e}function gv(e){var i=na(18,null,null,0);return i.stateNode=e,i}function ep(e,i,s){return i=na(4,e.children!==null?e.children:[],e.key,i),i.lanes=s,i.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},i}var vv=new WeakMap;function Ea(e,i){if(typeof e=="object"&&e!==null){var s=vv.get(e);return s!==void 0?s:(i={value:e,source:i,stack:W(i)},vv.set(e,i),i)}return{value:e,source:i,stack:W(i)}}var tl=[],el=0,df=null,bu=0,ba=[],Ta=0,os=null,er=1,nr="";function Rr(e,i){tl[el++]=bu,tl[el++]=df,df=e,bu=i}function xv(e,i,s){ba[Ta++]=er,ba[Ta++]=nr,ba[Ta++]=os,os=e;var u=er;e=nr;var h=32-Pt(u)-1;u&=~(1<<h),s+=1;var m=32-Pt(i)+h;if(30<m){var b=h-h%5;m=(u&(1<<b)-1).toString(32),u>>=b,h-=b,er=1<<32-Pt(i)+h|s<<h|u,nr=m+e}else er=1<<m|s<<h|u,nr=e}function np(e){e.return!==null&&(Rr(e,1),xv(e,1,0))}function ip(e){for(;e===df;)df=tl[--el],tl[el]=null,bu=tl[--el],tl[el]=null;for(;e===os;)os=ba[--Ta],ba[Ta]=null,nr=ba[--Ta],ba[Ta]=null,er=ba[--Ta],ba[Ta]=null}function yv(e,i){ba[Ta++]=er,ba[Ta++]=nr,ba[Ta++]=os,er=i.id,nr=i.overflow,os=e}var si=null,xn=null,Ve=!1,ls=null,Aa=!1,ap=Error(a(519));function us(e){var i=Error(a(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw Tu(Ea(i,e)),ap}function Sv(e){var i=e.stateNode,s=e.type,u=e.memoizedProps;switch(i[Te]=e,i[xe]=u,s){case"dialog":ze("cancel",i),ze("close",i);break;case"iframe":case"object":case"embed":ze("load",i);break;case"video":case"audio":for(s=0;s<qu.length;s++)ze(qu[s],i);break;case"source":ze("error",i);break;case"img":case"image":case"link":ze("error",i),ze("load",i);break;case"details":ze("toggle",i);break;case"input":ze("invalid",i),$i(i,u.value,u.defaultValue,u.checked,u.defaultChecked,u.type,u.name,!0);break;case"select":ze("invalid",i);break;case"textarea":ze("invalid",i),Bn(i,u.value,u.defaultValue,u.children)}s=u.children,typeof s!="string"&&typeof s!="number"&&typeof s!="bigint"||i.textContent===""+s||u.suppressHydrationWarning===!0||Iy(i.textContent,s)?(u.popover!=null&&(ze("beforetoggle",i),ze("toggle",i)),u.onScroll!=null&&ze("scroll",i),u.onScrollEnd!=null&&ze("scrollend",i),u.onClick!=null&&(i.onclick=br),i=!0):i=!1,i||us(e,!0)}function Mv(e){for(si=e.return;si;)switch(si.tag){case 5:case 31:case 13:Aa=!1;return;case 27:case 3:Aa=!0;return;default:si=si.return}}function nl(e){if(e!==si)return!1;if(!Ve)return Mv(e),Ve=!0,!1;var i=e.tag,s;if((s=i!==3&&i!==27)&&((s=i===5)&&(s=e.type,s=!(s!=="form"&&s!=="button")||Mm(e.type,e.memoizedProps)),s=!s),s&&xn&&us(e),Mv(e),i===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(a(317));xn=qy(e)}else if(i===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(a(317));xn=qy(e)}else i===27?(i=xn,Es(e.type)?(e=Rm,Rm=null,xn=e):xn=i):xn=si?Ca(e.stateNode.nextSibling):null;return!0}function io(){xn=si=null,Ve=!1}function rp(){var e=ls;return e!==null&&(Vi===null?Vi=e:Vi.push.apply(Vi,e),ls=null),e}function Tu(e){ls===null?ls=[e]:ls.push(e)}var sp=z(null),ao=null,Cr=null;function cs(e,i,s){xt(sp,i._currentValue),i._currentValue=s}function wr(e){e._currentValue=sp.current,K(sp)}function op(e,i,s){for(;e!==null;){var u=e.alternate;if((e.childLanes&i)!==i?(e.childLanes|=i,u!==null&&(u.childLanes|=i)):u!==null&&(u.childLanes&i)!==i&&(u.childLanes|=i),e===s)break;e=e.return}}function lp(e,i,s,u){var h=e.child;for(h!==null&&(h.return=e);h!==null;){var m=h.dependencies;if(m!==null){var b=h.child;m=m.firstContext;t:for(;m!==null;){var N=m;m=h;for(var X=0;X<i.length;X++)if(N.context===i[X]){m.lanes|=s,N=m.alternate,N!==null&&(N.lanes|=s),op(m.return,s,e),u||(b=null);break t}m=N.next}}else if(h.tag===18){if(b=h.return,b===null)throw Error(a(341));b.lanes|=s,m=b.alternate,m!==null&&(m.lanes|=s),op(b,s,e),b=null}else b=h.child;if(b!==null)b.return=h;else for(b=h;b!==null;){if(b===e){b=null;break}if(h=b.sibling,h!==null){h.return=b.return,b=h;break}b=b.return}h=b}}function il(e,i,s,u){e=null;for(var h=i,m=!1;h!==null;){if(!m){if((h.flags&524288)!==0)m=!0;else if((h.flags&262144)!==0)break}if(h.tag===10){var b=h.alternate;if(b===null)throw Error(a(387));if(b=b.memoizedProps,b!==null){var N=h.type;ea(h.pendingProps.value,b.value)||(e!==null?e.push(N):e=[N])}}else if(h===_t.current){if(b=h.alternate,b===null)throw Error(a(387));b.memoizedState.memoizedState!==h.memoizedState.memoizedState&&(e!==null?e.push(Ju):e=[Ju])}h=h.return}e!==null&&lp(i,e,s,u),i.flags|=262144}function pf(e){for(e=e.firstContext;e!==null;){if(!ea(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function ro(e){ao=e,Cr=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function oi(e){return Ev(ao,e)}function mf(e,i){return ao===null&&ro(e),Ev(e,i)}function Ev(e,i){var s=i._currentValue;if(i={context:i,memoizedValue:s,next:null},Cr===null){if(e===null)throw Error(a(308));Cr=i,e.dependencies={lanes:0,firstContext:i},e.flags|=524288}else Cr=Cr.next=i;return s}var aT=typeof AbortController<"u"?AbortController:function(){var e=[],i=this.signal={aborted:!1,addEventListener:function(s,u){e.push(u)}};this.abort=function(){i.aborted=!0,e.forEach(function(s){return s()})}},rT=o.unstable_scheduleCallback,sT=o.unstable_NormalPriority,Gn={$$typeof:U,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function up(){return{controller:new aT,data:new Map,refCount:0}}function Au(e){e.refCount--,e.refCount===0&&rT(sT,function(){e.controller.abort()})}var Ru=null,cp=0,al=0,rl=null;function oT(e,i){if(Ru===null){var s=Ru=[];cp=0,al=dm(),rl={status:"pending",value:void 0,then:function(u){s.push(u)}}}return cp++,i.then(bv,bv),i}function bv(){if(--cp===0&&Ru!==null){rl!==null&&(rl.status="fulfilled");var e=Ru;Ru=null,al=0,rl=null;for(var i=0;i<e.length;i++)(0,e[i])()}}function lT(e,i){var s=[],u={status:"pending",value:null,reason:null,then:function(h){s.push(h)}};return e.then(function(){u.status="fulfilled",u.value=i;for(var h=0;h<s.length;h++)(0,s[h])(i)},function(h){for(u.status="rejected",u.reason=h,h=0;h<s.length;h++)(0,s[h])(void 0)}),u}var Tv=F.S;F.S=function(e,i){ly=A(),typeof i=="object"&&i!==null&&typeof i.then=="function"&&oT(e,i),Tv!==null&&Tv(e,i)};var so=z(null);function fp(){var e=so.current;return e!==null?e:hn.pooledCache}function _f(e,i){i===null?xt(so,so.current):xt(so,i.pool)}function Av(){var e=fp();return e===null?null:{parent:Gn._currentValue,pool:e}}var sl=Error(a(460)),hp=Error(a(474)),gf=Error(a(542)),vf={then:function(){}};function Rv(e){return e=e.status,e==="fulfilled"||e==="rejected"}function Cv(e,i,s){switch(s=e[s],s===void 0?e.push(i):s!==i&&(i.then(br,br),i=s),i.status){case"fulfilled":return i.value;case"rejected":throw e=i.reason,Dv(e),e;default:if(typeof i.status=="string")i.then(br,br);else{if(e=hn,e!==null&&100<e.shellSuspendCounter)throw Error(a(482));e=i,e.status="pending",e.then(function(u){if(i.status==="pending"){var h=i;h.status="fulfilled",h.value=u}},function(u){if(i.status==="pending"){var h=i;h.status="rejected",h.reason=u}})}switch(i.status){case"fulfilled":return i.value;case"rejected":throw e=i.reason,Dv(e),e}throw lo=i,sl}}function oo(e){try{var i=e._init;return i(e._payload)}catch(s){throw s!==null&&typeof s=="object"&&typeof s.then=="function"?(lo=s,sl):s}}var lo=null;function wv(){if(lo===null)throw Error(a(459));var e=lo;return lo=null,e}function Dv(e){if(e===sl||e===gf)throw Error(a(483))}var ol=null,Cu=0;function xf(e){var i=Cu;return Cu+=1,ol===null&&(ol=[]),Cv(ol,e,i)}function wu(e,i){i=i.props.ref,e.ref=i!==void 0?i:null}function yf(e,i){throw i.$$typeof===g?Error(a(525)):(e=Object.prototype.toString.call(i),Error(a(31,e==="[object Object]"?"object with keys {"+Object.keys(i).join(", ")+"}":e)))}function Uv(e){function i($,Z){if(e){var rt=$.deletions;rt===null?($.deletions=[Z],$.flags|=16):rt.push(Z)}}function s($,Z){if(!e)return null;for(;Z!==null;)i($,Z),Z=Z.sibling;return null}function u($){for(var Z=new Map;$!==null;)$.key!==null?Z.set($.key,$):Z.set($.index,$),$=$.sibling;return Z}function h($,Z){return $=Ar($,Z),$.index=0,$.sibling=null,$}function m($,Z,rt){return $.index=rt,e?(rt=$.alternate,rt!==null?(rt=rt.index,rt<Z?($.flags|=67108866,Z):rt):($.flags|=67108866,Z)):($.flags|=1048576,Z)}function b($){return e&&$.alternate===null&&($.flags|=67108866),$}function N($,Z,rt,St){return Z===null||Z.tag!==6?(Z=tp(rt,$.mode,St),Z.return=$,Z):(Z=h(Z,rt),Z.return=$,Z)}function X($,Z,rt,St){var ue=rt.type;return ue===E?yt($,Z,rt.props.children,St,rt.key):Z!==null&&(Z.elementType===ue||typeof ue=="object"&&ue!==null&&ue.$$typeof===T&&oo(ue)===Z.type)?(Z=h(Z,rt.props),wu(Z,rt),Z.return=$,Z):(Z=hf(rt.type,rt.key,rt.props,null,$.mode,St),wu(Z,rt),Z.return=$,Z)}function ot($,Z,rt,St){return Z===null||Z.tag!==4||Z.stateNode.containerInfo!==rt.containerInfo||Z.stateNode.implementation!==rt.implementation?(Z=ep(rt,$.mode,St),Z.return=$,Z):(Z=h(Z,rt.children||[]),Z.return=$,Z)}function yt($,Z,rt,St,ue){return Z===null||Z.tag!==7?(Z=no(rt,$.mode,St,ue),Z.return=$,Z):(Z=h(Z,rt),Z.return=$,Z)}function Mt($,Z,rt){if(typeof Z=="string"&&Z!==""||typeof Z=="number"||typeof Z=="bigint")return Z=tp(""+Z,$.mode,rt),Z.return=$,Z;if(typeof Z=="object"&&Z!==null){switch(Z.$$typeof){case x:return rt=hf(Z.type,Z.key,Z.props,null,$.mode,rt),wu(rt,Z),rt.return=$,rt;case M:return Z=ep(Z,$.mode,rt),Z.return=$,Z;case T:return Z=oo(Z),Mt($,Z,rt)}if(Q(Z)||k(Z))return Z=no(Z,$.mode,rt,null),Z.return=$,Z;if(typeof Z.then=="function")return Mt($,xf(Z),rt);if(Z.$$typeof===U)return Mt($,mf($,Z),rt);yf($,Z)}return null}function ct($,Z,rt,St){var ue=Z!==null?Z.key:null;if(typeof rt=="string"&&rt!==""||typeof rt=="number"||typeof rt=="bigint")return ue!==null?null:N($,Z,""+rt,St);if(typeof rt=="object"&&rt!==null){switch(rt.$$typeof){case x:return rt.key===ue?X($,Z,rt,St):null;case M:return rt.key===ue?ot($,Z,rt,St):null;case T:return rt=oo(rt),ct($,Z,rt,St)}if(Q(rt)||k(rt))return ue!==null?null:yt($,Z,rt,St,null);if(typeof rt.then=="function")return ct($,Z,xf(rt),St);if(rt.$$typeof===U)return ct($,Z,mf($,rt),St);yf($,rt)}return null}function pt($,Z,rt,St,ue){if(typeof St=="string"&&St!==""||typeof St=="number"||typeof St=="bigint")return $=$.get(rt)||null,N(Z,$,""+St,ue);if(typeof St=="object"&&St!==null){switch(St.$$typeof){case x:return $=$.get(St.key===null?rt:St.key)||null,X(Z,$,St,ue);case M:return $=$.get(St.key===null?rt:St.key)||null,ot(Z,$,St,ue);case T:return St=oo(St),pt($,Z,rt,St,ue)}if(Q(St)||k(St))return $=$.get(rt)||null,yt(Z,$,St,ue,null);if(typeof St.then=="function")return pt($,Z,rt,xf(St),ue);if(St.$$typeof===U)return pt($,Z,rt,mf(Z,St),ue);yf(Z,St)}return null}function $t($,Z,rt,St){for(var ue=null,Ze=null,ae=Z,Ce=Z=0,He=null;ae!==null&&Ce<rt.length;Ce++){ae.index>Ce?(He=ae,ae=null):He=ae.sibling;var Ke=ct($,ae,rt[Ce],St);if(Ke===null){ae===null&&(ae=He);break}e&&ae&&Ke.alternate===null&&i($,ae),Z=m(Ke,Z,Ce),Ze===null?ue=Ke:Ze.sibling=Ke,Ze=Ke,ae=He}if(Ce===rt.length)return s($,ae),Ve&&Rr($,Ce),ue;if(ae===null){for(;Ce<rt.length;Ce++)ae=Mt($,rt[Ce],St),ae!==null&&(Z=m(ae,Z,Ce),Ze===null?ue=ae:Ze.sibling=ae,Ze=ae);return Ve&&Rr($,Ce),ue}for(ae=u(ae);Ce<rt.length;Ce++)He=pt(ae,$,Ce,rt[Ce],St),He!==null&&(e&&He.alternate!==null&&ae.delete(He.key===null?Ce:He.key),Z=m(He,Z,Ce),Ze===null?ue=He:Ze.sibling=He,Ze=He);return e&&ae.forEach(function(Cs){return i($,Cs)}),Ve&&Rr($,Ce),ue}function fe($,Z,rt,St){if(rt==null)throw Error(a(151));for(var ue=null,Ze=null,ae=Z,Ce=Z=0,He=null,Ke=rt.next();ae!==null&&!Ke.done;Ce++,Ke=rt.next()){ae.index>Ce?(He=ae,ae=null):He=ae.sibling;var Cs=ct($,ae,Ke.value,St);if(Cs===null){ae===null&&(ae=He);break}e&&ae&&Cs.alternate===null&&i($,ae),Z=m(Cs,Z,Ce),Ze===null?ue=Cs:Ze.sibling=Cs,Ze=Cs,ae=He}if(Ke.done)return s($,ae),Ve&&Rr($,Ce),ue;if(ae===null){for(;!Ke.done;Ce++,Ke=rt.next())Ke=Mt($,Ke.value,St),Ke!==null&&(Z=m(Ke,Z,Ce),Ze===null?ue=Ke:Ze.sibling=Ke,Ze=Ke);return Ve&&Rr($,Ce),ue}for(ae=u(ae);!Ke.done;Ce++,Ke=rt.next())Ke=pt(ae,$,Ce,Ke.value,St),Ke!==null&&(e&&Ke.alternate!==null&&ae.delete(Ke.key===null?Ce:Ke.key),Z=m(Ke,Z,Ce),Ze===null?ue=Ke:Ze.sibling=Ke,Ze=Ke);return e&&ae.forEach(function(xA){return i($,xA)}),Ve&&Rr($,Ce),ue}function cn($,Z,rt,St){if(typeof rt=="object"&&rt!==null&&rt.type===E&&rt.key===null&&(rt=rt.props.children),typeof rt=="object"&&rt!==null){switch(rt.$$typeof){case x:t:{for(var ue=rt.key;Z!==null;){if(Z.key===ue){if(ue=rt.type,ue===E){if(Z.tag===7){s($,Z.sibling),St=h(Z,rt.props.children),St.return=$,$=St;break t}}else if(Z.elementType===ue||typeof ue=="object"&&ue!==null&&ue.$$typeof===T&&oo(ue)===Z.type){s($,Z.sibling),St=h(Z,rt.props),wu(St,rt),St.return=$,$=St;break t}s($,Z);break}else i($,Z);Z=Z.sibling}rt.type===E?(St=no(rt.props.children,$.mode,St,rt.key),St.return=$,$=St):(St=hf(rt.type,rt.key,rt.props,null,$.mode,St),wu(St,rt),St.return=$,$=St)}return b($);case M:t:{for(ue=rt.key;Z!==null;){if(Z.key===ue)if(Z.tag===4&&Z.stateNode.containerInfo===rt.containerInfo&&Z.stateNode.implementation===rt.implementation){s($,Z.sibling),St=h(Z,rt.children||[]),St.return=$,$=St;break t}else{s($,Z);break}else i($,Z);Z=Z.sibling}St=ep(rt,$.mode,St),St.return=$,$=St}return b($);case T:return rt=oo(rt),cn($,Z,rt,St)}if(Q(rt))return $t($,Z,rt,St);if(k(rt)){if(ue=k(rt),typeof ue!="function")throw Error(a(150));return rt=ue.call(rt),fe($,Z,rt,St)}if(typeof rt.then=="function")return cn($,Z,xf(rt),St);if(rt.$$typeof===U)return cn($,Z,mf($,rt),St);yf($,rt)}return typeof rt=="string"&&rt!==""||typeof rt=="number"||typeof rt=="bigint"?(rt=""+rt,Z!==null&&Z.tag===6?(s($,Z.sibling),St=h(Z,rt),St.return=$,$=St):(s($,Z),St=tp(rt,$.mode,St),St.return=$,$=St),b($)):s($,Z)}return function($,Z,rt,St){try{Cu=0;var ue=cn($,Z,rt,St);return ol=null,ue}catch(ae){if(ae===sl||ae===gf)throw ae;var Ze=na(29,ae,null,$.mode);return Ze.lanes=St,Ze.return=$,Ze}finally{}}}var uo=Uv(!0),Nv=Uv(!1),fs=!1;function dp(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function pp(e,i){e=e.updateQueue,i.updateQueue===e&&(i.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function hs(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function ds(e,i,s){var u=e.updateQueue;if(u===null)return null;if(u=u.shared,(Je&2)!==0){var h=u.pending;return h===null?i.next=i:(i.next=h.next,h.next=i),u.pending=i,i=ff(e),mv(e,null,s),i}return cf(e,u,i,s),ff(e)}function Du(e,i,s){if(i=i.updateQueue,i!==null&&(i=i.shared,(s&4194048)!==0)){var u=i.lanes;u&=e.pendingLanes,s|=u,i.lanes=s,he(e,s)}}function mp(e,i){var s=e.updateQueue,u=e.alternate;if(u!==null&&(u=u.updateQueue,s===u)){var h=null,m=null;if(s=s.firstBaseUpdate,s!==null){do{var b={lane:s.lane,tag:s.tag,payload:s.payload,callback:null,next:null};m===null?h=m=b:m=m.next=b,s=s.next}while(s!==null);m===null?h=m=i:m=m.next=i}else h=m=i;s={baseState:u.baseState,firstBaseUpdate:h,lastBaseUpdate:m,shared:u.shared,callbacks:u.callbacks},e.updateQueue=s;return}e=s.lastBaseUpdate,e===null?s.firstBaseUpdate=i:e.next=i,s.lastBaseUpdate=i}var _p=!1;function Uu(){if(_p){var e=rl;if(e!==null)throw e}}function Nu(e,i,s,u){_p=!1;var h=e.updateQueue;fs=!1;var m=h.firstBaseUpdate,b=h.lastBaseUpdate,N=h.shared.pending;if(N!==null){h.shared.pending=null;var X=N,ot=X.next;X.next=null,b===null?m=ot:b.next=ot,b=X;var yt=e.alternate;yt!==null&&(yt=yt.updateQueue,N=yt.lastBaseUpdate,N!==b&&(N===null?yt.firstBaseUpdate=ot:N.next=ot,yt.lastBaseUpdate=X))}if(m!==null){var Mt=h.baseState;b=0,yt=ot=X=null,N=m;do{var ct=N.lane&-536870913,pt=ct!==N.lane;if(pt?(Be&ct)===ct:(u&ct)===ct){ct!==0&&ct===al&&(_p=!0),yt!==null&&(yt=yt.next={lane:0,tag:N.tag,payload:N.payload,callback:null,next:null});t:{var $t=e,fe=N;ct=i;var cn=s;switch(fe.tag){case 1:if($t=fe.payload,typeof $t=="function"){Mt=$t.call(cn,Mt,ct);break t}Mt=$t;break t;case 3:$t.flags=$t.flags&-65537|128;case 0:if($t=fe.payload,ct=typeof $t=="function"?$t.call(cn,Mt,ct):$t,ct==null)break t;Mt=v({},Mt,ct);break t;case 2:fs=!0}}ct=N.callback,ct!==null&&(e.flags|=64,pt&&(e.flags|=8192),pt=h.callbacks,pt===null?h.callbacks=[ct]:pt.push(ct))}else pt={lane:ct,tag:N.tag,payload:N.payload,callback:N.callback,next:null},yt===null?(ot=yt=pt,X=Mt):yt=yt.next=pt,b|=ct;if(N=N.next,N===null){if(N=h.shared.pending,N===null)break;pt=N,N=pt.next,pt.next=null,h.lastBaseUpdate=pt,h.shared.pending=null}}while(!0);yt===null&&(X=Mt),h.baseState=X,h.firstBaseUpdate=ot,h.lastBaseUpdate=yt,m===null&&(h.shared.lanes=0),vs|=b,e.lanes=b,e.memoizedState=Mt}}function Lv(e,i){if(typeof e!="function")throw Error(a(191,e));e.call(i)}function Ov(e,i){var s=e.callbacks;if(s!==null)for(e.callbacks=null,e=0;e<s.length;e++)Lv(s[e],i)}var ll=z(null),Sf=z(0);function Pv(e,i){e=Ir,xt(Sf,e),xt(ll,i),Ir=e|i.baseLanes}function gp(){xt(Sf,Ir),xt(ll,ll.current)}function vp(){Ir=Sf.current,K(ll),K(Sf)}var ia=z(null),Ra=null;function ps(e){var i=e.alternate;xt(Nn,Nn.current&1),xt(ia,e),Ra===null&&(i===null||ll.current!==null||i.memoizedState!==null)&&(Ra=e)}function xp(e){xt(Nn,Nn.current),xt(ia,e),Ra===null&&(Ra=e)}function Fv(e){e.tag===22?(xt(Nn,Nn.current),xt(ia,e),Ra===null&&(Ra=e)):ms()}function ms(){xt(Nn,Nn.current),xt(ia,ia.current)}function aa(e){K(ia),Ra===e&&(Ra=null),K(Nn)}var Nn=z(0);function Mf(e){for(var i=e;i!==null;){if(i.tag===13){var s=i.memoizedState;if(s!==null&&(s=s.dehydrated,s===null||Tm(s)||Am(s)))return i}else if(i.tag===19&&(i.memoizedProps.revealOrder==="forwards"||i.memoizedProps.revealOrder==="backwards"||i.memoizedProps.revealOrder==="unstable_legacy-backwards"||i.memoizedProps.revealOrder==="together")){if((i.flags&128)!==0)return i}else if(i.child!==null){i.child.return=i,i=i.child;continue}if(i===e)break;for(;i.sibling===null;){if(i.return===null||i.return===e)return null;i=i.return}i.sibling.return=i.return,i=i.sibling}return null}var Dr=0,Ae=null,ln=null,Vn=null,Ef=!1,ul=!1,co=!1,bf=0,Lu=0,cl=null,uT=0;function wn(){throw Error(a(321))}function yp(e,i){if(i===null)return!1;for(var s=0;s<i.length&&s<e.length;s++)if(!ea(e[s],i[s]))return!1;return!0}function Sp(e,i,s,u,h,m){return Dr=m,Ae=i,i.memoizedState=null,i.updateQueue=null,i.lanes=0,F.H=e===null||e.memoizedState===null?xx:Fp,co=!1,m=s(u,h),co=!1,ul&&(m=Iv(i,s,u,h)),zv(e),m}function zv(e){F.H=Fu;var i=ln!==null&&ln.next!==null;if(Dr=0,Vn=ln=Ae=null,Ef=!1,Lu=0,cl=null,i)throw Error(a(300));e===null||kn||(e=e.dependencies,e!==null&&pf(e)&&(kn=!0))}function Iv(e,i,s,u){Ae=e;var h=0;do{if(ul&&(cl=null),Lu=0,ul=!1,25<=h)throw Error(a(301));if(h+=1,Vn=ln=null,e.updateQueue!=null){var m=e.updateQueue;m.lastEffect=null,m.events=null,m.stores=null,m.memoCache!=null&&(m.memoCache.index=0)}F.H=yx,m=i(s,u)}while(ul);return m}function cT(){var e=F.H,i=e.useState()[0];return i=typeof i.then=="function"?Ou(i):i,e=e.useState()[0],(ln!==null?ln.memoizedState:null)!==e&&(Ae.flags|=1024),i}function Mp(){var e=bf!==0;return bf=0,e}function Ep(e,i,s){i.updateQueue=e.updateQueue,i.flags&=-2053,e.lanes&=~s}function bp(e){if(Ef){for(e=e.memoizedState;e!==null;){var i=e.queue;i!==null&&(i.pending=null),e=e.next}Ef=!1}Dr=0,Vn=ln=Ae=null,ul=!1,Lu=bf=0,cl=null}function Ci(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Vn===null?Ae.memoizedState=Vn=e:Vn=Vn.next=e,Vn}function Ln(){if(ln===null){var e=Ae.alternate;e=e!==null?e.memoizedState:null}else e=ln.next;var i=Vn===null?Ae.memoizedState:Vn.next;if(i!==null)Vn=i,ln=e;else{if(e===null)throw Ae.alternate===null?Error(a(467)):Error(a(310));ln=e,e={memoizedState:ln.memoizedState,baseState:ln.baseState,baseQueue:ln.baseQueue,queue:ln.queue,next:null},Vn===null?Ae.memoizedState=Vn=e:Vn=Vn.next=e}return Vn}function Tf(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Ou(e){var i=Lu;return Lu+=1,cl===null&&(cl=[]),e=Cv(cl,e,i),i=Ae,(Vn===null?i.memoizedState:Vn.next)===null&&(i=i.alternate,F.H=i===null||i.memoizedState===null?xx:Fp),e}function Af(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return Ou(e);if(e.$$typeof===U)return oi(e)}throw Error(a(438,String(e)))}function Tp(e){var i=null,s=Ae.updateQueue;if(s!==null&&(i=s.memoCache),i==null){var u=Ae.alternate;u!==null&&(u=u.updateQueue,u!==null&&(u=u.memoCache,u!=null&&(i={data:u.data.map(function(h){return h.slice()}),index:0})))}if(i==null&&(i={data:[],index:0}),s===null&&(s=Tf(),Ae.updateQueue=s),s.memoCache=i,s=i.data[i.index],s===void 0)for(s=i.data[i.index]=Array(e),u=0;u<e;u++)s[u]=q;return i.index++,s}function Ur(e,i){return typeof i=="function"?i(e):i}function Rf(e){var i=Ln();return Ap(i,ln,e)}function Ap(e,i,s){var u=e.queue;if(u===null)throw Error(a(311));u.lastRenderedReducer=s;var h=e.baseQueue,m=u.pending;if(m!==null){if(h!==null){var b=h.next;h.next=m.next,m.next=b}i.baseQueue=h=m,u.pending=null}if(m=e.baseState,h===null)e.memoizedState=m;else{i=h.next;var N=b=null,X=null,ot=i,yt=!1;do{var Mt=ot.lane&-536870913;if(Mt!==ot.lane?(Be&Mt)===Mt:(Dr&Mt)===Mt){var ct=ot.revertLane;if(ct===0)X!==null&&(X=X.next={lane:0,revertLane:0,gesture:null,action:ot.action,hasEagerState:ot.hasEagerState,eagerState:ot.eagerState,next:null}),Mt===al&&(yt=!0);else if((Dr&ct)===ct){ot=ot.next,ct===al&&(yt=!0);continue}else Mt={lane:0,revertLane:ot.revertLane,gesture:null,action:ot.action,hasEagerState:ot.hasEagerState,eagerState:ot.eagerState,next:null},X===null?(N=X=Mt,b=m):X=X.next=Mt,Ae.lanes|=ct,vs|=ct;Mt=ot.action,co&&s(m,Mt),m=ot.hasEagerState?ot.eagerState:s(m,Mt)}else ct={lane:Mt,revertLane:ot.revertLane,gesture:ot.gesture,action:ot.action,hasEagerState:ot.hasEagerState,eagerState:ot.eagerState,next:null},X===null?(N=X=ct,b=m):X=X.next=ct,Ae.lanes|=Mt,vs|=Mt;ot=ot.next}while(ot!==null&&ot!==i);if(X===null?b=m:X.next=N,!ea(m,e.memoizedState)&&(kn=!0,yt&&(s=rl,s!==null)))throw s;e.memoizedState=m,e.baseState=b,e.baseQueue=X,u.lastRenderedState=m}return h===null&&(u.lanes=0),[e.memoizedState,u.dispatch]}function Rp(e){var i=Ln(),s=i.queue;if(s===null)throw Error(a(311));s.lastRenderedReducer=e;var u=s.dispatch,h=s.pending,m=i.memoizedState;if(h!==null){s.pending=null;var b=h=h.next;do m=e(m,b.action),b=b.next;while(b!==h);ea(m,i.memoizedState)||(kn=!0),i.memoizedState=m,i.baseQueue===null&&(i.baseState=m),s.lastRenderedState=m}return[m,u]}function Bv(e,i,s){var u=Ae,h=Ln(),m=Ve;if(m){if(s===void 0)throw Error(a(407));s=s()}else s=i();var b=!ea((ln||h).memoizedState,s);if(b&&(h.memoizedState=s,kn=!0),h=h.queue,Dp(Vv.bind(null,u,h,e),[e]),h.getSnapshot!==i||b||Vn!==null&&Vn.memoizedState.tag&1){if(u.flags|=2048,fl(9,{destroy:void 0},Gv.bind(null,u,h,s,i),null),hn===null)throw Error(a(349));m||(Dr&127)!==0||Hv(u,i,s)}return s}function Hv(e,i,s){e.flags|=16384,e={getSnapshot:i,value:s},i=Ae.updateQueue,i===null?(i=Tf(),Ae.updateQueue=i,i.stores=[e]):(s=i.stores,s===null?i.stores=[e]:s.push(e))}function Gv(e,i,s,u){i.value=s,i.getSnapshot=u,kv(i)&&Xv(e)}function Vv(e,i,s){return s(function(){kv(i)&&Xv(e)})}function kv(e){var i=e.getSnapshot;e=e.value;try{var s=i();return!ea(e,s)}catch{return!0}}function Xv(e){var i=eo(e,2);i!==null&&ki(i,e,2)}function Cp(e){var i=Ci();if(typeof e=="function"){var s=e;if(e=s(),co){Ht(!0);try{s()}finally{Ht(!1)}}}return i.memoizedState=i.baseState=e,i.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ur,lastRenderedState:e},i}function Wv(e,i,s,u){return e.baseState=s,Ap(e,ln,typeof u=="function"?u:Ur)}function fT(e,i,s,u,h){if(Df(e))throw Error(a(485));if(e=i.action,e!==null){var m={payload:h,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(b){m.listeners.push(b)}};F.T!==null?s(!0):m.isTransition=!1,u(m),s=i.pending,s===null?(m.next=i.pending=m,Yv(i,m)):(m.next=s.next,i.pending=s.next=m)}}function Yv(e,i){var s=i.action,u=i.payload,h=e.state;if(i.isTransition){var m=F.T,b={};F.T=b;try{var N=s(h,u),X=F.S;X!==null&&X(b,N),qv(e,i,N)}catch(ot){wp(e,i,ot)}finally{m!==null&&b.types!==null&&(m.types=b.types),F.T=m}}else try{m=s(h,u),qv(e,i,m)}catch(ot){wp(e,i,ot)}}function qv(e,i,s){s!==null&&typeof s=="object"&&typeof s.then=="function"?s.then(function(u){jv(e,i,u)},function(u){return wp(e,i,u)}):jv(e,i,s)}function jv(e,i,s){i.status="fulfilled",i.value=s,Zv(i),e.state=s,i=e.pending,i!==null&&(s=i.next,s===i?e.pending=null:(s=s.next,i.next=s,Yv(e,s)))}function wp(e,i,s){var u=e.pending;if(e.pending=null,u!==null){u=u.next;do i.status="rejected",i.reason=s,Zv(i),i=i.next;while(i!==u)}e.action=null}function Zv(e){e=e.listeners;for(var i=0;i<e.length;i++)(0,e[i])()}function Kv(e,i){return i}function Qv(e,i){if(Ve){var s=hn.formState;if(s!==null){t:{var u=Ae;if(Ve){if(xn){e:{for(var h=xn,m=Aa;h.nodeType!==8;){if(!m){h=null;break e}if(h=Ca(h.nextSibling),h===null){h=null;break e}}m=h.data,h=m==="F!"||m==="F"?h:null}if(h){xn=Ca(h.nextSibling),u=h.data==="F!";break t}}us(u)}u=!1}u&&(i=s[0])}}return s=Ci(),s.memoizedState=s.baseState=i,u={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Kv,lastRenderedState:i},s.queue=u,s=_x.bind(null,Ae,u),u.dispatch=s,u=Cp(!1),m=Pp.bind(null,Ae,!1,u.queue),u=Ci(),h={state:i,dispatch:null,action:e,pending:null},u.queue=h,s=fT.bind(null,Ae,h,m,s),h.dispatch=s,u.memoizedState=e,[i,s,!1]}function Jv(e){var i=Ln();return $v(i,ln,e)}function $v(e,i,s){if(i=Ap(e,i,Kv)[0],e=Rf(Ur)[0],typeof i=="object"&&i!==null&&typeof i.then=="function")try{var u=Ou(i)}catch(b){throw b===sl?gf:b}else u=i;i=Ln();var h=i.queue,m=h.dispatch;return s!==i.memoizedState&&(Ae.flags|=2048,fl(9,{destroy:void 0},hT.bind(null,h,s),null)),[u,m,e]}function hT(e,i){e.action=i}function tx(e){var i=Ln(),s=ln;if(s!==null)return $v(i,s,e);Ln(),i=i.memoizedState,s=Ln();var u=s.queue.dispatch;return s.memoizedState=e,[i,u,!1]}function fl(e,i,s,u){return e={tag:e,create:s,deps:u,inst:i,next:null},i=Ae.updateQueue,i===null&&(i=Tf(),Ae.updateQueue=i),s=i.lastEffect,s===null?i.lastEffect=e.next=e:(u=s.next,s.next=e,e.next=u,i.lastEffect=e),e}function ex(){return Ln().memoizedState}function Cf(e,i,s,u){var h=Ci();Ae.flags|=e,h.memoizedState=fl(1|i,{destroy:void 0},s,u===void 0?null:u)}function wf(e,i,s,u){var h=Ln();u=u===void 0?null:u;var m=h.memoizedState.inst;ln!==null&&u!==null&&yp(u,ln.memoizedState.deps)?h.memoizedState=fl(i,m,s,u):(Ae.flags|=e,h.memoizedState=fl(1|i,m,s,u))}function nx(e,i){Cf(8390656,8,e,i)}function Dp(e,i){wf(2048,8,e,i)}function dT(e){Ae.flags|=4;var i=Ae.updateQueue;if(i===null)i=Tf(),Ae.updateQueue=i,i.events=[e];else{var s=i.events;s===null?i.events=[e]:s.push(e)}}function ix(e){var i=Ln().memoizedState;return dT({ref:i,nextImpl:e}),function(){if((Je&2)!==0)throw Error(a(440));return i.impl.apply(void 0,arguments)}}function ax(e,i){return wf(4,2,e,i)}function rx(e,i){return wf(4,4,e,i)}function sx(e,i){if(typeof i=="function"){e=e();var s=i(e);return function(){typeof s=="function"?s():i(null)}}if(i!=null)return e=e(),i.current=e,function(){i.current=null}}function ox(e,i,s){s=s!=null?s.concat([e]):null,wf(4,4,sx.bind(null,i,e),s)}function Up(){}function lx(e,i){var s=Ln();i=i===void 0?null:i;var u=s.memoizedState;return i!==null&&yp(i,u[1])?u[0]:(s.memoizedState=[e,i],e)}function ux(e,i){var s=Ln();i=i===void 0?null:i;var u=s.memoizedState;if(i!==null&&yp(i,u[1]))return u[0];if(u=e(),co){Ht(!0);try{e()}finally{Ht(!1)}}return s.memoizedState=[u,i],u}function Np(e,i,s){return s===void 0||(Dr&1073741824)!==0&&(Be&261930)===0?e.memoizedState=i:(e.memoizedState=s,e=cy(),Ae.lanes|=e,vs|=e,s)}function cx(e,i,s,u){return ea(s,i)?s:ll.current!==null?(e=Np(e,s,u),ea(e,i)||(kn=!0),e):(Dr&42)===0||(Dr&1073741824)!==0&&(Be&261930)===0?(kn=!0,e.memoizedState=s):(e=cy(),Ae.lanes|=e,vs|=e,i)}function fx(e,i,s,u,h){var m=I.p;I.p=m!==0&&8>m?m:8;var b=F.T,N={};F.T=N,Pp(e,!1,i,s);try{var X=h(),ot=F.S;if(ot!==null&&ot(N,X),X!==null&&typeof X=="object"&&typeof X.then=="function"){var yt=lT(X,u);Pu(e,i,yt,oa(e))}else Pu(e,i,u,oa(e))}catch(Mt){Pu(e,i,{then:function(){},status:"rejected",reason:Mt},oa())}finally{I.p=m,b!==null&&N.types!==null&&(b.types=N.types),F.T=b}}function pT(){}function Lp(e,i,s,u){if(e.tag!==5)throw Error(a(476));var h=hx(e).queue;fx(e,h,i,it,s===null?pT:function(){return dx(e),s(u)})}function hx(e){var i=e.memoizedState;if(i!==null)return i;i={memoizedState:it,baseState:it,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ur,lastRenderedState:it},next:null};var s={};return i.next={memoizedState:s,baseState:s,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ur,lastRenderedState:s},next:null},e.memoizedState=i,e=e.alternate,e!==null&&(e.memoizedState=i),i}function dx(e){var i=hx(e);i.next===null&&(i=e.alternate.memoizedState),Pu(e,i.next.queue,{},oa())}function Op(){return oi(Ju)}function px(){return Ln().memoizedState}function mx(){return Ln().memoizedState}function mT(e){for(var i=e.return;i!==null;){switch(i.tag){case 24:case 3:var s=oa();e=hs(s);var u=ds(i,e,s);u!==null&&(ki(u,i,s),Du(u,i,s)),i={cache:up()},e.payload=i;return}i=i.return}}function _T(e,i,s){var u=oa();s={lane:u,revertLane:0,gesture:null,action:s,hasEagerState:!1,eagerState:null,next:null},Df(e)?gx(i,s):(s=Jd(e,i,s,u),s!==null&&(ki(s,e,u),vx(s,i,u)))}function _x(e,i,s){var u=oa();Pu(e,i,s,u)}function Pu(e,i,s,u){var h={lane:u,revertLane:0,gesture:null,action:s,hasEagerState:!1,eagerState:null,next:null};if(Df(e))gx(i,h);else{var m=e.alternate;if(e.lanes===0&&(m===null||m.lanes===0)&&(m=i.lastRenderedReducer,m!==null))try{var b=i.lastRenderedState,N=m(b,s);if(h.hasEagerState=!0,h.eagerState=N,ea(N,b))return cf(e,i,h,0),hn===null&&uf(),!1}catch{}finally{}if(s=Jd(e,i,h,u),s!==null)return ki(s,e,u),vx(s,i,u),!0}return!1}function Pp(e,i,s,u){if(u={lane:2,revertLane:dm(),gesture:null,action:u,hasEagerState:!1,eagerState:null,next:null},Df(e)){if(i)throw Error(a(479))}else i=Jd(e,s,u,2),i!==null&&ki(i,e,2)}function Df(e){var i=e.alternate;return e===Ae||i!==null&&i===Ae}function gx(e,i){ul=Ef=!0;var s=e.pending;s===null?i.next=i:(i.next=s.next,s.next=i),e.pending=i}function vx(e,i,s){if((s&4194048)!==0){var u=i.lanes;u&=e.pendingLanes,s|=u,i.lanes=s,he(e,s)}}var Fu={readContext:oi,use:Af,useCallback:wn,useContext:wn,useEffect:wn,useImperativeHandle:wn,useLayoutEffect:wn,useInsertionEffect:wn,useMemo:wn,useReducer:wn,useRef:wn,useState:wn,useDebugValue:wn,useDeferredValue:wn,useTransition:wn,useSyncExternalStore:wn,useId:wn,useHostTransitionStatus:wn,useFormState:wn,useActionState:wn,useOptimistic:wn,useMemoCache:wn,useCacheRefresh:wn};Fu.useEffectEvent=wn;var xx={readContext:oi,use:Af,useCallback:function(e,i){return Ci().memoizedState=[e,i===void 0?null:i],e},useContext:oi,useEffect:nx,useImperativeHandle:function(e,i,s){s=s!=null?s.concat([e]):null,Cf(4194308,4,sx.bind(null,i,e),s)},useLayoutEffect:function(e,i){return Cf(4194308,4,e,i)},useInsertionEffect:function(e,i){Cf(4,2,e,i)},useMemo:function(e,i){var s=Ci();i=i===void 0?null:i;var u=e();if(co){Ht(!0);try{e()}finally{Ht(!1)}}return s.memoizedState=[u,i],u},useReducer:function(e,i,s){var u=Ci();if(s!==void 0){var h=s(i);if(co){Ht(!0);try{s(i)}finally{Ht(!1)}}}else h=i;return u.memoizedState=u.baseState=h,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:h},u.queue=e,e=e.dispatch=_T.bind(null,Ae,e),[u.memoizedState,e]},useRef:function(e){var i=Ci();return e={current:e},i.memoizedState=e},useState:function(e){e=Cp(e);var i=e.queue,s=_x.bind(null,Ae,i);return i.dispatch=s,[e.memoizedState,s]},useDebugValue:Up,useDeferredValue:function(e,i){var s=Ci();return Np(s,e,i)},useTransition:function(){var e=Cp(!1);return e=fx.bind(null,Ae,e.queue,!0,!1),Ci().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,i,s){var u=Ae,h=Ci();if(Ve){if(s===void 0)throw Error(a(407));s=s()}else{if(s=i(),hn===null)throw Error(a(349));(Be&127)!==0||Hv(u,i,s)}h.memoizedState=s;var m={value:s,getSnapshot:i};return h.queue=m,nx(Vv.bind(null,u,m,e),[e]),u.flags|=2048,fl(9,{destroy:void 0},Gv.bind(null,u,m,s,i),null),s},useId:function(){var e=Ci(),i=hn.identifierPrefix;if(Ve){var s=nr,u=er;s=(u&~(1<<32-Pt(u)-1)).toString(32)+s,i="_"+i+"R_"+s,s=bf++,0<s&&(i+="H"+s.toString(32)),i+="_"}else s=uT++,i="_"+i+"r_"+s.toString(32)+"_";return e.memoizedState=i},useHostTransitionStatus:Op,useFormState:Qv,useActionState:Qv,useOptimistic:function(e){var i=Ci();i.memoizedState=i.baseState=e;var s={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return i.queue=s,i=Pp.bind(null,Ae,!0,s),s.dispatch=i,[e,i]},useMemoCache:Tp,useCacheRefresh:function(){return Ci().memoizedState=mT.bind(null,Ae)},useEffectEvent:function(e){var i=Ci(),s={impl:e};return i.memoizedState=s,function(){if((Je&2)!==0)throw Error(a(440));return s.impl.apply(void 0,arguments)}}},Fp={readContext:oi,use:Af,useCallback:lx,useContext:oi,useEffect:Dp,useImperativeHandle:ox,useInsertionEffect:ax,useLayoutEffect:rx,useMemo:ux,useReducer:Rf,useRef:ex,useState:function(){return Rf(Ur)},useDebugValue:Up,useDeferredValue:function(e,i){var s=Ln();return cx(s,ln.memoizedState,e,i)},useTransition:function(){var e=Rf(Ur)[0],i=Ln().memoizedState;return[typeof e=="boolean"?e:Ou(e),i]},useSyncExternalStore:Bv,useId:px,useHostTransitionStatus:Op,useFormState:Jv,useActionState:Jv,useOptimistic:function(e,i){var s=Ln();return Wv(s,ln,e,i)},useMemoCache:Tp,useCacheRefresh:mx};Fp.useEffectEvent=ix;var yx={readContext:oi,use:Af,useCallback:lx,useContext:oi,useEffect:Dp,useImperativeHandle:ox,useInsertionEffect:ax,useLayoutEffect:rx,useMemo:ux,useReducer:Rp,useRef:ex,useState:function(){return Rp(Ur)},useDebugValue:Up,useDeferredValue:function(e,i){var s=Ln();return ln===null?Np(s,e,i):cx(s,ln.memoizedState,e,i)},useTransition:function(){var e=Rp(Ur)[0],i=Ln().memoizedState;return[typeof e=="boolean"?e:Ou(e),i]},useSyncExternalStore:Bv,useId:px,useHostTransitionStatus:Op,useFormState:tx,useActionState:tx,useOptimistic:function(e,i){var s=Ln();return ln!==null?Wv(s,ln,e,i):(s.baseState=e,[e,s.queue.dispatch])},useMemoCache:Tp,useCacheRefresh:mx};yx.useEffectEvent=ix;function zp(e,i,s,u){i=e.memoizedState,s=s(u,i),s=s==null?i:v({},i,s),e.memoizedState=s,e.lanes===0&&(e.updateQueue.baseState=s)}var Ip={enqueueSetState:function(e,i,s){e=e._reactInternals;var u=oa(),h=hs(u);h.payload=i,s!=null&&(h.callback=s),i=ds(e,h,u),i!==null&&(ki(i,e,u),Du(i,e,u))},enqueueReplaceState:function(e,i,s){e=e._reactInternals;var u=oa(),h=hs(u);h.tag=1,h.payload=i,s!=null&&(h.callback=s),i=ds(e,h,u),i!==null&&(ki(i,e,u),Du(i,e,u))},enqueueForceUpdate:function(e,i){e=e._reactInternals;var s=oa(),u=hs(s);u.tag=2,i!=null&&(u.callback=i),i=ds(e,u,s),i!==null&&(ki(i,e,s),Du(i,e,s))}};function Sx(e,i,s,u,h,m,b){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(u,m,b):i.prototype&&i.prototype.isPureReactComponent?!Mu(s,u)||!Mu(h,m):!0}function Mx(e,i,s,u){e=i.state,typeof i.componentWillReceiveProps=="function"&&i.componentWillReceiveProps(s,u),typeof i.UNSAFE_componentWillReceiveProps=="function"&&i.UNSAFE_componentWillReceiveProps(s,u),i.state!==e&&Ip.enqueueReplaceState(i,i.state,null)}function fo(e,i){var s=i;if("ref"in i){s={};for(var u in i)u!=="ref"&&(s[u]=i[u])}if(e=e.defaultProps){s===i&&(s=v({},s));for(var h in e)s[h]===void 0&&(s[h]=e[h])}return s}function Ex(e){lf(e)}function bx(e){console.error(e)}function Tx(e){lf(e)}function Uf(e,i){try{var s=e.onUncaughtError;s(i.value,{componentStack:i.stack})}catch(u){setTimeout(function(){throw u})}}function Ax(e,i,s){try{var u=e.onCaughtError;u(s.value,{componentStack:s.stack,errorBoundary:i.tag===1?i.stateNode:null})}catch(h){setTimeout(function(){throw h})}}function Bp(e,i,s){return s=hs(s),s.tag=3,s.payload={element:null},s.callback=function(){Uf(e,i)},s}function Rx(e){return e=hs(e),e.tag=3,e}function Cx(e,i,s,u){var h=s.type.getDerivedStateFromError;if(typeof h=="function"){var m=u.value;e.payload=function(){return h(m)},e.callback=function(){Ax(i,s,u)}}var b=s.stateNode;b!==null&&typeof b.componentDidCatch=="function"&&(e.callback=function(){Ax(i,s,u),typeof h!="function"&&(xs===null?xs=new Set([this]):xs.add(this));var N=u.stack;this.componentDidCatch(u.value,{componentStack:N!==null?N:""})})}function gT(e,i,s,u,h){if(s.flags|=32768,u!==null&&typeof u=="object"&&typeof u.then=="function"){if(i=s.alternate,i!==null&&il(i,s,h,!0),s=ia.current,s!==null){switch(s.tag){case 31:case 13:return Ra===null?kf():s.alternate===null&&Dn===0&&(Dn=3),s.flags&=-257,s.flags|=65536,s.lanes=h,u===vf?s.flags|=16384:(i=s.updateQueue,i===null?s.updateQueue=new Set([u]):i.add(u),cm(e,u,h)),!1;case 22:return s.flags|=65536,u===vf?s.flags|=16384:(i=s.updateQueue,i===null?(i={transitions:null,markerInstances:null,retryQueue:new Set([u])},s.updateQueue=i):(s=i.retryQueue,s===null?i.retryQueue=new Set([u]):s.add(u)),cm(e,u,h)),!1}throw Error(a(435,s.tag))}return cm(e,u,h),kf(),!1}if(Ve)return i=ia.current,i!==null?((i.flags&65536)===0&&(i.flags|=256),i.flags|=65536,i.lanes=h,u!==ap&&(e=Error(a(422),{cause:u}),Tu(Ea(e,s)))):(u!==ap&&(i=Error(a(423),{cause:u}),Tu(Ea(i,s))),e=e.current.alternate,e.flags|=65536,h&=-h,e.lanes|=h,u=Ea(u,s),h=Bp(e.stateNode,u,h),mp(e,h),Dn!==4&&(Dn=2)),!1;var m=Error(a(520),{cause:u});if(m=Ea(m,s),Xu===null?Xu=[m]:Xu.push(m),Dn!==4&&(Dn=2),i===null)return!0;u=Ea(u,s),s=i;do{switch(s.tag){case 3:return s.flags|=65536,e=h&-h,s.lanes|=e,e=Bp(s.stateNode,u,e),mp(s,e),!1;case 1:if(i=s.type,m=s.stateNode,(s.flags&128)===0&&(typeof i.getDerivedStateFromError=="function"||m!==null&&typeof m.componentDidCatch=="function"&&(xs===null||!xs.has(m))))return s.flags|=65536,h&=-h,s.lanes|=h,h=Rx(h),Cx(h,e,s,u),mp(s,h),!1}s=s.return}while(s!==null);return!1}var Hp=Error(a(461)),kn=!1;function li(e,i,s,u){i.child=e===null?Nv(i,null,s,u):uo(i,e.child,s,u)}function wx(e,i,s,u,h){s=s.render;var m=i.ref;if("ref"in u){var b={};for(var N in u)N!=="ref"&&(b[N]=u[N])}else b=u;return ro(i),u=Sp(e,i,s,b,m,h),N=Mp(),e!==null&&!kn?(Ep(e,i,h),Nr(e,i,h)):(Ve&&N&&np(i),i.flags|=1,li(e,i,u,h),i.child)}function Dx(e,i,s,u,h){if(e===null){var m=s.type;return typeof m=="function"&&!$d(m)&&m.defaultProps===void 0&&s.compare===null?(i.tag=15,i.type=m,Ux(e,i,m,u,h)):(e=hf(s.type,null,u,i,i.mode,h),e.ref=i.ref,e.return=i,i.child=e)}if(m=e.child,!jp(e,h)){var b=m.memoizedProps;if(s=s.compare,s=s!==null?s:Mu,s(b,u)&&e.ref===i.ref)return Nr(e,i,h)}return i.flags|=1,e=Ar(m,u),e.ref=i.ref,e.return=i,i.child=e}function Ux(e,i,s,u,h){if(e!==null){var m=e.memoizedProps;if(Mu(m,u)&&e.ref===i.ref)if(kn=!1,i.pendingProps=u=m,jp(e,h))(e.flags&131072)!==0&&(kn=!0);else return i.lanes=e.lanes,Nr(e,i,h)}return Gp(e,i,s,u,h)}function Nx(e,i,s,u){var h=u.children,m=e!==null?e.memoizedState:null;if(e===null&&i.stateNode===null&&(i.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),u.mode==="hidden"){if((i.flags&128)!==0){if(m=m!==null?m.baseLanes|s:s,e!==null){for(u=i.child=e.child,h=0;u!==null;)h=h|u.lanes|u.childLanes,u=u.sibling;u=h&~m}else u=0,i.child=null;return Lx(e,i,m,s,u)}if((s&536870912)!==0)i.memoizedState={baseLanes:0,cachePool:null},e!==null&&_f(i,m!==null?m.cachePool:null),m!==null?Pv(i,m):gp(),Fv(i);else return u=i.lanes=536870912,Lx(e,i,m!==null?m.baseLanes|s:s,s,u)}else m!==null?(_f(i,m.cachePool),Pv(i,m),ms(),i.memoizedState=null):(e!==null&&_f(i,null),gp(),ms());return li(e,i,h,s),i.child}function zu(e,i){return e!==null&&e.tag===22||i.stateNode!==null||(i.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),i.sibling}function Lx(e,i,s,u,h){var m=fp();return m=m===null?null:{parent:Gn._currentValue,pool:m},i.memoizedState={baseLanes:s,cachePool:m},e!==null&&_f(i,null),gp(),Fv(i),e!==null&&il(e,i,u,!0),i.childLanes=h,null}function Nf(e,i){return i=Of({mode:i.mode,children:i.children},e.mode),i.ref=e.ref,e.child=i,i.return=e,i}function Ox(e,i,s){return uo(i,e.child,null,s),e=Nf(i,i.pendingProps),e.flags|=2,aa(i),i.memoizedState=null,e}function vT(e,i,s){var u=i.pendingProps,h=(i.flags&128)!==0;if(i.flags&=-129,e===null){if(Ve){if(u.mode==="hidden")return e=Nf(i,u),i.lanes=536870912,zu(null,e);if(xp(i),(e=xn)?(e=Yy(e,Aa),e=e!==null&&e.data==="&"?e:null,e!==null&&(i.memoizedState={dehydrated:e,treeContext:os!==null?{id:er,overflow:nr}:null,retryLane:536870912,hydrationErrors:null},s=gv(e),s.return=i,i.child=s,si=i,xn=null)):e=null,e===null)throw us(i);return i.lanes=536870912,null}return Nf(i,u)}var m=e.memoizedState;if(m!==null){var b=m.dehydrated;if(xp(i),h)if(i.flags&256)i.flags&=-257,i=Ox(e,i,s);else if(i.memoizedState!==null)i.child=e.child,i.flags|=128,i=null;else throw Error(a(558));else if(kn||il(e,i,s,!1),h=(s&e.childLanes)!==0,kn||h){if(u=hn,u!==null&&(b=oe(u,s),b!==0&&b!==m.retryLane))throw m.retryLane=b,eo(e,b),ki(u,e,b),Hp;kf(),i=Ox(e,i,s)}else e=m.treeContext,xn=Ca(b.nextSibling),si=i,Ve=!0,ls=null,Aa=!1,e!==null&&yv(i,e),i=Nf(i,u),i.flags|=4096;return i}return e=Ar(e.child,{mode:u.mode,children:u.children}),e.ref=i.ref,i.child=e,e.return=i,e}function Lf(e,i){var s=i.ref;if(s===null)e!==null&&e.ref!==null&&(i.flags|=4194816);else{if(typeof s!="function"&&typeof s!="object")throw Error(a(284));(e===null||e.ref!==s)&&(i.flags|=4194816)}}function Gp(e,i,s,u,h){return ro(i),s=Sp(e,i,s,u,void 0,h),u=Mp(),e!==null&&!kn?(Ep(e,i,h),Nr(e,i,h)):(Ve&&u&&np(i),i.flags|=1,li(e,i,s,h),i.child)}function Px(e,i,s,u,h,m){return ro(i),i.updateQueue=null,s=Iv(i,u,s,h),zv(e),u=Mp(),e!==null&&!kn?(Ep(e,i,m),Nr(e,i,m)):(Ve&&u&&np(i),i.flags|=1,li(e,i,s,m),i.child)}function Fx(e,i,s,u,h){if(ro(i),i.stateNode===null){var m=$o,b=s.contextType;typeof b=="object"&&b!==null&&(m=oi(b)),m=new s(u,m),i.memoizedState=m.state!==null&&m.state!==void 0?m.state:null,m.updater=Ip,i.stateNode=m,m._reactInternals=i,m=i.stateNode,m.props=u,m.state=i.memoizedState,m.refs={},dp(i),b=s.contextType,m.context=typeof b=="object"&&b!==null?oi(b):$o,m.state=i.memoizedState,b=s.getDerivedStateFromProps,typeof b=="function"&&(zp(i,s,b,u),m.state=i.memoizedState),typeof s.getDerivedStateFromProps=="function"||typeof m.getSnapshotBeforeUpdate=="function"||typeof m.UNSAFE_componentWillMount!="function"&&typeof m.componentWillMount!="function"||(b=m.state,typeof m.componentWillMount=="function"&&m.componentWillMount(),typeof m.UNSAFE_componentWillMount=="function"&&m.UNSAFE_componentWillMount(),b!==m.state&&Ip.enqueueReplaceState(m,m.state,null),Nu(i,u,m,h),Uu(),m.state=i.memoizedState),typeof m.componentDidMount=="function"&&(i.flags|=4194308),u=!0}else if(e===null){m=i.stateNode;var N=i.memoizedProps,X=fo(s,N);m.props=X;var ot=m.context,yt=s.contextType;b=$o,typeof yt=="object"&&yt!==null&&(b=oi(yt));var Mt=s.getDerivedStateFromProps;yt=typeof Mt=="function"||typeof m.getSnapshotBeforeUpdate=="function",N=i.pendingProps!==N,yt||typeof m.UNSAFE_componentWillReceiveProps!="function"&&typeof m.componentWillReceiveProps!="function"||(N||ot!==b)&&Mx(i,m,u,b),fs=!1;var ct=i.memoizedState;m.state=ct,Nu(i,u,m,h),Uu(),ot=i.memoizedState,N||ct!==ot||fs?(typeof Mt=="function"&&(zp(i,s,Mt,u),ot=i.memoizedState),(X=fs||Sx(i,s,X,u,ct,ot,b))?(yt||typeof m.UNSAFE_componentWillMount!="function"&&typeof m.componentWillMount!="function"||(typeof m.componentWillMount=="function"&&m.componentWillMount(),typeof m.UNSAFE_componentWillMount=="function"&&m.UNSAFE_componentWillMount()),typeof m.componentDidMount=="function"&&(i.flags|=4194308)):(typeof m.componentDidMount=="function"&&(i.flags|=4194308),i.memoizedProps=u,i.memoizedState=ot),m.props=u,m.state=ot,m.context=b,u=X):(typeof m.componentDidMount=="function"&&(i.flags|=4194308),u=!1)}else{m=i.stateNode,pp(e,i),b=i.memoizedProps,yt=fo(s,b),m.props=yt,Mt=i.pendingProps,ct=m.context,ot=s.contextType,X=$o,typeof ot=="object"&&ot!==null&&(X=oi(ot)),N=s.getDerivedStateFromProps,(ot=typeof N=="function"||typeof m.getSnapshotBeforeUpdate=="function")||typeof m.UNSAFE_componentWillReceiveProps!="function"&&typeof m.componentWillReceiveProps!="function"||(b!==Mt||ct!==X)&&Mx(i,m,u,X),fs=!1,ct=i.memoizedState,m.state=ct,Nu(i,u,m,h),Uu();var pt=i.memoizedState;b!==Mt||ct!==pt||fs||e!==null&&e.dependencies!==null&&pf(e.dependencies)?(typeof N=="function"&&(zp(i,s,N,u),pt=i.memoizedState),(yt=fs||Sx(i,s,yt,u,ct,pt,X)||e!==null&&e.dependencies!==null&&pf(e.dependencies))?(ot||typeof m.UNSAFE_componentWillUpdate!="function"&&typeof m.componentWillUpdate!="function"||(typeof m.componentWillUpdate=="function"&&m.componentWillUpdate(u,pt,X),typeof m.UNSAFE_componentWillUpdate=="function"&&m.UNSAFE_componentWillUpdate(u,pt,X)),typeof m.componentDidUpdate=="function"&&(i.flags|=4),typeof m.getSnapshotBeforeUpdate=="function"&&(i.flags|=1024)):(typeof m.componentDidUpdate!="function"||b===e.memoizedProps&&ct===e.memoizedState||(i.flags|=4),typeof m.getSnapshotBeforeUpdate!="function"||b===e.memoizedProps&&ct===e.memoizedState||(i.flags|=1024),i.memoizedProps=u,i.memoizedState=pt),m.props=u,m.state=pt,m.context=X,u=yt):(typeof m.componentDidUpdate!="function"||b===e.memoizedProps&&ct===e.memoizedState||(i.flags|=4),typeof m.getSnapshotBeforeUpdate!="function"||b===e.memoizedProps&&ct===e.memoizedState||(i.flags|=1024),u=!1)}return m=u,Lf(e,i),u=(i.flags&128)!==0,m||u?(m=i.stateNode,s=u&&typeof s.getDerivedStateFromError!="function"?null:m.render(),i.flags|=1,e!==null&&u?(i.child=uo(i,e.child,null,h),i.child=uo(i,null,s,h)):li(e,i,s,h),i.memoizedState=m.state,e=i.child):e=Nr(e,i,h),e}function zx(e,i,s,u){return io(),i.flags|=256,li(e,i,s,u),i.child}var Vp={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function kp(e){return{baseLanes:e,cachePool:Av()}}function Xp(e,i,s){return e=e!==null?e.childLanes&~s:0,i&&(e|=sa),e}function Ix(e,i,s){var u=i.pendingProps,h=!1,m=(i.flags&128)!==0,b;if((b=m)||(b=e!==null&&e.memoizedState===null?!1:(Nn.current&2)!==0),b&&(h=!0,i.flags&=-129),b=(i.flags&32)!==0,i.flags&=-33,e===null){if(Ve){if(h?ps(i):ms(),(e=xn)?(e=Yy(e,Aa),e=e!==null&&e.data!=="&"?e:null,e!==null&&(i.memoizedState={dehydrated:e,treeContext:os!==null?{id:er,overflow:nr}:null,retryLane:536870912,hydrationErrors:null},s=gv(e),s.return=i,i.child=s,si=i,xn=null)):e=null,e===null)throw us(i);return Am(e)?i.lanes=32:i.lanes=536870912,null}var N=u.children;return u=u.fallback,h?(ms(),h=i.mode,N=Of({mode:"hidden",children:N},h),u=no(u,h,s,null),N.return=i,u.return=i,N.sibling=u,i.child=N,u=i.child,u.memoizedState=kp(s),u.childLanes=Xp(e,b,s),i.memoizedState=Vp,zu(null,u)):(ps(i),Wp(i,N))}var X=e.memoizedState;if(X!==null&&(N=X.dehydrated,N!==null)){if(m)i.flags&256?(ps(i),i.flags&=-257,i=Yp(e,i,s)):i.memoizedState!==null?(ms(),i.child=e.child,i.flags|=128,i=null):(ms(),N=u.fallback,h=i.mode,u=Of({mode:"visible",children:u.children},h),N=no(N,h,s,null),N.flags|=2,u.return=i,N.return=i,u.sibling=N,i.child=u,uo(i,e.child,null,s),u=i.child,u.memoizedState=kp(s),u.childLanes=Xp(e,b,s),i.memoizedState=Vp,i=zu(null,u));else if(ps(i),Am(N)){if(b=N.nextSibling&&N.nextSibling.dataset,b)var ot=b.dgst;b=ot,u=Error(a(419)),u.stack="",u.digest=b,Tu({value:u,source:null,stack:null}),i=Yp(e,i,s)}else if(kn||il(e,i,s,!1),b=(s&e.childLanes)!==0,kn||b){if(b=hn,b!==null&&(u=oe(b,s),u!==0&&u!==X.retryLane))throw X.retryLane=u,eo(e,u),ki(b,e,u),Hp;Tm(N)||kf(),i=Yp(e,i,s)}else Tm(N)?(i.flags|=192,i.child=e.child,i=null):(e=X.treeContext,xn=Ca(N.nextSibling),si=i,Ve=!0,ls=null,Aa=!1,e!==null&&yv(i,e),i=Wp(i,u.children),i.flags|=4096);return i}return h?(ms(),N=u.fallback,h=i.mode,X=e.child,ot=X.sibling,u=Ar(X,{mode:"hidden",children:u.children}),u.subtreeFlags=X.subtreeFlags&65011712,ot!==null?N=Ar(ot,N):(N=no(N,h,s,null),N.flags|=2),N.return=i,u.return=i,u.sibling=N,i.child=u,zu(null,u),u=i.child,N=e.child.memoizedState,N===null?N=kp(s):(h=N.cachePool,h!==null?(X=Gn._currentValue,h=h.parent!==X?{parent:X,pool:X}:h):h=Av(),N={baseLanes:N.baseLanes|s,cachePool:h}),u.memoizedState=N,u.childLanes=Xp(e,b,s),i.memoizedState=Vp,zu(e.child,u)):(ps(i),s=e.child,e=s.sibling,s=Ar(s,{mode:"visible",children:u.children}),s.return=i,s.sibling=null,e!==null&&(b=i.deletions,b===null?(i.deletions=[e],i.flags|=16):b.push(e)),i.child=s,i.memoizedState=null,s)}function Wp(e,i){return i=Of({mode:"visible",children:i},e.mode),i.return=e,e.child=i}function Of(e,i){return e=na(22,e,null,i),e.lanes=0,e}function Yp(e,i,s){return uo(i,e.child,null,s),e=Wp(i,i.pendingProps.children),e.flags|=2,i.memoizedState=null,e}function Bx(e,i,s){e.lanes|=i;var u=e.alternate;u!==null&&(u.lanes|=i),op(e.return,i,s)}function qp(e,i,s,u,h,m){var b=e.memoizedState;b===null?e.memoizedState={isBackwards:i,rendering:null,renderingStartTime:0,last:u,tail:s,tailMode:h,treeForkCount:m}:(b.isBackwards=i,b.rendering=null,b.renderingStartTime=0,b.last=u,b.tail=s,b.tailMode=h,b.treeForkCount=m)}function Hx(e,i,s){var u=i.pendingProps,h=u.revealOrder,m=u.tail;u=u.children;var b=Nn.current,N=(b&2)!==0;if(N?(b=b&1|2,i.flags|=128):b&=1,xt(Nn,b),li(e,i,u,s),u=Ve?bu:0,!N&&e!==null&&(e.flags&128)!==0)t:for(e=i.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&Bx(e,s,i);else if(e.tag===19)Bx(e,s,i);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===i)break t;for(;e.sibling===null;){if(e.return===null||e.return===i)break t;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(h){case"forwards":for(s=i.child,h=null;s!==null;)e=s.alternate,e!==null&&Mf(e)===null&&(h=s),s=s.sibling;s=h,s===null?(h=i.child,i.child=null):(h=s.sibling,s.sibling=null),qp(i,!1,h,s,m,u);break;case"backwards":case"unstable_legacy-backwards":for(s=null,h=i.child,i.child=null;h!==null;){if(e=h.alternate,e!==null&&Mf(e)===null){i.child=h;break}e=h.sibling,h.sibling=s,s=h,h=e}qp(i,!0,s,null,m,u);break;case"together":qp(i,!1,null,null,void 0,u);break;default:i.memoizedState=null}return i.child}function Nr(e,i,s){if(e!==null&&(i.dependencies=e.dependencies),vs|=i.lanes,(s&i.childLanes)===0)if(e!==null){if(il(e,i,s,!1),(s&i.childLanes)===0)return null}else return null;if(e!==null&&i.child!==e.child)throw Error(a(153));if(i.child!==null){for(e=i.child,s=Ar(e,e.pendingProps),i.child=s,s.return=i;e.sibling!==null;)e=e.sibling,s=s.sibling=Ar(e,e.pendingProps),s.return=i;s.sibling=null}return i.child}function jp(e,i){return(e.lanes&i)!==0?!0:(e=e.dependencies,!!(e!==null&&pf(e)))}function xT(e,i,s){switch(i.tag){case 3:Et(i,i.stateNode.containerInfo),cs(i,Gn,e.memoizedState.cache),io();break;case 27:case 5:ee(i);break;case 4:Et(i,i.stateNode.containerInfo);break;case 10:cs(i,i.type,i.memoizedProps.value);break;case 31:if(i.memoizedState!==null)return i.flags|=128,xp(i),null;break;case 13:var u=i.memoizedState;if(u!==null)return u.dehydrated!==null?(ps(i),i.flags|=128,null):(s&i.child.childLanes)!==0?Ix(e,i,s):(ps(i),e=Nr(e,i,s),e!==null?e.sibling:null);ps(i);break;case 19:var h=(e.flags&128)!==0;if(u=(s&i.childLanes)!==0,u||(il(e,i,s,!1),u=(s&i.childLanes)!==0),h){if(u)return Hx(e,i,s);i.flags|=128}if(h=i.memoizedState,h!==null&&(h.rendering=null,h.tail=null,h.lastEffect=null),xt(Nn,Nn.current),u)break;return null;case 22:return i.lanes=0,Nx(e,i,s,i.pendingProps);case 24:cs(i,Gn,e.memoizedState.cache)}return Nr(e,i,s)}function Gx(e,i,s){if(e!==null)if(e.memoizedProps!==i.pendingProps)kn=!0;else{if(!jp(e,s)&&(i.flags&128)===0)return kn=!1,xT(e,i,s);kn=(e.flags&131072)!==0}else kn=!1,Ve&&(i.flags&1048576)!==0&&xv(i,bu,i.index);switch(i.lanes=0,i.tag){case 16:t:{var u=i.pendingProps;if(e=oo(i.elementType),i.type=e,typeof e=="function")$d(e)?(u=fo(e,u),i.tag=1,i=Fx(null,i,e,u,s)):(i.tag=0,i=Gp(null,i,e,u,s));else{if(e!=null){var h=e.$$typeof;if(h===C){i.tag=11,i=wx(null,i,e,u,s);break t}else if(h===L){i.tag=14,i=Dx(null,i,e,u,s);break t}}throw i=et(e)||e,Error(a(306,i,""))}}return i;case 0:return Gp(e,i,i.type,i.pendingProps,s);case 1:return u=i.type,h=fo(u,i.pendingProps),Fx(e,i,u,h,s);case 3:t:{if(Et(i,i.stateNode.containerInfo),e===null)throw Error(a(387));u=i.pendingProps;var m=i.memoizedState;h=m.element,pp(e,i),Nu(i,u,null,s);var b=i.memoizedState;if(u=b.cache,cs(i,Gn,u),u!==m.cache&&lp(i,[Gn],s,!0),Uu(),u=b.element,m.isDehydrated)if(m={element:u,isDehydrated:!1,cache:b.cache},i.updateQueue.baseState=m,i.memoizedState=m,i.flags&256){i=zx(e,i,u,s);break t}else if(u!==h){h=Ea(Error(a(424)),i),Tu(h),i=zx(e,i,u,s);break t}else{switch(e=i.stateNode.containerInfo,e.nodeType){case 9:e=e.body;break;default:e=e.nodeName==="HTML"?e.ownerDocument.body:e}for(xn=Ca(e.firstChild),si=i,Ve=!0,ls=null,Aa=!0,s=Nv(i,null,u,s),i.child=s;s;)s.flags=s.flags&-3|4096,s=s.sibling}else{if(io(),u===h){i=Nr(e,i,s);break t}li(e,i,u,s)}i=i.child}return i;case 26:return Lf(e,i),e===null?(s=Jy(i.type,null,i.pendingProps,null))?i.memoizedState=s:Ve||(s=i.type,e=i.pendingProps,u=Kf(nt.current).createElement(s),u[Te]=i,u[xe]=e,ui(u,s,e),Y(u),i.stateNode=u):i.memoizedState=Jy(i.type,e.memoizedProps,i.pendingProps,e.memoizedState),null;case 27:return ee(i),e===null&&Ve&&(u=i.stateNode=Zy(i.type,i.pendingProps,nt.current),si=i,Aa=!0,h=xn,Es(i.type)?(Rm=h,xn=Ca(u.firstChild)):xn=h),li(e,i,i.pendingProps.children,s),Lf(e,i),e===null&&(i.flags|=4194304),i.child;case 5:return e===null&&Ve&&((h=u=xn)&&(u=ZT(u,i.type,i.pendingProps,Aa),u!==null?(i.stateNode=u,si=i,xn=Ca(u.firstChild),Aa=!1,h=!0):h=!1),h||us(i)),ee(i),h=i.type,m=i.pendingProps,b=e!==null?e.memoizedProps:null,u=m.children,Mm(h,m)?u=null:b!==null&&Mm(h,b)&&(i.flags|=32),i.memoizedState!==null&&(h=Sp(e,i,cT,null,null,s),Ju._currentValue=h),Lf(e,i),li(e,i,u,s),i.child;case 6:return e===null&&Ve&&((e=s=xn)&&(s=KT(s,i.pendingProps,Aa),s!==null?(i.stateNode=s,si=i,xn=null,e=!0):e=!1),e||us(i)),null;case 13:return Ix(e,i,s);case 4:return Et(i,i.stateNode.containerInfo),u=i.pendingProps,e===null?i.child=uo(i,null,u,s):li(e,i,u,s),i.child;case 11:return wx(e,i,i.type,i.pendingProps,s);case 7:return li(e,i,i.pendingProps,s),i.child;case 8:return li(e,i,i.pendingProps.children,s),i.child;case 12:return li(e,i,i.pendingProps.children,s),i.child;case 10:return u=i.pendingProps,cs(i,i.type,u.value),li(e,i,u.children,s),i.child;case 9:return h=i.type._context,u=i.pendingProps.children,ro(i),h=oi(h),u=u(h),i.flags|=1,li(e,i,u,s),i.child;case 14:return Dx(e,i,i.type,i.pendingProps,s);case 15:return Ux(e,i,i.type,i.pendingProps,s);case 19:return Hx(e,i,s);case 31:return vT(e,i,s);case 22:return Nx(e,i,s,i.pendingProps);case 24:return ro(i),u=oi(Gn),e===null?(h=fp(),h===null&&(h=hn,m=up(),h.pooledCache=m,m.refCount++,m!==null&&(h.pooledCacheLanes|=s),h=m),i.memoizedState={parent:u,cache:h},dp(i),cs(i,Gn,h)):((e.lanes&s)!==0&&(pp(e,i),Nu(i,null,null,s),Uu()),h=e.memoizedState,m=i.memoizedState,h.parent!==u?(h={parent:u,cache:u},i.memoizedState=h,i.lanes===0&&(i.memoizedState=i.updateQueue.baseState=h),cs(i,Gn,u)):(u=m.cache,cs(i,Gn,u),u!==h.cache&&lp(i,[Gn],s,!0))),li(e,i,i.pendingProps.children,s),i.child;case 29:throw i.pendingProps}throw Error(a(156,i.tag))}function Lr(e){e.flags|=4}function Zp(e,i,s,u,h){if((i=(e.mode&32)!==0)&&(i=!1),i){if(e.flags|=16777216,(h&335544128)===h)if(e.stateNode.complete)e.flags|=8192;else if(py())e.flags|=8192;else throw lo=vf,hp}else e.flags&=-16777217}function Vx(e,i){if(i.type!=="stylesheet"||(i.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!iS(i))if(py())e.flags|=8192;else throw lo=vf,hp}function Pf(e,i){i!==null&&(e.flags|=4),e.flags&16384&&(i=e.tag!==22?Ge():536870912,e.lanes|=i,ml|=i)}function Iu(e,i){if(!Ve)switch(e.tailMode){case"hidden":i=e.tail;for(var s=null;i!==null;)i.alternate!==null&&(s=i),i=i.sibling;s===null?e.tail=null:s.sibling=null;break;case"collapsed":s=e.tail;for(var u=null;s!==null;)s.alternate!==null&&(u=s),s=s.sibling;u===null?i||e.tail===null?e.tail=null:e.tail.sibling=null:u.sibling=null}}function yn(e){var i=e.alternate!==null&&e.alternate.child===e.child,s=0,u=0;if(i)for(var h=e.child;h!==null;)s|=h.lanes|h.childLanes,u|=h.subtreeFlags&65011712,u|=h.flags&65011712,h.return=e,h=h.sibling;else for(h=e.child;h!==null;)s|=h.lanes|h.childLanes,u|=h.subtreeFlags,u|=h.flags,h.return=e,h=h.sibling;return e.subtreeFlags|=u,e.childLanes=s,i}function yT(e,i,s){var u=i.pendingProps;switch(ip(i),i.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return yn(i),null;case 1:return yn(i),null;case 3:return s=i.stateNode,u=null,e!==null&&(u=e.memoizedState.cache),i.memoizedState.cache!==u&&(i.flags|=2048),wr(Gn),Ft(),s.pendingContext&&(s.context=s.pendingContext,s.pendingContext=null),(e===null||e.child===null)&&(nl(i)?Lr(i):e===null||e.memoizedState.isDehydrated&&(i.flags&256)===0||(i.flags|=1024,rp())),yn(i),null;case 26:var h=i.type,m=i.memoizedState;return e===null?(Lr(i),m!==null?(yn(i),Vx(i,m)):(yn(i),Zp(i,h,null,u,s))):m?m!==e.memoizedState?(Lr(i),yn(i),Vx(i,m)):(yn(i),i.flags&=-16777217):(e=e.memoizedProps,e!==u&&Lr(i),yn(i),Zp(i,h,e,u,s)),null;case 27:if(Kt(i),s=nt.current,h=i.type,e!==null&&i.stateNode!=null)e.memoizedProps!==u&&Lr(i);else{if(!u){if(i.stateNode===null)throw Error(a(166));return yn(i),null}e=Tt.current,nl(i)?Sv(i):(e=Zy(h,u,s),i.stateNode=e,Lr(i))}return yn(i),null;case 5:if(Kt(i),h=i.type,e!==null&&i.stateNode!=null)e.memoizedProps!==u&&Lr(i);else{if(!u){if(i.stateNode===null)throw Error(a(166));return yn(i),null}if(m=Tt.current,nl(i))Sv(i);else{var b=Kf(nt.current);switch(m){case 1:m=b.createElementNS("http://www.w3.org/2000/svg",h);break;case 2:m=b.createElementNS("http://www.w3.org/1998/Math/MathML",h);break;default:switch(h){case"svg":m=b.createElementNS("http://www.w3.org/2000/svg",h);break;case"math":m=b.createElementNS("http://www.w3.org/1998/Math/MathML",h);break;case"script":m=b.createElement("div"),m.innerHTML="<script><\/script>",m=m.removeChild(m.firstChild);break;case"select":m=typeof u.is=="string"?b.createElement("select",{is:u.is}):b.createElement("select"),u.multiple?m.multiple=!0:u.size&&(m.size=u.size);break;default:m=typeof u.is=="string"?b.createElement(h,{is:u.is}):b.createElement(h)}}m[Te]=i,m[xe]=u;t:for(b=i.child;b!==null;){if(b.tag===5||b.tag===6)m.appendChild(b.stateNode);else if(b.tag!==4&&b.tag!==27&&b.child!==null){b.child.return=b,b=b.child;continue}if(b===i)break t;for(;b.sibling===null;){if(b.return===null||b.return===i)break t;b=b.return}b.sibling.return=b.return,b=b.sibling}i.stateNode=m;t:switch(ui(m,h,u),h){case"button":case"input":case"select":case"textarea":u=!!u.autoFocus;break t;case"img":u=!0;break t;default:u=!1}u&&Lr(i)}}return yn(i),Zp(i,i.type,e===null?null:e.memoizedProps,i.pendingProps,s),null;case 6:if(e&&i.stateNode!=null)e.memoizedProps!==u&&Lr(i);else{if(typeof u!="string"&&i.stateNode===null)throw Error(a(166));if(e=nt.current,nl(i)){if(e=i.stateNode,s=i.memoizedProps,u=null,h=si,h!==null)switch(h.tag){case 27:case 5:u=h.memoizedProps}e[Te]=i,e=!!(e.nodeValue===s||u!==null&&u.suppressHydrationWarning===!0||Iy(e.nodeValue,s)),e||us(i,!0)}else e=Kf(e).createTextNode(u),e[Te]=i,i.stateNode=e}return yn(i),null;case 31:if(s=i.memoizedState,e===null||e.memoizedState!==null){if(u=nl(i),s!==null){if(e===null){if(!u)throw Error(a(318));if(e=i.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(a(557));e[Te]=i}else io(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;yn(i),e=!1}else s=rp(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=s),e=!0;if(!e)return i.flags&256?(aa(i),i):(aa(i),null);if((i.flags&128)!==0)throw Error(a(558))}return yn(i),null;case 13:if(u=i.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(h=nl(i),u!==null&&u.dehydrated!==null){if(e===null){if(!h)throw Error(a(318));if(h=i.memoizedState,h=h!==null?h.dehydrated:null,!h)throw Error(a(317));h[Te]=i}else io(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;yn(i),h=!1}else h=rp(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=h),h=!0;if(!h)return i.flags&256?(aa(i),i):(aa(i),null)}return aa(i),(i.flags&128)!==0?(i.lanes=s,i):(s=u!==null,e=e!==null&&e.memoizedState!==null,s&&(u=i.child,h=null,u.alternate!==null&&u.alternate.memoizedState!==null&&u.alternate.memoizedState.cachePool!==null&&(h=u.alternate.memoizedState.cachePool.pool),m=null,u.memoizedState!==null&&u.memoizedState.cachePool!==null&&(m=u.memoizedState.cachePool.pool),m!==h&&(u.flags|=2048)),s!==e&&s&&(i.child.flags|=8192),Pf(i,i.updateQueue),yn(i),null);case 4:return Ft(),e===null&&gm(i.stateNode.containerInfo),yn(i),null;case 10:return wr(i.type),yn(i),null;case 19:if(K(Nn),u=i.memoizedState,u===null)return yn(i),null;if(h=(i.flags&128)!==0,m=u.rendering,m===null)if(h)Iu(u,!1);else{if(Dn!==0||e!==null&&(e.flags&128)!==0)for(e=i.child;e!==null;){if(m=Mf(e),m!==null){for(i.flags|=128,Iu(u,!1),e=m.updateQueue,i.updateQueue=e,Pf(i,e),i.subtreeFlags=0,e=s,s=i.child;s!==null;)_v(s,e),s=s.sibling;return xt(Nn,Nn.current&1|2),Ve&&Rr(i,u.treeForkCount),i.child}e=e.sibling}u.tail!==null&&A()>Hf&&(i.flags|=128,h=!0,Iu(u,!1),i.lanes=4194304)}else{if(!h)if(e=Mf(m),e!==null){if(i.flags|=128,h=!0,e=e.updateQueue,i.updateQueue=e,Pf(i,e),Iu(u,!0),u.tail===null&&u.tailMode==="hidden"&&!m.alternate&&!Ve)return yn(i),null}else 2*A()-u.renderingStartTime>Hf&&s!==536870912&&(i.flags|=128,h=!0,Iu(u,!1),i.lanes=4194304);u.isBackwards?(m.sibling=i.child,i.child=m):(e=u.last,e!==null?e.sibling=m:i.child=m,u.last=m)}return u.tail!==null?(e=u.tail,u.rendering=e,u.tail=e.sibling,u.renderingStartTime=A(),e.sibling=null,s=Nn.current,xt(Nn,h?s&1|2:s&1),Ve&&Rr(i,u.treeForkCount),e):(yn(i),null);case 22:case 23:return aa(i),vp(),u=i.memoizedState!==null,e!==null?e.memoizedState!==null!==u&&(i.flags|=8192):u&&(i.flags|=8192),u?(s&536870912)!==0&&(i.flags&128)===0&&(yn(i),i.subtreeFlags&6&&(i.flags|=8192)):yn(i),s=i.updateQueue,s!==null&&Pf(i,s.retryQueue),s=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(s=e.memoizedState.cachePool.pool),u=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(u=i.memoizedState.cachePool.pool),u!==s&&(i.flags|=2048),e!==null&&K(so),null;case 24:return s=null,e!==null&&(s=e.memoizedState.cache),i.memoizedState.cache!==s&&(i.flags|=2048),wr(Gn),yn(i),null;case 25:return null;case 30:return null}throw Error(a(156,i.tag))}function ST(e,i){switch(ip(i),i.tag){case 1:return e=i.flags,e&65536?(i.flags=e&-65537|128,i):null;case 3:return wr(Gn),Ft(),e=i.flags,(e&65536)!==0&&(e&128)===0?(i.flags=e&-65537|128,i):null;case 26:case 27:case 5:return Kt(i),null;case 31:if(i.memoizedState!==null){if(aa(i),i.alternate===null)throw Error(a(340));io()}return e=i.flags,e&65536?(i.flags=e&-65537|128,i):null;case 13:if(aa(i),e=i.memoizedState,e!==null&&e.dehydrated!==null){if(i.alternate===null)throw Error(a(340));io()}return e=i.flags,e&65536?(i.flags=e&-65537|128,i):null;case 19:return K(Nn),null;case 4:return Ft(),null;case 10:return wr(i.type),null;case 22:case 23:return aa(i),vp(),e!==null&&K(so),e=i.flags,e&65536?(i.flags=e&-65537|128,i):null;case 24:return wr(Gn),null;case 25:return null;default:return null}}function kx(e,i){switch(ip(i),i.tag){case 3:wr(Gn),Ft();break;case 26:case 27:case 5:Kt(i);break;case 4:Ft();break;case 31:i.memoizedState!==null&&aa(i);break;case 13:aa(i);break;case 19:K(Nn);break;case 10:wr(i.type);break;case 22:case 23:aa(i),vp(),e!==null&&K(so);break;case 24:wr(Gn)}}function Bu(e,i){try{var s=i.updateQueue,u=s!==null?s.lastEffect:null;if(u!==null){var h=u.next;s=h;do{if((s.tag&e)===e){u=void 0;var m=s.create,b=s.inst;u=m(),b.destroy=u}s=s.next}while(s!==h)}}catch(N){nn(i,i.return,N)}}function _s(e,i,s){try{var u=i.updateQueue,h=u!==null?u.lastEffect:null;if(h!==null){var m=h.next;u=m;do{if((u.tag&e)===e){var b=u.inst,N=b.destroy;if(N!==void 0){b.destroy=void 0,h=i;var X=s,ot=N;try{ot()}catch(yt){nn(h,X,yt)}}}u=u.next}while(u!==m)}}catch(yt){nn(i,i.return,yt)}}function Xx(e){var i=e.updateQueue;if(i!==null){var s=e.stateNode;try{Ov(i,s)}catch(u){nn(e,e.return,u)}}}function Wx(e,i,s){s.props=fo(e.type,e.memoizedProps),s.state=e.memoizedState;try{s.componentWillUnmount()}catch(u){nn(e,i,u)}}function Hu(e,i){try{var s=e.ref;if(s!==null){switch(e.tag){case 26:case 27:case 5:var u=e.stateNode;break;case 30:u=e.stateNode;break;default:u=e.stateNode}typeof s=="function"?e.refCleanup=s(u):s.current=u}}catch(h){nn(e,i,h)}}function ir(e,i){var s=e.ref,u=e.refCleanup;if(s!==null)if(typeof u=="function")try{u()}catch(h){nn(e,i,h)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof s=="function")try{s(null)}catch(h){nn(e,i,h)}else s.current=null}function Yx(e){var i=e.type,s=e.memoizedProps,u=e.stateNode;try{t:switch(i){case"button":case"input":case"select":case"textarea":s.autoFocus&&u.focus();break t;case"img":s.src?u.src=s.src:s.srcSet&&(u.srcset=s.srcSet)}}catch(h){nn(e,e.return,h)}}function Kp(e,i,s){try{var u=e.stateNode;kT(u,e.type,s,i),u[xe]=i}catch(h){nn(e,e.return,h)}}function qx(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&Es(e.type)||e.tag===4}function Qp(e){t:for(;;){for(;e.sibling===null;){if(e.return===null||qx(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&Es(e.type)||e.flags&2||e.child===null||e.tag===4)continue t;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Jp(e,i,s){var u=e.tag;if(u===5||u===6)e=e.stateNode,i?(s.nodeType===9?s.body:s.nodeName==="HTML"?s.ownerDocument.body:s).insertBefore(e,i):(i=s.nodeType===9?s.body:s.nodeName==="HTML"?s.ownerDocument.body:s,i.appendChild(e),s=s._reactRootContainer,s!=null||i.onclick!==null||(i.onclick=br));else if(u!==4&&(u===27&&Es(e.type)&&(s=e.stateNode,i=null),e=e.child,e!==null))for(Jp(e,i,s),e=e.sibling;e!==null;)Jp(e,i,s),e=e.sibling}function Ff(e,i,s){var u=e.tag;if(u===5||u===6)e=e.stateNode,i?s.insertBefore(e,i):s.appendChild(e);else if(u!==4&&(u===27&&Es(e.type)&&(s=e.stateNode),e=e.child,e!==null))for(Ff(e,i,s),e=e.sibling;e!==null;)Ff(e,i,s),e=e.sibling}function jx(e){var i=e.stateNode,s=e.memoizedProps;try{for(var u=e.type,h=i.attributes;h.length;)i.removeAttributeNode(h[0]);ui(i,u,s),i[Te]=e,i[xe]=s}catch(m){nn(e,e.return,m)}}var Or=!1,Xn=!1,$p=!1,Zx=typeof WeakSet=="function"?WeakSet:Set,ei=null;function MT(e,i){if(e=e.containerInfo,ym=ih,e=ov(e),Yd(e)){if("selectionStart"in e)var s={start:e.selectionStart,end:e.selectionEnd};else t:{s=(s=e.ownerDocument)&&s.defaultView||window;var u=s.getSelection&&s.getSelection();if(u&&u.rangeCount!==0){s=u.anchorNode;var h=u.anchorOffset,m=u.focusNode;u=u.focusOffset;try{s.nodeType,m.nodeType}catch{s=null;break t}var b=0,N=-1,X=-1,ot=0,yt=0,Mt=e,ct=null;e:for(;;){for(var pt;Mt!==s||h!==0&&Mt.nodeType!==3||(N=b+h),Mt!==m||u!==0&&Mt.nodeType!==3||(X=b+u),Mt.nodeType===3&&(b+=Mt.nodeValue.length),(pt=Mt.firstChild)!==null;)ct=Mt,Mt=pt;for(;;){if(Mt===e)break e;if(ct===s&&++ot===h&&(N=b),ct===m&&++yt===u&&(X=b),(pt=Mt.nextSibling)!==null)break;Mt=ct,ct=Mt.parentNode}Mt=pt}s=N===-1||X===-1?null:{start:N,end:X}}else s=null}s=s||{start:0,end:0}}else s=null;for(Sm={focusedElem:e,selectionRange:s},ih=!1,ei=i;ei!==null;)if(i=ei,e=i.child,(i.subtreeFlags&1028)!==0&&e!==null)e.return=i,ei=e;else for(;ei!==null;){switch(i=ei,m=i.alternate,e=i.flags,i.tag){case 0:if((e&4)!==0&&(e=i.updateQueue,e=e!==null?e.events:null,e!==null))for(s=0;s<e.length;s++)h=e[s],h.ref.impl=h.nextImpl;break;case 11:case 15:break;case 1:if((e&1024)!==0&&m!==null){e=void 0,s=i,h=m.memoizedProps,m=m.memoizedState,u=s.stateNode;try{var $t=fo(s.type,h);e=u.getSnapshotBeforeUpdate($t,m),u.__reactInternalSnapshotBeforeUpdate=e}catch(fe){nn(s,s.return,fe)}}break;case 3:if((e&1024)!==0){if(e=i.stateNode.containerInfo,s=e.nodeType,s===9)bm(e);else if(s===1)switch(e.nodeName){case"HEAD":case"HTML":case"BODY":bm(e);break;default:e.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((e&1024)!==0)throw Error(a(163))}if(e=i.sibling,e!==null){e.return=i.return,ei=e;break}ei=i.return}}function Kx(e,i,s){var u=s.flags;switch(s.tag){case 0:case 11:case 15:Fr(e,s),u&4&&Bu(5,s);break;case 1:if(Fr(e,s),u&4)if(e=s.stateNode,i===null)try{e.componentDidMount()}catch(b){nn(s,s.return,b)}else{var h=fo(s.type,i.memoizedProps);i=i.memoizedState;try{e.componentDidUpdate(h,i,e.__reactInternalSnapshotBeforeUpdate)}catch(b){nn(s,s.return,b)}}u&64&&Xx(s),u&512&&Hu(s,s.return);break;case 3:if(Fr(e,s),u&64&&(e=s.updateQueue,e!==null)){if(i=null,s.child!==null)switch(s.child.tag){case 27:case 5:i=s.child.stateNode;break;case 1:i=s.child.stateNode}try{Ov(e,i)}catch(b){nn(s,s.return,b)}}break;case 27:i===null&&u&4&&jx(s);case 26:case 5:Fr(e,s),i===null&&u&4&&Yx(s),u&512&&Hu(s,s.return);break;case 12:Fr(e,s);break;case 31:Fr(e,s),u&4&&$x(e,s);break;case 13:Fr(e,s),u&4&&ty(e,s),u&64&&(e=s.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(s=UT.bind(null,s),QT(e,s))));break;case 22:if(u=s.memoizedState!==null||Or,!u){i=i!==null&&i.memoizedState!==null||Xn,h=Or;var m=Xn;Or=u,(Xn=i)&&!m?zr(e,s,(s.subtreeFlags&8772)!==0):Fr(e,s),Or=h,Xn=m}break;case 30:break;default:Fr(e,s)}}function Qx(e){var i=e.alternate;i!==null&&(e.alternate=null,Qx(i)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(i=e.stateNode,i!==null&&Tn(i)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var En=null,Bi=!1;function Pr(e,i,s){for(s=s.child;s!==null;)Jx(e,i,s),s=s.sibling}function Jx(e,i,s){if(At&&typeof At.onCommitFiberUnmount=="function")try{At.onCommitFiberUnmount(Rt,s)}catch{}switch(s.tag){case 26:Xn||ir(s,i),Pr(e,i,s),s.memoizedState?s.memoizedState.count--:s.stateNode&&(s=s.stateNode,s.parentNode.removeChild(s));break;case 27:Xn||ir(s,i);var u=En,h=Bi;Es(s.type)&&(En=s.stateNode,Bi=!1),Pr(e,i,s),Zu(s.stateNode),En=u,Bi=h;break;case 5:Xn||ir(s,i);case 6:if(u=En,h=Bi,En=null,Pr(e,i,s),En=u,Bi=h,En!==null)if(Bi)try{(En.nodeType===9?En.body:En.nodeName==="HTML"?En.ownerDocument.body:En).removeChild(s.stateNode)}catch(m){nn(s,i,m)}else try{En.removeChild(s.stateNode)}catch(m){nn(s,i,m)}break;case 18:En!==null&&(Bi?(e=En,Xy(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,s.stateNode),El(e)):Xy(En,s.stateNode));break;case 4:u=En,h=Bi,En=s.stateNode.containerInfo,Bi=!0,Pr(e,i,s),En=u,Bi=h;break;case 0:case 11:case 14:case 15:_s(2,s,i),Xn||_s(4,s,i),Pr(e,i,s);break;case 1:Xn||(ir(s,i),u=s.stateNode,typeof u.componentWillUnmount=="function"&&Wx(s,i,u)),Pr(e,i,s);break;case 21:Pr(e,i,s);break;case 22:Xn=(u=Xn)||s.memoizedState!==null,Pr(e,i,s),Xn=u;break;default:Pr(e,i,s)}}function $x(e,i){if(i.memoizedState===null&&(e=i.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{El(e)}catch(s){nn(i,i.return,s)}}}function ty(e,i){if(i.memoizedState===null&&(e=i.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{El(e)}catch(s){nn(i,i.return,s)}}function ET(e){switch(e.tag){case 31:case 13:case 19:var i=e.stateNode;return i===null&&(i=e.stateNode=new Zx),i;case 22:return e=e.stateNode,i=e._retryCache,i===null&&(i=e._retryCache=new Zx),i;default:throw Error(a(435,e.tag))}}function zf(e,i){var s=ET(e);i.forEach(function(u){if(!s.has(u)){s.add(u);var h=NT.bind(null,e,u);u.then(h,h)}})}function Hi(e,i){var s=i.deletions;if(s!==null)for(var u=0;u<s.length;u++){var h=s[u],m=e,b=i,N=b;t:for(;N!==null;){switch(N.tag){case 27:if(Es(N.type)){En=N.stateNode,Bi=!1;break t}break;case 5:En=N.stateNode,Bi=!1;break t;case 3:case 4:En=N.stateNode.containerInfo,Bi=!0;break t}N=N.return}if(En===null)throw Error(a(160));Jx(m,b,h),En=null,Bi=!1,m=h.alternate,m!==null&&(m.return=null),h.return=null}if(i.subtreeFlags&13886)for(i=i.child;i!==null;)ey(i,e),i=i.sibling}var Wa=null;function ey(e,i){var s=e.alternate,u=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:Hi(i,e),Gi(e),u&4&&(_s(3,e,e.return),Bu(3,e),_s(5,e,e.return));break;case 1:Hi(i,e),Gi(e),u&512&&(Xn||s===null||ir(s,s.return)),u&64&&Or&&(e=e.updateQueue,e!==null&&(u=e.callbacks,u!==null&&(s=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=s===null?u:s.concat(u))));break;case 26:var h=Wa;if(Hi(i,e),Gi(e),u&512&&(Xn||s===null||ir(s,s.return)),u&4){var m=s!==null?s.memoizedState:null;if(u=e.memoizedState,s===null)if(u===null)if(e.stateNode===null){t:{u=e.type,s=e.memoizedProps,h=h.ownerDocument||h;e:switch(u){case"title":m=h.getElementsByTagName("title")[0],(!m||m[gn]||m[Te]||m.namespaceURI==="http://www.w3.org/2000/svg"||m.hasAttribute("itemprop"))&&(m=h.createElement(u),h.head.insertBefore(m,h.querySelector("head > title"))),ui(m,u,s),m[Te]=e,Y(m),u=m;break t;case"link":var b=eS("link","href",h).get(u+(s.href||""));if(b){for(var N=0;N<b.length;N++)if(m=b[N],m.getAttribute("href")===(s.href==null||s.href===""?null:s.href)&&m.getAttribute("rel")===(s.rel==null?null:s.rel)&&m.getAttribute("title")===(s.title==null?null:s.title)&&m.getAttribute("crossorigin")===(s.crossOrigin==null?null:s.crossOrigin)){b.splice(N,1);break e}}m=h.createElement(u),ui(m,u,s),h.head.appendChild(m);break;case"meta":if(b=eS("meta","content",h).get(u+(s.content||""))){for(N=0;N<b.length;N++)if(m=b[N],m.getAttribute("content")===(s.content==null?null:""+s.content)&&m.getAttribute("name")===(s.name==null?null:s.name)&&m.getAttribute("property")===(s.property==null?null:s.property)&&m.getAttribute("http-equiv")===(s.httpEquiv==null?null:s.httpEquiv)&&m.getAttribute("charset")===(s.charSet==null?null:s.charSet)){b.splice(N,1);break e}}m=h.createElement(u),ui(m,u,s),h.head.appendChild(m);break;default:throw Error(a(468,u))}m[Te]=e,Y(m),u=m}e.stateNode=u}else nS(h,e.type,e.stateNode);else e.stateNode=tS(h,u,e.memoizedProps);else m!==u?(m===null?s.stateNode!==null&&(s=s.stateNode,s.parentNode.removeChild(s)):m.count--,u===null?nS(h,e.type,e.stateNode):tS(h,u,e.memoizedProps)):u===null&&e.stateNode!==null&&Kp(e,e.memoizedProps,s.memoizedProps)}break;case 27:Hi(i,e),Gi(e),u&512&&(Xn||s===null||ir(s,s.return)),s!==null&&u&4&&Kp(e,e.memoizedProps,s.memoizedProps);break;case 5:if(Hi(i,e),Gi(e),u&512&&(Xn||s===null||ir(s,s.return)),e.flags&32){h=e.stateNode;try{Ri(h,"")}catch($t){nn(e,e.return,$t)}}u&4&&e.stateNode!=null&&(h=e.memoizedProps,Kp(e,h,s!==null?s.memoizedProps:h)),u&1024&&($p=!0);break;case 6:if(Hi(i,e),Gi(e),u&4){if(e.stateNode===null)throw Error(a(162));u=e.memoizedProps,s=e.stateNode;try{s.nodeValue=u}catch($t){nn(e,e.return,$t)}}break;case 3:if($f=null,h=Wa,Wa=Qf(i.containerInfo),Hi(i,e),Wa=h,Gi(e),u&4&&s!==null&&s.memoizedState.isDehydrated)try{El(i.containerInfo)}catch($t){nn(e,e.return,$t)}$p&&($p=!1,ny(e));break;case 4:u=Wa,Wa=Qf(e.stateNode.containerInfo),Hi(i,e),Gi(e),Wa=u;break;case 12:Hi(i,e),Gi(e);break;case 31:Hi(i,e),Gi(e),u&4&&(u=e.updateQueue,u!==null&&(e.updateQueue=null,zf(e,u)));break;case 13:Hi(i,e),Gi(e),e.child.flags&8192&&e.memoizedState!==null!=(s!==null&&s.memoizedState!==null)&&(Bf=A()),u&4&&(u=e.updateQueue,u!==null&&(e.updateQueue=null,zf(e,u)));break;case 22:h=e.memoizedState!==null;var X=s!==null&&s.memoizedState!==null,ot=Or,yt=Xn;if(Or=ot||h,Xn=yt||X,Hi(i,e),Xn=yt,Or=ot,Gi(e),u&8192)t:for(i=e.stateNode,i._visibility=h?i._visibility&-2:i._visibility|1,h&&(s===null||X||Or||Xn||ho(e)),s=null,i=e;;){if(i.tag===5||i.tag===26){if(s===null){X=s=i;try{if(m=X.stateNode,h)b=m.style,typeof b.setProperty=="function"?b.setProperty("display","none","important"):b.display="none";else{N=X.stateNode;var Mt=X.memoizedProps.style,ct=Mt!=null&&Mt.hasOwnProperty("display")?Mt.display:null;N.style.display=ct==null||typeof ct=="boolean"?"":(""+ct).trim()}}catch($t){nn(X,X.return,$t)}}}else if(i.tag===6){if(s===null){X=i;try{X.stateNode.nodeValue=h?"":X.memoizedProps}catch($t){nn(X,X.return,$t)}}}else if(i.tag===18){if(s===null){X=i;try{var pt=X.stateNode;h?Wy(pt,!0):Wy(X.stateNode,!1)}catch($t){nn(X,X.return,$t)}}}else if((i.tag!==22&&i.tag!==23||i.memoizedState===null||i===e)&&i.child!==null){i.child.return=i,i=i.child;continue}if(i===e)break t;for(;i.sibling===null;){if(i.return===null||i.return===e)break t;s===i&&(s=null),i=i.return}s===i&&(s=null),i.sibling.return=i.return,i=i.sibling}u&4&&(u=e.updateQueue,u!==null&&(s=u.retryQueue,s!==null&&(u.retryQueue=null,zf(e,s))));break;case 19:Hi(i,e),Gi(e),u&4&&(u=e.updateQueue,u!==null&&(e.updateQueue=null,zf(e,u)));break;case 30:break;case 21:break;default:Hi(i,e),Gi(e)}}function Gi(e){var i=e.flags;if(i&2){try{for(var s,u=e.return;u!==null;){if(qx(u)){s=u;break}u=u.return}if(s==null)throw Error(a(160));switch(s.tag){case 27:var h=s.stateNode,m=Qp(e);Ff(e,m,h);break;case 5:var b=s.stateNode;s.flags&32&&(Ri(b,""),s.flags&=-33);var N=Qp(e);Ff(e,N,b);break;case 3:case 4:var X=s.stateNode.containerInfo,ot=Qp(e);Jp(e,ot,X);break;default:throw Error(a(161))}}catch(yt){nn(e,e.return,yt)}e.flags&=-3}i&4096&&(e.flags&=-4097)}function ny(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var i=e;ny(i),i.tag===5&&i.flags&1024&&i.stateNode.reset(),e=e.sibling}}function Fr(e,i){if(i.subtreeFlags&8772)for(i=i.child;i!==null;)Kx(e,i.alternate,i),i=i.sibling}function ho(e){for(e=e.child;e!==null;){var i=e;switch(i.tag){case 0:case 11:case 14:case 15:_s(4,i,i.return),ho(i);break;case 1:ir(i,i.return);var s=i.stateNode;typeof s.componentWillUnmount=="function"&&Wx(i,i.return,s),ho(i);break;case 27:Zu(i.stateNode);case 26:case 5:ir(i,i.return),ho(i);break;case 22:i.memoizedState===null&&ho(i);break;case 30:ho(i);break;default:ho(i)}e=e.sibling}}function zr(e,i,s){for(s=s&&(i.subtreeFlags&8772)!==0,i=i.child;i!==null;){var u=i.alternate,h=e,m=i,b=m.flags;switch(m.tag){case 0:case 11:case 15:zr(h,m,s),Bu(4,m);break;case 1:if(zr(h,m,s),u=m,h=u.stateNode,typeof h.componentDidMount=="function")try{h.componentDidMount()}catch(ot){nn(u,u.return,ot)}if(u=m,h=u.updateQueue,h!==null){var N=u.stateNode;try{var X=h.shared.hiddenCallbacks;if(X!==null)for(h.shared.hiddenCallbacks=null,h=0;h<X.length;h++)Lv(X[h],N)}catch(ot){nn(u,u.return,ot)}}s&&b&64&&Xx(m),Hu(m,m.return);break;case 27:jx(m);case 26:case 5:zr(h,m,s),s&&u===null&&b&4&&Yx(m),Hu(m,m.return);break;case 12:zr(h,m,s);break;case 31:zr(h,m,s),s&&b&4&&$x(h,m);break;case 13:zr(h,m,s),s&&b&4&&ty(h,m);break;case 22:m.memoizedState===null&&zr(h,m,s),Hu(m,m.return);break;case 30:break;default:zr(h,m,s)}i=i.sibling}}function tm(e,i){var s=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(s=e.memoizedState.cachePool.pool),e=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(e=i.memoizedState.cachePool.pool),e!==s&&(e!=null&&e.refCount++,s!=null&&Au(s))}function em(e,i){e=null,i.alternate!==null&&(e=i.alternate.memoizedState.cache),i=i.memoizedState.cache,i!==e&&(i.refCount++,e!=null&&Au(e))}function Ya(e,i,s,u){if(i.subtreeFlags&10256)for(i=i.child;i!==null;)iy(e,i,s,u),i=i.sibling}function iy(e,i,s,u){var h=i.flags;switch(i.tag){case 0:case 11:case 15:Ya(e,i,s,u),h&2048&&Bu(9,i);break;case 1:Ya(e,i,s,u);break;case 3:Ya(e,i,s,u),h&2048&&(e=null,i.alternate!==null&&(e=i.alternate.memoizedState.cache),i=i.memoizedState.cache,i!==e&&(i.refCount++,e!=null&&Au(e)));break;case 12:if(h&2048){Ya(e,i,s,u),e=i.stateNode;try{var m=i.memoizedProps,b=m.id,N=m.onPostCommit;typeof N=="function"&&N(b,i.alternate===null?"mount":"update",e.passiveEffectDuration,-0)}catch(X){nn(i,i.return,X)}}else Ya(e,i,s,u);break;case 31:Ya(e,i,s,u);break;case 13:Ya(e,i,s,u);break;case 23:break;case 22:m=i.stateNode,b=i.alternate,i.memoizedState!==null?m._visibility&2?Ya(e,i,s,u):Gu(e,i):m._visibility&2?Ya(e,i,s,u):(m._visibility|=2,hl(e,i,s,u,(i.subtreeFlags&10256)!==0||!1)),h&2048&&tm(b,i);break;case 24:Ya(e,i,s,u),h&2048&&em(i.alternate,i);break;default:Ya(e,i,s,u)}}function hl(e,i,s,u,h){for(h=h&&((i.subtreeFlags&10256)!==0||!1),i=i.child;i!==null;){var m=e,b=i,N=s,X=u,ot=b.flags;switch(b.tag){case 0:case 11:case 15:hl(m,b,N,X,h),Bu(8,b);break;case 23:break;case 22:var yt=b.stateNode;b.memoizedState!==null?yt._visibility&2?hl(m,b,N,X,h):Gu(m,b):(yt._visibility|=2,hl(m,b,N,X,h)),h&&ot&2048&&tm(b.alternate,b);break;case 24:hl(m,b,N,X,h),h&&ot&2048&&em(b.alternate,b);break;default:hl(m,b,N,X,h)}i=i.sibling}}function Gu(e,i){if(i.subtreeFlags&10256)for(i=i.child;i!==null;){var s=e,u=i,h=u.flags;switch(u.tag){case 22:Gu(s,u),h&2048&&tm(u.alternate,u);break;case 24:Gu(s,u),h&2048&&em(u.alternate,u);break;default:Gu(s,u)}i=i.sibling}}var Vu=8192;function dl(e,i,s){if(e.subtreeFlags&Vu)for(e=e.child;e!==null;)ay(e,i,s),e=e.sibling}function ay(e,i,s){switch(e.tag){case 26:dl(e,i,s),e.flags&Vu&&e.memoizedState!==null&&uA(s,Wa,e.memoizedState,e.memoizedProps);break;case 5:dl(e,i,s);break;case 3:case 4:var u=Wa;Wa=Qf(e.stateNode.containerInfo),dl(e,i,s),Wa=u;break;case 22:e.memoizedState===null&&(u=e.alternate,u!==null&&u.memoizedState!==null?(u=Vu,Vu=16777216,dl(e,i,s),Vu=u):dl(e,i,s));break;default:dl(e,i,s)}}function ry(e){var i=e.alternate;if(i!==null&&(e=i.child,e!==null)){i.child=null;do i=e.sibling,e.sibling=null,e=i;while(e!==null)}}function ku(e){var i=e.deletions;if((e.flags&16)!==0){if(i!==null)for(var s=0;s<i.length;s++){var u=i[s];ei=u,oy(u,e)}ry(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)sy(e),e=e.sibling}function sy(e){switch(e.tag){case 0:case 11:case 15:ku(e),e.flags&2048&&_s(9,e,e.return);break;case 3:ku(e);break;case 12:ku(e);break;case 22:var i=e.stateNode;e.memoizedState!==null&&i._visibility&2&&(e.return===null||e.return.tag!==13)?(i._visibility&=-3,If(e)):ku(e);break;default:ku(e)}}function If(e){var i=e.deletions;if((e.flags&16)!==0){if(i!==null)for(var s=0;s<i.length;s++){var u=i[s];ei=u,oy(u,e)}ry(e)}for(e=e.child;e!==null;){switch(i=e,i.tag){case 0:case 11:case 15:_s(8,i,i.return),If(i);break;case 22:s=i.stateNode,s._visibility&2&&(s._visibility&=-3,If(i));break;default:If(i)}e=e.sibling}}function oy(e,i){for(;ei!==null;){var s=ei;switch(s.tag){case 0:case 11:case 15:_s(8,s,i);break;case 23:case 22:if(s.memoizedState!==null&&s.memoizedState.cachePool!==null){var u=s.memoizedState.cachePool.pool;u!=null&&u.refCount++}break;case 24:Au(s.memoizedState.cache)}if(u=s.child,u!==null)u.return=s,ei=u;else t:for(s=e;ei!==null;){u=ei;var h=u.sibling,m=u.return;if(Qx(u),u===s){ei=null;break t}if(h!==null){h.return=m,ei=h;break t}ei=m}}}var bT={getCacheForType:function(e){var i=oi(Gn),s=i.data.get(e);return s===void 0&&(s=e(),i.data.set(e,s)),s},cacheSignal:function(){return oi(Gn).controller.signal}},TT=typeof WeakMap=="function"?WeakMap:Map,Je=0,hn=null,Fe=null,Be=0,en=0,ra=null,gs=!1,pl=!1,nm=!1,Ir=0,Dn=0,vs=0,po=0,im=0,sa=0,ml=0,Xu=null,Vi=null,am=!1,Bf=0,ly=0,Hf=1/0,Gf=null,xs=null,Zn=0,ys=null,_l=null,Br=0,rm=0,sm=null,uy=null,Wu=0,om=null;function oa(){return(Je&2)!==0&&Be!==0?Be&-Be:F.T!==null?dm():ge()}function cy(){if(sa===0)if((Be&536870912)===0||Ve){var e=Ct;Ct<<=1,(Ct&3932160)===0&&(Ct=262144),sa=e}else sa=536870912;return e=ia.current,e!==null&&(e.flags|=32),sa}function ki(e,i,s){(e===hn&&(en===2||en===9)||e.cancelPendingCommit!==null)&&(gl(e,0),Ss(e,Be,sa,!1)),Jt(e,s),((Je&2)===0||e!==hn)&&(e===hn&&((Je&2)===0&&(po|=s),Dn===4&&Ss(e,Be,sa,!1)),ar(e))}function fy(e,i,s){if((Je&6)!==0)throw Error(a(327));var u=!s&&(i&127)===0&&(i&e.expiredLanes)===0||Xt(e,i),h=u?CT(e,i):um(e,i,!0),m=u;do{if(h===0){pl&&!u&&Ss(e,i,0,!1);break}else{if(s=e.current.alternate,m&&!AT(s)){h=um(e,i,!1),m=!1;continue}if(h===2){if(m=i,e.errorRecoveryDisabledLanes&m)var b=0;else b=e.pendingLanes&-536870913,b=b!==0?b:b&536870912?536870912:0;if(b!==0){i=b;t:{var N=e;h=Xu;var X=N.current.memoizedState.isDehydrated;if(X&&(gl(N,b).flags|=256),b=um(N,b,!1),b!==2){if(nm&&!X){N.errorRecoveryDisabledLanes|=m,po|=m,h=4;break t}m=Vi,Vi=h,m!==null&&(Vi===null?Vi=m:Vi.push.apply(Vi,m))}h=b}if(m=!1,h!==2)continue}}if(h===1){gl(e,0),Ss(e,i,0,!0);break}t:{switch(u=e,m=h,m){case 0:case 1:throw Error(a(345));case 4:if((i&4194048)!==i)break;case 6:Ss(u,i,sa,!gs);break t;case 2:Vi=null;break;case 3:case 5:break;default:throw Error(a(329))}if((i&62914560)===i&&(h=Bf+300-A(),10<h)){if(Ss(u,i,sa,!gs),mt(u,0,!0)!==0)break t;Br=i,u.timeoutHandle=Vy(hy.bind(null,u,s,Vi,Gf,am,i,sa,po,ml,gs,m,"Throttled",-0,0),h);break t}hy(u,s,Vi,Gf,am,i,sa,po,ml,gs,m,null,-0,0)}}break}while(!0);ar(e)}function hy(e,i,s,u,h,m,b,N,X,ot,yt,Mt,ct,pt){if(e.timeoutHandle=-1,Mt=i.subtreeFlags,Mt&8192||(Mt&16785408)===16785408){Mt={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:br},ay(i,m,Mt);var $t=(m&62914560)===m?Bf-A():(m&4194048)===m?ly-A():0;if($t=cA(Mt,$t),$t!==null){Br=m,e.cancelPendingCommit=$t(yy.bind(null,e,i,m,s,u,h,b,N,X,yt,Mt,null,ct,pt)),Ss(e,m,b,!ot);return}}yy(e,i,m,s,u,h,b,N,X)}function AT(e){for(var i=e;;){var s=i.tag;if((s===0||s===11||s===15)&&i.flags&16384&&(s=i.updateQueue,s!==null&&(s=s.stores,s!==null)))for(var u=0;u<s.length;u++){var h=s[u],m=h.getSnapshot;h=h.value;try{if(!ea(m(),h))return!1}catch{return!1}}if(s=i.child,i.subtreeFlags&16384&&s!==null)s.return=i,i=s;else{if(i===e)break;for(;i.sibling===null;){if(i.return===null||i.return===e)return!0;i=i.return}i.sibling.return=i.return,i=i.sibling}}return!0}function Ss(e,i,s,u){i&=~im,i&=~po,e.suspendedLanes|=i,e.pingedLanes&=~i,u&&(e.warmLanes|=i),u=e.expirationTimes;for(var h=i;0<h;){var m=31-Pt(h),b=1<<m;u[m]=-1,h&=~b}s!==0&&It(e,s,i)}function Vf(){return(Je&6)===0?(Yu(0),!1):!0}function lm(){if(Fe!==null){if(en===0)var e=Fe.return;else e=Fe,Cr=ao=null,bp(e),ol=null,Cu=0,e=Fe;for(;e!==null;)kx(e.alternate,e),e=e.return;Fe=null}}function gl(e,i){var s=e.timeoutHandle;s!==-1&&(e.timeoutHandle=-1,YT(s)),s=e.cancelPendingCommit,s!==null&&(e.cancelPendingCommit=null,s()),Br=0,lm(),hn=e,Fe=s=Ar(e.current,null),Be=i,en=0,ra=null,gs=!1,pl=Xt(e,i),nm=!1,ml=sa=im=po=vs=Dn=0,Vi=Xu=null,am=!1,(i&8)!==0&&(i|=i&32);var u=e.entangledLanes;if(u!==0)for(e=e.entanglements,u&=i;0<u;){var h=31-Pt(u),m=1<<h;i|=e[h],u&=~m}return Ir=i,uf(),s}function dy(e,i){Ae=null,F.H=Fu,i===sl||i===gf?(i=wv(),en=3):i===hp?(i=wv(),en=4):en=i===Hp?8:i!==null&&typeof i=="object"&&typeof i.then=="function"?6:1,ra=i,Fe===null&&(Dn=1,Uf(e,Ea(i,e.current)))}function py(){var e=ia.current;return e===null?!0:(Be&4194048)===Be?Ra===null:(Be&62914560)===Be||(Be&536870912)!==0?e===Ra:!1}function my(){var e=F.H;return F.H=Fu,e===null?Fu:e}function _y(){var e=F.A;return F.A=bT,e}function kf(){Dn=4,gs||(Be&4194048)!==Be&&ia.current!==null||(pl=!0),(vs&134217727)===0&&(po&134217727)===0||hn===null||Ss(hn,Be,sa,!1)}function um(e,i,s){var u=Je;Je|=2;var h=my(),m=_y();(hn!==e||Be!==i)&&(Gf=null,gl(e,i)),i=!1;var b=Dn;t:do try{if(en!==0&&Fe!==null){var N=Fe,X=ra;switch(en){case 8:lm(),b=6;break t;case 3:case 2:case 9:case 6:ia.current===null&&(i=!0);var ot=en;if(en=0,ra=null,vl(e,N,X,ot),s&&pl){b=0;break t}break;default:ot=en,en=0,ra=null,vl(e,N,X,ot)}}RT(),b=Dn;break}catch(yt){dy(e,yt)}while(!0);return i&&e.shellSuspendCounter++,Cr=ao=null,Je=u,F.H=h,F.A=m,Fe===null&&(hn=null,Be=0,uf()),b}function RT(){for(;Fe!==null;)gy(Fe)}function CT(e,i){var s=Je;Je|=2;var u=my(),h=_y();hn!==e||Be!==i?(Gf=null,Hf=A()+500,gl(e,i)):pl=Xt(e,i);t:do try{if(en!==0&&Fe!==null){i=Fe;var m=ra;e:switch(en){case 1:en=0,ra=null,vl(e,i,m,1);break;case 2:case 9:if(Rv(m)){en=0,ra=null,vy(i);break}i=function(){en!==2&&en!==9||hn!==e||(en=7),ar(e)},m.then(i,i);break t;case 3:en=7;break t;case 4:en=5;break t;case 7:Rv(m)?(en=0,ra=null,vy(i)):(en=0,ra=null,vl(e,i,m,7));break;case 5:var b=null;switch(Fe.tag){case 26:b=Fe.memoizedState;case 5:case 27:var N=Fe;if(b?iS(b):N.stateNode.complete){en=0,ra=null;var X=N.sibling;if(X!==null)Fe=X;else{var ot=N.return;ot!==null?(Fe=ot,Xf(ot)):Fe=null}break e}}en=0,ra=null,vl(e,i,m,5);break;case 6:en=0,ra=null,vl(e,i,m,6);break;case 8:lm(),Dn=6;break t;default:throw Error(a(462))}}wT();break}catch(yt){dy(e,yt)}while(!0);return Cr=ao=null,F.H=u,F.A=h,Je=s,Fe!==null?0:(hn=null,Be=0,uf(),Dn)}function wT(){for(;Fe!==null&&!Wt();)gy(Fe)}function gy(e){var i=Gx(e.alternate,e,Ir);e.memoizedProps=e.pendingProps,i===null?Xf(e):Fe=i}function vy(e){var i=e,s=i.alternate;switch(i.tag){case 15:case 0:i=Px(s,i,i.pendingProps,i.type,void 0,Be);break;case 11:i=Px(s,i,i.pendingProps,i.type.render,i.ref,Be);break;case 5:bp(i);default:kx(s,i),i=Fe=_v(i,Ir),i=Gx(s,i,Ir)}e.memoizedProps=e.pendingProps,i===null?Xf(e):Fe=i}function vl(e,i,s,u){Cr=ao=null,bp(i),ol=null,Cu=0;var h=i.return;try{if(gT(e,h,i,s,Be)){Dn=1,Uf(e,Ea(s,e.current)),Fe=null;return}}catch(m){if(h!==null)throw Fe=h,m;Dn=1,Uf(e,Ea(s,e.current)),Fe=null;return}i.flags&32768?(Ve||u===1?e=!0:pl||(Be&536870912)!==0?e=!1:(gs=e=!0,(u===2||u===9||u===3||u===6)&&(u=ia.current,u!==null&&u.tag===13&&(u.flags|=16384))),xy(i,e)):Xf(i)}function Xf(e){var i=e;do{if((i.flags&32768)!==0){xy(i,gs);return}e=i.return;var s=yT(i.alternate,i,Ir);if(s!==null){Fe=s;return}if(i=i.sibling,i!==null){Fe=i;return}Fe=i=e}while(i!==null);Dn===0&&(Dn=5)}function xy(e,i){do{var s=ST(e.alternate,e);if(s!==null){s.flags&=32767,Fe=s;return}if(s=e.return,s!==null&&(s.flags|=32768,s.subtreeFlags=0,s.deletions=null),!i&&(e=e.sibling,e!==null)){Fe=e;return}Fe=e=s}while(e!==null);Dn=6,Fe=null}function yy(e,i,s,u,h,m,b,N,X){e.cancelPendingCommit=null;do Wf();while(Zn!==0);if((Je&6)!==0)throw Error(a(327));if(i!==null){if(i===e.current)throw Error(a(177));if(m=i.lanes|i.childLanes,m|=Qd,be(e,s,m,b,N,X),e===hn&&(Fe=hn=null,Be=0),_l=i,ys=e,Br=s,rm=m,sm=h,uy=u,(i.subtreeFlags&10256)!==0||(i.flags&10256)!==0?(e.callbackNode=null,e.callbackPriority=0,LT(dt,function(){return Ty(),null})):(e.callbackNode=null,e.callbackPriority=0),u=(i.flags&13878)!==0,(i.subtreeFlags&13878)!==0||u){u=F.T,F.T=null,h=I.p,I.p=2,b=Je,Je|=4;try{MT(e,i,s)}finally{Je=b,I.p=h,F.T=u}}Zn=1,Sy(),My(),Ey()}}function Sy(){if(Zn===1){Zn=0;var e=ys,i=_l,s=(i.flags&13878)!==0;if((i.subtreeFlags&13878)!==0||s){s=F.T,F.T=null;var u=I.p;I.p=2;var h=Je;Je|=4;try{ey(i,e);var m=Sm,b=ov(e.containerInfo),N=m.focusedElem,X=m.selectionRange;if(b!==N&&N&&N.ownerDocument&&sv(N.ownerDocument.documentElement,N)){if(X!==null&&Yd(N)){var ot=X.start,yt=X.end;if(yt===void 0&&(yt=ot),"selectionStart"in N)N.selectionStart=ot,N.selectionEnd=Math.min(yt,N.value.length);else{var Mt=N.ownerDocument||document,ct=Mt&&Mt.defaultView||window;if(ct.getSelection){var pt=ct.getSelection(),$t=N.textContent.length,fe=Math.min(X.start,$t),cn=X.end===void 0?fe:Math.min(X.end,$t);!pt.extend&&fe>cn&&(b=cn,cn=fe,fe=b);var $=rv(N,fe),Z=rv(N,cn);if($&&Z&&(pt.rangeCount!==1||pt.anchorNode!==$.node||pt.anchorOffset!==$.offset||pt.focusNode!==Z.node||pt.focusOffset!==Z.offset)){var rt=Mt.createRange();rt.setStart($.node,$.offset),pt.removeAllRanges(),fe>cn?(pt.addRange(rt),pt.extend(Z.node,Z.offset)):(rt.setEnd(Z.node,Z.offset),pt.addRange(rt))}}}}for(Mt=[],pt=N;pt=pt.parentNode;)pt.nodeType===1&&Mt.push({element:pt,left:pt.scrollLeft,top:pt.scrollTop});for(typeof N.focus=="function"&&N.focus(),N=0;N<Mt.length;N++){var St=Mt[N];St.element.scrollLeft=St.left,St.element.scrollTop=St.top}}ih=!!ym,Sm=ym=null}finally{Je=h,I.p=u,F.T=s}}e.current=i,Zn=2}}function My(){if(Zn===2){Zn=0;var e=ys,i=_l,s=(i.flags&8772)!==0;if((i.subtreeFlags&8772)!==0||s){s=F.T,F.T=null;var u=I.p;I.p=2;var h=Je;Je|=4;try{Kx(e,i.alternate,i)}finally{Je=h,I.p=u,F.T=s}}Zn=3}}function Ey(){if(Zn===4||Zn===3){Zn=0,B();var e=ys,i=_l,s=Br,u=uy;(i.subtreeFlags&10256)!==0||(i.flags&10256)!==0?Zn=5:(Zn=0,_l=ys=null,by(e,e.pendingLanes));var h=e.pendingLanes;if(h===0&&(xs=null),_n(s),i=i.stateNode,At&&typeof At.onCommitFiberRoot=="function")try{At.onCommitFiberRoot(Rt,i,void 0,(i.current.flags&128)===128)}catch{}if(u!==null){i=F.T,h=I.p,I.p=2,F.T=null;try{for(var m=e.onRecoverableError,b=0;b<u.length;b++){var N=u[b];m(N.value,{componentStack:N.stack})}}finally{F.T=i,I.p=h}}(Br&3)!==0&&Wf(),ar(e),h=e.pendingLanes,(s&261930)!==0&&(h&42)!==0?e===om?Wu++:(Wu=0,om=e):Wu=0,Yu(0)}}function by(e,i){(e.pooledCacheLanes&=i)===0&&(i=e.pooledCache,i!=null&&(e.pooledCache=null,Au(i)))}function Wf(){return Sy(),My(),Ey(),Ty()}function Ty(){if(Zn!==5)return!1;var e=ys,i=rm;rm=0;var s=_n(Br),u=F.T,h=I.p;try{I.p=32>s?32:s,F.T=null,s=sm,sm=null;var m=ys,b=Br;if(Zn=0,_l=ys=null,Br=0,(Je&6)!==0)throw Error(a(331));var N=Je;if(Je|=4,sy(m.current),iy(m,m.current,b,s),Je=N,Yu(0,!1),At&&typeof At.onPostCommitFiberRoot=="function")try{At.onPostCommitFiberRoot(Rt,m)}catch{}return!0}finally{I.p=h,F.T=u,by(e,i)}}function Ay(e,i,s){i=Ea(s,i),i=Bp(e.stateNode,i,2),e=ds(e,i,2),e!==null&&(Jt(e,2),ar(e))}function nn(e,i,s){if(e.tag===3)Ay(e,e,s);else for(;i!==null;){if(i.tag===3){Ay(i,e,s);break}else if(i.tag===1){var u=i.stateNode;if(typeof i.type.getDerivedStateFromError=="function"||typeof u.componentDidCatch=="function"&&(xs===null||!xs.has(u))){e=Ea(s,e),s=Rx(2),u=ds(i,s,2),u!==null&&(Cx(s,u,i,e),Jt(u,2),ar(u));break}}i=i.return}}function cm(e,i,s){var u=e.pingCache;if(u===null){u=e.pingCache=new TT;var h=new Set;u.set(i,h)}else h=u.get(i),h===void 0&&(h=new Set,u.set(i,h));h.has(s)||(nm=!0,h.add(s),e=DT.bind(null,e,i,s),i.then(e,e))}function DT(e,i,s){var u=e.pingCache;u!==null&&u.delete(i),e.pingedLanes|=e.suspendedLanes&s,e.warmLanes&=~s,hn===e&&(Be&s)===s&&(Dn===4||Dn===3&&(Be&62914560)===Be&&300>A()-Bf?(Je&2)===0&&gl(e,0):im|=s,ml===Be&&(ml=0)),ar(e)}function Ry(e,i){i===0&&(i=Ge()),e=eo(e,i),e!==null&&(Jt(e,i),ar(e))}function UT(e){var i=e.memoizedState,s=0;i!==null&&(s=i.retryLane),Ry(e,s)}function NT(e,i){var s=0;switch(e.tag){case 31:case 13:var u=e.stateNode,h=e.memoizedState;h!==null&&(s=h.retryLane);break;case 19:u=e.stateNode;break;case 22:u=e.stateNode._retryCache;break;default:throw Error(a(314))}u!==null&&u.delete(i),Ry(e,s)}function LT(e,i){return Ee(e,i)}var Yf=null,xl=null,fm=!1,qf=!1,hm=!1,Ms=0;function ar(e){e!==xl&&e.next===null&&(xl===null?Yf=xl=e:xl=xl.next=e),qf=!0,fm||(fm=!0,PT())}function Yu(e,i){if(!hm&&qf){hm=!0;do for(var s=!1,u=Yf;u!==null;){if(e!==0){var h=u.pendingLanes;if(h===0)var m=0;else{var b=u.suspendedLanes,N=u.pingedLanes;m=(1<<31-Pt(42|e)+1)-1,m&=h&~(b&~N),m=m&201326741?m&201326741|1:m?m|2:0}m!==0&&(s=!0,Uy(u,m))}else m=Be,m=mt(u,u===hn?m:0,u.cancelPendingCommit!==null||u.timeoutHandle!==-1),(m&3)===0||Xt(u,m)||(s=!0,Uy(u,m));u=u.next}while(s);hm=!1}}function OT(){Cy()}function Cy(){qf=fm=!1;var e=0;Ms!==0&&WT()&&(e=Ms);for(var i=A(),s=null,u=Yf;u!==null;){var h=u.next,m=wy(u,i);m===0?(u.next=null,s===null?Yf=h:s.next=h,h===null&&(xl=s)):(s=u,(e!==0||(m&3)!==0)&&(qf=!0)),u=h}Zn!==0&&Zn!==5||Yu(e),Ms!==0&&(Ms=0)}function wy(e,i){for(var s=e.suspendedLanes,u=e.pingedLanes,h=e.expirationTimes,m=e.pendingLanes&-62914561;0<m;){var b=31-Pt(m),N=1<<b,X=h[b];X===-1?((N&s)===0||(N&u)!==0)&&(h[b]=le(N,i)):X<=i&&(e.expiredLanes|=N),m&=~N}if(i=hn,s=Be,s=mt(e,e===i?s:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),u=e.callbackNode,s===0||e===i&&(en===2||en===9)||e.cancelPendingCommit!==null)return u!==null&&u!==null&&ce(u),e.callbackNode=null,e.callbackPriority=0;if((s&3)===0||Xt(e,s)){if(i=s&-s,i===e.callbackPriority)return i;switch(u!==null&&ce(u),_n(s)){case 2:case 8:s=vt;break;case 32:s=dt;break;case 268435456:s=wt;break;default:s=dt}return u=Dy.bind(null,e),s=Ee(s,u),e.callbackPriority=i,e.callbackNode=s,i}return u!==null&&u!==null&&ce(u),e.callbackPriority=2,e.callbackNode=null,2}function Dy(e,i){if(Zn!==0&&Zn!==5)return e.callbackNode=null,e.callbackPriority=0,null;var s=e.callbackNode;if(Wf()&&e.callbackNode!==s)return null;var u=Be;return u=mt(e,e===hn?u:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),u===0?null:(fy(e,u,i),wy(e,A()),e.callbackNode!=null&&e.callbackNode===s?Dy.bind(null,e):null)}function Uy(e,i){if(Wf())return null;fy(e,i,!0)}function PT(){qT(function(){(Je&6)!==0?Ee(gt,OT):Cy()})}function dm(){if(Ms===0){var e=al;e===0&&(e=Dt,Dt<<=1,(Dt&261888)===0&&(Dt=256)),Ms=e}return Ms}function Ny(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:tf(""+e)}function Ly(e,i){var s=i.ownerDocument.createElement("input");return s.name=i.name,s.value=i.value,e.id&&s.setAttribute("form",e.id),i.parentNode.insertBefore(s,i),e=new FormData(e),s.parentNode.removeChild(s),e}function FT(e,i,s,u,h){if(i==="submit"&&s&&s.stateNode===h){var m=Ny((h[xe]||null).action),b=u.submitter;b&&(i=(i=b[xe]||null)?Ny(i.formAction):b.getAttribute("formAction"),i!==null&&(m=i,b=null));var N=new rf("action","action",null,u,h);e.push({event:N,listeners:[{instance:null,listener:function(){if(u.defaultPrevented){if(Ms!==0){var X=b?Ly(h,b):new FormData(h);Lp(s,{pending:!0,data:X,method:h.method,action:m},null,X)}}else typeof m=="function"&&(N.preventDefault(),X=b?Ly(h,b):new FormData(h),Lp(s,{pending:!0,data:X,method:h.method,action:m},m,X))},currentTarget:h}]})}}for(var pm=0;pm<Kd.length;pm++){var mm=Kd[pm],zT=mm.toLowerCase(),IT=mm[0].toUpperCase()+mm.slice(1);Xa(zT,"on"+IT)}Xa(cv,"onAnimationEnd"),Xa(fv,"onAnimationIteration"),Xa(hv,"onAnimationStart"),Xa("dblclick","onDoubleClick"),Xa("focusin","onFocus"),Xa("focusout","onBlur"),Xa(tT,"onTransitionRun"),Xa(eT,"onTransitionStart"),Xa(nT,"onTransitionCancel"),Xa(dv,"onTransitionEnd"),Nt("onMouseEnter",["mouseout","mouseover"]),Nt("onMouseLeave",["mouseout","mouseover"]),Nt("onPointerEnter",["pointerout","pointerover"]),Nt("onPointerLeave",["pointerout","pointerover"]),at("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),at("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),at("onBeforeInput",["compositionend","keypress","textInput","paste"]),at("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),at("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),at("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var qu="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),BT=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(qu));function Oy(e,i){i=(i&4)!==0;for(var s=0;s<e.length;s++){var u=e[s],h=u.event;u=u.listeners;t:{var m=void 0;if(i)for(var b=u.length-1;0<=b;b--){var N=u[b],X=N.instance,ot=N.currentTarget;if(N=N.listener,X!==m&&h.isPropagationStopped())break t;m=N,h.currentTarget=ot;try{m(h)}catch(yt){lf(yt)}h.currentTarget=null,m=X}else for(b=0;b<u.length;b++){if(N=u[b],X=N.instance,ot=N.currentTarget,N=N.listener,X!==m&&h.isPropagationStopped())break t;m=N,h.currentTarget=ot;try{m(h)}catch(yt){lf(yt)}h.currentTarget=null,m=X}}}}function ze(e,i){var s=i[In];s===void 0&&(s=i[In]=new Set);var u=e+"__bubble";s.has(u)||(Py(i,e,2,!1),s.add(u))}function _m(e,i,s){var u=0;i&&(u|=4),Py(s,e,u,i)}var jf="_reactListening"+Math.random().toString(36).slice(2);function gm(e){if(!e[jf]){e[jf]=!0,ut.forEach(function(s){s!=="selectionchange"&&(BT.has(s)||_m(s,!1,e),_m(s,!0,e))});var i=e.nodeType===9?e:e.ownerDocument;i===null||i[jf]||(i[jf]=!0,_m("selectionchange",!1,i))}}function Py(e,i,s,u){switch(cS(i)){case 2:var h=dA;break;case 8:h=pA;break;default:h=Nm}s=h.bind(null,i,s,e),h=void 0,!zd||i!=="touchstart"&&i!=="touchmove"&&i!=="wheel"||(h=!0),u?h!==void 0?e.addEventListener(i,s,{capture:!0,passive:h}):e.addEventListener(i,s,!0):h!==void 0?e.addEventListener(i,s,{passive:h}):e.addEventListener(i,s,!1)}function vm(e,i,s,u,h){var m=u;if((i&1)===0&&(i&2)===0&&u!==null)t:for(;;){if(u===null)return;var b=u.tag;if(b===3||b===4){var N=u.stateNode.containerInfo;if(N===h)break;if(b===4)for(b=u.return;b!==null;){var X=b.tag;if((X===3||X===4)&&b.stateNode.containerInfo===h)return;b=b.return}for(;N!==null;){if(b=vn(N),b===null)return;if(X=b.tag,X===5||X===6||X===26||X===27){u=m=b;continue t}N=N.parentNode}}u=u.return}Hg(function(){var ot=m,yt=Pd(s),Mt=[];t:{var ct=pv.get(e);if(ct!==void 0){var pt=rf,$t=e;switch(e){case"keypress":if(nf(s)===0)break t;case"keydown":case"keyup":pt=Nb;break;case"focusin":$t="focus",pt=Gd;break;case"focusout":$t="blur",pt=Gd;break;case"beforeblur":case"afterblur":pt=Gd;break;case"click":if(s.button===2)break t;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":pt=kg;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":pt=yb;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":pt=Pb;break;case cv:case fv:case hv:pt=Eb;break;case dv:pt=zb;break;case"scroll":case"scrollend":pt=vb;break;case"wheel":pt=Bb;break;case"copy":case"cut":case"paste":pt=Tb;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":pt=Wg;break;case"toggle":case"beforetoggle":pt=Gb}var fe=(i&4)!==0,cn=!fe&&(e==="scroll"||e==="scrollend"),$=fe?ct!==null?ct+"Capture":null:ct;fe=[];for(var Z=ot,rt;Z!==null;){var St=Z;if(rt=St.stateNode,St=St.tag,St!==5&&St!==26&&St!==27||rt===null||$===null||(St=mu(Z,$),St!=null&&fe.push(ju(Z,St,rt))),cn)break;Z=Z.return}0<fe.length&&(ct=new pt(ct,$t,null,s,yt),Mt.push({event:ct,listeners:fe}))}}if((i&7)===0){t:{if(ct=e==="mouseover"||e==="pointerover",pt=e==="mouseout"||e==="pointerout",ct&&s!==Od&&($t=s.relatedTarget||s.fromElement)&&(vn($t)||$t[Pe]))break t;if((pt||ct)&&(ct=yt.window===yt?yt:(ct=yt.ownerDocument)?ct.defaultView||ct.parentWindow:window,pt?($t=s.relatedTarget||s.toElement,pt=ot,$t=$t?vn($t):null,$t!==null&&(cn=l($t),fe=$t.tag,$t!==cn||fe!==5&&fe!==27&&fe!==6)&&($t=null)):(pt=null,$t=ot),pt!==$t)){if(fe=kg,St="onMouseLeave",$="onMouseEnter",Z="mouse",(e==="pointerout"||e==="pointerover")&&(fe=Wg,St="onPointerLeave",$="onPointerEnter",Z="pointer"),cn=pt==null?ct:Sa(pt),rt=$t==null?ct:Sa($t),ct=new fe(St,Z+"leave",pt,s,yt),ct.target=cn,ct.relatedTarget=rt,St=null,vn(yt)===ot&&(fe=new fe($,Z+"enter",$t,s,yt),fe.target=rt,fe.relatedTarget=cn,St=fe),cn=St,pt&&$t)e:{for(fe=HT,$=pt,Z=$t,rt=0,St=$;St;St=fe(St))rt++;St=0;for(var ue=Z;ue;ue=fe(ue))St++;for(;0<rt-St;)$=fe($),rt--;for(;0<St-rt;)Z=fe(Z),St--;for(;rt--;){if($===Z||Z!==null&&$===Z.alternate){fe=$;break e}$=fe($),Z=fe(Z)}fe=null}else fe=null;pt!==null&&Fy(Mt,ct,pt,fe,!1),$t!==null&&cn!==null&&Fy(Mt,cn,$t,fe,!0)}}t:{if(ct=ot?Sa(ot):window,pt=ct.nodeName&&ct.nodeName.toLowerCase(),pt==="select"||pt==="input"&&ct.type==="file")var Ze=$g;else if(Qg(ct))if(tv)Ze=Qb;else{Ze=Zb;var ae=jb}else pt=ct.nodeName,!pt||pt.toLowerCase()!=="input"||ct.type!=="checkbox"&&ct.type!=="radio"?ot&&Yo(ot.elementType)&&(Ze=$g):Ze=Kb;if(Ze&&(Ze=Ze(e,ot))){Jg(Mt,Ze,s,yt);break t}ae&&ae(e,ct,ot),e==="focusout"&&ot&&ct.type==="number"&&ot.memoizedProps.value!=null&&Va(ct,"number",ct.value)}switch(ae=ot?Sa(ot):window,e){case"focusin":(Qg(ae)||ae.contentEditable==="true")&&(Ko=ae,qd=ot,Eu=null);break;case"focusout":Eu=qd=Ko=null;break;case"mousedown":jd=!0;break;case"contextmenu":case"mouseup":case"dragend":jd=!1,lv(Mt,s,yt);break;case"selectionchange":if($b)break;case"keydown":case"keyup":lv(Mt,s,yt)}var Ce;if(kd)t:{switch(e){case"compositionstart":var He="onCompositionStart";break t;case"compositionend":He="onCompositionEnd";break t;case"compositionupdate":He="onCompositionUpdate";break t}He=void 0}else Zo?Zg(e,s)&&(He="onCompositionEnd"):e==="keydown"&&s.keyCode===229&&(He="onCompositionStart");He&&(Yg&&s.locale!=="ko"&&(Zo||He!=="onCompositionStart"?He==="onCompositionEnd"&&Zo&&(Ce=Gg()):(ss=yt,Id="value"in ss?ss.value:ss.textContent,Zo=!0)),ae=Zf(ot,He),0<ae.length&&(He=new Xg(He,e,null,s,yt),Mt.push({event:He,listeners:ae}),Ce?He.data=Ce:(Ce=Kg(s),Ce!==null&&(He.data=Ce)))),(Ce=kb?Xb(e,s):Wb(e,s))&&(He=Zf(ot,"onBeforeInput"),0<He.length&&(ae=new Xg("onBeforeInput","beforeinput",null,s,yt),Mt.push({event:ae,listeners:He}),ae.data=Ce)),FT(Mt,e,ot,s,yt)}Oy(Mt,i)})}function ju(e,i,s){return{instance:e,listener:i,currentTarget:s}}function Zf(e,i){for(var s=i+"Capture",u=[];e!==null;){var h=e,m=h.stateNode;if(h=h.tag,h!==5&&h!==26&&h!==27||m===null||(h=mu(e,s),h!=null&&u.unshift(ju(e,h,m)),h=mu(e,i),h!=null&&u.push(ju(e,h,m))),e.tag===3)return u;e=e.return}return[]}function HT(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function Fy(e,i,s,u,h){for(var m=i._reactName,b=[];s!==null&&s!==u;){var N=s,X=N.alternate,ot=N.stateNode;if(N=N.tag,X!==null&&X===u)break;N!==5&&N!==26&&N!==27||ot===null||(X=ot,h?(ot=mu(s,m),ot!=null&&b.unshift(ju(s,ot,X))):h||(ot=mu(s,m),ot!=null&&b.push(ju(s,ot,X)))),s=s.return}b.length!==0&&e.push({event:i,listeners:b})}var GT=/\r\n?/g,VT=/\u0000|\uFFFD/g;function zy(e){return(typeof e=="string"?e:""+e).replace(GT,`
`).replace(VT,"")}function Iy(e,i){return i=zy(i),zy(e)===i}function un(e,i,s,u,h,m){switch(s){case"children":typeof u=="string"?i==="body"||i==="textarea"&&u===""||Ri(e,u):(typeof u=="number"||typeof u=="bigint")&&i!=="body"&&Ri(e,""+u);break;case"className":ye(e,"class",u);break;case"tabIndex":ye(e,"tabindex",u);break;case"dir":case"role":case"viewBox":case"width":case"height":ye(e,s,u);break;case"style":Er(e,u,m);break;case"data":if(i!=="object"){ye(e,"data",u);break}case"src":case"href":if(u===""&&(i!=="a"||s!=="href")){e.removeAttribute(s);break}if(u==null||typeof u=="function"||typeof u=="symbol"||typeof u=="boolean"){e.removeAttribute(s);break}u=tf(""+u),e.setAttribute(s,u);break;case"action":case"formAction":if(typeof u=="function"){e.setAttribute(s,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof m=="function"&&(s==="formAction"?(i!=="input"&&un(e,i,"name",h.name,h,null),un(e,i,"formEncType",h.formEncType,h,null),un(e,i,"formMethod",h.formMethod,h,null),un(e,i,"formTarget",h.formTarget,h,null)):(un(e,i,"encType",h.encType,h,null),un(e,i,"method",h.method,h,null),un(e,i,"target",h.target,h,null)));if(u==null||typeof u=="symbol"||typeof u=="boolean"){e.removeAttribute(s);break}u=tf(""+u),e.setAttribute(s,u);break;case"onClick":u!=null&&(e.onclick=br);break;case"onScroll":u!=null&&ze("scroll",e);break;case"onScrollEnd":u!=null&&ze("scrollend",e);break;case"dangerouslySetInnerHTML":if(u!=null){if(typeof u!="object"||!("__html"in u))throw Error(a(61));if(s=u.__html,s!=null){if(h.children!=null)throw Error(a(60));e.innerHTML=s}}break;case"multiple":e.multiple=u&&typeof u!="function"&&typeof u!="symbol";break;case"muted":e.muted=u&&typeof u!="function"&&typeof u!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(u==null||typeof u=="function"||typeof u=="boolean"||typeof u=="symbol"){e.removeAttribute("xlink:href");break}s=tf(""+u),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",s);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":u!=null&&typeof u!="function"&&typeof u!="symbol"?e.setAttribute(s,""+u):e.removeAttribute(s);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":u&&typeof u!="function"&&typeof u!="symbol"?e.setAttribute(s,""):e.removeAttribute(s);break;case"capture":case"download":u===!0?e.setAttribute(s,""):u!==!1&&u!=null&&typeof u!="function"&&typeof u!="symbol"?e.setAttribute(s,u):e.removeAttribute(s);break;case"cols":case"rows":case"size":case"span":u!=null&&typeof u!="function"&&typeof u!="symbol"&&!isNaN(u)&&1<=u?e.setAttribute(s,u):e.removeAttribute(s);break;case"rowSpan":case"start":u==null||typeof u=="function"||typeof u=="symbol"||isNaN(u)?e.removeAttribute(s):e.setAttribute(s,u);break;case"popover":ze("beforetoggle",e),ze("toggle",e),me(e,"popover",u);break;case"xlinkActuate":Qt(e,"http://www.w3.org/1999/xlink","xlink:actuate",u);break;case"xlinkArcrole":Qt(e,"http://www.w3.org/1999/xlink","xlink:arcrole",u);break;case"xlinkRole":Qt(e,"http://www.w3.org/1999/xlink","xlink:role",u);break;case"xlinkShow":Qt(e,"http://www.w3.org/1999/xlink","xlink:show",u);break;case"xlinkTitle":Qt(e,"http://www.w3.org/1999/xlink","xlink:title",u);break;case"xlinkType":Qt(e,"http://www.w3.org/1999/xlink","xlink:type",u);break;case"xmlBase":Qt(e,"http://www.w3.org/XML/1998/namespace","xml:base",u);break;case"xmlLang":Qt(e,"http://www.w3.org/XML/1998/namespace","xml:lang",u);break;case"xmlSpace":Qt(e,"http://www.w3.org/XML/1998/namespace","xml:space",u);break;case"is":me(e,"is",u);break;case"innerText":case"textContent":break;default:(!(2<s.length)||s[0]!=="o"&&s[0]!=="O"||s[1]!=="n"&&s[1]!=="N")&&(s=_b.get(s)||s,me(e,s,u))}}function xm(e,i,s,u,h,m){switch(s){case"style":Er(e,u,m);break;case"dangerouslySetInnerHTML":if(u!=null){if(typeof u!="object"||!("__html"in u))throw Error(a(61));if(s=u.__html,s!=null){if(h.children!=null)throw Error(a(60));e.innerHTML=s}}break;case"children":typeof u=="string"?Ri(e,u):(typeof u=="number"||typeof u=="bigint")&&Ri(e,""+u);break;case"onScroll":u!=null&&ze("scroll",e);break;case"onScrollEnd":u!=null&&ze("scrollend",e);break;case"onClick":u!=null&&(e.onclick=br);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!st.hasOwnProperty(s))t:{if(s[0]==="o"&&s[1]==="n"&&(h=s.endsWith("Capture"),i=s.slice(2,h?s.length-7:void 0),m=e[xe]||null,m=m!=null?m[s]:null,typeof m=="function"&&e.removeEventListener(i,m,h),typeof u=="function")){typeof m!="function"&&m!==null&&(s in e?e[s]=null:e.hasAttribute(s)&&e.removeAttribute(s)),e.addEventListener(i,u,h);break t}s in e?e[s]=u:u===!0?e.setAttribute(s,""):me(e,s,u)}}}function ui(e,i,s){switch(i){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":ze("error",e),ze("load",e);var u=!1,h=!1,m;for(m in s)if(s.hasOwnProperty(m)){var b=s[m];if(b!=null)switch(m){case"src":u=!0;break;case"srcSet":h=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(a(137,i));default:un(e,i,m,b,s,null)}}h&&un(e,i,"srcSet",s.srcSet,s,null),u&&un(e,i,"src",s.src,s,null);return;case"input":ze("invalid",e);var N=m=b=h=null,X=null,ot=null;for(u in s)if(s.hasOwnProperty(u)){var yt=s[u];if(yt!=null)switch(u){case"name":h=yt;break;case"type":b=yt;break;case"checked":X=yt;break;case"defaultChecked":ot=yt;break;case"value":m=yt;break;case"defaultValue":N=yt;break;case"children":case"dangerouslySetInnerHTML":if(yt!=null)throw Error(a(137,i));break;default:un(e,i,u,yt,s,null)}}$i(e,m,N,X,ot,b,h,!1);return;case"select":ze("invalid",e),u=b=m=null;for(h in s)if(s.hasOwnProperty(h)&&(N=s[h],N!=null))switch(h){case"value":m=N;break;case"defaultValue":b=N;break;case"multiple":u=N;default:un(e,i,h,N,s,null)}i=m,s=b,e.multiple=!!u,i!=null?ta(e,!!u,i,!1):s!=null&&ta(e,!!u,s,!0);return;case"textarea":ze("invalid",e),m=h=u=null;for(b in s)if(s.hasOwnProperty(b)&&(N=s[b],N!=null))switch(b){case"value":u=N;break;case"defaultValue":h=N;break;case"children":m=N;break;case"dangerouslySetInnerHTML":if(N!=null)throw Error(a(91));break;default:un(e,i,b,N,s,null)}Bn(e,u,h,m);return;case"option":for(X in s)if(s.hasOwnProperty(X)&&(u=s[X],u!=null))switch(X){case"selected":e.selected=u&&typeof u!="function"&&typeof u!="symbol";break;default:un(e,i,X,u,s,null)}return;case"dialog":ze("beforetoggle",e),ze("toggle",e),ze("cancel",e),ze("close",e);break;case"iframe":case"object":ze("load",e);break;case"video":case"audio":for(u=0;u<qu.length;u++)ze(qu[u],e);break;case"image":ze("error",e),ze("load",e);break;case"details":ze("toggle",e);break;case"embed":case"source":case"link":ze("error",e),ze("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(ot in s)if(s.hasOwnProperty(ot)&&(u=s[ot],u!=null))switch(ot){case"children":case"dangerouslySetInnerHTML":throw Error(a(137,i));default:un(e,i,ot,u,s,null)}return;default:if(Yo(i)){for(yt in s)s.hasOwnProperty(yt)&&(u=s[yt],u!==void 0&&xm(e,i,yt,u,s,void 0));return}}for(N in s)s.hasOwnProperty(N)&&(u=s[N],u!=null&&un(e,i,N,u,s,null))}function kT(e,i,s,u){switch(i){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var h=null,m=null,b=null,N=null,X=null,ot=null,yt=null;for(pt in s){var Mt=s[pt];if(s.hasOwnProperty(pt)&&Mt!=null)switch(pt){case"checked":break;case"value":break;case"defaultValue":X=Mt;default:u.hasOwnProperty(pt)||un(e,i,pt,null,u,Mt)}}for(var ct in u){var pt=u[ct];if(Mt=s[ct],u.hasOwnProperty(ct)&&(pt!=null||Mt!=null))switch(ct){case"type":m=pt;break;case"name":h=pt;break;case"checked":ot=pt;break;case"defaultChecked":yt=pt;break;case"value":b=pt;break;case"defaultValue":N=pt;break;case"children":case"dangerouslySetInnerHTML":if(pt!=null)throw Error(a(137,i));break;default:pt!==Mt&&un(e,i,ct,pt,u,Mt)}}Ai(e,b,N,X,ot,yt,m,h);return;case"select":pt=b=N=ct=null;for(m in s)if(X=s[m],s.hasOwnProperty(m)&&X!=null)switch(m){case"value":break;case"multiple":pt=X;default:u.hasOwnProperty(m)||un(e,i,m,null,u,X)}for(h in u)if(m=u[h],X=s[h],u.hasOwnProperty(h)&&(m!=null||X!=null))switch(h){case"value":ct=m;break;case"defaultValue":N=m;break;case"multiple":b=m;default:m!==X&&un(e,i,h,m,u,X)}i=N,s=b,u=pt,ct!=null?ta(e,!!s,ct,!1):!!u!=!!s&&(i!=null?ta(e,!!s,i,!0):ta(e,!!s,s?[]:"",!1));return;case"textarea":pt=ct=null;for(N in s)if(h=s[N],s.hasOwnProperty(N)&&h!=null&&!u.hasOwnProperty(N))switch(N){case"value":break;case"children":break;default:un(e,i,N,null,u,h)}for(b in u)if(h=u[b],m=s[b],u.hasOwnProperty(b)&&(h!=null||m!=null))switch(b){case"value":ct=h;break;case"defaultValue":pt=h;break;case"children":break;case"dangerouslySetInnerHTML":if(h!=null)throw Error(a(91));break;default:h!==m&&un(e,i,b,h,u,m)}$e(e,ct,pt);return;case"option":for(var $t in s)if(ct=s[$t],s.hasOwnProperty($t)&&ct!=null&&!u.hasOwnProperty($t))switch($t){case"selected":e.selected=!1;break;default:un(e,i,$t,null,u,ct)}for(X in u)if(ct=u[X],pt=s[X],u.hasOwnProperty(X)&&ct!==pt&&(ct!=null||pt!=null))switch(X){case"selected":e.selected=ct&&typeof ct!="function"&&typeof ct!="symbol";break;default:un(e,i,X,ct,u,pt)}return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var fe in s)ct=s[fe],s.hasOwnProperty(fe)&&ct!=null&&!u.hasOwnProperty(fe)&&un(e,i,fe,null,u,ct);for(ot in u)if(ct=u[ot],pt=s[ot],u.hasOwnProperty(ot)&&ct!==pt&&(ct!=null||pt!=null))switch(ot){case"children":case"dangerouslySetInnerHTML":if(ct!=null)throw Error(a(137,i));break;default:un(e,i,ot,ct,u,pt)}return;default:if(Yo(i)){for(var cn in s)ct=s[cn],s.hasOwnProperty(cn)&&ct!==void 0&&!u.hasOwnProperty(cn)&&xm(e,i,cn,void 0,u,ct);for(yt in u)ct=u[yt],pt=s[yt],!u.hasOwnProperty(yt)||ct===pt||ct===void 0&&pt===void 0||xm(e,i,yt,ct,u,pt);return}}for(var $ in s)ct=s[$],s.hasOwnProperty($)&&ct!=null&&!u.hasOwnProperty($)&&un(e,i,$,null,u,ct);for(Mt in u)ct=u[Mt],pt=s[Mt],!u.hasOwnProperty(Mt)||ct===pt||ct==null&&pt==null||un(e,i,Mt,ct,u,pt)}function By(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function XT(){if(typeof performance.getEntriesByType=="function"){for(var e=0,i=0,s=performance.getEntriesByType("resource"),u=0;u<s.length;u++){var h=s[u],m=h.transferSize,b=h.initiatorType,N=h.duration;if(m&&N&&By(b)){for(b=0,N=h.responseEnd,u+=1;u<s.length;u++){var X=s[u],ot=X.startTime;if(ot>N)break;var yt=X.transferSize,Mt=X.initiatorType;yt&&By(Mt)&&(X=X.responseEnd,b+=yt*(X<N?1:(N-ot)/(X-ot)))}if(--u,i+=8*(m+b)/(h.duration/1e3),e++,10<e)break}}if(0<e)return i/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var ym=null,Sm=null;function Kf(e){return e.nodeType===9?e:e.ownerDocument}function Hy(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function Gy(e,i){if(e===0)switch(i){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&i==="foreignObject"?0:e}function Mm(e,i){return e==="textarea"||e==="noscript"||typeof i.children=="string"||typeof i.children=="number"||typeof i.children=="bigint"||typeof i.dangerouslySetInnerHTML=="object"&&i.dangerouslySetInnerHTML!==null&&i.dangerouslySetInnerHTML.__html!=null}var Em=null;function WT(){var e=window.event;return e&&e.type==="popstate"?e===Em?!1:(Em=e,!0):(Em=null,!1)}var Vy=typeof setTimeout=="function"?setTimeout:void 0,YT=typeof clearTimeout=="function"?clearTimeout:void 0,ky=typeof Promise=="function"?Promise:void 0,qT=typeof queueMicrotask=="function"?queueMicrotask:typeof ky<"u"?function(e){return ky.resolve(null).then(e).catch(jT)}:Vy;function jT(e){setTimeout(function(){throw e})}function Es(e){return e==="head"}function Xy(e,i){var s=i,u=0;do{var h=s.nextSibling;if(e.removeChild(s),h&&h.nodeType===8)if(s=h.data,s==="/$"||s==="/&"){if(u===0){e.removeChild(h),El(i);return}u--}else if(s==="$"||s==="$?"||s==="$~"||s==="$!"||s==="&")u++;else if(s==="html")Zu(e.ownerDocument.documentElement);else if(s==="head"){s=e.ownerDocument.head,Zu(s);for(var m=s.firstChild;m;){var b=m.nextSibling,N=m.nodeName;m[gn]||N==="SCRIPT"||N==="STYLE"||N==="LINK"&&m.rel.toLowerCase()==="stylesheet"||s.removeChild(m),m=b}}else s==="body"&&Zu(e.ownerDocument.body);s=h}while(s);El(i)}function Wy(e,i){var s=e;e=0;do{var u=s.nextSibling;if(s.nodeType===1?i?(s._stashedDisplay=s.style.display,s.style.display="none"):(s.style.display=s._stashedDisplay||"",s.getAttribute("style")===""&&s.removeAttribute("style")):s.nodeType===3&&(i?(s._stashedText=s.nodeValue,s.nodeValue=""):s.nodeValue=s._stashedText||""),u&&u.nodeType===8)if(s=u.data,s==="/$"){if(e===0)break;e--}else s!=="$"&&s!=="$?"&&s!=="$~"&&s!=="$!"||e++;s=u}while(s)}function bm(e){var i=e.firstChild;for(i&&i.nodeType===10&&(i=i.nextSibling);i;){var s=i;switch(i=i.nextSibling,s.nodeName){case"HTML":case"HEAD":case"BODY":bm(s),Tn(s);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(s.rel.toLowerCase()==="stylesheet")continue}e.removeChild(s)}}function ZT(e,i,s,u){for(;e.nodeType===1;){var h=s;if(e.nodeName.toLowerCase()!==i.toLowerCase()){if(!u&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(u){if(!e[gn])switch(i){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(m=e.getAttribute("rel"),m==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(m!==h.rel||e.getAttribute("href")!==(h.href==null||h.href===""?null:h.href)||e.getAttribute("crossorigin")!==(h.crossOrigin==null?null:h.crossOrigin)||e.getAttribute("title")!==(h.title==null?null:h.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(m=e.getAttribute("src"),(m!==(h.src==null?null:h.src)||e.getAttribute("type")!==(h.type==null?null:h.type)||e.getAttribute("crossorigin")!==(h.crossOrigin==null?null:h.crossOrigin))&&m&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(i==="input"&&e.type==="hidden"){var m=h.name==null?null:""+h.name;if(h.type==="hidden"&&e.getAttribute("name")===m)return e}else return e;if(e=Ca(e.nextSibling),e===null)break}return null}function KT(e,i,s){if(i==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!s||(e=Ca(e.nextSibling),e===null))return null;return e}function Yy(e,i){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!i||(e=Ca(e.nextSibling),e===null))return null;return e}function Tm(e){return e.data==="$?"||e.data==="$~"}function Am(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function QT(e,i){var s=e.ownerDocument;if(e.data==="$~")e._reactRetry=i;else if(e.data!=="$?"||s.readyState!=="loading")i();else{var u=function(){i(),s.removeEventListener("DOMContentLoaded",u)};s.addEventListener("DOMContentLoaded",u),e._reactRetry=u}}function Ca(e){for(;e!=null;e=e.nextSibling){var i=e.nodeType;if(i===1||i===3)break;if(i===8){if(i=e.data,i==="$"||i==="$!"||i==="$?"||i==="$~"||i==="&"||i==="F!"||i==="F")break;if(i==="/$"||i==="/&")return null}}return e}var Rm=null;function qy(e){e=e.nextSibling;for(var i=0;e;){if(e.nodeType===8){var s=e.data;if(s==="/$"||s==="/&"){if(i===0)return Ca(e.nextSibling);i--}else s!=="$"&&s!=="$!"&&s!=="$?"&&s!=="$~"&&s!=="&"||i++}e=e.nextSibling}return null}function jy(e){e=e.previousSibling;for(var i=0;e;){if(e.nodeType===8){var s=e.data;if(s==="$"||s==="$!"||s==="$?"||s==="$~"||s==="&"){if(i===0)return e;i--}else s!=="/$"&&s!=="/&"||i++}e=e.previousSibling}return null}function Zy(e,i,s){switch(i=Kf(s),e){case"html":if(e=i.documentElement,!e)throw Error(a(452));return e;case"head":if(e=i.head,!e)throw Error(a(453));return e;case"body":if(e=i.body,!e)throw Error(a(454));return e;default:throw Error(a(451))}}function Zu(e){for(var i=e.attributes;i.length;)e.removeAttributeNode(i[0]);Tn(e)}var wa=new Map,Ky=new Set;function Qf(e){return typeof e.getRootNode=="function"?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var Hr=I.d;I.d={f:JT,r:$T,D:tA,C:eA,L:nA,m:iA,X:rA,S:aA,M:sA};function JT(){var e=Hr.f(),i=Vf();return e||i}function $T(e){var i=di(e);i!==null&&i.tag===5&&i.type==="form"?dx(i):Hr.r(e)}var yl=typeof document>"u"?null:document;function Qy(e,i,s){var u=yl;if(u&&typeof i=="string"&&i){var h=ve(i);h='link[rel="'+e+'"][href="'+h+'"]',typeof s=="string"&&(h+='[crossorigin="'+s+'"]'),Ky.has(h)||(Ky.add(h),e={rel:e,crossOrigin:s,href:i},u.querySelector(h)===null&&(i=u.createElement("link"),ui(i,"link",e),Y(i),u.head.appendChild(i)))}}function tA(e){Hr.D(e),Qy("dns-prefetch",e,null)}function eA(e,i){Hr.C(e,i),Qy("preconnect",e,i)}function nA(e,i,s){Hr.L(e,i,s);var u=yl;if(u&&e&&i){var h='link[rel="preload"][as="'+ve(i)+'"]';i==="image"&&s&&s.imageSrcSet?(h+='[imagesrcset="'+ve(s.imageSrcSet)+'"]',typeof s.imageSizes=="string"&&(h+='[imagesizes="'+ve(s.imageSizes)+'"]')):h+='[href="'+ve(e)+'"]';var m=h;switch(i){case"style":m=Sl(e);break;case"script":m=Ml(e)}wa.has(m)||(e=v({rel:"preload",href:i==="image"&&s&&s.imageSrcSet?void 0:e,as:i},s),wa.set(m,e),u.querySelector(h)!==null||i==="style"&&u.querySelector(Ku(m))||i==="script"&&u.querySelector(Qu(m))||(i=u.createElement("link"),ui(i,"link",e),Y(i),u.head.appendChild(i)))}}function iA(e,i){Hr.m(e,i);var s=yl;if(s&&e){var u=i&&typeof i.as=="string"?i.as:"script",h='link[rel="modulepreload"][as="'+ve(u)+'"][href="'+ve(e)+'"]',m=h;switch(u){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":m=Ml(e)}if(!wa.has(m)&&(e=v({rel:"modulepreload",href:e},i),wa.set(m,e),s.querySelector(h)===null)){switch(u){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(s.querySelector(Qu(m)))return}u=s.createElement("link"),ui(u,"link",e),Y(u),s.head.appendChild(u)}}}function aA(e,i,s){Hr.S(e,i,s);var u=yl;if(u&&e){var h=D(u).hoistableStyles,m=Sl(e);i=i||"default";var b=h.get(m);if(!b){var N={loading:0,preload:null};if(b=u.querySelector(Ku(m)))N.loading=5;else{e=v({rel:"stylesheet",href:e,"data-precedence":i},s),(s=wa.get(m))&&Cm(e,s);var X=b=u.createElement("link");Y(X),ui(X,"link",e),X._p=new Promise(function(ot,yt){X.onload=ot,X.onerror=yt}),X.addEventListener("load",function(){N.loading|=1}),X.addEventListener("error",function(){N.loading|=2}),N.loading|=4,Jf(b,i,u)}b={type:"stylesheet",instance:b,count:1,state:N},h.set(m,b)}}}function rA(e,i){Hr.X(e,i);var s=yl;if(s&&e){var u=D(s).hoistableScripts,h=Ml(e),m=u.get(h);m||(m=s.querySelector(Qu(h)),m||(e=v({src:e,async:!0},i),(i=wa.get(h))&&wm(e,i),m=s.createElement("script"),Y(m),ui(m,"link",e),s.head.appendChild(m)),m={type:"script",instance:m,count:1,state:null},u.set(h,m))}}function sA(e,i){Hr.M(e,i);var s=yl;if(s&&e){var u=D(s).hoistableScripts,h=Ml(e),m=u.get(h);m||(m=s.querySelector(Qu(h)),m||(e=v({src:e,async:!0,type:"module"},i),(i=wa.get(h))&&wm(e,i),m=s.createElement("script"),Y(m),ui(m,"link",e),s.head.appendChild(m)),m={type:"script",instance:m,count:1,state:null},u.set(h,m))}}function Jy(e,i,s,u){var h=(h=nt.current)?Qf(h):null;if(!h)throw Error(a(446));switch(e){case"meta":case"title":return null;case"style":return typeof s.precedence=="string"&&typeof s.href=="string"?(i=Sl(s.href),s=D(h).hoistableStyles,u=s.get(i),u||(u={type:"style",instance:null,count:0,state:null},s.set(i,u)),u):{type:"void",instance:null,count:0,state:null};case"link":if(s.rel==="stylesheet"&&typeof s.href=="string"&&typeof s.precedence=="string"){e=Sl(s.href);var m=D(h).hoistableStyles,b=m.get(e);if(b||(h=h.ownerDocument||h,b={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},m.set(e,b),(m=h.querySelector(Ku(e)))&&!m._p&&(b.instance=m,b.state.loading=5),wa.has(e)||(s={rel:"preload",as:"style",href:s.href,crossOrigin:s.crossOrigin,integrity:s.integrity,media:s.media,hrefLang:s.hrefLang,referrerPolicy:s.referrerPolicy},wa.set(e,s),m||oA(h,e,s,b.state))),i&&u===null)throw Error(a(528,""));return b}if(i&&u!==null)throw Error(a(529,""));return null;case"script":return i=s.async,s=s.src,typeof s=="string"&&i&&typeof i!="function"&&typeof i!="symbol"?(i=Ml(s),s=D(h).hoistableScripts,u=s.get(i),u||(u={type:"script",instance:null,count:0,state:null},s.set(i,u)),u):{type:"void",instance:null,count:0,state:null};default:throw Error(a(444,e))}}function Sl(e){return'href="'+ve(e)+'"'}function Ku(e){return'link[rel="stylesheet"]['+e+"]"}function $y(e){return v({},e,{"data-precedence":e.precedence,precedence:null})}function oA(e,i,s,u){e.querySelector('link[rel="preload"][as="style"]['+i+"]")?u.loading=1:(i=e.createElement("link"),u.preload=i,i.addEventListener("load",function(){return u.loading|=1}),i.addEventListener("error",function(){return u.loading|=2}),ui(i,"link",s),Y(i),e.head.appendChild(i))}function Ml(e){return'[src="'+ve(e)+'"]'}function Qu(e){return"script[async]"+e}function tS(e,i,s){if(i.count++,i.instance===null)switch(i.type){case"style":var u=e.querySelector('style[data-href~="'+ve(s.href)+'"]');if(u)return i.instance=u,Y(u),u;var h=v({},s,{"data-href":s.href,"data-precedence":s.precedence,href:null,precedence:null});return u=(e.ownerDocument||e).createElement("style"),Y(u),ui(u,"style",h),Jf(u,s.precedence,e),i.instance=u;case"stylesheet":h=Sl(s.href);var m=e.querySelector(Ku(h));if(m)return i.state.loading|=4,i.instance=m,Y(m),m;u=$y(s),(h=wa.get(h))&&Cm(u,h),m=(e.ownerDocument||e).createElement("link"),Y(m);var b=m;return b._p=new Promise(function(N,X){b.onload=N,b.onerror=X}),ui(m,"link",u),i.state.loading|=4,Jf(m,s.precedence,e),i.instance=m;case"script":return m=Ml(s.src),(h=e.querySelector(Qu(m)))?(i.instance=h,Y(h),h):(u=s,(h=wa.get(m))&&(u=v({},s),wm(u,h)),e=e.ownerDocument||e,h=e.createElement("script"),Y(h),ui(h,"link",u),e.head.appendChild(h),i.instance=h);case"void":return null;default:throw Error(a(443,i.type))}else i.type==="stylesheet"&&(i.state.loading&4)===0&&(u=i.instance,i.state.loading|=4,Jf(u,s.precedence,e));return i.instance}function Jf(e,i,s){for(var u=s.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),h=u.length?u[u.length-1]:null,m=h,b=0;b<u.length;b++){var N=u[b];if(N.dataset.precedence===i)m=N;else if(m!==h)break}m?m.parentNode.insertBefore(e,m.nextSibling):(i=s.nodeType===9?s.head:s,i.insertBefore(e,i.firstChild))}function Cm(e,i){e.crossOrigin==null&&(e.crossOrigin=i.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=i.referrerPolicy),e.title==null&&(e.title=i.title)}function wm(e,i){e.crossOrigin==null&&(e.crossOrigin=i.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=i.referrerPolicy),e.integrity==null&&(e.integrity=i.integrity)}var $f=null;function eS(e,i,s){if($f===null){var u=new Map,h=$f=new Map;h.set(s,u)}else h=$f,u=h.get(s),u||(u=new Map,h.set(s,u));if(u.has(e))return u;for(u.set(e,null),s=s.getElementsByTagName(e),h=0;h<s.length;h++){var m=s[h];if(!(m[gn]||m[Te]||e==="link"&&m.getAttribute("rel")==="stylesheet")&&m.namespaceURI!=="http://www.w3.org/2000/svg"){var b=m.getAttribute(i)||"";b=e+b;var N=u.get(b);N?N.push(m):u.set(b,[m])}}return u}function nS(e,i,s){e=e.ownerDocument||e,e.head.insertBefore(s,i==="title"?e.querySelector("head > title"):null)}function lA(e,i,s){if(s===1||i.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof i.precedence!="string"||typeof i.href!="string"||i.href==="")break;return!0;case"link":if(typeof i.rel!="string"||typeof i.href!="string"||i.href===""||i.onLoad||i.onError)break;switch(i.rel){case"stylesheet":return e=i.disabled,typeof i.precedence=="string"&&e==null;default:return!0}case"script":if(i.async&&typeof i.async!="function"&&typeof i.async!="symbol"&&!i.onLoad&&!i.onError&&i.src&&typeof i.src=="string")return!0}return!1}function iS(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function uA(e,i,s,u){if(s.type==="stylesheet"&&(typeof u.media!="string"||matchMedia(u.media).matches!==!1)&&(s.state.loading&4)===0){if(s.instance===null){var h=Sl(u.href),m=i.querySelector(Ku(h));if(m){i=m._p,i!==null&&typeof i=="object"&&typeof i.then=="function"&&(e.count++,e=th.bind(e),i.then(e,e)),s.state.loading|=4,s.instance=m,Y(m);return}m=i.ownerDocument||i,u=$y(u),(h=wa.get(h))&&Cm(u,h),m=m.createElement("link"),Y(m);var b=m;b._p=new Promise(function(N,X){b.onload=N,b.onerror=X}),ui(m,"link",u),s.instance=m}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(s,i),(i=s.state.preload)&&(s.state.loading&3)===0&&(e.count++,s=th.bind(e),i.addEventListener("load",s),i.addEventListener("error",s))}}var Dm=0;function cA(e,i){return e.stylesheets&&e.count===0&&nh(e,e.stylesheets),0<e.count||0<e.imgCount?function(s){var u=setTimeout(function(){if(e.stylesheets&&nh(e,e.stylesheets),e.unsuspend){var m=e.unsuspend;e.unsuspend=null,m()}},6e4+i);0<e.imgBytes&&Dm===0&&(Dm=62500*XT());var h=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&nh(e,e.stylesheets),e.unsuspend)){var m=e.unsuspend;e.unsuspend=null,m()}},(e.imgBytes>Dm?50:800)+i);return e.unsuspend=s,function(){e.unsuspend=null,clearTimeout(u),clearTimeout(h)}}:null}function th(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)nh(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var eh=null;function nh(e,i){e.stylesheets=null,e.unsuspend!==null&&(e.count++,eh=new Map,i.forEach(fA,e),eh=null,th.call(e))}function fA(e,i){if(!(i.state.loading&4)){var s=eh.get(e);if(s)var u=s.get(null);else{s=new Map,eh.set(e,s);for(var h=e.querySelectorAll("link[data-precedence],style[data-precedence]"),m=0;m<h.length;m++){var b=h[m];(b.nodeName==="LINK"||b.getAttribute("media")!=="not all")&&(s.set(b.dataset.precedence,b),u=b)}u&&s.set(null,u)}h=i.instance,b=h.getAttribute("data-precedence"),m=s.get(b)||u,m===u&&s.set(null,h),s.set(b,h),this.count++,u=th.bind(this),h.addEventListener("load",u),h.addEventListener("error",u),m?m.parentNode.insertBefore(h,m.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(h,e.firstChild)),i.state.loading|=4}}var Ju={$$typeof:U,Provider:null,Consumer:null,_currentValue:it,_currentValue2:it,_threadCount:0};function hA(e,i,s,u,h,m,b,N,X){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Vt(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Vt(0),this.hiddenUpdates=Vt(null),this.identifierPrefix=u,this.onUncaughtError=h,this.onCaughtError=m,this.onRecoverableError=b,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=X,this.incompleteTransitions=new Map}function aS(e,i,s,u,h,m,b,N,X,ot,yt,Mt){return e=new hA(e,i,s,b,X,ot,yt,Mt,N),i=1,m===!0&&(i|=24),m=na(3,null,null,i),e.current=m,m.stateNode=e,i=up(),i.refCount++,e.pooledCache=i,i.refCount++,m.memoizedState={element:u,isDehydrated:s,cache:i},dp(m),e}function rS(e){return e?(e=$o,e):$o}function sS(e,i,s,u,h,m){h=rS(h),u.context===null?u.context=h:u.pendingContext=h,u=hs(i),u.payload={element:s},m=m===void 0?null:m,m!==null&&(u.callback=m),s=ds(e,u,i),s!==null&&(ki(s,e,i),Du(s,e,i))}function oS(e,i){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var s=e.retryLane;e.retryLane=s!==0&&s<i?s:i}}function Um(e,i){oS(e,i),(e=e.alternate)&&oS(e,i)}function lS(e){if(e.tag===13||e.tag===31){var i=eo(e,67108864);i!==null&&ki(i,e,67108864),Um(e,67108864)}}function uS(e){if(e.tag===13||e.tag===31){var i=oa();i=de(i);var s=eo(e,i);s!==null&&ki(s,e,i),Um(e,i)}}var ih=!0;function dA(e,i,s,u){var h=F.T;F.T=null;var m=I.p;try{I.p=2,Nm(e,i,s,u)}finally{I.p=m,F.T=h}}function pA(e,i,s,u){var h=F.T;F.T=null;var m=I.p;try{I.p=8,Nm(e,i,s,u)}finally{I.p=m,F.T=h}}function Nm(e,i,s,u){if(ih){var h=Lm(u);if(h===null)vm(e,i,u,ah,s),fS(e,u);else if(_A(h,e,i,s,u))u.stopPropagation();else if(fS(e,u),i&4&&-1<mA.indexOf(e)){for(;h!==null;){var m=di(h);if(m!==null)switch(m.tag){case 3:if(m=m.stateNode,m.current.memoizedState.isDehydrated){var b=bt(m.pendingLanes);if(b!==0){var N=m;for(N.pendingLanes|=2,N.entangledLanes|=2;b;){var X=1<<31-Pt(b);N.entanglements[1]|=X,b&=~X}ar(m),(Je&6)===0&&(Hf=A()+500,Yu(0))}}break;case 31:case 13:N=eo(m,2),N!==null&&ki(N,m,2),Vf(),Um(m,2)}if(m=Lm(u),m===null&&vm(e,i,u,ah,s),m===h)break;h=m}h!==null&&u.stopPropagation()}else vm(e,i,u,null,s)}}function Lm(e){return e=Pd(e),Om(e)}var ah=null;function Om(e){if(ah=null,e=vn(e),e!==null){var i=l(e);if(i===null)e=null;else{var s=i.tag;if(s===13){if(e=c(i),e!==null)return e;e=null}else if(s===31){if(e=f(i),e!==null)return e;e=null}else if(s===3){if(i.stateNode.current.memoizedState.isDehydrated)return i.tag===3?i.stateNode.containerInfo:null;e=null}else i!==e&&(e=null)}}return ah=e,null}function cS(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(j()){case gt:return 2;case vt:return 8;case dt:case Gt:return 32;case wt:return 268435456;default:return 32}default:return 32}}var Pm=!1,bs=null,Ts=null,As=null,$u=new Map,tc=new Map,Rs=[],mA="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function fS(e,i){switch(e){case"focusin":case"focusout":bs=null;break;case"dragenter":case"dragleave":Ts=null;break;case"mouseover":case"mouseout":As=null;break;case"pointerover":case"pointerout":$u.delete(i.pointerId);break;case"gotpointercapture":case"lostpointercapture":tc.delete(i.pointerId)}}function ec(e,i,s,u,h,m){return e===null||e.nativeEvent!==m?(e={blockedOn:i,domEventName:s,eventSystemFlags:u,nativeEvent:m,targetContainers:[h]},i!==null&&(i=di(i),i!==null&&lS(i)),e):(e.eventSystemFlags|=u,i=e.targetContainers,h!==null&&i.indexOf(h)===-1&&i.push(h),e)}function _A(e,i,s,u,h){switch(i){case"focusin":return bs=ec(bs,e,i,s,u,h),!0;case"dragenter":return Ts=ec(Ts,e,i,s,u,h),!0;case"mouseover":return As=ec(As,e,i,s,u,h),!0;case"pointerover":var m=h.pointerId;return $u.set(m,ec($u.get(m)||null,e,i,s,u,h)),!0;case"gotpointercapture":return m=h.pointerId,tc.set(m,ec(tc.get(m)||null,e,i,s,u,h)),!0}return!1}function hS(e){var i=vn(e.target);if(i!==null){var s=l(i);if(s!==null){if(i=s.tag,i===13){if(i=c(s),i!==null){e.blockedOn=i,rn(e.priority,function(){uS(s)});return}}else if(i===31){if(i=f(s),i!==null){e.blockedOn=i,rn(e.priority,function(){uS(s)});return}}else if(i===3&&s.stateNode.current.memoizedState.isDehydrated){e.blockedOn=s.tag===3?s.stateNode.containerInfo:null;return}}}e.blockedOn=null}function rh(e){if(e.blockedOn!==null)return!1;for(var i=e.targetContainers;0<i.length;){var s=Lm(e.nativeEvent);if(s===null){s=e.nativeEvent;var u=new s.constructor(s.type,s);Od=u,s.target.dispatchEvent(u),Od=null}else return i=di(s),i!==null&&lS(i),e.blockedOn=s,!1;i.shift()}return!0}function dS(e,i,s){rh(e)&&s.delete(i)}function gA(){Pm=!1,bs!==null&&rh(bs)&&(bs=null),Ts!==null&&rh(Ts)&&(Ts=null),As!==null&&rh(As)&&(As=null),$u.forEach(dS),tc.forEach(dS)}function sh(e,i){e.blockedOn===i&&(e.blockedOn=null,Pm||(Pm=!0,o.unstable_scheduleCallback(o.unstable_NormalPriority,gA)))}var oh=null;function pS(e){oh!==e&&(oh=e,o.unstable_scheduleCallback(o.unstable_NormalPriority,function(){oh===e&&(oh=null);for(var i=0;i<e.length;i+=3){var s=e[i],u=e[i+1],h=e[i+2];if(typeof u!="function"){if(Om(u||s)===null)continue;break}var m=di(s);m!==null&&(e.splice(i,3),i-=3,Lp(m,{pending:!0,data:h,method:s.method,action:u},u,h))}}))}function El(e){function i(X){return sh(X,e)}bs!==null&&sh(bs,e),Ts!==null&&sh(Ts,e),As!==null&&sh(As,e),$u.forEach(i),tc.forEach(i);for(var s=0;s<Rs.length;s++){var u=Rs[s];u.blockedOn===e&&(u.blockedOn=null)}for(;0<Rs.length&&(s=Rs[0],s.blockedOn===null);)hS(s),s.blockedOn===null&&Rs.shift();if(s=(e.ownerDocument||e).$$reactFormReplay,s!=null)for(u=0;u<s.length;u+=3){var h=s[u],m=s[u+1],b=h[xe]||null;if(typeof m=="function")b||pS(s);else if(b){var N=null;if(m&&m.hasAttribute("formAction")){if(h=m,b=m[xe]||null)N=b.formAction;else if(Om(h)!==null)continue}else N=b.action;typeof N=="function"?s[u+1]=N:(s.splice(u,3),u-=3),pS(s)}}}function mS(){function e(m){m.canIntercept&&m.info==="react-transition"&&m.intercept({handler:function(){return new Promise(function(b){return h=b})},focusReset:"manual",scroll:"manual"})}function i(){h!==null&&(h(),h=null),u||setTimeout(s,20)}function s(){if(!u&&!navigation.transition){var m=navigation.currentEntry;m&&m.url!=null&&navigation.navigate(m.url,{state:m.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var u=!1,h=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",i),navigation.addEventListener("navigateerror",i),setTimeout(s,100),function(){u=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",i),navigation.removeEventListener("navigateerror",i),h!==null&&(h(),h=null)}}}function Fm(e){this._internalRoot=e}lh.prototype.render=Fm.prototype.render=function(e){var i=this._internalRoot;if(i===null)throw Error(a(409));var s=i.current,u=oa();sS(s,u,e,i,null,null)},lh.prototype.unmount=Fm.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var i=e.containerInfo;sS(e.current,2,null,e,null,null),Vf(),i[Pe]=null}};function lh(e){this._internalRoot=e}lh.prototype.unstable_scheduleHydration=function(e){if(e){var i=ge();e={blockedOn:null,target:e,priority:i};for(var s=0;s<Rs.length&&i!==0&&i<Rs[s].priority;s++);Rs.splice(s,0,e),s===0&&hS(e)}};var _S=t.version;if(_S!=="19.2.4")throw Error(a(527,_S,"19.2.4"));I.findDOMNode=function(e){var i=e._reactInternals;if(i===void 0)throw typeof e.render=="function"?Error(a(188)):(e=Object.keys(e).join(","),Error(a(268,e)));return e=d(i),e=e!==null?_(e):null,e=e===null?null:e.stateNode,e};var vA={bundleType:0,version:"19.2.4",rendererPackageName:"react-dom",currentDispatcherRef:F,reconcilerVersion:"19.2.4"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var uh=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!uh.isDisabled&&uh.supportsFiber)try{Rt=uh.inject(vA),At=uh}catch{}}return ic.createRoot=function(e,i){if(!r(e))throw Error(a(299));var s=!1,u="",h=Ex,m=bx,b=Tx;return i!=null&&(i.unstable_strictMode===!0&&(s=!0),i.identifierPrefix!==void 0&&(u=i.identifierPrefix),i.onUncaughtError!==void 0&&(h=i.onUncaughtError),i.onCaughtError!==void 0&&(m=i.onCaughtError),i.onRecoverableError!==void 0&&(b=i.onRecoverableError)),i=aS(e,1,!1,null,null,s,u,null,h,m,b,mS),e[Pe]=i.current,gm(e),new Fm(i)},ic.hydrateRoot=function(e,i,s){if(!r(e))throw Error(a(299));var u=!1,h="",m=Ex,b=bx,N=Tx,X=null;return s!=null&&(s.unstable_strictMode===!0&&(u=!0),s.identifierPrefix!==void 0&&(h=s.identifierPrefix),s.onUncaughtError!==void 0&&(m=s.onUncaughtError),s.onCaughtError!==void 0&&(b=s.onCaughtError),s.onRecoverableError!==void 0&&(N=s.onRecoverableError),s.formState!==void 0&&(X=s.formState)),i=aS(e,1,!0,i,s??null,u,h,X,m,b,N,mS),i.context=rS(null),s=i.current,u=oa(),u=de(u),h=hs(u),h.callback=null,ds(s,h,u),s=u,i.current.lanes=s,Jt(i,s),ar(i),e[Pe]=i.current,gm(e),new lh(i)},ic.version="19.2.4",ic}var AS;function CA(){if(AS)return Bm.exports;AS=1;function o(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(o)}catch(t){console.error(t)}}return o(),Bm.exports=RA(),Bm.exports}var wA=CA();/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const eg="183",DA=0,RS=1,UA=2,jh=1,NA=2,pc=3,Ys=0,Yi=1,jr=2,Jr=0,Yl=1,CS=2,wS=3,DS=4,LA=5,Ro=100,OA=101,PA=102,FA=103,zA=104,IA=200,BA=201,HA=202,GA=203,z_=204,I_=205,VA=206,kA=207,XA=208,WA=209,YA=210,qA=211,jA=212,ZA=213,KA=214,B_=0,H_=1,G_=2,tu=3,V_=4,k_=5,X_=6,W_=7,c1=0,QA=1,JA=2,gr=0,f1=1,h1=2,d1=3,p1=4,m1=5,_1=6,g1=7,v1=300,Ho=301,eu=302,km=303,Xm=304,Td=306,Y_=1e3,Kr=1001,q_=1002,ci=1003,$A=1004,ch=1005,Si=1006,Wm=1007,wo=1008,Fa=1009,x1=1010,y1=1011,zc=1012,ng=1013,Sr=1014,dr=1015,es=1016,ig=1017,ag=1018,Ic=1020,S1=35902,M1=35899,E1=1021,b1=1022,Ja=1023,ns=1026,Do=1027,T1=1028,rg=1029,nu=1030,sg=1031,og=1033,Zh=33776,Kh=33777,Qh=33778,Jh=33779,j_=35840,Z_=35841,K_=35842,Q_=35843,J_=36196,$_=37492,t0=37496,e0=37488,n0=37489,i0=37490,a0=37491,r0=37808,s0=37809,o0=37810,l0=37811,u0=37812,c0=37813,f0=37814,h0=37815,d0=37816,p0=37817,m0=37818,_0=37819,g0=37820,v0=37821,x0=36492,y0=36494,S0=36495,M0=36283,E0=36284,b0=36285,T0=36286,tR=3200,eR=0,nR=1,Fs="",Na="srgb",iu="srgb-linear",ud="linear",an="srgb",bl=7680,US=519,iR=512,aR=513,rR=514,lg=515,sR=516,oR=517,ug=518,lR=519,NS=35044,LS="300 es",pr=2e3,cd=2001;function uR(o){for(let t=o.length-1;t>=0;--t)if(o[t]>=65535)return!0;return!1}function fd(o){return document.createElementNS("http://www.w3.org/1999/xhtml",o)}function cR(){const o=fd("canvas");return o.style.display="block",o}const OS={};function PS(...o){const t="THREE."+o.shift();console.log(t,...o)}function A1(o){const t=o[0];if(typeof t=="string"&&t.startsWith("TSL:")){const n=o[1];n&&n.isStackTrace?o[0]+=" "+n.getLocation():o[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return o}function Me(...o){o=A1(o);const t="THREE."+o.shift();{const n=o[0];n&&n.isStackTrace?console.warn(n.getError(t)):console.warn(t,...o)}}function Qe(...o){o=A1(o);const t="THREE."+o.shift();{const n=o[0];n&&n.isStackTrace?console.error(n.getError(t)):console.error(t,...o)}}function hd(...o){const t=o.join(" ");t in OS||(OS[t]=!0,Me(...o))}function fR(o,t,n){return new Promise(function(a,r){function l(){switch(o.clientWaitSync(t,o.SYNC_FLUSH_COMMANDS_BIT,0)){case o.WAIT_FAILED:r();break;case o.TIMEOUT_EXPIRED:setTimeout(l,n);break;default:a()}}setTimeout(l,n)})}const hR={[B_]:H_,[G_]:X_,[V_]:W_,[tu]:k_,[H_]:B_,[X_]:G_,[W_]:V_,[k_]:tu};class hu{addEventListener(t,n){this._listeners===void 0&&(this._listeners={});const a=this._listeners;a[t]===void 0&&(a[t]=[]),a[t].indexOf(n)===-1&&a[t].push(n)}hasEventListener(t,n){const a=this._listeners;return a===void 0?!1:a[t]!==void 0&&a[t].indexOf(n)!==-1}removeEventListener(t,n){const a=this._listeners;if(a===void 0)return;const r=a[t];if(r!==void 0){const l=r.indexOf(n);l!==-1&&r.splice(l,1)}}dispatchEvent(t){const n=this._listeners;if(n===void 0)return;const a=n[t.type];if(a!==void 0){t.target=this;const r=a.slice(0);for(let l=0,c=r.length;l<c;l++)r[l].call(this,t);t.target=null}}}const mi=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Ym=Math.PI/180,A0=180/Math.PI;function Zc(){const o=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0,a=Math.random()*4294967295|0;return(mi[o&255]+mi[o>>8&255]+mi[o>>16&255]+mi[o>>24&255]+"-"+mi[t&255]+mi[t>>8&255]+"-"+mi[t>>16&15|64]+mi[t>>24&255]+"-"+mi[n&63|128]+mi[n>>8&255]+"-"+mi[n>>16&255]+mi[n>>24&255]+mi[a&255]+mi[a>>8&255]+mi[a>>16&255]+mi[a>>24&255]).toLowerCase()}function ke(o,t,n){return Math.max(t,Math.min(n,o))}function dR(o,t){return(o%t+t)%t}function qm(o,t,n){return(1-n)*o+n*t}function ac(o,t){switch(t.constructor){case Float32Array:return o;case Uint32Array:return o/4294967295;case Uint16Array:return o/65535;case Uint8Array:return o/255;case Int32Array:return Math.max(o/2147483647,-1);case Int16Array:return Math.max(o/32767,-1);case Int8Array:return Math.max(o/127,-1);default:throw new Error("Invalid component type.")}}function Xi(o,t){switch(t.constructor){case Float32Array:return o;case Uint32Array:return Math.round(o*4294967295);case Uint16Array:return Math.round(o*65535);case Uint8Array:return Math.round(o*255);case Int32Array:return Math.round(o*2147483647);case Int16Array:return Math.round(o*32767);case Int8Array:return Math.round(o*127);default:throw new Error("Invalid component type.")}}class fn{constructor(t=0,n=0){fn.prototype.isVector2=!0,this.x=t,this.y=n}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,n){return this.x=t,this.y=n,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,n){switch(t){case 0:this.x=n;break;case 1:this.y=n;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,n){return this.x=t.x+n.x,this.y=t.y+n.y,this}addScaledVector(t,n){return this.x+=t.x*n,this.y+=t.y*n,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,n){return this.x=t.x-n.x,this.y=t.y-n.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const n=this.x,a=this.y,r=t.elements;return this.x=r[0]*n+r[3]*a+r[6],this.y=r[1]*n+r[4]*a+r[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,n){return this.x=ke(this.x,t.x,n.x),this.y=ke(this.y,t.y,n.y),this}clampScalar(t,n){return this.x=ke(this.x,t,n),this.y=ke(this.y,t,n),this}clampLength(t,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(ke(a,t,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const n=Math.sqrt(this.lengthSq()*t.lengthSq());if(n===0)return Math.PI/2;const a=this.dot(t)/n;return Math.acos(ke(a,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const n=this.x-t.x,a=this.y-t.y;return n*n+a*a}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,n){return this.x+=(t.x-this.x)*n,this.y+=(t.y-this.y)*n,this}lerpVectors(t,n,a){return this.x=t.x+(n.x-t.x)*a,this.y=t.y+(n.y-t.y)*a,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,n=0){return this.x=t[n],this.y=t[n+1],this}toArray(t=[],n=0){return t[n]=this.x,t[n+1]=this.y,t}fromBufferAttribute(t,n){return this.x=t.getX(n),this.y=t.getY(n),this}rotateAround(t,n){const a=Math.cos(n),r=Math.sin(n),l=this.x-t.x,c=this.y-t.y;return this.x=l*a-c*r+t.x,this.y=l*r+c*a+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class du{constructor(t=0,n=0,a=0,r=1){this.isQuaternion=!0,this._x=t,this._y=n,this._z=a,this._w=r}static slerpFlat(t,n,a,r,l,c,f){let p=a[r+0],d=a[r+1],_=a[r+2],v=a[r+3],g=l[c+0],x=l[c+1],M=l[c+2],E=l[c+3];if(v!==E||p!==g||d!==x||_!==M){let y=p*g+d*x+_*M+v*E;y<0&&(g=-g,x=-x,M=-M,E=-E,y=-y);let S=1-f;if(y<.9995){const R=Math.acos(y),U=Math.sin(R);S=Math.sin(S*R)/U,f=Math.sin(f*R)/U,p=p*S+g*f,d=d*S+x*f,_=_*S+M*f,v=v*S+E*f}else{p=p*S+g*f,d=d*S+x*f,_=_*S+M*f,v=v*S+E*f;const R=1/Math.sqrt(p*p+d*d+_*_+v*v);p*=R,d*=R,_*=R,v*=R}}t[n]=p,t[n+1]=d,t[n+2]=_,t[n+3]=v}static multiplyQuaternionsFlat(t,n,a,r,l,c){const f=a[r],p=a[r+1],d=a[r+2],_=a[r+3],v=l[c],g=l[c+1],x=l[c+2],M=l[c+3];return t[n]=f*M+_*v+p*x-d*g,t[n+1]=p*M+_*g+d*v-f*x,t[n+2]=d*M+_*x+f*g-p*v,t[n+3]=_*M-f*v-p*g-d*x,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,n,a,r){return this._x=t,this._y=n,this._z=a,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,n=!0){const a=t._x,r=t._y,l=t._z,c=t._order,f=Math.cos,p=Math.sin,d=f(a/2),_=f(r/2),v=f(l/2),g=p(a/2),x=p(r/2),M=p(l/2);switch(c){case"XYZ":this._x=g*_*v+d*x*M,this._y=d*x*v-g*_*M,this._z=d*_*M+g*x*v,this._w=d*_*v-g*x*M;break;case"YXZ":this._x=g*_*v+d*x*M,this._y=d*x*v-g*_*M,this._z=d*_*M-g*x*v,this._w=d*_*v+g*x*M;break;case"ZXY":this._x=g*_*v-d*x*M,this._y=d*x*v+g*_*M,this._z=d*_*M+g*x*v,this._w=d*_*v-g*x*M;break;case"ZYX":this._x=g*_*v-d*x*M,this._y=d*x*v+g*_*M,this._z=d*_*M-g*x*v,this._w=d*_*v+g*x*M;break;case"YZX":this._x=g*_*v+d*x*M,this._y=d*x*v+g*_*M,this._z=d*_*M-g*x*v,this._w=d*_*v-g*x*M;break;case"XZY":this._x=g*_*v-d*x*M,this._y=d*x*v-g*_*M,this._z=d*_*M+g*x*v,this._w=d*_*v+g*x*M;break;default:Me("Quaternion: .setFromEuler() encountered an unknown order: "+c)}return n===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,n){const a=n/2,r=Math.sin(a);return this._x=t.x*r,this._y=t.y*r,this._z=t.z*r,this._w=Math.cos(a),this._onChangeCallback(),this}setFromRotationMatrix(t){const n=t.elements,a=n[0],r=n[4],l=n[8],c=n[1],f=n[5],p=n[9],d=n[2],_=n[6],v=n[10],g=a+f+v;if(g>0){const x=.5/Math.sqrt(g+1);this._w=.25/x,this._x=(_-p)*x,this._y=(l-d)*x,this._z=(c-r)*x}else if(a>f&&a>v){const x=2*Math.sqrt(1+a-f-v);this._w=(_-p)/x,this._x=.25*x,this._y=(r+c)/x,this._z=(l+d)/x}else if(f>v){const x=2*Math.sqrt(1+f-a-v);this._w=(l-d)/x,this._x=(r+c)/x,this._y=.25*x,this._z=(p+_)/x}else{const x=2*Math.sqrt(1+v-a-f);this._w=(c-r)/x,this._x=(l+d)/x,this._y=(p+_)/x,this._z=.25*x}return this._onChangeCallback(),this}setFromUnitVectors(t,n){let a=t.dot(n)+1;return a<1e-8?(a=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=a):(this._x=0,this._y=-t.z,this._z=t.y,this._w=a)):(this._x=t.y*n.z-t.z*n.y,this._y=t.z*n.x-t.x*n.z,this._z=t.x*n.y-t.y*n.x,this._w=a),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(ke(this.dot(t),-1,1)))}rotateTowards(t,n){const a=this.angleTo(t);if(a===0)return this;const r=Math.min(1,n/a);return this.slerp(t,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,n){const a=t._x,r=t._y,l=t._z,c=t._w,f=n._x,p=n._y,d=n._z,_=n._w;return this._x=a*_+c*f+r*d-l*p,this._y=r*_+c*p+l*f-a*d,this._z=l*_+c*d+a*p-r*f,this._w=c*_-a*f-r*p-l*d,this._onChangeCallback(),this}slerp(t,n){let a=t._x,r=t._y,l=t._z,c=t._w,f=this.dot(t);f<0&&(a=-a,r=-r,l=-l,c=-c,f=-f);let p=1-n;if(f<.9995){const d=Math.acos(f),_=Math.sin(d);p=Math.sin(p*d)/_,n=Math.sin(n*d)/_,this._x=this._x*p+a*n,this._y=this._y*p+r*n,this._z=this._z*p+l*n,this._w=this._w*p+c*n,this._onChangeCallback()}else this._x=this._x*p+a*n,this._y=this._y*p+r*n,this._z=this._z*p+l*n,this._w=this._w*p+c*n,this.normalize();return this}slerpQuaternions(t,n,a){return this.copy(t).slerp(n,a)}random(){const t=2*Math.PI*Math.random(),n=2*Math.PI*Math.random(),a=Math.random(),r=Math.sqrt(1-a),l=Math.sqrt(a);return this.set(r*Math.sin(t),r*Math.cos(t),l*Math.sin(n),l*Math.cos(n))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,n=0){return this._x=t[n],this._y=t[n+1],this._z=t[n+2],this._w=t[n+3],this._onChangeCallback(),this}toArray(t=[],n=0){return t[n]=this._x,t[n+1]=this._y,t[n+2]=this._z,t[n+3]=this._w,t}fromBufferAttribute(t,n){return this._x=t.getX(n),this._y=t.getY(n),this._z=t.getZ(n),this._w=t.getW(n),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class ft{constructor(t=0,n=0,a=0){ft.prototype.isVector3=!0,this.x=t,this.y=n,this.z=a}set(t,n,a){return a===void 0&&(a=this.z),this.x=t,this.y=n,this.z=a,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,n){switch(t){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,n){return this.x=t.x+n.x,this.y=t.y+n.y,this.z=t.z+n.z,this}addScaledVector(t,n){return this.x+=t.x*n,this.y+=t.y*n,this.z+=t.z*n,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,n){return this.x=t.x-n.x,this.y=t.y-n.y,this.z=t.z-n.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,n){return this.x=t.x*n.x,this.y=t.y*n.y,this.z=t.z*n.z,this}applyEuler(t){return this.applyQuaternion(FS.setFromEuler(t))}applyAxisAngle(t,n){return this.applyQuaternion(FS.setFromAxisAngle(t,n))}applyMatrix3(t){const n=this.x,a=this.y,r=this.z,l=t.elements;return this.x=l[0]*n+l[3]*a+l[6]*r,this.y=l[1]*n+l[4]*a+l[7]*r,this.z=l[2]*n+l[5]*a+l[8]*r,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const n=this.x,a=this.y,r=this.z,l=t.elements,c=1/(l[3]*n+l[7]*a+l[11]*r+l[15]);return this.x=(l[0]*n+l[4]*a+l[8]*r+l[12])*c,this.y=(l[1]*n+l[5]*a+l[9]*r+l[13])*c,this.z=(l[2]*n+l[6]*a+l[10]*r+l[14])*c,this}applyQuaternion(t){const n=this.x,a=this.y,r=this.z,l=t.x,c=t.y,f=t.z,p=t.w,d=2*(c*r-f*a),_=2*(f*n-l*r),v=2*(l*a-c*n);return this.x=n+p*d+c*v-f*_,this.y=a+p*_+f*d-l*v,this.z=r+p*v+l*_-c*d,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const n=this.x,a=this.y,r=this.z,l=t.elements;return this.x=l[0]*n+l[4]*a+l[8]*r,this.y=l[1]*n+l[5]*a+l[9]*r,this.z=l[2]*n+l[6]*a+l[10]*r,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,n){return this.x=ke(this.x,t.x,n.x),this.y=ke(this.y,t.y,n.y),this.z=ke(this.z,t.z,n.z),this}clampScalar(t,n){return this.x=ke(this.x,t,n),this.y=ke(this.y,t,n),this.z=ke(this.z,t,n),this}clampLength(t,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(ke(a,t,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,n){return this.x+=(t.x-this.x)*n,this.y+=(t.y-this.y)*n,this.z+=(t.z-this.z)*n,this}lerpVectors(t,n,a){return this.x=t.x+(n.x-t.x)*a,this.y=t.y+(n.y-t.y)*a,this.z=t.z+(n.z-t.z)*a,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,n){const a=t.x,r=t.y,l=t.z,c=n.x,f=n.y,p=n.z;return this.x=r*p-l*f,this.y=l*c-a*p,this.z=a*f-r*c,this}projectOnVector(t){const n=t.lengthSq();if(n===0)return this.set(0,0,0);const a=t.dot(this)/n;return this.copy(t).multiplyScalar(a)}projectOnPlane(t){return jm.copy(this).projectOnVector(t),this.sub(jm)}reflect(t){return this.sub(jm.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const n=Math.sqrt(this.lengthSq()*t.lengthSq());if(n===0)return Math.PI/2;const a=this.dot(t)/n;return Math.acos(ke(a,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const n=this.x-t.x,a=this.y-t.y,r=this.z-t.z;return n*n+a*a+r*r}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,n,a){const r=Math.sin(n)*t;return this.x=r*Math.sin(a),this.y=Math.cos(n)*t,this.z=r*Math.cos(a),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,n,a){return this.x=t*Math.sin(n),this.y=a,this.z=t*Math.cos(n),this}setFromMatrixPosition(t){const n=t.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this}setFromMatrixScale(t){const n=this.setFromMatrixColumn(t,0).length(),a=this.setFromMatrixColumn(t,1).length(),r=this.setFromMatrixColumn(t,2).length();return this.x=n,this.y=a,this.z=r,this}setFromMatrixColumn(t,n){return this.fromArray(t.elements,n*4)}setFromMatrix3Column(t,n){return this.fromArray(t.elements,n*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,n=0){return this.x=t[n],this.y=t[n+1],this.z=t[n+2],this}toArray(t=[],n=0){return t[n]=this.x,t[n+1]=this.y,t[n+2]=this.z,t}fromBufferAttribute(t,n){return this.x=t.getX(n),this.y=t.getY(n),this.z=t.getZ(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,n=Math.random()*2-1,a=Math.sqrt(1-n*n);return this.x=a*Math.cos(t),this.y=n,this.z=a*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const jm=new ft,FS=new du;class we{constructor(t,n,a,r,l,c,f,p,d){we.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,n,a,r,l,c,f,p,d)}set(t,n,a,r,l,c,f,p,d){const _=this.elements;return _[0]=t,_[1]=r,_[2]=f,_[3]=n,_[4]=l,_[5]=p,_[6]=a,_[7]=c,_[8]=d,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const n=this.elements,a=t.elements;return n[0]=a[0],n[1]=a[1],n[2]=a[2],n[3]=a[3],n[4]=a[4],n[5]=a[5],n[6]=a[6],n[7]=a[7],n[8]=a[8],this}extractBasis(t,n,a){return t.setFromMatrix3Column(this,0),n.setFromMatrix3Column(this,1),a.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const n=t.elements;return this.set(n[0],n[4],n[8],n[1],n[5],n[9],n[2],n[6],n[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,n){const a=t.elements,r=n.elements,l=this.elements,c=a[0],f=a[3],p=a[6],d=a[1],_=a[4],v=a[7],g=a[2],x=a[5],M=a[8],E=r[0],y=r[3],S=r[6],R=r[1],U=r[4],C=r[7],O=r[2],P=r[5],L=r[8];return l[0]=c*E+f*R+p*O,l[3]=c*y+f*U+p*P,l[6]=c*S+f*C+p*L,l[1]=d*E+_*R+v*O,l[4]=d*y+_*U+v*P,l[7]=d*S+_*C+v*L,l[2]=g*E+x*R+M*O,l[5]=g*y+x*U+M*P,l[8]=g*S+x*C+M*L,this}multiplyScalar(t){const n=this.elements;return n[0]*=t,n[3]*=t,n[6]*=t,n[1]*=t,n[4]*=t,n[7]*=t,n[2]*=t,n[5]*=t,n[8]*=t,this}determinant(){const t=this.elements,n=t[0],a=t[1],r=t[2],l=t[3],c=t[4],f=t[5],p=t[6],d=t[7],_=t[8];return n*c*_-n*f*d-a*l*_+a*f*p+r*l*d-r*c*p}invert(){const t=this.elements,n=t[0],a=t[1],r=t[2],l=t[3],c=t[4],f=t[5],p=t[6],d=t[7],_=t[8],v=_*c-f*d,g=f*p-_*l,x=d*l-c*p,M=n*v+a*g+r*x;if(M===0)return this.set(0,0,0,0,0,0,0,0,0);const E=1/M;return t[0]=v*E,t[1]=(r*d-_*a)*E,t[2]=(f*a-r*c)*E,t[3]=g*E,t[4]=(_*n-r*p)*E,t[5]=(r*l-f*n)*E,t[6]=x*E,t[7]=(a*p-d*n)*E,t[8]=(c*n-a*l)*E,this}transpose(){let t;const n=this.elements;return t=n[1],n[1]=n[3],n[3]=t,t=n[2],n[2]=n[6],n[6]=t,t=n[5],n[5]=n[7],n[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const n=this.elements;return t[0]=n[0],t[1]=n[3],t[2]=n[6],t[3]=n[1],t[4]=n[4],t[5]=n[7],t[6]=n[2],t[7]=n[5],t[8]=n[8],this}setUvTransform(t,n,a,r,l,c,f){const p=Math.cos(l),d=Math.sin(l);return this.set(a*p,a*d,-a*(p*c+d*f)+c+t,-r*d,r*p,-r*(-d*c+p*f)+f+n,0,0,1),this}scale(t,n){return this.premultiply(Zm.makeScale(t,n)),this}rotate(t){return this.premultiply(Zm.makeRotation(-t)),this}translate(t,n){return this.premultiply(Zm.makeTranslation(t,n)),this}makeTranslation(t,n){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,n,0,0,1),this}makeRotation(t){const n=Math.cos(t),a=Math.sin(t);return this.set(n,-a,0,a,n,0,0,0,1),this}makeScale(t,n){return this.set(t,0,0,0,n,0,0,0,1),this}equals(t){const n=this.elements,a=t.elements;for(let r=0;r<9;r++)if(n[r]!==a[r])return!1;return!0}fromArray(t,n=0){for(let a=0;a<9;a++)this.elements[a]=t[a+n];return this}toArray(t=[],n=0){const a=this.elements;return t[n]=a[0],t[n+1]=a[1],t[n+2]=a[2],t[n+3]=a[3],t[n+4]=a[4],t[n+5]=a[5],t[n+6]=a[6],t[n+7]=a[7],t[n+8]=a[8],t}clone(){return new this.constructor().fromArray(this.elements)}}const Zm=new we,zS=new we().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),IS=new we().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function pR(){const o={enabled:!0,workingColorSpace:iu,spaces:{},convert:function(r,l,c){return this.enabled===!1||l===c||!l||!c||(this.spaces[l].transfer===an&&(r.r=$r(r.r),r.g=$r(r.g),r.b=$r(r.b)),this.spaces[l].primaries!==this.spaces[c].primaries&&(r.applyMatrix3(this.spaces[l].toXYZ),r.applyMatrix3(this.spaces[c].fromXYZ)),this.spaces[c].transfer===an&&(r.r=ql(r.r),r.g=ql(r.g),r.b=ql(r.b))),r},workingToColorSpace:function(r,l){return this.convert(r,this.workingColorSpace,l)},colorSpaceToWorking:function(r,l){return this.convert(r,l,this.workingColorSpace)},getPrimaries:function(r){return this.spaces[r].primaries},getTransfer:function(r){return r===Fs?ud:this.spaces[r].transfer},getToneMappingMode:function(r){return this.spaces[r].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(r,l=this.workingColorSpace){return r.fromArray(this.spaces[l].luminanceCoefficients)},define:function(r){Object.assign(this.spaces,r)},_getMatrix:function(r,l,c){return r.copy(this.spaces[l].toXYZ).multiply(this.spaces[c].fromXYZ)},_getDrawingBufferColorSpace:function(r){return this.spaces[r].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(r=this.workingColorSpace){return this.spaces[r].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(r,l){return hd("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),o.workingToColorSpace(r,l)},toWorkingColorSpace:function(r,l){return hd("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),o.colorSpaceToWorking(r,l)}},t=[.64,.33,.3,.6,.15,.06],n=[.2126,.7152,.0722],a=[.3127,.329];return o.define({[iu]:{primaries:t,whitePoint:a,transfer:ud,toXYZ:zS,fromXYZ:IS,luminanceCoefficients:n,workingColorSpaceConfig:{unpackColorSpace:Na},outputColorSpaceConfig:{drawingBufferColorSpace:Na}},[Na]:{primaries:t,whitePoint:a,transfer:an,toXYZ:zS,fromXYZ:IS,luminanceCoefficients:n,outputColorSpaceConfig:{drawingBufferColorSpace:Na}}}),o}const Ye=pR();function $r(o){return o<.04045?o*.0773993808:Math.pow(o*.9478672986+.0521327014,2.4)}function ql(o){return o<.0031308?o*12.92:1.055*Math.pow(o,.41666)-.055}let Tl;class mR{static getDataURL(t,n="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let a;if(t instanceof HTMLCanvasElement)a=t;else{Tl===void 0&&(Tl=fd("canvas")),Tl.width=t.width,Tl.height=t.height;const r=Tl.getContext("2d");t instanceof ImageData?r.putImageData(t,0,0):r.drawImage(t,0,0,t.width,t.height),a=Tl}return a.toDataURL(n)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const n=fd("canvas");n.width=t.width,n.height=t.height;const a=n.getContext("2d");a.drawImage(t,0,0,t.width,t.height);const r=a.getImageData(0,0,t.width,t.height),l=r.data;for(let c=0;c<l.length;c++)l[c]=$r(l[c]/255)*255;return a.putImageData(r,0,0),n}else if(t.data){const n=t.data.slice(0);for(let a=0;a<n.length;a++)n instanceof Uint8Array||n instanceof Uint8ClampedArray?n[a]=Math.floor($r(n[a]/255)*255):n[a]=$r(n[a]);return{data:n,width:t.width,height:t.height}}else return Me("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let _R=0;class cg{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:_R++}),this.uuid=Zc(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){const n=this.data;return typeof HTMLVideoElement<"u"&&n instanceof HTMLVideoElement?t.set(n.videoWidth,n.videoHeight,0):typeof VideoFrame<"u"&&n instanceof VideoFrame?t.set(n.displayHeight,n.displayWidth,0):n!==null?t.set(n.width,n.height,n.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const n=t===void 0||typeof t=="string";if(!n&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const a={uuid:this.uuid,url:""},r=this.data;if(r!==null){let l;if(Array.isArray(r)){l=[];for(let c=0,f=r.length;c<f;c++)r[c].isDataTexture?l.push(Km(r[c].image)):l.push(Km(r[c]))}else l=Km(r);a.url=l}return n||(t.images[this.uuid]=a),a}}function Km(o){return typeof HTMLImageElement<"u"&&o instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&o instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&o instanceof ImageBitmap?mR.getDataURL(o):o.data?{data:Array.from(o.data),width:o.width,height:o.height,type:o.data.constructor.name}:(Me("Texture: Unable to serialize Texture."),{})}let gR=0;const Qm=new ft;class zi extends hu{constructor(t=zi.DEFAULT_IMAGE,n=zi.DEFAULT_MAPPING,a=Kr,r=Kr,l=Si,c=wo,f=Ja,p=Fa,d=zi.DEFAULT_ANISOTROPY,_=Fs){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:gR++}),this.uuid=Zc(),this.name="",this.source=new cg(t),this.mipmaps=[],this.mapping=n,this.channel=0,this.wrapS=a,this.wrapT=r,this.magFilter=l,this.minFilter=c,this.anisotropy=d,this.format=f,this.internalFormat=null,this.type=p,this.offset=new fn(0,0),this.repeat=new fn(1,1),this.center=new fn(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new we,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=_,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(Qm).x}get height(){return this.source.getSize(Qm).y}get depth(){return this.source.getSize(Qm).z}get image(){return this.source.data}set image(t=null){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,n){this.updateRanges.push({start:t,count:n})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(const n in t){const a=t[n];if(a===void 0){Me(`Texture.setValues(): parameter '${n}' has value of undefined.`);continue}const r=this[n];if(r===void 0){Me(`Texture.setValues(): property '${n}' does not exist.`);continue}r&&a&&r.isVector2&&a.isVector2||r&&a&&r.isVector3&&a.isVector3||r&&a&&r.isMatrix3&&a.isMatrix3?r.copy(a):this[n]=a}}toJSON(t){const n=t===void 0||typeof t=="string";if(!n&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const a={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(a.userData=this.userData),n||(t.textures[this.uuid]=a),a}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==v1)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case Y_:t.x=t.x-Math.floor(t.x);break;case Kr:t.x=t.x<0?0:1;break;case q_:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case Y_:t.y=t.y-Math.floor(t.y);break;case Kr:t.y=t.y<0?0:1;break;case q_:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}zi.DEFAULT_IMAGE=null;zi.DEFAULT_MAPPING=v1;zi.DEFAULT_ANISOTROPY=1;class Pn{constructor(t=0,n=0,a=0,r=1){Pn.prototype.isVector4=!0,this.x=t,this.y=n,this.z=a,this.w=r}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,n,a,r){return this.x=t,this.y=n,this.z=a,this.w=r,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,n){switch(t){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;case 3:this.w=n;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,n){return this.x=t.x+n.x,this.y=t.y+n.y,this.z=t.z+n.z,this.w=t.w+n.w,this}addScaledVector(t,n){return this.x+=t.x*n,this.y+=t.y*n,this.z+=t.z*n,this.w+=t.w*n,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,n){return this.x=t.x-n.x,this.y=t.y-n.y,this.z=t.z-n.z,this.w=t.w-n.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const n=this.x,a=this.y,r=this.z,l=this.w,c=t.elements;return this.x=c[0]*n+c[4]*a+c[8]*r+c[12]*l,this.y=c[1]*n+c[5]*a+c[9]*r+c[13]*l,this.z=c[2]*n+c[6]*a+c[10]*r+c[14]*l,this.w=c[3]*n+c[7]*a+c[11]*r+c[15]*l,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const n=Math.sqrt(1-t.w*t.w);return n<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/n,this.y=t.y/n,this.z=t.z/n),this}setAxisAngleFromRotationMatrix(t){let n,a,r,l;const p=t.elements,d=p[0],_=p[4],v=p[8],g=p[1],x=p[5],M=p[9],E=p[2],y=p[6],S=p[10];if(Math.abs(_-g)<.01&&Math.abs(v-E)<.01&&Math.abs(M-y)<.01){if(Math.abs(_+g)<.1&&Math.abs(v+E)<.1&&Math.abs(M+y)<.1&&Math.abs(d+x+S-3)<.1)return this.set(1,0,0,0),this;n=Math.PI;const U=(d+1)/2,C=(x+1)/2,O=(S+1)/2,P=(_+g)/4,L=(v+E)/4,T=(M+y)/4;return U>C&&U>O?U<.01?(a=0,r=.707106781,l=.707106781):(a=Math.sqrt(U),r=P/a,l=L/a):C>O?C<.01?(a=.707106781,r=0,l=.707106781):(r=Math.sqrt(C),a=P/r,l=T/r):O<.01?(a=.707106781,r=.707106781,l=0):(l=Math.sqrt(O),a=L/l,r=T/l),this.set(a,r,l,n),this}let R=Math.sqrt((y-M)*(y-M)+(v-E)*(v-E)+(g-_)*(g-_));return Math.abs(R)<.001&&(R=1),this.x=(y-M)/R,this.y=(v-E)/R,this.z=(g-_)/R,this.w=Math.acos((d+x+S-1)/2),this}setFromMatrixPosition(t){const n=t.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this.w=n[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,n){return this.x=ke(this.x,t.x,n.x),this.y=ke(this.y,t.y,n.y),this.z=ke(this.z,t.z,n.z),this.w=ke(this.w,t.w,n.w),this}clampScalar(t,n){return this.x=ke(this.x,t,n),this.y=ke(this.y,t,n),this.z=ke(this.z,t,n),this.w=ke(this.w,t,n),this}clampLength(t,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(ke(a,t,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,n){return this.x+=(t.x-this.x)*n,this.y+=(t.y-this.y)*n,this.z+=(t.z-this.z)*n,this.w+=(t.w-this.w)*n,this}lerpVectors(t,n,a){return this.x=t.x+(n.x-t.x)*a,this.y=t.y+(n.y-t.y)*a,this.z=t.z+(n.z-t.z)*a,this.w=t.w+(n.w-t.w)*a,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,n=0){return this.x=t[n],this.y=t[n+1],this.z=t[n+2],this.w=t[n+3],this}toArray(t=[],n=0){return t[n]=this.x,t[n+1]=this.y,t[n+2]=this.z,t[n+3]=this.w,t}fromBufferAttribute(t,n){return this.x=t.getX(n),this.y=t.getY(n),this.z=t.getZ(n),this.w=t.getW(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class vR extends hu{constructor(t=1,n=1,a={}){super(),a=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Si,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},a),this.isRenderTarget=!0,this.width=t,this.height=n,this.depth=a.depth,this.scissor=new Pn(0,0,t,n),this.scissorTest=!1,this.viewport=new Pn(0,0,t,n),this.textures=[];const r={width:t,height:n,depth:a.depth},l=new zi(r),c=a.count;for(let f=0;f<c;f++)this.textures[f]=l.clone(),this.textures[f].isRenderTargetTexture=!0,this.textures[f].renderTarget=this;this._setTextureOptions(a),this.depthBuffer=a.depthBuffer,this.stencilBuffer=a.stencilBuffer,this.resolveDepthBuffer=a.resolveDepthBuffer,this.resolveStencilBuffer=a.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=a.depthTexture,this.samples=a.samples,this.multiview=a.multiview}_setTextureOptions(t={}){const n={minFilter:Si,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(n.mapping=t.mapping),t.wrapS!==void 0&&(n.wrapS=t.wrapS),t.wrapT!==void 0&&(n.wrapT=t.wrapT),t.wrapR!==void 0&&(n.wrapR=t.wrapR),t.magFilter!==void 0&&(n.magFilter=t.magFilter),t.minFilter!==void 0&&(n.minFilter=t.minFilter),t.format!==void 0&&(n.format=t.format),t.type!==void 0&&(n.type=t.type),t.anisotropy!==void 0&&(n.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(n.colorSpace=t.colorSpace),t.flipY!==void 0&&(n.flipY=t.flipY),t.generateMipmaps!==void 0&&(n.generateMipmaps=t.generateMipmaps),t.internalFormat!==void 0&&(n.internalFormat=t.internalFormat);for(let a=0;a<this.textures.length;a++)this.textures[a].setValues(n)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),t!==null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,n,a=1){if(this.width!==t||this.height!==n||this.depth!==a){this.width=t,this.height=n,this.depth=a;for(let r=0,l=this.textures.length;r<l;r++)this.textures[r].image.width=t,this.textures[r].image.height=n,this.textures[r].image.depth=a,this.textures[r].isData3DTexture!==!0&&(this.textures[r].isArrayTexture=this.textures[r].image.depth>1);this.dispose()}this.viewport.set(0,0,t,n),this.scissor.set(0,0,t,n)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let n=0,a=t.textures.length;n<a;n++){this.textures[n]=t.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0,this.textures[n].renderTarget=this;const r=Object.assign({},t.textures[n].image);this.textures[n].source=new cg(r)}return this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class vr extends vR{constructor(t=1,n=1,a={}){super(t,n,a),this.isWebGLRenderTarget=!0}}class R1 extends zi{constructor(t=null,n=1,a=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:n,height:a,depth:r},this.magFilter=ci,this.minFilter=ci,this.wrapR=Kr,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class xR extends zi{constructor(t=null,n=1,a=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:n,height:a,depth:r},this.magFilter=ci,this.minFilter=ci,this.wrapR=Kr,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class zn{constructor(t,n,a,r,l,c,f,p,d,_,v,g,x,M,E,y){zn.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,n,a,r,l,c,f,p,d,_,v,g,x,M,E,y)}set(t,n,a,r,l,c,f,p,d,_,v,g,x,M,E,y){const S=this.elements;return S[0]=t,S[4]=n,S[8]=a,S[12]=r,S[1]=l,S[5]=c,S[9]=f,S[13]=p,S[2]=d,S[6]=_,S[10]=v,S[14]=g,S[3]=x,S[7]=M,S[11]=E,S[15]=y,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new zn().fromArray(this.elements)}copy(t){const n=this.elements,a=t.elements;return n[0]=a[0],n[1]=a[1],n[2]=a[2],n[3]=a[3],n[4]=a[4],n[5]=a[5],n[6]=a[6],n[7]=a[7],n[8]=a[8],n[9]=a[9],n[10]=a[10],n[11]=a[11],n[12]=a[12],n[13]=a[13],n[14]=a[14],n[15]=a[15],this}copyPosition(t){const n=this.elements,a=t.elements;return n[12]=a[12],n[13]=a[13],n[14]=a[14],this}setFromMatrix3(t){const n=t.elements;return this.set(n[0],n[3],n[6],0,n[1],n[4],n[7],0,n[2],n[5],n[8],0,0,0,0,1),this}extractBasis(t,n,a){return this.determinant()===0?(t.set(1,0,0),n.set(0,1,0),a.set(0,0,1),this):(t.setFromMatrixColumn(this,0),n.setFromMatrixColumn(this,1),a.setFromMatrixColumn(this,2),this)}makeBasis(t,n,a){return this.set(t.x,n.x,a.x,0,t.y,n.y,a.y,0,t.z,n.z,a.z,0,0,0,0,1),this}extractRotation(t){if(t.determinant()===0)return this.identity();const n=this.elements,a=t.elements,r=1/Al.setFromMatrixColumn(t,0).length(),l=1/Al.setFromMatrixColumn(t,1).length(),c=1/Al.setFromMatrixColumn(t,2).length();return n[0]=a[0]*r,n[1]=a[1]*r,n[2]=a[2]*r,n[3]=0,n[4]=a[4]*l,n[5]=a[5]*l,n[6]=a[6]*l,n[7]=0,n[8]=a[8]*c,n[9]=a[9]*c,n[10]=a[10]*c,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromEuler(t){const n=this.elements,a=t.x,r=t.y,l=t.z,c=Math.cos(a),f=Math.sin(a),p=Math.cos(r),d=Math.sin(r),_=Math.cos(l),v=Math.sin(l);if(t.order==="XYZ"){const g=c*_,x=c*v,M=f*_,E=f*v;n[0]=p*_,n[4]=-p*v,n[8]=d,n[1]=x+M*d,n[5]=g-E*d,n[9]=-f*p,n[2]=E-g*d,n[6]=M+x*d,n[10]=c*p}else if(t.order==="YXZ"){const g=p*_,x=p*v,M=d*_,E=d*v;n[0]=g+E*f,n[4]=M*f-x,n[8]=c*d,n[1]=c*v,n[5]=c*_,n[9]=-f,n[2]=x*f-M,n[6]=E+g*f,n[10]=c*p}else if(t.order==="ZXY"){const g=p*_,x=p*v,M=d*_,E=d*v;n[0]=g-E*f,n[4]=-c*v,n[8]=M+x*f,n[1]=x+M*f,n[5]=c*_,n[9]=E-g*f,n[2]=-c*d,n[6]=f,n[10]=c*p}else if(t.order==="ZYX"){const g=c*_,x=c*v,M=f*_,E=f*v;n[0]=p*_,n[4]=M*d-x,n[8]=g*d+E,n[1]=p*v,n[5]=E*d+g,n[9]=x*d-M,n[2]=-d,n[6]=f*p,n[10]=c*p}else if(t.order==="YZX"){const g=c*p,x=c*d,M=f*p,E=f*d;n[0]=p*_,n[4]=E-g*v,n[8]=M*v+x,n[1]=v,n[5]=c*_,n[9]=-f*_,n[2]=-d*_,n[6]=x*v+M,n[10]=g-E*v}else if(t.order==="XZY"){const g=c*p,x=c*d,M=f*p,E=f*d;n[0]=p*_,n[4]=-v,n[8]=d*_,n[1]=g*v+E,n[5]=c*_,n[9]=x*v-M,n[2]=M*v-x,n[6]=f*_,n[10]=E*v+g}return n[3]=0,n[7]=0,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromQuaternion(t){return this.compose(yR,t,SR)}lookAt(t,n,a){const r=this.elements;return la.subVectors(t,n),la.lengthSq()===0&&(la.z=1),la.normalize(),ws.crossVectors(a,la),ws.lengthSq()===0&&(Math.abs(a.z)===1?la.x+=1e-4:la.z+=1e-4,la.normalize(),ws.crossVectors(a,la)),ws.normalize(),fh.crossVectors(la,ws),r[0]=ws.x,r[4]=fh.x,r[8]=la.x,r[1]=ws.y,r[5]=fh.y,r[9]=la.y,r[2]=ws.z,r[6]=fh.z,r[10]=la.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,n){const a=t.elements,r=n.elements,l=this.elements,c=a[0],f=a[4],p=a[8],d=a[12],_=a[1],v=a[5],g=a[9],x=a[13],M=a[2],E=a[6],y=a[10],S=a[14],R=a[3],U=a[7],C=a[11],O=a[15],P=r[0],L=r[4],T=r[8],w=r[12],q=r[1],G=r[5],k=r[9],J=r[13],et=r[2],Q=r[6],F=r[10],I=r[14],it=r[3],ht=r[7],H=r[11],z=r[15];return l[0]=c*P+f*q+p*et+d*it,l[4]=c*L+f*G+p*Q+d*ht,l[8]=c*T+f*k+p*F+d*H,l[12]=c*w+f*J+p*I+d*z,l[1]=_*P+v*q+g*et+x*it,l[5]=_*L+v*G+g*Q+x*ht,l[9]=_*T+v*k+g*F+x*H,l[13]=_*w+v*J+g*I+x*z,l[2]=M*P+E*q+y*et+S*it,l[6]=M*L+E*G+y*Q+S*ht,l[10]=M*T+E*k+y*F+S*H,l[14]=M*w+E*J+y*I+S*z,l[3]=R*P+U*q+C*et+O*it,l[7]=R*L+U*G+C*Q+O*ht,l[11]=R*T+U*k+C*F+O*H,l[15]=R*w+U*J+C*I+O*z,this}multiplyScalar(t){const n=this.elements;return n[0]*=t,n[4]*=t,n[8]*=t,n[12]*=t,n[1]*=t,n[5]*=t,n[9]*=t,n[13]*=t,n[2]*=t,n[6]*=t,n[10]*=t,n[14]*=t,n[3]*=t,n[7]*=t,n[11]*=t,n[15]*=t,this}determinant(){const t=this.elements,n=t[0],a=t[4],r=t[8],l=t[12],c=t[1],f=t[5],p=t[9],d=t[13],_=t[2],v=t[6],g=t[10],x=t[14],M=t[3],E=t[7],y=t[11],S=t[15],R=p*x-d*g,U=f*x-d*v,C=f*g-p*v,O=c*x-d*_,P=c*g-p*_,L=c*v-f*_;return n*(E*R-y*U+S*C)-a*(M*R-y*O+S*P)+r*(M*U-E*O+S*L)-l*(M*C-E*P+y*L)}transpose(){const t=this.elements;let n;return n=t[1],t[1]=t[4],t[4]=n,n=t[2],t[2]=t[8],t[8]=n,n=t[6],t[6]=t[9],t[9]=n,n=t[3],t[3]=t[12],t[12]=n,n=t[7],t[7]=t[13],t[13]=n,n=t[11],t[11]=t[14],t[14]=n,this}setPosition(t,n,a){const r=this.elements;return t.isVector3?(r[12]=t.x,r[13]=t.y,r[14]=t.z):(r[12]=t,r[13]=n,r[14]=a),this}invert(){const t=this.elements,n=t[0],a=t[1],r=t[2],l=t[3],c=t[4],f=t[5],p=t[6],d=t[7],_=t[8],v=t[9],g=t[10],x=t[11],M=t[12],E=t[13],y=t[14],S=t[15],R=n*f-a*c,U=n*p-r*c,C=n*d-l*c,O=a*p-r*f,P=a*d-l*f,L=r*d-l*p,T=_*E-v*M,w=_*y-g*M,q=_*S-x*M,G=v*y-g*E,k=v*S-x*E,J=g*S-x*y,et=R*J-U*k+C*G+O*q-P*w+L*T;if(et===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const Q=1/et;return t[0]=(f*J-p*k+d*G)*Q,t[1]=(r*k-a*J-l*G)*Q,t[2]=(E*L-y*P+S*O)*Q,t[3]=(g*P-v*L-x*O)*Q,t[4]=(p*q-c*J-d*w)*Q,t[5]=(n*J-r*q+l*w)*Q,t[6]=(y*C-M*L-S*U)*Q,t[7]=(_*L-g*C+x*U)*Q,t[8]=(c*k-f*q+d*T)*Q,t[9]=(a*q-n*k-l*T)*Q,t[10]=(M*P-E*C+S*R)*Q,t[11]=(v*C-_*P-x*R)*Q,t[12]=(f*w-c*G-p*T)*Q,t[13]=(n*G-a*w+r*T)*Q,t[14]=(E*U-M*O-y*R)*Q,t[15]=(_*O-v*U+g*R)*Q,this}scale(t){const n=this.elements,a=t.x,r=t.y,l=t.z;return n[0]*=a,n[4]*=r,n[8]*=l,n[1]*=a,n[5]*=r,n[9]*=l,n[2]*=a,n[6]*=r,n[10]*=l,n[3]*=a,n[7]*=r,n[11]*=l,this}getMaxScaleOnAxis(){const t=this.elements,n=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],a=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],r=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(n,a,r))}makeTranslation(t,n,a){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,n,0,0,1,a,0,0,0,1),this}makeRotationX(t){const n=Math.cos(t),a=Math.sin(t);return this.set(1,0,0,0,0,n,-a,0,0,a,n,0,0,0,0,1),this}makeRotationY(t){const n=Math.cos(t),a=Math.sin(t);return this.set(n,0,a,0,0,1,0,0,-a,0,n,0,0,0,0,1),this}makeRotationZ(t){const n=Math.cos(t),a=Math.sin(t);return this.set(n,-a,0,0,a,n,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,n){const a=Math.cos(n),r=Math.sin(n),l=1-a,c=t.x,f=t.y,p=t.z,d=l*c,_=l*f;return this.set(d*c+a,d*f-r*p,d*p+r*f,0,d*f+r*p,_*f+a,_*p-r*c,0,d*p-r*f,_*p+r*c,l*p*p+a,0,0,0,0,1),this}makeScale(t,n,a){return this.set(t,0,0,0,0,n,0,0,0,0,a,0,0,0,0,1),this}makeShear(t,n,a,r,l,c){return this.set(1,a,l,0,t,1,c,0,n,r,1,0,0,0,0,1),this}compose(t,n,a){const r=this.elements,l=n._x,c=n._y,f=n._z,p=n._w,d=l+l,_=c+c,v=f+f,g=l*d,x=l*_,M=l*v,E=c*_,y=c*v,S=f*v,R=p*d,U=p*_,C=p*v,O=a.x,P=a.y,L=a.z;return r[0]=(1-(E+S))*O,r[1]=(x+C)*O,r[2]=(M-U)*O,r[3]=0,r[4]=(x-C)*P,r[5]=(1-(g+S))*P,r[6]=(y+R)*P,r[7]=0,r[8]=(M+U)*L,r[9]=(y-R)*L,r[10]=(1-(g+E))*L,r[11]=0,r[12]=t.x,r[13]=t.y,r[14]=t.z,r[15]=1,this}decompose(t,n,a){const r=this.elements;t.x=r[12],t.y=r[13],t.z=r[14];const l=this.determinant();if(l===0)return a.set(1,1,1),n.identity(),this;let c=Al.set(r[0],r[1],r[2]).length();const f=Al.set(r[4],r[5],r[6]).length(),p=Al.set(r[8],r[9],r[10]).length();l<0&&(c=-c),qa.copy(this);const d=1/c,_=1/f,v=1/p;return qa.elements[0]*=d,qa.elements[1]*=d,qa.elements[2]*=d,qa.elements[4]*=_,qa.elements[5]*=_,qa.elements[6]*=_,qa.elements[8]*=v,qa.elements[9]*=v,qa.elements[10]*=v,n.setFromRotationMatrix(qa),a.x=c,a.y=f,a.z=p,this}makePerspective(t,n,a,r,l,c,f=pr,p=!1){const d=this.elements,_=2*l/(n-t),v=2*l/(a-r),g=(n+t)/(n-t),x=(a+r)/(a-r);let M,E;if(p)M=l/(c-l),E=c*l/(c-l);else if(f===pr)M=-(c+l)/(c-l),E=-2*c*l/(c-l);else if(f===cd)M=-c/(c-l),E=-c*l/(c-l);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+f);return d[0]=_,d[4]=0,d[8]=g,d[12]=0,d[1]=0,d[5]=v,d[9]=x,d[13]=0,d[2]=0,d[6]=0,d[10]=M,d[14]=E,d[3]=0,d[7]=0,d[11]=-1,d[15]=0,this}makeOrthographic(t,n,a,r,l,c,f=pr,p=!1){const d=this.elements,_=2/(n-t),v=2/(a-r),g=-(n+t)/(n-t),x=-(a+r)/(a-r);let M,E;if(p)M=1/(c-l),E=c/(c-l);else if(f===pr)M=-2/(c-l),E=-(c+l)/(c-l);else if(f===cd)M=-1/(c-l),E=-l/(c-l);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+f);return d[0]=_,d[4]=0,d[8]=0,d[12]=g,d[1]=0,d[5]=v,d[9]=0,d[13]=x,d[2]=0,d[6]=0,d[10]=M,d[14]=E,d[3]=0,d[7]=0,d[11]=0,d[15]=1,this}equals(t){const n=this.elements,a=t.elements;for(let r=0;r<16;r++)if(n[r]!==a[r])return!1;return!0}fromArray(t,n=0){for(let a=0;a<16;a++)this.elements[a]=t[a+n];return this}toArray(t=[],n=0){const a=this.elements;return t[n]=a[0],t[n+1]=a[1],t[n+2]=a[2],t[n+3]=a[3],t[n+4]=a[4],t[n+5]=a[5],t[n+6]=a[6],t[n+7]=a[7],t[n+8]=a[8],t[n+9]=a[9],t[n+10]=a[10],t[n+11]=a[11],t[n+12]=a[12],t[n+13]=a[13],t[n+14]=a[14],t[n+15]=a[15],t}}const Al=new ft,qa=new zn,yR=new ft(0,0,0),SR=new ft(1,1,1),ws=new ft,fh=new ft,la=new ft,BS=new zn,HS=new du;class is{constructor(t=0,n=0,a=0,r=is.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=n,this._z=a,this._order=r}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,n,a,r=this._order){return this._x=t,this._y=n,this._z=a,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,n=this._order,a=!0){const r=t.elements,l=r[0],c=r[4],f=r[8],p=r[1],d=r[5],_=r[9],v=r[2],g=r[6],x=r[10];switch(n){case"XYZ":this._y=Math.asin(ke(f,-1,1)),Math.abs(f)<.9999999?(this._x=Math.atan2(-_,x),this._z=Math.atan2(-c,l)):(this._x=Math.atan2(g,d),this._z=0);break;case"YXZ":this._x=Math.asin(-ke(_,-1,1)),Math.abs(_)<.9999999?(this._y=Math.atan2(f,x),this._z=Math.atan2(p,d)):(this._y=Math.atan2(-v,l),this._z=0);break;case"ZXY":this._x=Math.asin(ke(g,-1,1)),Math.abs(g)<.9999999?(this._y=Math.atan2(-v,x),this._z=Math.atan2(-c,d)):(this._y=0,this._z=Math.atan2(p,l));break;case"ZYX":this._y=Math.asin(-ke(v,-1,1)),Math.abs(v)<.9999999?(this._x=Math.atan2(g,x),this._z=Math.atan2(p,l)):(this._x=0,this._z=Math.atan2(-c,d));break;case"YZX":this._z=Math.asin(ke(p,-1,1)),Math.abs(p)<.9999999?(this._x=Math.atan2(-_,d),this._y=Math.atan2(-v,l)):(this._x=0,this._y=Math.atan2(f,x));break;case"XZY":this._z=Math.asin(-ke(c,-1,1)),Math.abs(c)<.9999999?(this._x=Math.atan2(g,d),this._y=Math.atan2(f,l)):(this._x=Math.atan2(-_,x),this._y=0);break;default:Me("Euler: .setFromRotationMatrix() encountered an unknown order: "+n)}return this._order=n,a===!0&&this._onChangeCallback(),this}setFromQuaternion(t,n,a){return BS.makeRotationFromQuaternion(t),this.setFromRotationMatrix(BS,n,a)}setFromVector3(t,n=this._order){return this.set(t.x,t.y,t.z,n)}reorder(t){return HS.setFromEuler(this),this.setFromQuaternion(HS,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],n=0){return t[n]=this._x,t[n+1]=this._y,t[n+2]=this._z,t[n+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}is.DEFAULT_ORDER="XYZ";class C1{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let MR=0;const GS=new ft,Rl=new du,Gr=new zn,hh=new ft,rc=new ft,ER=new ft,bR=new du,VS=new ft(1,0,0),kS=new ft(0,1,0),XS=new ft(0,0,1),WS={type:"added"},TR={type:"removed"},Cl={type:"childadded",child:null},Jm={type:"childremoved",child:null};class qi extends hu{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:MR++}),this.uuid=Zc(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=qi.DEFAULT_UP.clone();const t=new ft,n=new is,a=new du,r=new ft(1,1,1);function l(){a.setFromEuler(n,!1)}function c(){n.setFromQuaternion(a,void 0,!1)}n._onChange(l),a._onChange(c),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:n},quaternion:{configurable:!0,enumerable:!0,value:a},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new zn},normalMatrix:{value:new we}}),this.matrix=new zn,this.matrixWorld=new zn,this.matrixAutoUpdate=qi.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=qi.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new C1,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,n){this.quaternion.setFromAxisAngle(t,n)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,n){return Rl.setFromAxisAngle(t,n),this.quaternion.multiply(Rl),this}rotateOnWorldAxis(t,n){return Rl.setFromAxisAngle(t,n),this.quaternion.premultiply(Rl),this}rotateX(t){return this.rotateOnAxis(VS,t)}rotateY(t){return this.rotateOnAxis(kS,t)}rotateZ(t){return this.rotateOnAxis(XS,t)}translateOnAxis(t,n){return GS.copy(t).applyQuaternion(this.quaternion),this.position.add(GS.multiplyScalar(n)),this}translateX(t){return this.translateOnAxis(VS,t)}translateY(t){return this.translateOnAxis(kS,t)}translateZ(t){return this.translateOnAxis(XS,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(Gr.copy(this.matrixWorld).invert())}lookAt(t,n,a){t.isVector3?hh.copy(t):hh.set(t,n,a);const r=this.parent;this.updateWorldMatrix(!0,!1),rc.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Gr.lookAt(rc,hh,this.up):Gr.lookAt(hh,rc,this.up),this.quaternion.setFromRotationMatrix(Gr),r&&(Gr.extractRotation(r.matrixWorld),Rl.setFromRotationMatrix(Gr),this.quaternion.premultiply(Rl.invert()))}add(t){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.add(arguments[n]);return this}return t===this?(Qe("Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(WS),Cl.child=t,this.dispatchEvent(Cl),Cl.child=null):Qe("Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let a=0;a<arguments.length;a++)this.remove(arguments[a]);return this}const n=this.children.indexOf(t);return n!==-1&&(t.parent=null,this.children.splice(n,1),t.dispatchEvent(TR),Jm.child=t,this.dispatchEvent(Jm),Jm.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),Gr.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),Gr.multiply(t.parent.matrixWorld)),t.applyMatrix4(Gr),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(WS),Cl.child=t,this.dispatchEvent(Cl),Cl.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,n){if(this[t]===n)return this;for(let a=0,r=this.children.length;a<r;a++){const c=this.children[a].getObjectByProperty(t,n);if(c!==void 0)return c}}getObjectsByProperty(t,n,a=[]){this[t]===n&&a.push(this);const r=this.children;for(let l=0,c=r.length;l<c;l++)r[l].getObjectsByProperty(t,n,a);return a}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(rc,t,ER),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(rc,bR,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const n=this.matrixWorld.elements;return t.set(n[8],n[9],n[10]).normalize()}raycast(){}traverse(t){t(this);const n=this.children;for(let a=0,r=n.length;a<r;a++)n[a].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const n=this.children;for(let a=0,r=n.length;a<r;a++)n[a].traverseVisible(t)}traverseAncestors(t){const n=this.parent;n!==null&&(t(n),n.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const t=this.pivot;if(t!==null){const n=t.x,a=t.y,r=t.z,l=this.matrix.elements;l[12]+=n-l[0]*n-l[4]*a-l[8]*r,l[13]+=a-l[1]*n-l[5]*a-l[9]*r,l[14]+=r-l[2]*n-l[6]*a-l[10]*r}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const n=this.children;for(let a=0,r=n.length;a<r;a++)n[a].updateMatrixWorld(t)}updateWorldMatrix(t,n){const a=this.parent;if(t===!0&&a!==null&&a.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),n===!0){const r=this.children;for(let l=0,c=r.length;l<c;l++)r[l].updateWorldMatrix(!1,!0)}}toJSON(t){const n=t===void 0||typeof t=="string",a={};n&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},a.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.castShadow===!0&&(r.castShadow=!0),this.receiveShadow===!0&&(r.receiveShadow=!0),this.visible===!1&&(r.visible=!1),this.frustumCulled===!1&&(r.frustumCulled=!1),this.renderOrder!==0&&(r.renderOrder=this.renderOrder),this.static!==!1&&(r.static=this.static),Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.pivot!==null&&(r.pivot=this.pivot.toArray()),this.matrixAutoUpdate===!1&&(r.matrixAutoUpdate=!1),this.morphTargetDictionary!==void 0&&(r.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(r.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(f=>({...f,boundingBox:f.boundingBox?f.boundingBox.toJSON():void 0,boundingSphere:f.boundingSphere?f.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(f=>({...f})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(t),r.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function l(f,p){return f[p.uuid]===void 0&&(f[p.uuid]=p.toJSON(t)),p.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=l(t.geometries,this.geometry);const f=this.geometry.parameters;if(f!==void 0&&f.shapes!==void 0){const p=f.shapes;if(Array.isArray(p))for(let d=0,_=p.length;d<_;d++){const v=p[d];l(t.shapes,v)}else l(t.shapes,p)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(l(t.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const f=[];for(let p=0,d=this.material.length;p<d;p++)f.push(l(t.materials,this.material[p]));r.material=f}else r.material=l(t.materials,this.material);if(this.children.length>0){r.children=[];for(let f=0;f<this.children.length;f++)r.children.push(this.children[f].toJSON(t).object)}if(this.animations.length>0){r.animations=[];for(let f=0;f<this.animations.length;f++){const p=this.animations[f];r.animations.push(l(t.animations,p))}}if(n){const f=c(t.geometries),p=c(t.materials),d=c(t.textures),_=c(t.images),v=c(t.shapes),g=c(t.skeletons),x=c(t.animations),M=c(t.nodes);f.length>0&&(a.geometries=f),p.length>0&&(a.materials=p),d.length>0&&(a.textures=d),_.length>0&&(a.images=_),v.length>0&&(a.shapes=v),g.length>0&&(a.skeletons=g),x.length>0&&(a.animations=x),M.length>0&&(a.nodes=M)}return a.object=r,a;function c(f){const p=[];for(const d in f){const _=f[d];delete _.metadata,p.push(_)}return p}}clone(t){return new this.constructor().copy(this,t)}copy(t,n=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),t.pivot!==null&&(this.pivot=t.pivot.clone()),this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.static=t.static,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),n===!0)for(let a=0;a<t.children.length;a++){const r=t.children[a];this.add(r.clone())}return this}}qi.DEFAULT_UP=new ft(0,1,0);qi.DEFAULT_MATRIX_AUTO_UPDATE=!0;qi.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class mc extends qi{constructor(){super(),this.isGroup=!0,this.type="Group"}}const AR={type:"move"};class $m{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new mc,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new mc,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new ft,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new ft),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new mc,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new ft,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new ft),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const n=this._hand;if(n)for(const a of t.hand.values())this._getHandJoint(n,a)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,n,a){let r=null,l=null,c=null;const f=this._targetRay,p=this._grip,d=this._hand;if(t&&n.session.visibilityState!=="visible-blurred"){if(d&&t.hand){c=!0;for(const E of t.hand.values()){const y=n.getJointPose(E,a),S=this._getHandJoint(d,E);y!==null&&(S.matrix.fromArray(y.transform.matrix),S.matrix.decompose(S.position,S.rotation,S.scale),S.matrixWorldNeedsUpdate=!0,S.jointRadius=y.radius),S.visible=y!==null}const _=d.joints["index-finger-tip"],v=d.joints["thumb-tip"],g=_.position.distanceTo(v.position),x=.02,M=.005;d.inputState.pinching&&g>x+M?(d.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!d.inputState.pinching&&g<=x-M&&(d.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else p!==null&&t.gripSpace&&(l=n.getPose(t.gripSpace,a),l!==null&&(p.matrix.fromArray(l.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,l.linearVelocity?(p.hasLinearVelocity=!0,p.linearVelocity.copy(l.linearVelocity)):p.hasLinearVelocity=!1,l.angularVelocity?(p.hasAngularVelocity=!0,p.angularVelocity.copy(l.angularVelocity)):p.hasAngularVelocity=!1));f!==null&&(r=n.getPose(t.targetRaySpace,a),r===null&&l!==null&&(r=l),r!==null&&(f.matrix.fromArray(r.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,r.linearVelocity?(f.hasLinearVelocity=!0,f.linearVelocity.copy(r.linearVelocity)):f.hasLinearVelocity=!1,r.angularVelocity?(f.hasAngularVelocity=!0,f.angularVelocity.copy(r.angularVelocity)):f.hasAngularVelocity=!1,this.dispatchEvent(AR)))}return f!==null&&(f.visible=r!==null),p!==null&&(p.visible=l!==null),d!==null&&(d.visible=c!==null),this}_getHandJoint(t,n){if(t.joints[n.jointName]===void 0){const a=new mc;a.matrixAutoUpdate=!1,a.visible=!1,t.joints[n.jointName]=a,t.add(a)}return t.joints[n.jointName]}}const w1={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Ds={h:0,s:0,l:0},dh={h:0,s:0,l:0};function t_(o,t,n){return n<0&&(n+=1),n>1&&(n-=1),n<1/6?o+(t-o)*6*n:n<1/2?t:n<2/3?o+(t-o)*6*(2/3-n):o}class qe{constructor(t,n,a){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,n,a)}set(t,n,a){if(n===void 0&&a===void 0){const r=t;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(t,n,a);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,n=Na){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Ye.colorSpaceToWorking(this,n),this}setRGB(t,n,a,r=Ye.workingColorSpace){return this.r=t,this.g=n,this.b=a,Ye.colorSpaceToWorking(this,r),this}setHSL(t,n,a,r=Ye.workingColorSpace){if(t=dR(t,1),n=ke(n,0,1),a=ke(a,0,1),n===0)this.r=this.g=this.b=a;else{const l=a<=.5?a*(1+n):a+n-a*n,c=2*a-l;this.r=t_(c,l,t+1/3),this.g=t_(c,l,t),this.b=t_(c,l,t-1/3)}return Ye.colorSpaceToWorking(this,r),this}setStyle(t,n=Na){function a(l){l!==void 0&&parseFloat(l)<1&&Me("Color: Alpha component of "+t+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(t)){let l;const c=r[1],f=r[2];switch(c){case"rgb":case"rgba":if(l=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(f))return a(l[4]),this.setRGB(Math.min(255,parseInt(l[1],10))/255,Math.min(255,parseInt(l[2],10))/255,Math.min(255,parseInt(l[3],10))/255,n);if(l=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(f))return a(l[4]),this.setRGB(Math.min(100,parseInt(l[1],10))/100,Math.min(100,parseInt(l[2],10))/100,Math.min(100,parseInt(l[3],10))/100,n);break;case"hsl":case"hsla":if(l=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(f))return a(l[4]),this.setHSL(parseFloat(l[1])/360,parseFloat(l[2])/100,parseFloat(l[3])/100,n);break;default:Me("Color: Unknown color model "+t)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(t)){const l=r[1],c=l.length;if(c===3)return this.setRGB(parseInt(l.charAt(0),16)/15,parseInt(l.charAt(1),16)/15,parseInt(l.charAt(2),16)/15,n);if(c===6)return this.setHex(parseInt(l,16),n);Me("Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,n);return this}setColorName(t,n=Na){const a=w1[t.toLowerCase()];return a!==void 0?this.setHex(a,n):Me("Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=$r(t.r),this.g=$r(t.g),this.b=$r(t.b),this}copyLinearToSRGB(t){return this.r=ql(t.r),this.g=ql(t.g),this.b=ql(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Na){return Ye.workingToColorSpace(_i.copy(this),t),Math.round(ke(_i.r*255,0,255))*65536+Math.round(ke(_i.g*255,0,255))*256+Math.round(ke(_i.b*255,0,255))}getHexString(t=Na){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,n=Ye.workingColorSpace){Ye.workingToColorSpace(_i.copy(this),n);const a=_i.r,r=_i.g,l=_i.b,c=Math.max(a,r,l),f=Math.min(a,r,l);let p,d;const _=(f+c)/2;if(f===c)p=0,d=0;else{const v=c-f;switch(d=_<=.5?v/(c+f):v/(2-c-f),c){case a:p=(r-l)/v+(r<l?6:0);break;case r:p=(l-a)/v+2;break;case l:p=(a-r)/v+4;break}p/=6}return t.h=p,t.s=d,t.l=_,t}getRGB(t,n=Ye.workingColorSpace){return Ye.workingToColorSpace(_i.copy(this),n),t.r=_i.r,t.g=_i.g,t.b=_i.b,t}getStyle(t=Na){Ye.workingToColorSpace(_i.copy(this),t);const n=_i.r,a=_i.g,r=_i.b;return t!==Na?`color(${t} ${n.toFixed(3)} ${a.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(n*255)},${Math.round(a*255)},${Math.round(r*255)})`}offsetHSL(t,n,a){return this.getHSL(Ds),this.setHSL(Ds.h+t,Ds.s+n,Ds.l+a)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,n){return this.r=t.r+n.r,this.g=t.g+n.g,this.b=t.b+n.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,n){return this.r+=(t.r-this.r)*n,this.g+=(t.g-this.g)*n,this.b+=(t.b-this.b)*n,this}lerpColors(t,n,a){return this.r=t.r+(n.r-t.r)*a,this.g=t.g+(n.g-t.g)*a,this.b=t.b+(n.b-t.b)*a,this}lerpHSL(t,n){this.getHSL(Ds),t.getHSL(dh);const a=qm(Ds.h,dh.h,n),r=qm(Ds.s,dh.s,n),l=qm(Ds.l,dh.l,n);return this.setHSL(a,r,l),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const n=this.r,a=this.g,r=this.b,l=t.elements;return this.r=l[0]*n+l[3]*a+l[6]*r,this.g=l[1]*n+l[4]*a+l[7]*r,this.b=l[2]*n+l[5]*a+l[8]*r,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,n=0){return this.r=t[n],this.g=t[n+1],this.b=t[n+2],this}toArray(t=[],n=0){return t[n]=this.r,t[n+1]=this.g,t[n+2]=this.b,t}fromBufferAttribute(t,n){return this.r=t.getX(n),this.g=t.getY(n),this.b=t.getZ(n),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const _i=new qe;qe.NAMES=w1;class RR extends qi{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new is,this.environmentIntensity=1,this.environmentRotation=new is,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,n){return super.copy(t,n),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const n=super.toJSON(t);return this.fog!==null&&(n.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(n.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(n.object.backgroundIntensity=this.backgroundIntensity),n.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(n.object.environmentIntensity=this.environmentIntensity),n.object.environmentRotation=this.environmentRotation.toArray(),n}}const ja=new ft,Vr=new ft,e_=new ft,kr=new ft,wl=new ft,Dl=new ft,YS=new ft,n_=new ft,i_=new ft,a_=new ft,r_=new Pn,s_=new Pn,o_=new Pn;class Qa{constructor(t=new ft,n=new ft,a=new ft){this.a=t,this.b=n,this.c=a}static getNormal(t,n,a,r){r.subVectors(a,n),ja.subVectors(t,n),r.cross(ja);const l=r.lengthSq();return l>0?r.multiplyScalar(1/Math.sqrt(l)):r.set(0,0,0)}static getBarycoord(t,n,a,r,l){ja.subVectors(r,n),Vr.subVectors(a,n),e_.subVectors(t,n);const c=ja.dot(ja),f=ja.dot(Vr),p=ja.dot(e_),d=Vr.dot(Vr),_=Vr.dot(e_),v=c*d-f*f;if(v===0)return l.set(0,0,0),null;const g=1/v,x=(d*p-f*_)*g,M=(c*_-f*p)*g;return l.set(1-x-M,M,x)}static containsPoint(t,n,a,r){return this.getBarycoord(t,n,a,r,kr)===null?!1:kr.x>=0&&kr.y>=0&&kr.x+kr.y<=1}static getInterpolation(t,n,a,r,l,c,f,p){return this.getBarycoord(t,n,a,r,kr)===null?(p.x=0,p.y=0,"z"in p&&(p.z=0),"w"in p&&(p.w=0),null):(p.setScalar(0),p.addScaledVector(l,kr.x),p.addScaledVector(c,kr.y),p.addScaledVector(f,kr.z),p)}static getInterpolatedAttribute(t,n,a,r,l,c){return r_.setScalar(0),s_.setScalar(0),o_.setScalar(0),r_.fromBufferAttribute(t,n),s_.fromBufferAttribute(t,a),o_.fromBufferAttribute(t,r),c.setScalar(0),c.addScaledVector(r_,l.x),c.addScaledVector(s_,l.y),c.addScaledVector(o_,l.z),c}static isFrontFacing(t,n,a,r){return ja.subVectors(a,n),Vr.subVectors(t,n),ja.cross(Vr).dot(r)<0}set(t,n,a){return this.a.copy(t),this.b.copy(n),this.c.copy(a),this}setFromPointsAndIndices(t,n,a,r){return this.a.copy(t[n]),this.b.copy(t[a]),this.c.copy(t[r]),this}setFromAttributeAndIndices(t,n,a,r){return this.a.fromBufferAttribute(t,n),this.b.fromBufferAttribute(t,a),this.c.fromBufferAttribute(t,r),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return ja.subVectors(this.c,this.b),Vr.subVectors(this.a,this.b),ja.cross(Vr).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return Qa.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,n){return Qa.getBarycoord(t,this.a,this.b,this.c,n)}getInterpolation(t,n,a,r,l){return Qa.getInterpolation(t,this.a,this.b,this.c,n,a,r,l)}containsPoint(t){return Qa.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return Qa.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,n){const a=this.a,r=this.b,l=this.c;let c,f;wl.subVectors(r,a),Dl.subVectors(l,a),n_.subVectors(t,a);const p=wl.dot(n_),d=Dl.dot(n_);if(p<=0&&d<=0)return n.copy(a);i_.subVectors(t,r);const _=wl.dot(i_),v=Dl.dot(i_);if(_>=0&&v<=_)return n.copy(r);const g=p*v-_*d;if(g<=0&&p>=0&&_<=0)return c=p/(p-_),n.copy(a).addScaledVector(wl,c);a_.subVectors(t,l);const x=wl.dot(a_),M=Dl.dot(a_);if(M>=0&&x<=M)return n.copy(l);const E=x*d-p*M;if(E<=0&&d>=0&&M<=0)return f=d/(d-M),n.copy(a).addScaledVector(Dl,f);const y=_*M-x*v;if(y<=0&&v-_>=0&&x-M>=0)return YS.subVectors(l,r),f=(v-_)/(v-_+(x-M)),n.copy(r).addScaledVector(YS,f);const S=1/(y+E+g);return c=E*S,f=g*S,n.copy(a).addScaledVector(wl,c).addScaledVector(Dl,f)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}class Kc{constructor(t=new ft(1/0,1/0,1/0),n=new ft(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=n}set(t,n){return this.min.copy(t),this.max.copy(n),this}setFromArray(t){this.makeEmpty();for(let n=0,a=t.length;n<a;n+=3)this.expandByPoint(Za.fromArray(t,n));return this}setFromBufferAttribute(t){this.makeEmpty();for(let n=0,a=t.count;n<a;n++)this.expandByPoint(Za.fromBufferAttribute(t,n));return this}setFromPoints(t){this.makeEmpty();for(let n=0,a=t.length;n<a;n++)this.expandByPoint(t[n]);return this}setFromCenterAndSize(t,n){const a=Za.copy(n).multiplyScalar(.5);return this.min.copy(t).sub(a),this.max.copy(t).add(a),this}setFromObject(t,n=!1){return this.makeEmpty(),this.expandByObject(t,n)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,n=!1){t.updateWorldMatrix(!1,!1);const a=t.geometry;if(a!==void 0){const l=a.getAttribute("position");if(n===!0&&l!==void 0&&t.isInstancedMesh!==!0)for(let c=0,f=l.count;c<f;c++)t.isMesh===!0?t.getVertexPosition(c,Za):Za.fromBufferAttribute(l,c),Za.applyMatrix4(t.matrixWorld),this.expandByPoint(Za);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),ph.copy(t.boundingBox)):(a.boundingBox===null&&a.computeBoundingBox(),ph.copy(a.boundingBox)),ph.applyMatrix4(t.matrixWorld),this.union(ph)}const r=t.children;for(let l=0,c=r.length;l<c;l++)this.expandByObject(r[l],n);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,n){return n.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,Za),Za.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let n,a;return t.normal.x>0?(n=t.normal.x*this.min.x,a=t.normal.x*this.max.x):(n=t.normal.x*this.max.x,a=t.normal.x*this.min.x),t.normal.y>0?(n+=t.normal.y*this.min.y,a+=t.normal.y*this.max.y):(n+=t.normal.y*this.max.y,a+=t.normal.y*this.min.y),t.normal.z>0?(n+=t.normal.z*this.min.z,a+=t.normal.z*this.max.z):(n+=t.normal.z*this.max.z,a+=t.normal.z*this.min.z),n<=-t.constant&&a>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(sc),mh.subVectors(this.max,sc),Ul.subVectors(t.a,sc),Nl.subVectors(t.b,sc),Ll.subVectors(t.c,sc),Us.subVectors(Nl,Ul),Ns.subVectors(Ll,Nl),mo.subVectors(Ul,Ll);let n=[0,-Us.z,Us.y,0,-Ns.z,Ns.y,0,-mo.z,mo.y,Us.z,0,-Us.x,Ns.z,0,-Ns.x,mo.z,0,-mo.x,-Us.y,Us.x,0,-Ns.y,Ns.x,0,-mo.y,mo.x,0];return!l_(n,Ul,Nl,Ll,mh)||(n=[1,0,0,0,1,0,0,0,1],!l_(n,Ul,Nl,Ll,mh))?!1:(_h.crossVectors(Us,Ns),n=[_h.x,_h.y,_h.z],l_(n,Ul,Nl,Ll,mh))}clampPoint(t,n){return n.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Za).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Za).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(Xr[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),Xr[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),Xr[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),Xr[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),Xr[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),Xr[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),Xr[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),Xr[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(Xr),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}}const Xr=[new ft,new ft,new ft,new ft,new ft,new ft,new ft,new ft],Za=new ft,ph=new Kc,Ul=new ft,Nl=new ft,Ll=new ft,Us=new ft,Ns=new ft,mo=new ft,sc=new ft,mh=new ft,_h=new ft,_o=new ft;function l_(o,t,n,a,r){for(let l=0,c=o.length-3;l<=c;l+=3){_o.fromArray(o,l);const f=r.x*Math.abs(_o.x)+r.y*Math.abs(_o.y)+r.z*Math.abs(_o.z),p=t.dot(_o),d=n.dot(_o),_=a.dot(_o);if(Math.max(-Math.max(p,d,_),Math.min(p,d,_))>f)return!1}return!0}const Wn=new ft,gh=new fn;let CR=0;class xr{constructor(t,n,a=!1){if(Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:CR++}),this.name="",this.array=t,this.itemSize=n,this.count=t!==void 0?t.length/n:0,this.normalized=a,this.usage=NS,this.updateRanges=[],this.gpuType=dr,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,n){this.updateRanges.push({start:t,count:n})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,n,a){t*=this.itemSize,a*=n.itemSize;for(let r=0,l=this.itemSize;r<l;r++)this.array[t+r]=n.array[a+r];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let n=0,a=this.count;n<a;n++)gh.fromBufferAttribute(this,n),gh.applyMatrix3(t),this.setXY(n,gh.x,gh.y);else if(this.itemSize===3)for(let n=0,a=this.count;n<a;n++)Wn.fromBufferAttribute(this,n),Wn.applyMatrix3(t),this.setXYZ(n,Wn.x,Wn.y,Wn.z);return this}applyMatrix4(t){for(let n=0,a=this.count;n<a;n++)Wn.fromBufferAttribute(this,n),Wn.applyMatrix4(t),this.setXYZ(n,Wn.x,Wn.y,Wn.z);return this}applyNormalMatrix(t){for(let n=0,a=this.count;n<a;n++)Wn.fromBufferAttribute(this,n),Wn.applyNormalMatrix(t),this.setXYZ(n,Wn.x,Wn.y,Wn.z);return this}transformDirection(t){for(let n=0,a=this.count;n<a;n++)Wn.fromBufferAttribute(this,n),Wn.transformDirection(t),this.setXYZ(n,Wn.x,Wn.y,Wn.z);return this}set(t,n=0){return this.array.set(t,n),this}getComponent(t,n){let a=this.array[t*this.itemSize+n];return this.normalized&&(a=ac(a,this.array)),a}setComponent(t,n,a){return this.normalized&&(a=Xi(a,this.array)),this.array[t*this.itemSize+n]=a,this}getX(t){let n=this.array[t*this.itemSize];return this.normalized&&(n=ac(n,this.array)),n}setX(t,n){return this.normalized&&(n=Xi(n,this.array)),this.array[t*this.itemSize]=n,this}getY(t){let n=this.array[t*this.itemSize+1];return this.normalized&&(n=ac(n,this.array)),n}setY(t,n){return this.normalized&&(n=Xi(n,this.array)),this.array[t*this.itemSize+1]=n,this}getZ(t){let n=this.array[t*this.itemSize+2];return this.normalized&&(n=ac(n,this.array)),n}setZ(t,n){return this.normalized&&(n=Xi(n,this.array)),this.array[t*this.itemSize+2]=n,this}getW(t){let n=this.array[t*this.itemSize+3];return this.normalized&&(n=ac(n,this.array)),n}setW(t,n){return this.normalized&&(n=Xi(n,this.array)),this.array[t*this.itemSize+3]=n,this}setXY(t,n,a){return t*=this.itemSize,this.normalized&&(n=Xi(n,this.array),a=Xi(a,this.array)),this.array[t+0]=n,this.array[t+1]=a,this}setXYZ(t,n,a,r){return t*=this.itemSize,this.normalized&&(n=Xi(n,this.array),a=Xi(a,this.array),r=Xi(r,this.array)),this.array[t+0]=n,this.array[t+1]=a,this.array[t+2]=r,this}setXYZW(t,n,a,r,l){return t*=this.itemSize,this.normalized&&(n=Xi(n,this.array),a=Xi(a,this.array),r=Xi(r,this.array),l=Xi(l,this.array)),this.array[t+0]=n,this.array[t+1]=a,this.array[t+2]=r,this.array[t+3]=l,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==NS&&(t.usage=this.usage),t}}class D1 extends xr{constructor(t,n,a){super(new Uint16Array(t),n,a)}}class U1 extends xr{constructor(t,n,a){super(new Uint32Array(t),n,a)}}class Ba extends xr{constructor(t,n,a){super(new Float32Array(t),n,a)}}const wR=new Kc,oc=new ft,u_=new ft;class Ad{constructor(t=new ft,n=-1){this.isSphere=!0,this.center=t,this.radius=n}set(t,n){return this.center.copy(t),this.radius=n,this}setFromPoints(t,n){const a=this.center;n!==void 0?a.copy(n):wR.setFromPoints(t).getCenter(a);let r=0;for(let l=0,c=t.length;l<c;l++)r=Math.max(r,a.distanceToSquared(t[l]));return this.radius=Math.sqrt(r),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const n=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=n*n}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,n){const a=this.center.distanceToSquared(t);return n.copy(t),a>this.radius*this.radius&&(n.sub(this.center).normalize(),n.multiplyScalar(this.radius).add(this.center)),n}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;oc.subVectors(t,this.center);const n=oc.lengthSq();if(n>this.radius*this.radius){const a=Math.sqrt(n),r=(a-this.radius)*.5;this.center.addScaledVector(oc,r/a),this.radius+=r}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(u_.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(oc.copy(t.center).add(u_)),this.expandByPoint(oc.copy(t.center).sub(u_))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}}let DR=0;const Da=new zn,c_=new qi,Ol=new ft,ua=new Kc,lc=new Kc,ni=new ft;class tr extends hu{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:DR++}),this.uuid=Zc(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(uR(t)?U1:D1)(t,1):this.index=t,this}setIndirect(t,n=0){return this.indirect=t,this.indirectOffset=n,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,n){return this.attributes[t]=n,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,n,a=0){this.groups.push({start:t,count:n,materialIndex:a})}clearGroups(){this.groups=[]}setDrawRange(t,n){this.drawRange.start=t,this.drawRange.count=n}applyMatrix4(t){const n=this.attributes.position;n!==void 0&&(n.applyMatrix4(t),n.needsUpdate=!0);const a=this.attributes.normal;if(a!==void 0){const l=new we().getNormalMatrix(t);a.applyNormalMatrix(l),a.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(t),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return Da.makeRotationFromQuaternion(t),this.applyMatrix4(Da),this}rotateX(t){return Da.makeRotationX(t),this.applyMatrix4(Da),this}rotateY(t){return Da.makeRotationY(t),this.applyMatrix4(Da),this}rotateZ(t){return Da.makeRotationZ(t),this.applyMatrix4(Da),this}translate(t,n,a){return Da.makeTranslation(t,n,a),this.applyMatrix4(Da),this}scale(t,n,a){return Da.makeScale(t,n,a),this.applyMatrix4(Da),this}lookAt(t){return c_.lookAt(t),c_.updateMatrix(),this.applyMatrix4(c_.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Ol).negate(),this.translate(Ol.x,Ol.y,Ol.z),this}setFromPoints(t){const n=this.getAttribute("position");if(n===void 0){const a=[];for(let r=0,l=t.length;r<l;r++){const c=t[r];a.push(c.x,c.y,c.z||0)}this.setAttribute("position",new Ba(a,3))}else{const a=Math.min(t.length,n.count);for(let r=0;r<a;r++){const l=t[r];n.setXYZ(r,l.x,l.y,l.z||0)}t.length>n.count&&Me("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),n.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Kc);const t=this.attributes.position,n=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){Qe("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new ft(-1/0,-1/0,-1/0),new ft(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),n)for(let a=0,r=n.length;a<r;a++){const l=n[a];ua.setFromBufferAttribute(l),this.morphTargetsRelative?(ni.addVectors(this.boundingBox.min,ua.min),this.boundingBox.expandByPoint(ni),ni.addVectors(this.boundingBox.max,ua.max),this.boundingBox.expandByPoint(ni)):(this.boundingBox.expandByPoint(ua.min),this.boundingBox.expandByPoint(ua.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Qe('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ad);const t=this.attributes.position,n=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){Qe("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new ft,1/0);return}if(t){const a=this.boundingSphere.center;if(ua.setFromBufferAttribute(t),n)for(let l=0,c=n.length;l<c;l++){const f=n[l];lc.setFromBufferAttribute(f),this.morphTargetsRelative?(ni.addVectors(ua.min,lc.min),ua.expandByPoint(ni),ni.addVectors(ua.max,lc.max),ua.expandByPoint(ni)):(ua.expandByPoint(lc.min),ua.expandByPoint(lc.max))}ua.getCenter(a);let r=0;for(let l=0,c=t.count;l<c;l++)ni.fromBufferAttribute(t,l),r=Math.max(r,a.distanceToSquared(ni));if(n)for(let l=0,c=n.length;l<c;l++){const f=n[l],p=this.morphTargetsRelative;for(let d=0,_=f.count;d<_;d++)ni.fromBufferAttribute(f,d),p&&(Ol.fromBufferAttribute(t,d),ni.add(Ol)),r=Math.max(r,a.distanceToSquared(ni))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&Qe('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,n=this.attributes;if(t===null||n.position===void 0||n.normal===void 0||n.uv===void 0){Qe("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const a=n.position,r=n.normal,l=n.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new xr(new Float32Array(4*a.count),4));const c=this.getAttribute("tangent"),f=[],p=[];for(let T=0;T<a.count;T++)f[T]=new ft,p[T]=new ft;const d=new ft,_=new ft,v=new ft,g=new fn,x=new fn,M=new fn,E=new ft,y=new ft;function S(T,w,q){d.fromBufferAttribute(a,T),_.fromBufferAttribute(a,w),v.fromBufferAttribute(a,q),g.fromBufferAttribute(l,T),x.fromBufferAttribute(l,w),M.fromBufferAttribute(l,q),_.sub(d),v.sub(d),x.sub(g),M.sub(g);const G=1/(x.x*M.y-M.x*x.y);isFinite(G)&&(E.copy(_).multiplyScalar(M.y).addScaledVector(v,-x.y).multiplyScalar(G),y.copy(v).multiplyScalar(x.x).addScaledVector(_,-M.x).multiplyScalar(G),f[T].add(E),f[w].add(E),f[q].add(E),p[T].add(y),p[w].add(y),p[q].add(y))}let R=this.groups;R.length===0&&(R=[{start:0,count:t.count}]);for(let T=0,w=R.length;T<w;++T){const q=R[T],G=q.start,k=q.count;for(let J=G,et=G+k;J<et;J+=3)S(t.getX(J+0),t.getX(J+1),t.getX(J+2))}const U=new ft,C=new ft,O=new ft,P=new ft;function L(T){O.fromBufferAttribute(r,T),P.copy(O);const w=f[T];U.copy(w),U.sub(O.multiplyScalar(O.dot(w))).normalize(),C.crossVectors(P,w);const G=C.dot(p[T])<0?-1:1;c.setXYZW(T,U.x,U.y,U.z,G)}for(let T=0,w=R.length;T<w;++T){const q=R[T],G=q.start,k=q.count;for(let J=G,et=G+k;J<et;J+=3)L(t.getX(J+0)),L(t.getX(J+1)),L(t.getX(J+2))}}computeVertexNormals(){const t=this.index,n=this.getAttribute("position");if(n!==void 0){let a=this.getAttribute("normal");if(a===void 0)a=new xr(new Float32Array(n.count*3),3),this.setAttribute("normal",a);else for(let g=0,x=a.count;g<x;g++)a.setXYZ(g,0,0,0);const r=new ft,l=new ft,c=new ft,f=new ft,p=new ft,d=new ft,_=new ft,v=new ft;if(t)for(let g=0,x=t.count;g<x;g+=3){const M=t.getX(g+0),E=t.getX(g+1),y=t.getX(g+2);r.fromBufferAttribute(n,M),l.fromBufferAttribute(n,E),c.fromBufferAttribute(n,y),_.subVectors(c,l),v.subVectors(r,l),_.cross(v),f.fromBufferAttribute(a,M),p.fromBufferAttribute(a,E),d.fromBufferAttribute(a,y),f.add(_),p.add(_),d.add(_),a.setXYZ(M,f.x,f.y,f.z),a.setXYZ(E,p.x,p.y,p.z),a.setXYZ(y,d.x,d.y,d.z)}else for(let g=0,x=n.count;g<x;g+=3)r.fromBufferAttribute(n,g+0),l.fromBufferAttribute(n,g+1),c.fromBufferAttribute(n,g+2),_.subVectors(c,l),v.subVectors(r,l),_.cross(v),a.setXYZ(g+0,_.x,_.y,_.z),a.setXYZ(g+1,_.x,_.y,_.z),a.setXYZ(g+2,_.x,_.y,_.z);this.normalizeNormals(),a.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let n=0,a=t.count;n<a;n++)ni.fromBufferAttribute(t,n),ni.normalize(),t.setXYZ(n,ni.x,ni.y,ni.z)}toNonIndexed(){function t(f,p){const d=f.array,_=f.itemSize,v=f.normalized,g=new d.constructor(p.length*_);let x=0,M=0;for(let E=0,y=p.length;E<y;E++){f.isInterleavedBufferAttribute?x=p[E]*f.data.stride+f.offset:x=p[E]*_;for(let S=0;S<_;S++)g[M++]=d[x++]}return new xr(g,_,v)}if(this.index===null)return Me("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const n=new tr,a=this.index.array,r=this.attributes;for(const f in r){const p=r[f],d=t(p,a);n.setAttribute(f,d)}const l=this.morphAttributes;for(const f in l){const p=[],d=l[f];for(let _=0,v=d.length;_<v;_++){const g=d[_],x=t(g,a);p.push(x)}n.morphAttributes[f]=p}n.morphTargetsRelative=this.morphTargetsRelative;const c=this.groups;for(let f=0,p=c.length;f<p;f++){const d=c[f];n.addGroup(d.start,d.count,d.materialIndex)}return n}toJSON(){const t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){const p=this.parameters;for(const d in p)p[d]!==void 0&&(t[d]=p[d]);return t}t.data={attributes:{}};const n=this.index;n!==null&&(t.data.index={type:n.array.constructor.name,array:Array.prototype.slice.call(n.array)});const a=this.attributes;for(const p in a){const d=a[p];t.data.attributes[p]=d.toJSON(t.data)}const r={};let l=!1;for(const p in this.morphAttributes){const d=this.morphAttributes[p],_=[];for(let v=0,g=d.length;v<g;v++){const x=d[v];_.push(x.toJSON(t.data))}_.length>0&&(r[p]=_,l=!0)}l&&(t.data.morphAttributes=r,t.data.morphTargetsRelative=this.morphTargetsRelative);const c=this.groups;c.length>0&&(t.data.groups=JSON.parse(JSON.stringify(c)));const f=this.boundingSphere;return f!==null&&(t.data.boundingSphere=f.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const n={};this.name=t.name;const a=t.index;a!==null&&this.setIndex(a.clone());const r=t.attributes;for(const d in r){const _=r[d];this.setAttribute(d,_.clone(n))}const l=t.morphAttributes;for(const d in l){const _=[],v=l[d];for(let g=0,x=v.length;g<x;g++)_.push(v[g].clone(n));this.morphAttributes[d]=_}this.morphTargetsRelative=t.morphTargetsRelative;const c=t.groups;for(let d=0,_=c.length;d<_;d++){const v=c[d];this.addGroup(v.start,v.count,v.materialIndex)}const f=t.boundingBox;f!==null&&(this.boundingBox=f.clone());const p=t.boundingSphere;return p!==null&&(this.boundingSphere=p.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}let UR=0;class Qc extends hu{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:UR++}),this.uuid=Zc(),this.name="",this.type="Material",this.blending=Yl,this.side=Ys,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=z_,this.blendDst=I_,this.blendEquation=Ro,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new qe(0,0,0),this.blendAlpha=0,this.depthFunc=tu,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=US,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=bl,this.stencilZFail=bl,this.stencilZPass=bl,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const n in t){const a=t[n];if(a===void 0){Me(`Material: parameter '${n}' has value of undefined.`);continue}const r=this[n];if(r===void 0){Me(`Material: '${n}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(a):r&&r.isVector3&&a&&a.isVector3?r.copy(a):this[n]=a}}toJSON(t){const n=t===void 0||typeof t=="string";n&&(t={textures:{},images:{}});const a={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};a.uuid=this.uuid,a.type=this.type,this.name!==""&&(a.name=this.name),this.color&&this.color.isColor&&(a.color=this.color.getHex()),this.roughness!==void 0&&(a.roughness=this.roughness),this.metalness!==void 0&&(a.metalness=this.metalness),this.sheen!==void 0&&(a.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(a.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(a.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(a.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(a.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(a.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(a.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(a.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(a.shininess=this.shininess),this.clearcoat!==void 0&&(a.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(a.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(a.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(a.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(a.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,a.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(a.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(a.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(a.dispersion=this.dispersion),this.iridescence!==void 0&&(a.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(a.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(a.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(a.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(a.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(a.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(a.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(a.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(a.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(a.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(a.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(a.lightMap=this.lightMap.toJSON(t).uuid,a.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(a.aoMap=this.aoMap.toJSON(t).uuid,a.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(a.bumpMap=this.bumpMap.toJSON(t).uuid,a.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(a.normalMap=this.normalMap.toJSON(t).uuid,a.normalMapType=this.normalMapType,a.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(a.displacementMap=this.displacementMap.toJSON(t).uuid,a.displacementScale=this.displacementScale,a.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(a.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(a.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(a.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(a.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(a.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(a.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(a.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(a.combine=this.combine)),this.envMapRotation!==void 0&&(a.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(a.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(a.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(a.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(a.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(a.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(a.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(a.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(a.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(a.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(a.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(a.size=this.size),this.shadowSide!==null&&(a.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(a.sizeAttenuation=this.sizeAttenuation),this.blending!==Yl&&(a.blending=this.blending),this.side!==Ys&&(a.side=this.side),this.vertexColors===!0&&(a.vertexColors=!0),this.opacity<1&&(a.opacity=this.opacity),this.transparent===!0&&(a.transparent=!0),this.blendSrc!==z_&&(a.blendSrc=this.blendSrc),this.blendDst!==I_&&(a.blendDst=this.blendDst),this.blendEquation!==Ro&&(a.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(a.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(a.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(a.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(a.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(a.blendAlpha=this.blendAlpha),this.depthFunc!==tu&&(a.depthFunc=this.depthFunc),this.depthTest===!1&&(a.depthTest=this.depthTest),this.depthWrite===!1&&(a.depthWrite=this.depthWrite),this.colorWrite===!1&&(a.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(a.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==US&&(a.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(a.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(a.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==bl&&(a.stencilFail=this.stencilFail),this.stencilZFail!==bl&&(a.stencilZFail=this.stencilZFail),this.stencilZPass!==bl&&(a.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(a.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(a.rotation=this.rotation),this.polygonOffset===!0&&(a.polygonOffset=!0),this.polygonOffsetFactor!==0&&(a.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(a.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(a.linewidth=this.linewidth),this.dashSize!==void 0&&(a.dashSize=this.dashSize),this.gapSize!==void 0&&(a.gapSize=this.gapSize),this.scale!==void 0&&(a.scale=this.scale),this.dithering===!0&&(a.dithering=!0),this.alphaTest>0&&(a.alphaTest=this.alphaTest),this.alphaHash===!0&&(a.alphaHash=!0),this.alphaToCoverage===!0&&(a.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(a.premultipliedAlpha=!0),this.forceSinglePass===!0&&(a.forceSinglePass=!0),this.allowOverride===!1&&(a.allowOverride=!1),this.wireframe===!0&&(a.wireframe=!0),this.wireframeLinewidth>1&&(a.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(a.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(a.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(a.flatShading=!0),this.visible===!1&&(a.visible=!1),this.toneMapped===!1&&(a.toneMapped=!1),this.fog===!1&&(a.fog=!1),Object.keys(this.userData).length>0&&(a.userData=this.userData);function r(l){const c=[];for(const f in l){const p=l[f];delete p.metadata,c.push(p)}return c}if(n){const l=r(t.textures),c=r(t.images);l.length>0&&(a.textures=l),c.length>0&&(a.images=c)}return a}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const n=t.clippingPlanes;let a=null;if(n!==null){const r=n.length;a=new Array(r);for(let l=0;l!==r;++l)a[l]=n[l].clone()}return this.clippingPlanes=a,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.allowOverride=t.allowOverride,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}}const Wr=new ft,f_=new ft,vh=new ft,Ls=new ft,h_=new ft,xh=new ft,d_=new ft;class N1{constructor(t=new ft,n=new ft(0,0,-1)){this.origin=t,this.direction=n}set(t,n){return this.origin.copy(t),this.direction.copy(n),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,n){return n.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,Wr)),this}closestPointToPoint(t,n){n.subVectors(t,this.origin);const a=n.dot(this.direction);return a<0?n.copy(this.origin):n.copy(this.origin).addScaledVector(this.direction,a)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const n=Wr.subVectors(t,this.origin).dot(this.direction);return n<0?this.origin.distanceToSquared(t):(Wr.copy(this.origin).addScaledVector(this.direction,n),Wr.distanceToSquared(t))}distanceSqToSegment(t,n,a,r){f_.copy(t).add(n).multiplyScalar(.5),vh.copy(n).sub(t).normalize(),Ls.copy(this.origin).sub(f_);const l=t.distanceTo(n)*.5,c=-this.direction.dot(vh),f=Ls.dot(this.direction),p=-Ls.dot(vh),d=Ls.lengthSq(),_=Math.abs(1-c*c);let v,g,x,M;if(_>0)if(v=c*p-f,g=c*f-p,M=l*_,v>=0)if(g>=-M)if(g<=M){const E=1/_;v*=E,g*=E,x=v*(v+c*g+2*f)+g*(c*v+g+2*p)+d}else g=l,v=Math.max(0,-(c*g+f)),x=-v*v+g*(g+2*p)+d;else g=-l,v=Math.max(0,-(c*g+f)),x=-v*v+g*(g+2*p)+d;else g<=-M?(v=Math.max(0,-(-c*l+f)),g=v>0?-l:Math.min(Math.max(-l,-p),l),x=-v*v+g*(g+2*p)+d):g<=M?(v=0,g=Math.min(Math.max(-l,-p),l),x=g*(g+2*p)+d):(v=Math.max(0,-(c*l+f)),g=v>0?l:Math.min(Math.max(-l,-p),l),x=-v*v+g*(g+2*p)+d);else g=c>0?-l:l,v=Math.max(0,-(c*g+f)),x=-v*v+g*(g+2*p)+d;return a&&a.copy(this.origin).addScaledVector(this.direction,v),r&&r.copy(f_).addScaledVector(vh,g),x}intersectSphere(t,n){Wr.subVectors(t.center,this.origin);const a=Wr.dot(this.direction),r=Wr.dot(Wr)-a*a,l=t.radius*t.radius;if(r>l)return null;const c=Math.sqrt(l-r),f=a-c,p=a+c;return p<0?null:f<0?this.at(p,n):this.at(f,n)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const n=t.normal.dot(this.direction);if(n===0)return t.distanceToPoint(this.origin)===0?0:null;const a=-(this.origin.dot(t.normal)+t.constant)/n;return a>=0?a:null}intersectPlane(t,n){const a=this.distanceToPlane(t);return a===null?null:this.at(a,n)}intersectsPlane(t){const n=t.distanceToPoint(this.origin);return n===0||t.normal.dot(this.direction)*n<0}intersectBox(t,n){let a,r,l,c,f,p;const d=1/this.direction.x,_=1/this.direction.y,v=1/this.direction.z,g=this.origin;return d>=0?(a=(t.min.x-g.x)*d,r=(t.max.x-g.x)*d):(a=(t.max.x-g.x)*d,r=(t.min.x-g.x)*d),_>=0?(l=(t.min.y-g.y)*_,c=(t.max.y-g.y)*_):(l=(t.max.y-g.y)*_,c=(t.min.y-g.y)*_),a>c||l>r||((l>a||isNaN(a))&&(a=l),(c<r||isNaN(r))&&(r=c),v>=0?(f=(t.min.z-g.z)*v,p=(t.max.z-g.z)*v):(f=(t.max.z-g.z)*v,p=(t.min.z-g.z)*v),a>p||f>r)||((f>a||a!==a)&&(a=f),(p<r||r!==r)&&(r=p),r<0)?null:this.at(a>=0?a:r,n)}intersectsBox(t){return this.intersectBox(t,Wr)!==null}intersectTriangle(t,n,a,r,l){h_.subVectors(n,t),xh.subVectors(a,t),d_.crossVectors(h_,xh);let c=this.direction.dot(d_),f;if(c>0){if(r)return null;f=1}else if(c<0)f=-1,c=-c;else return null;Ls.subVectors(this.origin,t);const p=f*this.direction.dot(xh.crossVectors(Ls,xh));if(p<0)return null;const d=f*this.direction.dot(h_.cross(Ls));if(d<0||p+d>c)return null;const _=-f*Ls.dot(d_);return _<0?null:this.at(_/c,l)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class fg extends Qc{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new qe(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new is,this.combine=c1,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const qS=new zn,go=new N1,yh=new Ad,jS=new ft,Sh=new ft,Mh=new ft,Eh=new ft,p_=new ft,bh=new ft,ZS=new ft,Th=new ft;class $a extends qi{constructor(t=new tr,n=new fg){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=n,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,n){return super.copy(t,n),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const n=this.geometry.morphAttributes,a=Object.keys(n);if(a.length>0){const r=n[a[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let l=0,c=r.length;l<c;l++){const f=r[l].name||String(l);this.morphTargetInfluences.push(0),this.morphTargetDictionary[f]=l}}}}getVertexPosition(t,n){const a=this.geometry,r=a.attributes.position,l=a.morphAttributes.position,c=a.morphTargetsRelative;n.fromBufferAttribute(r,t);const f=this.morphTargetInfluences;if(l&&f){bh.set(0,0,0);for(let p=0,d=l.length;p<d;p++){const _=f[p],v=l[p];_!==0&&(p_.fromBufferAttribute(v,t),c?bh.addScaledVector(p_,_):bh.addScaledVector(p_.sub(n),_))}n.add(bh)}return n}raycast(t,n){const a=this.geometry,r=this.material,l=this.matrixWorld;r!==void 0&&(a.boundingSphere===null&&a.computeBoundingSphere(),yh.copy(a.boundingSphere),yh.applyMatrix4(l),go.copy(t.ray).recast(t.near),!(yh.containsPoint(go.origin)===!1&&(go.intersectSphere(yh,jS)===null||go.origin.distanceToSquared(jS)>(t.far-t.near)**2))&&(qS.copy(l).invert(),go.copy(t.ray).applyMatrix4(qS),!(a.boundingBox!==null&&go.intersectsBox(a.boundingBox)===!1)&&this._computeIntersections(t,n,go)))}_computeIntersections(t,n,a){let r;const l=this.geometry,c=this.material,f=l.index,p=l.attributes.position,d=l.attributes.uv,_=l.attributes.uv1,v=l.attributes.normal,g=l.groups,x=l.drawRange;if(f!==null)if(Array.isArray(c))for(let M=0,E=g.length;M<E;M++){const y=g[M],S=c[y.materialIndex],R=Math.max(y.start,x.start),U=Math.min(f.count,Math.min(y.start+y.count,x.start+x.count));for(let C=R,O=U;C<O;C+=3){const P=f.getX(C),L=f.getX(C+1),T=f.getX(C+2);r=Ah(this,S,t,a,d,_,v,P,L,T),r&&(r.faceIndex=Math.floor(C/3),r.face.materialIndex=y.materialIndex,n.push(r))}}else{const M=Math.max(0,x.start),E=Math.min(f.count,x.start+x.count);for(let y=M,S=E;y<S;y+=3){const R=f.getX(y),U=f.getX(y+1),C=f.getX(y+2);r=Ah(this,c,t,a,d,_,v,R,U,C),r&&(r.faceIndex=Math.floor(y/3),n.push(r))}}else if(p!==void 0)if(Array.isArray(c))for(let M=0,E=g.length;M<E;M++){const y=g[M],S=c[y.materialIndex],R=Math.max(y.start,x.start),U=Math.min(p.count,Math.min(y.start+y.count,x.start+x.count));for(let C=R,O=U;C<O;C+=3){const P=C,L=C+1,T=C+2;r=Ah(this,S,t,a,d,_,v,P,L,T),r&&(r.faceIndex=Math.floor(C/3),r.face.materialIndex=y.materialIndex,n.push(r))}}else{const M=Math.max(0,x.start),E=Math.min(p.count,x.start+x.count);for(let y=M,S=E;y<S;y+=3){const R=y,U=y+1,C=y+2;r=Ah(this,c,t,a,d,_,v,R,U,C),r&&(r.faceIndex=Math.floor(y/3),n.push(r))}}}}function NR(o,t,n,a,r,l,c,f){let p;if(t.side===Yi?p=a.intersectTriangle(c,l,r,!0,f):p=a.intersectTriangle(r,l,c,t.side===Ys,f),p===null)return null;Th.copy(f),Th.applyMatrix4(o.matrixWorld);const d=n.ray.origin.distanceTo(Th);return d<n.near||d>n.far?null:{distance:d,point:Th.clone(),object:o}}function Ah(o,t,n,a,r,l,c,f,p,d){o.getVertexPosition(f,Sh),o.getVertexPosition(p,Mh),o.getVertexPosition(d,Eh);const _=NR(o,t,n,a,Sh,Mh,Eh,ZS);if(_){const v=new ft;Qa.getBarycoord(ZS,Sh,Mh,Eh,v),r&&(_.uv=Qa.getInterpolatedAttribute(r,f,p,d,v,new fn)),l&&(_.uv1=Qa.getInterpolatedAttribute(l,f,p,d,v,new fn)),c&&(_.normal=Qa.getInterpolatedAttribute(c,f,p,d,v,new ft),_.normal.dot(a.direction)>0&&_.normal.multiplyScalar(-1));const g={a:f,b:p,c:d,normal:new ft,materialIndex:0};Qa.getNormal(Sh,Mh,Eh,g.normal),_.face=g,_.barycoord=v}return _}class LR extends zi{constructor(t=null,n=1,a=1,r,l,c,f,p,d=ci,_=ci,v,g){super(null,c,f,p,d,_,r,l,v,g),this.isDataTexture=!0,this.image={data:t,width:n,height:a},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const m_=new ft,OR=new ft,PR=new we;class Eo{constructor(t=new ft(1,0,0),n=0){this.isPlane=!0,this.normal=t,this.constant=n}set(t,n){return this.normal.copy(t),this.constant=n,this}setComponents(t,n,a,r){return this.normal.set(t,n,a),this.constant=r,this}setFromNormalAndCoplanarPoint(t,n){return this.normal.copy(t),this.constant=-n.dot(this.normal),this}setFromCoplanarPoints(t,n,a){const r=m_.subVectors(a,n).cross(OR.subVectors(t,n)).normalize();return this.setFromNormalAndCoplanarPoint(r,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,n){return n.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,n){const a=t.delta(m_),r=this.normal.dot(a);if(r===0)return this.distanceToPoint(t.start)===0?n.copy(t.start):null;const l=-(t.start.dot(this.normal)+this.constant)/r;return l<0||l>1?null:n.copy(t.start).addScaledVector(a,l)}intersectsLine(t){const n=this.distanceToPoint(t.start),a=this.distanceToPoint(t.end);return n<0&&a>0||a<0&&n>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,n){const a=n||PR.getNormalMatrix(t),r=this.coplanarPoint(m_).applyMatrix4(t),l=this.normal.applyMatrix3(a).normalize();return this.constant=-r.dot(l),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}}const vo=new Ad,FR=new fn(.5,.5),Rh=new ft;class L1{constructor(t=new Eo,n=new Eo,a=new Eo,r=new Eo,l=new Eo,c=new Eo){this.planes=[t,n,a,r,l,c]}set(t,n,a,r,l,c){const f=this.planes;return f[0].copy(t),f[1].copy(n),f[2].copy(a),f[3].copy(r),f[4].copy(l),f[5].copy(c),this}copy(t){const n=this.planes;for(let a=0;a<6;a++)n[a].copy(t.planes[a]);return this}setFromProjectionMatrix(t,n=pr,a=!1){const r=this.planes,l=t.elements,c=l[0],f=l[1],p=l[2],d=l[3],_=l[4],v=l[5],g=l[6],x=l[7],M=l[8],E=l[9],y=l[10],S=l[11],R=l[12],U=l[13],C=l[14],O=l[15];if(r[0].setComponents(d-c,x-_,S-M,O-R).normalize(),r[1].setComponents(d+c,x+_,S+M,O+R).normalize(),r[2].setComponents(d+f,x+v,S+E,O+U).normalize(),r[3].setComponents(d-f,x-v,S-E,O-U).normalize(),a)r[4].setComponents(p,g,y,C).normalize(),r[5].setComponents(d-p,x-g,S-y,O-C).normalize();else if(r[4].setComponents(d-p,x-g,S-y,O-C).normalize(),n===pr)r[5].setComponents(d+p,x+g,S+y,O+C).normalize();else if(n===cd)r[5].setComponents(p,g,y,C).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+n);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),vo.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const n=t.geometry;n.boundingSphere===null&&n.computeBoundingSphere(),vo.copy(n.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(vo)}intersectsSprite(t){vo.center.set(0,0,0);const n=FR.distanceTo(t.center);return vo.radius=.7071067811865476+n,vo.applyMatrix4(t.matrixWorld),this.intersectsSphere(vo)}intersectsSphere(t){const n=this.planes,a=t.center,r=-t.radius;for(let l=0;l<6;l++)if(n[l].distanceToPoint(a)<r)return!1;return!0}intersectsBox(t){const n=this.planes;for(let a=0;a<6;a++){const r=n[a];if(Rh.x=r.normal.x>0?t.max.x:t.min.x,Rh.y=r.normal.y>0?t.max.y:t.min.y,Rh.z=r.normal.z>0?t.max.z:t.min.z,r.distanceToPoint(Rh)<0)return!1}return!0}containsPoint(t){const n=this.planes;for(let a=0;a<6;a++)if(n[a].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class zR extends Qc{constructor(t){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new qe(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this}}const KS=new zn,R0=new N1,Ch=new Ad,wh=new ft;class IR extends qi{constructor(t=new tr,n=new zR){super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=n,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(t,n){return super.copy(t,n),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}raycast(t,n){const a=this.geometry,r=this.matrixWorld,l=t.params.Points.threshold,c=a.drawRange;if(a.boundingSphere===null&&a.computeBoundingSphere(),Ch.copy(a.boundingSphere),Ch.applyMatrix4(r),Ch.radius+=l,t.ray.intersectsSphere(Ch)===!1)return;KS.copy(r).invert(),R0.copy(t.ray).applyMatrix4(KS);const f=l/((this.scale.x+this.scale.y+this.scale.z)/3),p=f*f,d=a.index,v=a.attributes.position;if(d!==null){const g=Math.max(0,c.start),x=Math.min(d.count,c.start+c.count);for(let M=g,E=x;M<E;M++){const y=d.getX(M);wh.fromBufferAttribute(v,y),QS(wh,y,p,r,t,n,this)}}else{const g=Math.max(0,c.start),x=Math.min(v.count,c.start+c.count);for(let M=g,E=x;M<E;M++)wh.fromBufferAttribute(v,M),QS(wh,M,p,r,t,n,this)}}updateMorphTargets(){const n=this.geometry.morphAttributes,a=Object.keys(n);if(a.length>0){const r=n[a[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let l=0,c=r.length;l<c;l++){const f=r[l].name||String(l);this.morphTargetInfluences.push(0),this.morphTargetDictionary[f]=l}}}}}function QS(o,t,n,a,r,l,c){const f=R0.distanceSqToPoint(o);if(f<n){const p=new ft;R0.closestPointToPoint(o,p),p.applyMatrix4(a);const d=r.ray.origin.distanceTo(p);if(d<r.near||d>r.far)return;l.push({distance:d,distanceToRay:Math.sqrt(f),point:p,index:t,face:null,faceIndex:null,barycoord:null,object:c})}}class O1 extends zi{constructor(t=[],n=Ho,a,r,l,c,f,p,d,_){super(t,n,a,r,l,c,f,p,d,_),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class Bc extends zi{constructor(t,n,a=Sr,r,l,c,f=ci,p=ci,d,_=ns,v=1){if(_!==ns&&_!==Do)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const g={width:t,height:n,depth:v};super(g,r,l,c,f,p,_,a,d),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new cg(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){const n=super.toJSON(t);return this.compareFunction!==null&&(n.compareFunction=this.compareFunction),n}}class BR extends Bc{constructor(t,n=Sr,a=Ho,r,l,c=ci,f=ci,p,d=ns){const _={width:t,height:t,depth:1},v=[_,_,_,_,_,_];super(t,t,n,a,r,l,c,f,p,d),this.image=v,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(t){this.image=t}}class P1 extends zi{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}}class Jc extends tr{constructor(t=1,n=1,a=1,r=1,l=1,c=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:n,depth:a,widthSegments:r,heightSegments:l,depthSegments:c};const f=this;r=Math.floor(r),l=Math.floor(l),c=Math.floor(c);const p=[],d=[],_=[],v=[];let g=0,x=0;M("z","y","x",-1,-1,a,n,t,c,l,0),M("z","y","x",1,-1,a,n,-t,c,l,1),M("x","z","y",1,1,t,a,n,r,c,2),M("x","z","y",1,-1,t,a,-n,r,c,3),M("x","y","z",1,-1,t,n,a,r,l,4),M("x","y","z",-1,-1,t,n,-a,r,l,5),this.setIndex(p),this.setAttribute("position",new Ba(d,3)),this.setAttribute("normal",new Ba(_,3)),this.setAttribute("uv",new Ba(v,2));function M(E,y,S,R,U,C,O,P,L,T,w){const q=C/L,G=O/T,k=C/2,J=O/2,et=P/2,Q=L+1,F=T+1;let I=0,it=0;const ht=new ft;for(let H=0;H<F;H++){const z=H*G-J;for(let K=0;K<Q;K++){const xt=K*q-k;ht[E]=xt*R,ht[y]=z*U,ht[S]=et,d.push(ht.x,ht.y,ht.z),ht[E]=0,ht[y]=0,ht[S]=P>0?1:-1,_.push(ht.x,ht.y,ht.z),v.push(K/L),v.push(1-H/T),I+=1}}for(let H=0;H<T;H++)for(let z=0;z<L;z++){const K=g+z+Q*H,xt=g+z+Q*(H+1),Tt=g+(z+1)+Q*(H+1),Ut=g+(z+1)+Q*H;p.push(K,xt,Ut),p.push(xt,Tt,Ut),it+=6}f.addGroup(x,it,w),x+=it,g+=I}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Jc(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}class Rd extends tr{constructor(t=1,n=1,a=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:n,widthSegments:a,heightSegments:r};const l=t/2,c=n/2,f=Math.floor(a),p=Math.floor(r),d=f+1,_=p+1,v=t/f,g=n/p,x=[],M=[],E=[],y=[];for(let S=0;S<_;S++){const R=S*g-c;for(let U=0;U<d;U++){const C=U*v-l;M.push(C,-R,0),E.push(0,0,1),y.push(U/f),y.push(1-S/p)}}for(let S=0;S<p;S++)for(let R=0;R<f;R++){const U=R+d*S,C=R+d*(S+1),O=R+1+d*(S+1),P=R+1+d*S;x.push(U,C,P),x.push(C,O,P)}this.setIndex(x),this.setAttribute("position",new Ba(M,3)),this.setAttribute("normal",new Ba(E,3)),this.setAttribute("uv",new Ba(y,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Rd(t.width,t.height,t.widthSegments,t.heightSegments)}}class dd extends tr{constructor(t=1,n=32,a=16,r=0,l=Math.PI*2,c=0,f=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:n,heightSegments:a,phiStart:r,phiLength:l,thetaStart:c,thetaLength:f},n=Math.max(3,Math.floor(n)),a=Math.max(2,Math.floor(a));const p=Math.min(c+f,Math.PI);let d=0;const _=[],v=new ft,g=new ft,x=[],M=[],E=[],y=[];for(let S=0;S<=a;S++){const R=[],U=S/a;let C=0;S===0&&c===0?C=.5/n:S===a&&p===Math.PI&&(C=-.5/n);for(let O=0;O<=n;O++){const P=O/n;v.x=-t*Math.cos(r+P*l)*Math.sin(c+U*f),v.y=t*Math.cos(c+U*f),v.z=t*Math.sin(r+P*l)*Math.sin(c+U*f),M.push(v.x,v.y,v.z),g.copy(v).normalize(),E.push(g.x,g.y,g.z),y.push(P+C,1-U),R.push(d++)}_.push(R)}for(let S=0;S<a;S++)for(let R=0;R<n;R++){const U=_[S][R+1],C=_[S][R],O=_[S+1][R],P=_[S+1][R+1];(S!==0||c>0)&&x.push(U,C,P),(S!==a-1||p<Math.PI)&&x.push(C,O,P)}this.setIndex(x),this.setAttribute("position",new Ba(M,3)),this.setAttribute("normal",new Ba(E,3)),this.setAttribute("uv",new Ba(y,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new dd(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}}function au(o){const t={};for(const n in o){t[n]={};for(const a in o[n]){const r=o[n][a];r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)?r.isRenderTargetTexture?(Me("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[n][a]=null):t[n][a]=r.clone():Array.isArray(r)?t[n][a]=r.slice():t[n][a]=r}}return t}function Ui(o){const t={};for(let n=0;n<o.length;n++){const a=au(o[n]);for(const r in a)t[r]=a[r]}return t}function HR(o){const t=[];for(let n=0;n<o.length;n++)t.push(o[n].clone());return t}function F1(o){const t=o.getRenderTarget();return t===null?o.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Ye.workingColorSpace}const GR={clone:au,merge:Ui};var VR=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,kR=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Ga extends Qc{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=VR,this.fragmentShader=kR,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=au(t.uniforms),this.uniformsGroups=HR(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this.defaultAttributeValues=Object.assign({},t.defaultAttributeValues),this.index0AttributeName=t.index0AttributeName,this.uniformsNeedUpdate=t.uniformsNeedUpdate,this}toJSON(t){const n=super.toJSON(t);n.glslVersion=this.glslVersion,n.uniforms={};for(const r in this.uniforms){const c=this.uniforms[r].value;c&&c.isTexture?n.uniforms[r]={type:"t",value:c.toJSON(t).uuid}:c&&c.isColor?n.uniforms[r]={type:"c",value:c.getHex()}:c&&c.isVector2?n.uniforms[r]={type:"v2",value:c.toArray()}:c&&c.isVector3?n.uniforms[r]={type:"v3",value:c.toArray()}:c&&c.isVector4?n.uniforms[r]={type:"v4",value:c.toArray()}:c&&c.isMatrix3?n.uniforms[r]={type:"m3",value:c.toArray()}:c&&c.isMatrix4?n.uniforms[r]={type:"m4",value:c.toArray()}:n.uniforms[r]={value:c}}Object.keys(this.defines).length>0&&(n.defines=this.defines),n.vertexShader=this.vertexShader,n.fragmentShader=this.fragmentShader,n.lights=this.lights,n.clipping=this.clipping;const a={};for(const r in this.extensions)this.extensions[r]===!0&&(a[r]=!0);return Object.keys(a).length>0&&(n.extensions=a),n}}class XR extends Ga{constructor(t){super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class WR extends Qc{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=tR,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class YR extends Qc{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}const Dh=new ft,Uh=new du,rr=new ft;class z1 extends qi{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new zn,this.projectionMatrix=new zn,this.projectionMatrixInverse=new zn,this.coordinateSystem=pr,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,n){return super.copy(t,n),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorld.decompose(Dh,Uh,rr),rr.x===1&&rr.y===1&&rr.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Dh,Uh,rr.set(1,1,1)).invert()}updateWorldMatrix(t,n){super.updateWorldMatrix(t,n),this.matrixWorld.decompose(Dh,Uh,rr),rr.x===1&&rr.y===1&&rr.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Dh,Uh,rr.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const Os=new ft,JS=new fn,$S=new fn;class La extends z1{constructor(t=50,n=1,a=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=a,this.far=r,this.focus=10,this.aspect=n,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,n){return super.copy(t,n),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const n=.5*this.getFilmHeight()/t;this.fov=A0*2*Math.atan(n),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(Ym*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return A0*2*Math.atan(Math.tan(Ym*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,n,a){Os.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Os.x,Os.y).multiplyScalar(-t/Os.z),Os.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),a.set(Os.x,Os.y).multiplyScalar(-t/Os.z)}getViewSize(t,n){return this.getViewBounds(t,JS,$S),n.subVectors($S,JS)}setViewOffset(t,n,a,r,l,c){this.aspect=t/n,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=n,this.view.offsetX=a,this.view.offsetY=r,this.view.width=l,this.view.height=c,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let n=t*Math.tan(Ym*.5*this.fov)/this.zoom,a=2*n,r=this.aspect*a,l=-.5*r;const c=this.view;if(this.view!==null&&this.view.enabled){const p=c.fullWidth,d=c.fullHeight;l+=c.offsetX*r/p,n-=c.offsetY*a/d,r*=c.width/p,a*=c.height/d}const f=this.filmOffset;f!==0&&(l+=t*f/this.getFilmWidth()),this.projectionMatrix.makePerspective(l,l+r,n,n-a,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const n=super.toJSON(t);return n.object.fov=this.fov,n.object.zoom=this.zoom,n.object.near=this.near,n.object.far=this.far,n.object.focus=this.focus,n.object.aspect=this.aspect,this.view!==null&&(n.object.view=Object.assign({},this.view)),n.object.filmGauge=this.filmGauge,n.object.filmOffset=this.filmOffset,n}}class I1 extends z1{constructor(t=-1,n=1,a=1,r=-1,l=.1,c=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=n,this.top=a,this.bottom=r,this.near=l,this.far=c,this.updateProjectionMatrix()}copy(t,n){return super.copy(t,n),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,n,a,r,l,c){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=n,this.view.offsetX=a,this.view.offsetY=r,this.view.width=l,this.view.height=c,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),n=(this.top-this.bottom)/(2*this.zoom),a=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let l=a-t,c=a+t,f=r+n,p=r-n;if(this.view!==null&&this.view.enabled){const d=(this.right-this.left)/this.view.fullWidth/this.zoom,_=(this.top-this.bottom)/this.view.fullHeight/this.zoom;l+=d*this.view.offsetX,c=l+d*this.view.width,f-=_*this.view.offsetY,p=f-_*this.view.height}this.projectionMatrix.makeOrthographic(l,c,f,p,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const n=super.toJSON(t);return n.object.zoom=this.zoom,n.object.left=this.left,n.object.right=this.right,n.object.top=this.top,n.object.bottom=this.bottom,n.object.near=this.near,n.object.far=this.far,this.view!==null&&(n.object.view=Object.assign({},this.view)),n}}const Pl=-90,Fl=1;class qR extends qi{constructor(t,n,a){super(),this.type="CubeCamera",this.renderTarget=a,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new La(Pl,Fl,t,n);r.layers=this.layers,this.add(r);const l=new La(Pl,Fl,t,n);l.layers=this.layers,this.add(l);const c=new La(Pl,Fl,t,n);c.layers=this.layers,this.add(c);const f=new La(Pl,Fl,t,n);f.layers=this.layers,this.add(f);const p=new La(Pl,Fl,t,n);p.layers=this.layers,this.add(p);const d=new La(Pl,Fl,t,n);d.layers=this.layers,this.add(d)}updateCoordinateSystem(){const t=this.coordinateSystem,n=this.children.concat(),[a,r,l,c,f,p]=n;for(const d of n)this.remove(d);if(t===pr)a.up.set(0,1,0),a.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),l.up.set(0,0,-1),l.lookAt(0,1,0),c.up.set(0,0,1),c.lookAt(0,-1,0),f.up.set(0,1,0),f.lookAt(0,0,1),p.up.set(0,1,0),p.lookAt(0,0,-1);else if(t===cd)a.up.set(0,-1,0),a.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),l.up.set(0,0,1),l.lookAt(0,1,0),c.up.set(0,0,-1),c.lookAt(0,-1,0),f.up.set(0,-1,0),f.lookAt(0,0,1),p.up.set(0,-1,0),p.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const d of n)this.add(d),d.updateMatrixWorld()}update(t,n){this.parent===null&&this.updateMatrixWorld();const{renderTarget:a,activeMipmapLevel:r}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[l,c,f,p,d,_]=this.children,v=t.getRenderTarget(),g=t.getActiveCubeFace(),x=t.getActiveMipmapLevel(),M=t.xr.enabled;t.xr.enabled=!1;const E=a.texture.generateMipmaps;a.texture.generateMipmaps=!1;let y=!1;t.isWebGLRenderer===!0?y=t.state.buffers.depth.getReversed():y=t.reversedDepthBuffer,t.setRenderTarget(a,0,r),y&&t.autoClear===!1&&t.clearDepth(),t.render(n,l),t.setRenderTarget(a,1,r),y&&t.autoClear===!1&&t.clearDepth(),t.render(n,c),t.setRenderTarget(a,2,r),y&&t.autoClear===!1&&t.clearDepth(),t.render(n,f),t.setRenderTarget(a,3,r),y&&t.autoClear===!1&&t.clearDepth(),t.render(n,p),t.setRenderTarget(a,4,r),y&&t.autoClear===!1&&t.clearDepth(),t.render(n,d),a.texture.generateMipmaps=E,t.setRenderTarget(a,5,r),y&&t.autoClear===!1&&t.clearDepth(),t.render(n,_),t.setRenderTarget(v,g,x),t.xr.enabled=M,a.texture.needsPMREMUpdate=!0}}class jR extends La{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t}}function tM(o,t,n,a){const r=ZR(a);switch(n){case E1:return o*t;case T1:return o*t/r.components*r.byteLength;case rg:return o*t/r.components*r.byteLength;case nu:return o*t*2/r.components*r.byteLength;case sg:return o*t*2/r.components*r.byteLength;case b1:return o*t*3/r.components*r.byteLength;case Ja:return o*t*4/r.components*r.byteLength;case og:return o*t*4/r.components*r.byteLength;case Zh:case Kh:return Math.floor((o+3)/4)*Math.floor((t+3)/4)*8;case Qh:case Jh:return Math.floor((o+3)/4)*Math.floor((t+3)/4)*16;case Z_:case Q_:return Math.max(o,16)*Math.max(t,8)/4;case j_:case K_:return Math.max(o,8)*Math.max(t,8)/2;case J_:case $_:case e0:case n0:return Math.floor((o+3)/4)*Math.floor((t+3)/4)*8;case t0:case i0:case a0:return Math.floor((o+3)/4)*Math.floor((t+3)/4)*16;case r0:return Math.floor((o+3)/4)*Math.floor((t+3)/4)*16;case s0:return Math.floor((o+4)/5)*Math.floor((t+3)/4)*16;case o0:return Math.floor((o+4)/5)*Math.floor((t+4)/5)*16;case l0:return Math.floor((o+5)/6)*Math.floor((t+4)/5)*16;case u0:return Math.floor((o+5)/6)*Math.floor((t+5)/6)*16;case c0:return Math.floor((o+7)/8)*Math.floor((t+4)/5)*16;case f0:return Math.floor((o+7)/8)*Math.floor((t+5)/6)*16;case h0:return Math.floor((o+7)/8)*Math.floor((t+7)/8)*16;case d0:return Math.floor((o+9)/10)*Math.floor((t+4)/5)*16;case p0:return Math.floor((o+9)/10)*Math.floor((t+5)/6)*16;case m0:return Math.floor((o+9)/10)*Math.floor((t+7)/8)*16;case _0:return Math.floor((o+9)/10)*Math.floor((t+9)/10)*16;case g0:return Math.floor((o+11)/12)*Math.floor((t+9)/10)*16;case v0:return Math.floor((o+11)/12)*Math.floor((t+11)/12)*16;case x0:case y0:case S0:return Math.ceil(o/4)*Math.ceil(t/4)*16;case M0:case E0:return Math.ceil(o/4)*Math.ceil(t/4)*8;case b0:case T0:return Math.ceil(o/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${n} format.`)}function ZR(o){switch(o){case Fa:case x1:return{byteLength:1,components:1};case zc:case y1:case es:return{byteLength:2,components:1};case ig:case ag:return{byteLength:2,components:4};case Sr:case ng:case dr:return{byteLength:4,components:1};case S1:case M1:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${o}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:eg}}));typeof window<"u"&&(window.__THREE__?Me("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=eg);/**
 * @license
 * Copyright 2010-2026 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function B1(){let o=null,t=!1,n=null,a=null;function r(l,c){n(l,c),a=o.requestAnimationFrame(r)}return{start:function(){t!==!0&&n!==null&&(a=o.requestAnimationFrame(r),t=!0)},stop:function(){o.cancelAnimationFrame(a),t=!1},setAnimationLoop:function(l){n=l},setContext:function(l){o=l}}}function KR(o){const t=new WeakMap;function n(f,p){const d=f.array,_=f.usage,v=d.byteLength,g=o.createBuffer();o.bindBuffer(p,g),o.bufferData(p,d,_),f.onUploadCallback();let x;if(d instanceof Float32Array)x=o.FLOAT;else if(typeof Float16Array<"u"&&d instanceof Float16Array)x=o.HALF_FLOAT;else if(d instanceof Uint16Array)f.isFloat16BufferAttribute?x=o.HALF_FLOAT:x=o.UNSIGNED_SHORT;else if(d instanceof Int16Array)x=o.SHORT;else if(d instanceof Uint32Array)x=o.UNSIGNED_INT;else if(d instanceof Int32Array)x=o.INT;else if(d instanceof Int8Array)x=o.BYTE;else if(d instanceof Uint8Array)x=o.UNSIGNED_BYTE;else if(d instanceof Uint8ClampedArray)x=o.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+d);return{buffer:g,type:x,bytesPerElement:d.BYTES_PER_ELEMENT,version:f.version,size:v}}function a(f,p,d){const _=p.array,v=p.updateRanges;if(o.bindBuffer(d,f),v.length===0)o.bufferSubData(d,0,_);else{v.sort((x,M)=>x.start-M.start);let g=0;for(let x=1;x<v.length;x++){const M=v[g],E=v[x];E.start<=M.start+M.count+1?M.count=Math.max(M.count,E.start+E.count-M.start):(++g,v[g]=E)}v.length=g+1;for(let x=0,M=v.length;x<M;x++){const E=v[x];o.bufferSubData(d,E.start*_.BYTES_PER_ELEMENT,_,E.start,E.count)}p.clearUpdateRanges()}p.onUploadCallback()}function r(f){return f.isInterleavedBufferAttribute&&(f=f.data),t.get(f)}function l(f){f.isInterleavedBufferAttribute&&(f=f.data);const p=t.get(f);p&&(o.deleteBuffer(p.buffer),t.delete(f))}function c(f,p){if(f.isInterleavedBufferAttribute&&(f=f.data),f.isGLBufferAttribute){const _=t.get(f);(!_||_.version<f.version)&&t.set(f,{buffer:f.buffer,type:f.type,bytesPerElement:f.elementSize,version:f.version});return}const d=t.get(f);if(d===void 0)t.set(f,n(f,p));else if(d.version<f.version){if(d.size!==f.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");a(d.buffer,f,p),d.version=f.version}}return{get:r,remove:l,update:c}}var QR=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,JR=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,$R=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,t2=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,e2=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,n2=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,i2=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,a2=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,r2=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,s2=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,o2=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,l2=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,u2=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,c2=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,f2=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,h2=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,d2=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,p2=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,m2=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,_2=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,g2=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,v2=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,x2=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,y2=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,S2=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,M2=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,E2=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,b2=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,T2=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,A2=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,R2="gl_FragColor = linearToOutputTexel( gl_FragColor );",C2=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,w2=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,D2=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,U2=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,N2=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,L2=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,O2=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,P2=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,F2=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,z2=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,I2=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,B2=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,H2=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,G2=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,V2=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,k2=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,X2=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,W2=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,Y2=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,q2=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,j2=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,Z2=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return v;
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,K2=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Q2=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,J2=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,$2=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,tC=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,eC=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,nC=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,iC=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,aC=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,rC=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,sC=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,oC=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,lC=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,uC=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,cC=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,fC=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,hC=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,dC=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,pC=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,mC=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,_C=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,gC=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,vC=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,xC=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,yC=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,SC=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,MC=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,EC=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,bC=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,TC=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,AC=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,RC=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,CC=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,wC=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,DC=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,UC=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,NC=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,LC=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,OC=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,PC=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,FC=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,zC=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,IC=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,BC=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,HC=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,GC=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,VC=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,kC=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,XC=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,WC=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,YC=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,qC=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,jC=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,ZC=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const KC=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,QC=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,JC=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,$C=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,t3=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,e3=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,n3=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,i3=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,a3=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,r3=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,s3=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,o3=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,l3=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,u3=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,c3=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,f3=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,h3=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,d3=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,p3=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,m3=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,_3=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,g3=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,v3=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,x3=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,y3=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,S3=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,M3=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,E3=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,b3=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,T3=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,A3=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,R3=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,C3=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,w3=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,De={alphahash_fragment:QR,alphahash_pars_fragment:JR,alphamap_fragment:$R,alphamap_pars_fragment:t2,alphatest_fragment:e2,alphatest_pars_fragment:n2,aomap_fragment:i2,aomap_pars_fragment:a2,batching_pars_vertex:r2,batching_vertex:s2,begin_vertex:o2,beginnormal_vertex:l2,bsdfs:u2,iridescence_fragment:c2,bumpmap_pars_fragment:f2,clipping_planes_fragment:h2,clipping_planes_pars_fragment:d2,clipping_planes_pars_vertex:p2,clipping_planes_vertex:m2,color_fragment:_2,color_pars_fragment:g2,color_pars_vertex:v2,color_vertex:x2,common:y2,cube_uv_reflection_fragment:S2,defaultnormal_vertex:M2,displacementmap_pars_vertex:E2,displacementmap_vertex:b2,emissivemap_fragment:T2,emissivemap_pars_fragment:A2,colorspace_fragment:R2,colorspace_pars_fragment:C2,envmap_fragment:w2,envmap_common_pars_fragment:D2,envmap_pars_fragment:U2,envmap_pars_vertex:N2,envmap_physical_pars_fragment:k2,envmap_vertex:L2,fog_vertex:O2,fog_pars_vertex:P2,fog_fragment:F2,fog_pars_fragment:z2,gradientmap_pars_fragment:I2,lightmap_pars_fragment:B2,lights_lambert_fragment:H2,lights_lambert_pars_fragment:G2,lights_pars_begin:V2,lights_toon_fragment:X2,lights_toon_pars_fragment:W2,lights_phong_fragment:Y2,lights_phong_pars_fragment:q2,lights_physical_fragment:j2,lights_physical_pars_fragment:Z2,lights_fragment_begin:K2,lights_fragment_maps:Q2,lights_fragment_end:J2,logdepthbuf_fragment:$2,logdepthbuf_pars_fragment:tC,logdepthbuf_pars_vertex:eC,logdepthbuf_vertex:nC,map_fragment:iC,map_pars_fragment:aC,map_particle_fragment:rC,map_particle_pars_fragment:sC,metalnessmap_fragment:oC,metalnessmap_pars_fragment:lC,morphinstance_vertex:uC,morphcolor_vertex:cC,morphnormal_vertex:fC,morphtarget_pars_vertex:hC,morphtarget_vertex:dC,normal_fragment_begin:pC,normal_fragment_maps:mC,normal_pars_fragment:_C,normal_pars_vertex:gC,normal_vertex:vC,normalmap_pars_fragment:xC,clearcoat_normal_fragment_begin:yC,clearcoat_normal_fragment_maps:SC,clearcoat_pars_fragment:MC,iridescence_pars_fragment:EC,opaque_fragment:bC,packing:TC,premultiplied_alpha_fragment:AC,project_vertex:RC,dithering_fragment:CC,dithering_pars_fragment:wC,roughnessmap_fragment:DC,roughnessmap_pars_fragment:UC,shadowmap_pars_fragment:NC,shadowmap_pars_vertex:LC,shadowmap_vertex:OC,shadowmask_pars_fragment:PC,skinbase_vertex:FC,skinning_pars_vertex:zC,skinning_vertex:IC,skinnormal_vertex:BC,specularmap_fragment:HC,specularmap_pars_fragment:GC,tonemapping_fragment:VC,tonemapping_pars_fragment:kC,transmission_fragment:XC,transmission_pars_fragment:WC,uv_pars_fragment:YC,uv_pars_vertex:qC,uv_vertex:jC,worldpos_vertex:ZC,background_vert:KC,background_frag:QC,backgroundCube_vert:JC,backgroundCube_frag:$C,cube_vert:t3,cube_frag:e3,depth_vert:n3,depth_frag:i3,distance_vert:a3,distance_frag:r3,equirect_vert:s3,equirect_frag:o3,linedashed_vert:l3,linedashed_frag:u3,meshbasic_vert:c3,meshbasic_frag:f3,meshlambert_vert:h3,meshlambert_frag:d3,meshmatcap_vert:p3,meshmatcap_frag:m3,meshnormal_vert:_3,meshnormal_frag:g3,meshphong_vert:v3,meshphong_frag:x3,meshphysical_vert:y3,meshphysical_frag:S3,meshtoon_vert:M3,meshtoon_frag:E3,points_vert:b3,points_frag:T3,shadow_vert:A3,shadow_frag:R3,sprite_vert:C3,sprite_frag:w3},kt={common:{diffuse:{value:new qe(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new we},alphaMap:{value:null},alphaMapTransform:{value:new we},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new we}},envmap:{envMap:{value:null},envMapRotation:{value:new we},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new we}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new we}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new we},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new we},normalScale:{value:new fn(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new we},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new we}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new we}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new we}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new qe(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new qe(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new we},alphaTest:{value:0},uvTransform:{value:new we}},sprite:{diffuse:{value:new qe(16777215)},opacity:{value:1},center:{value:new fn(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new we},alphaMap:{value:null},alphaMapTransform:{value:new we},alphaTest:{value:0}}},fr={basic:{uniforms:Ui([kt.common,kt.specularmap,kt.envmap,kt.aomap,kt.lightmap,kt.fog]),vertexShader:De.meshbasic_vert,fragmentShader:De.meshbasic_frag},lambert:{uniforms:Ui([kt.common,kt.specularmap,kt.envmap,kt.aomap,kt.lightmap,kt.emissivemap,kt.bumpmap,kt.normalmap,kt.displacementmap,kt.fog,kt.lights,{emissive:{value:new qe(0)},envMapIntensity:{value:1}}]),vertexShader:De.meshlambert_vert,fragmentShader:De.meshlambert_frag},phong:{uniforms:Ui([kt.common,kt.specularmap,kt.envmap,kt.aomap,kt.lightmap,kt.emissivemap,kt.bumpmap,kt.normalmap,kt.displacementmap,kt.fog,kt.lights,{emissive:{value:new qe(0)},specular:{value:new qe(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:De.meshphong_vert,fragmentShader:De.meshphong_frag},standard:{uniforms:Ui([kt.common,kt.envmap,kt.aomap,kt.lightmap,kt.emissivemap,kt.bumpmap,kt.normalmap,kt.displacementmap,kt.roughnessmap,kt.metalnessmap,kt.fog,kt.lights,{emissive:{value:new qe(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:De.meshphysical_vert,fragmentShader:De.meshphysical_frag},toon:{uniforms:Ui([kt.common,kt.aomap,kt.lightmap,kt.emissivemap,kt.bumpmap,kt.normalmap,kt.displacementmap,kt.gradientmap,kt.fog,kt.lights,{emissive:{value:new qe(0)}}]),vertexShader:De.meshtoon_vert,fragmentShader:De.meshtoon_frag},matcap:{uniforms:Ui([kt.common,kt.bumpmap,kt.normalmap,kt.displacementmap,kt.fog,{matcap:{value:null}}]),vertexShader:De.meshmatcap_vert,fragmentShader:De.meshmatcap_frag},points:{uniforms:Ui([kt.points,kt.fog]),vertexShader:De.points_vert,fragmentShader:De.points_frag},dashed:{uniforms:Ui([kt.common,kt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:De.linedashed_vert,fragmentShader:De.linedashed_frag},depth:{uniforms:Ui([kt.common,kt.displacementmap]),vertexShader:De.depth_vert,fragmentShader:De.depth_frag},normal:{uniforms:Ui([kt.common,kt.bumpmap,kt.normalmap,kt.displacementmap,{opacity:{value:1}}]),vertexShader:De.meshnormal_vert,fragmentShader:De.meshnormal_frag},sprite:{uniforms:Ui([kt.sprite,kt.fog]),vertexShader:De.sprite_vert,fragmentShader:De.sprite_frag},background:{uniforms:{uvTransform:{value:new we},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:De.background_vert,fragmentShader:De.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new we}},vertexShader:De.backgroundCube_vert,fragmentShader:De.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:De.cube_vert,fragmentShader:De.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:De.equirect_vert,fragmentShader:De.equirect_frag},distance:{uniforms:Ui([kt.common,kt.displacementmap,{referencePosition:{value:new ft},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:De.distance_vert,fragmentShader:De.distance_frag},shadow:{uniforms:Ui([kt.lights,kt.fog,{color:{value:new qe(0)},opacity:{value:1}}]),vertexShader:De.shadow_vert,fragmentShader:De.shadow_frag}};fr.physical={uniforms:Ui([fr.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new we},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new we},clearcoatNormalScale:{value:new fn(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new we},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new we},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new we},sheen:{value:0},sheenColor:{value:new qe(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new we},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new we},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new we},transmissionSamplerSize:{value:new fn},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new we},attenuationDistance:{value:0},attenuationColor:{value:new qe(0)},specularColor:{value:new qe(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new we},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new we},anisotropyVector:{value:new fn},anisotropyMap:{value:null},anisotropyMapTransform:{value:new we}}]),vertexShader:De.meshphysical_vert,fragmentShader:De.meshphysical_frag};const Nh={r:0,b:0,g:0},xo=new is,D3=new zn;function U3(o,t,n,a,r,l){const c=new qe(0);let f=r===!0?0:1,p,d,_=null,v=0,g=null;function x(R){let U=R.isScene===!0?R.background:null;if(U&&U.isTexture){const C=R.backgroundBlurriness>0;U=t.get(U,C)}return U}function M(R){let U=!1;const C=x(R);C===null?y(c,f):C&&C.isColor&&(y(C,1),U=!0);const O=o.xr.getEnvironmentBlendMode();O==="additive"?n.buffers.color.setClear(0,0,0,1,l):O==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,l),(o.autoClear||U)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),o.clear(o.autoClearColor,o.autoClearDepth,o.autoClearStencil))}function E(R,U){const C=x(U);C&&(C.isCubeTexture||C.mapping===Td)?(d===void 0&&(d=new $a(new Jc(1,1,1),new Ga({name:"BackgroundCubeMaterial",uniforms:au(fr.backgroundCube.uniforms),vertexShader:fr.backgroundCube.vertexShader,fragmentShader:fr.backgroundCube.fragmentShader,side:Yi,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),d.geometry.deleteAttribute("normal"),d.geometry.deleteAttribute("uv"),d.onBeforeRender=function(O,P,L){this.matrixWorld.copyPosition(L.matrixWorld)},Object.defineProperty(d.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),a.update(d)),xo.copy(U.backgroundRotation),xo.x*=-1,xo.y*=-1,xo.z*=-1,C.isCubeTexture&&C.isRenderTargetTexture===!1&&(xo.y*=-1,xo.z*=-1),d.material.uniforms.envMap.value=C,d.material.uniforms.flipEnvMap.value=C.isCubeTexture&&C.isRenderTargetTexture===!1?-1:1,d.material.uniforms.backgroundBlurriness.value=U.backgroundBlurriness,d.material.uniforms.backgroundIntensity.value=U.backgroundIntensity,d.material.uniforms.backgroundRotation.value.setFromMatrix4(D3.makeRotationFromEuler(xo)),d.material.toneMapped=Ye.getTransfer(C.colorSpace)!==an,(_!==C||v!==C.version||g!==o.toneMapping)&&(d.material.needsUpdate=!0,_=C,v=C.version,g=o.toneMapping),d.layers.enableAll(),R.unshift(d,d.geometry,d.material,0,0,null)):C&&C.isTexture&&(p===void 0&&(p=new $a(new Rd(2,2),new Ga({name:"BackgroundMaterial",uniforms:au(fr.background.uniforms),vertexShader:fr.background.vertexShader,fragmentShader:fr.background.fragmentShader,side:Ys,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),p.geometry.deleteAttribute("normal"),Object.defineProperty(p.material,"map",{get:function(){return this.uniforms.t2D.value}}),a.update(p)),p.material.uniforms.t2D.value=C,p.material.uniforms.backgroundIntensity.value=U.backgroundIntensity,p.material.toneMapped=Ye.getTransfer(C.colorSpace)!==an,C.matrixAutoUpdate===!0&&C.updateMatrix(),p.material.uniforms.uvTransform.value.copy(C.matrix),(_!==C||v!==C.version||g!==o.toneMapping)&&(p.material.needsUpdate=!0,_=C,v=C.version,g=o.toneMapping),p.layers.enableAll(),R.unshift(p,p.geometry,p.material,0,0,null))}function y(R,U){R.getRGB(Nh,F1(o)),n.buffers.color.setClear(Nh.r,Nh.g,Nh.b,U,l)}function S(){d!==void 0&&(d.geometry.dispose(),d.material.dispose(),d=void 0),p!==void 0&&(p.geometry.dispose(),p.material.dispose(),p=void 0)}return{getClearColor:function(){return c},setClearColor:function(R,U=1){c.set(R),f=U,y(c,f)},getClearAlpha:function(){return f},setClearAlpha:function(R){f=R,y(c,f)},render:M,addToRenderList:E,dispose:S}}function N3(o,t){const n=o.getParameter(o.MAX_VERTEX_ATTRIBS),a={},r=g(null);let l=r,c=!1;function f(G,k,J,et,Q){let F=!1;const I=v(G,et,J,k);l!==I&&(l=I,d(l.object)),F=x(G,et,J,Q),F&&M(G,et,J,Q),Q!==null&&t.update(Q,o.ELEMENT_ARRAY_BUFFER),(F||c)&&(c=!1,C(G,k,J,et),Q!==null&&o.bindBuffer(o.ELEMENT_ARRAY_BUFFER,t.get(Q).buffer))}function p(){return o.createVertexArray()}function d(G){return o.bindVertexArray(G)}function _(G){return o.deleteVertexArray(G)}function v(G,k,J,et){const Q=et.wireframe===!0;let F=a[k.id];F===void 0&&(F={},a[k.id]=F);const I=G.isInstancedMesh===!0?G.id:0;let it=F[I];it===void 0&&(it={},F[I]=it);let ht=it[J.id];ht===void 0&&(ht={},it[J.id]=ht);let H=ht[Q];return H===void 0&&(H=g(p()),ht[Q]=H),H}function g(G){const k=[],J=[],et=[];for(let Q=0;Q<n;Q++)k[Q]=0,J[Q]=0,et[Q]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:k,enabledAttributes:J,attributeDivisors:et,object:G,attributes:{},index:null}}function x(G,k,J,et){const Q=l.attributes,F=k.attributes;let I=0;const it=J.getAttributes();for(const ht in it)if(it[ht].location>=0){const z=Q[ht];let K=F[ht];if(K===void 0&&(ht==="instanceMatrix"&&G.instanceMatrix&&(K=G.instanceMatrix),ht==="instanceColor"&&G.instanceColor&&(K=G.instanceColor)),z===void 0||z.attribute!==K||K&&z.data!==K.data)return!0;I++}return l.attributesNum!==I||l.index!==et}function M(G,k,J,et){const Q={},F=k.attributes;let I=0;const it=J.getAttributes();for(const ht in it)if(it[ht].location>=0){let z=F[ht];z===void 0&&(ht==="instanceMatrix"&&G.instanceMatrix&&(z=G.instanceMatrix),ht==="instanceColor"&&G.instanceColor&&(z=G.instanceColor));const K={};K.attribute=z,z&&z.data&&(K.data=z.data),Q[ht]=K,I++}l.attributes=Q,l.attributesNum=I,l.index=et}function E(){const G=l.newAttributes;for(let k=0,J=G.length;k<J;k++)G[k]=0}function y(G){S(G,0)}function S(G,k){const J=l.newAttributes,et=l.enabledAttributes,Q=l.attributeDivisors;J[G]=1,et[G]===0&&(o.enableVertexAttribArray(G),et[G]=1),Q[G]!==k&&(o.vertexAttribDivisor(G,k),Q[G]=k)}function R(){const G=l.newAttributes,k=l.enabledAttributes;for(let J=0,et=k.length;J<et;J++)k[J]!==G[J]&&(o.disableVertexAttribArray(J),k[J]=0)}function U(G,k,J,et,Q,F,I){I===!0?o.vertexAttribIPointer(G,k,J,Q,F):o.vertexAttribPointer(G,k,J,et,Q,F)}function C(G,k,J,et){E();const Q=et.attributes,F=J.getAttributes(),I=k.defaultAttributeValues;for(const it in F){const ht=F[it];if(ht.location>=0){let H=Q[it];if(H===void 0&&(it==="instanceMatrix"&&G.instanceMatrix&&(H=G.instanceMatrix),it==="instanceColor"&&G.instanceColor&&(H=G.instanceColor)),H!==void 0){const z=H.normalized,K=H.itemSize,xt=t.get(H);if(xt===void 0)continue;const Tt=xt.buffer,Ut=xt.type,nt=xt.bytesPerElement,_t=Ut===o.INT||Ut===o.UNSIGNED_INT||H.gpuType===ng;if(H.isInterleavedBufferAttribute){const Et=H.data,Ft=Et.stride,ee=H.offset;if(Et.isInstancedInterleavedBuffer){for(let Kt=0;Kt<ht.locationSize;Kt++)S(ht.location+Kt,Et.meshPerAttribute);G.isInstancedMesh!==!0&&et._maxInstanceCount===void 0&&(et._maxInstanceCount=Et.meshPerAttribute*Et.count)}else for(let Kt=0;Kt<ht.locationSize;Kt++)y(ht.location+Kt);o.bindBuffer(o.ARRAY_BUFFER,Tt);for(let Kt=0;Kt<ht.locationSize;Kt++)U(ht.location+Kt,K/ht.locationSize,Ut,z,Ft*nt,(ee+K/ht.locationSize*Kt)*nt,_t)}else{if(H.isInstancedBufferAttribute){for(let Et=0;Et<ht.locationSize;Et++)S(ht.location+Et,H.meshPerAttribute);G.isInstancedMesh!==!0&&et._maxInstanceCount===void 0&&(et._maxInstanceCount=H.meshPerAttribute*H.count)}else for(let Et=0;Et<ht.locationSize;Et++)y(ht.location+Et);o.bindBuffer(o.ARRAY_BUFFER,Tt);for(let Et=0;Et<ht.locationSize;Et++)U(ht.location+Et,K/ht.locationSize,Ut,z,K*nt,K/ht.locationSize*Et*nt,_t)}}else if(I!==void 0){const z=I[it];if(z!==void 0)switch(z.length){case 2:o.vertexAttrib2fv(ht.location,z);break;case 3:o.vertexAttrib3fv(ht.location,z);break;case 4:o.vertexAttrib4fv(ht.location,z);break;default:o.vertexAttrib1fv(ht.location,z)}}}}R()}function O(){w();for(const G in a){const k=a[G];for(const J in k){const et=k[J];for(const Q in et){const F=et[Q];for(const I in F)_(F[I].object),delete F[I];delete et[Q]}}delete a[G]}}function P(G){if(a[G.id]===void 0)return;const k=a[G.id];for(const J in k){const et=k[J];for(const Q in et){const F=et[Q];for(const I in F)_(F[I].object),delete F[I];delete et[Q]}}delete a[G.id]}function L(G){for(const k in a){const J=a[k];for(const et in J){const Q=J[et];if(Q[G.id]===void 0)continue;const F=Q[G.id];for(const I in F)_(F[I].object),delete F[I];delete Q[G.id]}}}function T(G){for(const k in a){const J=a[k],et=G.isInstancedMesh===!0?G.id:0,Q=J[et];if(Q!==void 0){for(const F in Q){const I=Q[F];for(const it in I)_(I[it].object),delete I[it];delete Q[F]}delete J[et],Object.keys(J).length===0&&delete a[k]}}}function w(){q(),c=!0,l!==r&&(l=r,d(l.object))}function q(){r.geometry=null,r.program=null,r.wireframe=!1}return{setup:f,reset:w,resetDefaultState:q,dispose:O,releaseStatesOfGeometry:P,releaseStatesOfObject:T,releaseStatesOfProgram:L,initAttributes:E,enableAttribute:y,disableUnusedAttributes:R}}function L3(o,t,n){let a;function r(d){a=d}function l(d,_){o.drawArrays(a,d,_),n.update(_,a,1)}function c(d,_,v){v!==0&&(o.drawArraysInstanced(a,d,_,v),n.update(_,a,v))}function f(d,_,v){if(v===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(a,d,0,_,0,v);let x=0;for(let M=0;M<v;M++)x+=_[M];n.update(x,a,1)}function p(d,_,v,g){if(v===0)return;const x=t.get("WEBGL_multi_draw");if(x===null)for(let M=0;M<d.length;M++)c(d[M],_[M],g[M]);else{x.multiDrawArraysInstancedWEBGL(a,d,0,_,0,g,0,v);let M=0;for(let E=0;E<v;E++)M+=_[E]*g[E];n.update(M,a,1)}}this.setMode=r,this.render=l,this.renderInstances=c,this.renderMultiDraw=f,this.renderMultiDrawInstances=p}function O3(o,t,n,a){let r;function l(){if(r!==void 0)return r;if(t.has("EXT_texture_filter_anisotropic")===!0){const L=t.get("EXT_texture_filter_anisotropic");r=o.getParameter(L.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else r=0;return r}function c(L){return!(L!==Ja&&a.convert(L)!==o.getParameter(o.IMPLEMENTATION_COLOR_READ_FORMAT))}function f(L){const T=L===es&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(L!==Fa&&a.convert(L)!==o.getParameter(o.IMPLEMENTATION_COLOR_READ_TYPE)&&L!==dr&&!T)}function p(L){if(L==="highp"){if(o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.HIGH_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.HIGH_FLOAT).precision>0)return"highp";L="mediump"}return L==="mediump"&&o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.MEDIUM_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let d=n.precision!==void 0?n.precision:"highp";const _=p(d);_!==d&&(Me("WebGLRenderer:",d,"not supported, using",_,"instead."),d=_);const v=n.logarithmicDepthBuffer===!0,g=n.reversedDepthBuffer===!0&&t.has("EXT_clip_control"),x=o.getParameter(o.MAX_TEXTURE_IMAGE_UNITS),M=o.getParameter(o.MAX_VERTEX_TEXTURE_IMAGE_UNITS),E=o.getParameter(o.MAX_TEXTURE_SIZE),y=o.getParameter(o.MAX_CUBE_MAP_TEXTURE_SIZE),S=o.getParameter(o.MAX_VERTEX_ATTRIBS),R=o.getParameter(o.MAX_VERTEX_UNIFORM_VECTORS),U=o.getParameter(o.MAX_VARYING_VECTORS),C=o.getParameter(o.MAX_FRAGMENT_UNIFORM_VECTORS),O=o.getParameter(o.MAX_SAMPLES),P=o.getParameter(o.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:l,getMaxPrecision:p,textureFormatReadable:c,textureTypeReadable:f,precision:d,logarithmicDepthBuffer:v,reversedDepthBuffer:g,maxTextures:x,maxVertexTextures:M,maxTextureSize:E,maxCubemapSize:y,maxAttributes:S,maxVertexUniforms:R,maxVaryings:U,maxFragmentUniforms:C,maxSamples:O,samples:P}}function P3(o){const t=this;let n=null,a=0,r=!1,l=!1;const c=new Eo,f=new we,p={value:null,needsUpdate:!1};this.uniform=p,this.numPlanes=0,this.numIntersection=0,this.init=function(v,g){const x=v.length!==0||g||a!==0||r;return r=g,a=v.length,x},this.beginShadows=function(){l=!0,_(null)},this.endShadows=function(){l=!1},this.setGlobalState=function(v,g){n=_(v,g,0)},this.setState=function(v,g,x){const M=v.clippingPlanes,E=v.clipIntersection,y=v.clipShadows,S=o.get(v);if(!r||M===null||M.length===0||l&&!y)l?_(null):d();else{const R=l?0:a,U=R*4;let C=S.clippingState||null;p.value=C,C=_(M,g,U,x);for(let O=0;O!==U;++O)C[O]=n[O];S.clippingState=C,this.numIntersection=E?this.numPlanes:0,this.numPlanes+=R}};function d(){p.value!==n&&(p.value=n,p.needsUpdate=a>0),t.numPlanes=a,t.numIntersection=0}function _(v,g,x,M){const E=v!==null?v.length:0;let y=null;if(E!==0){if(y=p.value,M!==!0||y===null){const S=x+E*4,R=g.matrixWorldInverse;f.getNormalMatrix(R),(y===null||y.length<S)&&(y=new Float32Array(S));for(let U=0,C=x;U!==E;++U,C+=4)c.copy(v[U]).applyMatrix4(R,f),c.normal.toArray(y,C),y[C+3]=c.constant}p.value=y,p.needsUpdate=!0}return t.numPlanes=E,t.numIntersection=0,y}}const zs=4,eM=[.125,.215,.35,.446,.526,.582],Co=20,F3=256,uc=new I1,nM=new qe;let __=null,g_=0,v_=0,x_=!1;const z3=new ft;class iM{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(t,n=0,a=.1,r=100,l={}){const{size:c=256,position:f=z3}=l;__=this._renderer.getRenderTarget(),g_=this._renderer.getActiveCubeFace(),v_=this._renderer.getActiveMipmapLevel(),x_=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(c);const p=this._allocateTargets();return p.depthBuffer=!0,this._sceneToCubeUV(t,a,r,p,f),n>0&&this._blur(p,0,0,n),this._applyPMREM(p),this._cleanup(p),p}fromEquirectangular(t,n=null){return this._fromTexture(t,n)}fromCubemap(t,n=null){return this._fromTexture(t,n)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=sM(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=rM(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodMeshes.length;t++)this._lodMeshes[t].geometry.dispose()}_cleanup(t){this._renderer.setRenderTarget(__,g_,v_),this._renderer.xr.enabled=x_,t.scissorTest=!1,zl(t,0,0,t.width,t.height)}_fromTexture(t,n){t.mapping===Ho||t.mapping===eu?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),__=this._renderer.getRenderTarget(),g_=this._renderer.getActiveCubeFace(),v_=this._renderer.getActiveMipmapLevel(),x_=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const a=n||this._allocateTargets();return this._textureToCubeUV(t,a),this._applyPMREM(a),this._cleanup(a),a}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),n=4*this._cubeSize,a={magFilter:Si,minFilter:Si,generateMipmaps:!1,type:es,format:Ja,colorSpace:iu,depthBuffer:!1},r=aM(t,n,a);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==n){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=aM(t,n,a);const{_lodMax:l}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=I3(l)),this._blurMaterial=H3(l,t,n),this._ggxMaterial=B3(l,t,n)}return r}_compileMaterial(t){const n=new $a(new tr,t);this._renderer.compile(n,uc)}_sceneToCubeUV(t,n,a,r,l){const p=new La(90,1,n,a),d=[1,-1,1,1,1,1],_=[1,1,1,-1,-1,-1],v=this._renderer,g=v.autoClear,x=v.toneMapping;v.getClearColor(nM),v.toneMapping=gr,v.autoClear=!1,v.state.buffers.depth.getReversed()&&(v.setRenderTarget(r),v.clearDepth(),v.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new $a(new Jc,new fg({name:"PMREM.Background",side:Yi,depthWrite:!1,depthTest:!1})));const E=this._backgroundBox,y=E.material;let S=!1;const R=t.background;R?R.isColor&&(y.color.copy(R),t.background=null,S=!0):(y.color.copy(nM),S=!0);for(let U=0;U<6;U++){const C=U%3;C===0?(p.up.set(0,d[U],0),p.position.set(l.x,l.y,l.z),p.lookAt(l.x+_[U],l.y,l.z)):C===1?(p.up.set(0,0,d[U]),p.position.set(l.x,l.y,l.z),p.lookAt(l.x,l.y+_[U],l.z)):(p.up.set(0,d[U],0),p.position.set(l.x,l.y,l.z),p.lookAt(l.x,l.y,l.z+_[U]));const O=this._cubeSize;zl(r,C*O,U>2?O:0,O,O),v.setRenderTarget(r),S&&v.render(E,p),v.render(t,p)}v.toneMapping=x,v.autoClear=g,t.background=R}_textureToCubeUV(t,n){const a=this._renderer,r=t.mapping===Ho||t.mapping===eu;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=sM()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=rM());const l=r?this._cubemapMaterial:this._equirectMaterial,c=this._lodMeshes[0];c.material=l;const f=l.uniforms;f.envMap.value=t;const p=this._cubeSize;zl(n,0,0,3*p,2*p),a.setRenderTarget(n),a.render(c,uc)}_applyPMREM(t){const n=this._renderer,a=n.autoClear;n.autoClear=!1;const r=this._lodMeshes.length;for(let l=1;l<r;l++)this._applyGGXFilter(t,l-1,l);n.autoClear=a}_applyGGXFilter(t,n,a){const r=this._renderer,l=this._pingPongRenderTarget,c=this._ggxMaterial,f=this._lodMeshes[a];f.material=c;const p=c.uniforms,d=a/(this._lodMeshes.length-1),_=n/(this._lodMeshes.length-1),v=Math.sqrt(d*d-_*_),g=0+d*1.25,x=v*g,{_lodMax:M}=this,E=this._sizeLods[a],y=3*E*(a>M-zs?a-M+zs:0),S=4*(this._cubeSize-E);p.envMap.value=t.texture,p.roughness.value=x,p.mipInt.value=M-n,zl(l,y,S,3*E,2*E),r.setRenderTarget(l),r.render(f,uc),p.envMap.value=l.texture,p.roughness.value=0,p.mipInt.value=M-a,zl(t,y,S,3*E,2*E),r.setRenderTarget(t),r.render(f,uc)}_blur(t,n,a,r,l){const c=this._pingPongRenderTarget;this._halfBlur(t,c,n,a,r,"latitudinal",l),this._halfBlur(c,t,a,a,r,"longitudinal",l)}_halfBlur(t,n,a,r,l,c,f){const p=this._renderer,d=this._blurMaterial;c!=="latitudinal"&&c!=="longitudinal"&&Qe("blur direction must be either latitudinal or longitudinal!");const _=3,v=this._lodMeshes[r];v.material=d;const g=d.uniforms,x=this._sizeLods[a]-1,M=isFinite(l)?Math.PI/(2*x):2*Math.PI/(2*Co-1),E=l/M,y=isFinite(l)?1+Math.floor(_*E):Co;y>Co&&Me(`sigmaRadians, ${l}, is too large and will clip, as it requested ${y} samples when the maximum is set to ${Co}`);const S=[];let R=0;for(let L=0;L<Co;++L){const T=L/E,w=Math.exp(-T*T/2);S.push(w),L===0?R+=w:L<y&&(R+=2*w)}for(let L=0;L<S.length;L++)S[L]=S[L]/R;g.envMap.value=t.texture,g.samples.value=y,g.weights.value=S,g.latitudinal.value=c==="latitudinal",f&&(g.poleAxis.value=f);const{_lodMax:U}=this;g.dTheta.value=M,g.mipInt.value=U-a;const C=this._sizeLods[r],O=3*C*(r>U-zs?r-U+zs:0),P=4*(this._cubeSize-C);zl(n,O,P,3*C,2*C),p.setRenderTarget(n),p.render(v,uc)}}function I3(o){const t=[],n=[],a=[];let r=o;const l=o-zs+1+eM.length;for(let c=0;c<l;c++){const f=Math.pow(2,r);t.push(f);let p=1/f;c>o-zs?p=eM[c-o+zs-1]:c===0&&(p=0),n.push(p);const d=1/(f-2),_=-d,v=1+d,g=[_,_,v,_,v,v,_,_,v,v,_,v],x=6,M=6,E=3,y=2,S=1,R=new Float32Array(E*M*x),U=new Float32Array(y*M*x),C=new Float32Array(S*M*x);for(let P=0;P<x;P++){const L=P%3*2/3-1,T=P>2?0:-1,w=[L,T,0,L+2/3,T,0,L+2/3,T+1,0,L,T,0,L+2/3,T+1,0,L,T+1,0];R.set(w,E*M*P),U.set(g,y*M*P);const q=[P,P,P,P,P,P];C.set(q,S*M*P)}const O=new tr;O.setAttribute("position",new xr(R,E)),O.setAttribute("uv",new xr(U,y)),O.setAttribute("faceIndex",new xr(C,S)),a.push(new $a(O,null)),r>zs&&r--}return{lodMeshes:a,sizeLods:t,sigmas:n}}function aM(o,t,n){const a=new vr(o,t,n);return a.texture.mapping=Td,a.texture.name="PMREM.cubeUv",a.scissorTest=!0,a}function zl(o,t,n,a,r){o.viewport.set(t,n,a,r),o.scissor.set(t,n,a,r)}function B3(o,t,n){return new Ga({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:F3,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${o}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Cd(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Jr,depthTest:!1,depthWrite:!1})}function H3(o,t,n){const a=new Float32Array(Co),r=new ft(0,1,0);return new Ga({name:"SphericalGaussianBlur",defines:{n:Co,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${o}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:a},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:r}},vertexShader:Cd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Jr,depthTest:!1,depthWrite:!1})}function rM(){return new Ga({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Cd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Jr,depthTest:!1,depthWrite:!1})}function sM(){return new Ga({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Cd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Jr,depthTest:!1,depthWrite:!1})}function Cd(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}class H1 extends vr{constructor(t=1,n={}){super(t,t,n),this.isWebGLCubeRenderTarget=!0;const a={width:t,height:t,depth:1},r=[a,a,a,a,a,a];this.texture=new O1(r),this._setTextureOptions(n),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,n){this.texture.type=n.type,this.texture.colorSpace=n.colorSpace,this.texture.generateMipmaps=n.generateMipmaps,this.texture.minFilter=n.minFilter,this.texture.magFilter=n.magFilter;const a={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new Jc(5,5,5),l=new Ga({name:"CubemapFromEquirect",uniforms:au(a.uniforms),vertexShader:a.vertexShader,fragmentShader:a.fragmentShader,side:Yi,blending:Jr});l.uniforms.tEquirect.value=n;const c=new $a(r,l),f=n.minFilter;return n.minFilter===wo&&(n.minFilter=Si),new qR(1,10,this).update(t,c),n.minFilter=f,c.geometry.dispose(),c.material.dispose(),this}clear(t,n=!0,a=!0,r=!0){const l=t.getRenderTarget();for(let c=0;c<6;c++)t.setRenderTarget(this,c),t.clear(n,a,r);t.setRenderTarget(l)}}function G3(o){let t=new WeakMap,n=new WeakMap,a=null;function r(g,x=!1){return g==null?null:x?c(g):l(g)}function l(g){if(g&&g.isTexture){const x=g.mapping;if(x===km||x===Xm)if(t.has(g)){const M=t.get(g).texture;return f(M,g.mapping)}else{const M=g.image;if(M&&M.height>0){const E=new H1(M.height);return E.fromEquirectangularTexture(o,g),t.set(g,E),g.addEventListener("dispose",d),f(E.texture,g.mapping)}else return null}}return g}function c(g){if(g&&g.isTexture){const x=g.mapping,M=x===km||x===Xm,E=x===Ho||x===eu;if(M||E){let y=n.get(g);const S=y!==void 0?y.texture.pmremVersion:0;if(g.isRenderTargetTexture&&g.pmremVersion!==S)return a===null&&(a=new iM(o)),y=M?a.fromEquirectangular(g,y):a.fromCubemap(g,y),y.texture.pmremVersion=g.pmremVersion,n.set(g,y),y.texture;if(y!==void 0)return y.texture;{const R=g.image;return M&&R&&R.height>0||E&&R&&p(R)?(a===null&&(a=new iM(o)),y=M?a.fromEquirectangular(g):a.fromCubemap(g),y.texture.pmremVersion=g.pmremVersion,n.set(g,y),g.addEventListener("dispose",_),y.texture):null}}}return g}function f(g,x){return x===km?g.mapping=Ho:x===Xm&&(g.mapping=eu),g}function p(g){let x=0;const M=6;for(let E=0;E<M;E++)g[E]!==void 0&&x++;return x===M}function d(g){const x=g.target;x.removeEventListener("dispose",d);const M=t.get(x);M!==void 0&&(t.delete(x),M.dispose())}function _(g){const x=g.target;x.removeEventListener("dispose",_);const M=n.get(x);M!==void 0&&(n.delete(x),M.dispose())}function v(){t=new WeakMap,n=new WeakMap,a!==null&&(a.dispose(),a=null)}return{get:r,dispose:v}}function V3(o){const t={};function n(a){if(t[a]!==void 0)return t[a];const r=o.getExtension(a);return t[a]=r,r}return{has:function(a){return n(a)!==null},init:function(){n("EXT_color_buffer_float"),n("WEBGL_clip_cull_distance"),n("OES_texture_float_linear"),n("EXT_color_buffer_half_float"),n("WEBGL_multisampled_render_to_texture"),n("WEBGL_render_shared_exponent")},get:function(a){const r=n(a);return r===null&&hd("WebGLRenderer: "+a+" extension not supported."),r}}}function k3(o,t,n,a){const r={},l=new WeakMap;function c(v){const g=v.target;g.index!==null&&t.remove(g.index);for(const M in g.attributes)t.remove(g.attributes[M]);g.removeEventListener("dispose",c),delete r[g.id];const x=l.get(g);x&&(t.remove(x),l.delete(g)),a.releaseStatesOfGeometry(g),g.isInstancedBufferGeometry===!0&&delete g._maxInstanceCount,n.memory.geometries--}function f(v,g){return r[g.id]===!0||(g.addEventListener("dispose",c),r[g.id]=!0,n.memory.geometries++),g}function p(v){const g=v.attributes;for(const x in g)t.update(g[x],o.ARRAY_BUFFER)}function d(v){const g=[],x=v.index,M=v.attributes.position;let E=0;if(M===void 0)return;if(x!==null){const R=x.array;E=x.version;for(let U=0,C=R.length;U<C;U+=3){const O=R[U+0],P=R[U+1],L=R[U+2];g.push(O,P,P,L,L,O)}}else{const R=M.array;E=M.version;for(let U=0,C=R.length/3-1;U<C;U+=3){const O=U+0,P=U+1,L=U+2;g.push(O,P,P,L,L,O)}}const y=new(M.count>=65535?U1:D1)(g,1);y.version=E;const S=l.get(v);S&&t.remove(S),l.set(v,y)}function _(v){const g=l.get(v);if(g){const x=v.index;x!==null&&g.version<x.version&&d(v)}else d(v);return l.get(v)}return{get:f,update:p,getWireframeAttribute:_}}function X3(o,t,n){let a;function r(g){a=g}let l,c;function f(g){l=g.type,c=g.bytesPerElement}function p(g,x){o.drawElements(a,x,l,g*c),n.update(x,a,1)}function d(g,x,M){M!==0&&(o.drawElementsInstanced(a,x,l,g*c,M),n.update(x,a,M))}function _(g,x,M){if(M===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(a,x,0,l,g,0,M);let y=0;for(let S=0;S<M;S++)y+=x[S];n.update(y,a,1)}function v(g,x,M,E){if(M===0)return;const y=t.get("WEBGL_multi_draw");if(y===null)for(let S=0;S<g.length;S++)d(g[S]/c,x[S],E[S]);else{y.multiDrawElementsInstancedWEBGL(a,x,0,l,g,0,E,0,M);let S=0;for(let R=0;R<M;R++)S+=x[R]*E[R];n.update(S,a,1)}}this.setMode=r,this.setIndex=f,this.render=p,this.renderInstances=d,this.renderMultiDraw=_,this.renderMultiDrawInstances=v}function W3(o){const t={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function a(l,c,f){switch(n.calls++,c){case o.TRIANGLES:n.triangles+=f*(l/3);break;case o.LINES:n.lines+=f*(l/2);break;case o.LINE_STRIP:n.lines+=f*(l-1);break;case o.LINE_LOOP:n.lines+=f*l;break;case o.POINTS:n.points+=f*l;break;default:Qe("WebGLInfo: Unknown draw mode:",c);break}}function r(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:t,render:n,programs:null,autoReset:!0,reset:r,update:a}}function Y3(o,t,n){const a=new WeakMap,r=new Pn;function l(c,f,p){const d=c.morphTargetInfluences,_=f.morphAttributes.position||f.morphAttributes.normal||f.morphAttributes.color,v=_!==void 0?_.length:0;let g=a.get(f);if(g===void 0||g.count!==v){let q=function(){T.dispose(),a.delete(f),f.removeEventListener("dispose",q)};var x=q;g!==void 0&&g.texture.dispose();const M=f.morphAttributes.position!==void 0,E=f.morphAttributes.normal!==void 0,y=f.morphAttributes.color!==void 0,S=f.morphAttributes.position||[],R=f.morphAttributes.normal||[],U=f.morphAttributes.color||[];let C=0;M===!0&&(C=1),E===!0&&(C=2),y===!0&&(C=3);let O=f.attributes.position.count*C,P=1;O>t.maxTextureSize&&(P=Math.ceil(O/t.maxTextureSize),O=t.maxTextureSize);const L=new Float32Array(O*P*4*v),T=new R1(L,O,P,v);T.type=dr,T.needsUpdate=!0;const w=C*4;for(let G=0;G<v;G++){const k=S[G],J=R[G],et=U[G],Q=O*P*4*G;for(let F=0;F<k.count;F++){const I=F*w;M===!0&&(r.fromBufferAttribute(k,F),L[Q+I+0]=r.x,L[Q+I+1]=r.y,L[Q+I+2]=r.z,L[Q+I+3]=0),E===!0&&(r.fromBufferAttribute(J,F),L[Q+I+4]=r.x,L[Q+I+5]=r.y,L[Q+I+6]=r.z,L[Q+I+7]=0),y===!0&&(r.fromBufferAttribute(et,F),L[Q+I+8]=r.x,L[Q+I+9]=r.y,L[Q+I+10]=r.z,L[Q+I+11]=et.itemSize===4?r.w:1)}}g={count:v,texture:T,size:new fn(O,P)},a.set(f,g),f.addEventListener("dispose",q)}if(c.isInstancedMesh===!0&&c.morphTexture!==null)p.getUniforms().setValue(o,"morphTexture",c.morphTexture,n);else{let M=0;for(let y=0;y<d.length;y++)M+=d[y];const E=f.morphTargetsRelative?1:1-M;p.getUniforms().setValue(o,"morphTargetBaseInfluence",E),p.getUniforms().setValue(o,"morphTargetInfluences",d)}p.getUniforms().setValue(o,"morphTargetsTexture",g.texture,n),p.getUniforms().setValue(o,"morphTargetsTextureSize",g.size)}return{update:l}}function q3(o,t,n,a,r){let l=new WeakMap;function c(d){const _=r.render.frame,v=d.geometry,g=t.get(d,v);if(l.get(g)!==_&&(t.update(g),l.set(g,_)),d.isInstancedMesh&&(d.hasEventListener("dispose",p)===!1&&d.addEventListener("dispose",p),l.get(d)!==_&&(n.update(d.instanceMatrix,o.ARRAY_BUFFER),d.instanceColor!==null&&n.update(d.instanceColor,o.ARRAY_BUFFER),l.set(d,_))),d.isSkinnedMesh){const x=d.skeleton;l.get(x)!==_&&(x.update(),l.set(x,_))}return g}function f(){l=new WeakMap}function p(d){const _=d.target;_.removeEventListener("dispose",p),a.releaseStatesOfObject(_),n.remove(_.instanceMatrix),_.instanceColor!==null&&n.remove(_.instanceColor)}return{update:c,dispose:f}}const j3={[f1]:"LINEAR_TONE_MAPPING",[h1]:"REINHARD_TONE_MAPPING",[d1]:"CINEON_TONE_MAPPING",[p1]:"ACES_FILMIC_TONE_MAPPING",[_1]:"AGX_TONE_MAPPING",[g1]:"NEUTRAL_TONE_MAPPING",[m1]:"CUSTOM_TONE_MAPPING"};function Z3(o,t,n,a,r){const l=new vr(t,n,{type:o,depthBuffer:a,stencilBuffer:r}),c=new vr(t,n,{type:es,depthBuffer:!1,stencilBuffer:!1}),f=new tr;f.setAttribute("position",new Ba([-1,3,0,-1,-1,0,3,-1,0],3)),f.setAttribute("uv",new Ba([0,2,0,0,2,0],2));const p=new XR({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),d=new $a(f,p),_=new I1(-1,1,1,-1,0,1);let v=null,g=null,x=!1,M,E=null,y=[],S=!1;this.setSize=function(R,U){l.setSize(R,U),c.setSize(R,U);for(let C=0;C<y.length;C++){const O=y[C];O.setSize&&O.setSize(R,U)}},this.setEffects=function(R){y=R,S=y.length>0&&y[0].isRenderPass===!0;const U=l.width,C=l.height;for(let O=0;O<y.length;O++){const P=y[O];P.setSize&&P.setSize(U,C)}},this.begin=function(R,U){if(x||R.toneMapping===gr&&y.length===0)return!1;if(E=U,U!==null){const C=U.width,O=U.height;(l.width!==C||l.height!==O)&&this.setSize(C,O)}return S===!1&&R.setRenderTarget(l),M=R.toneMapping,R.toneMapping=gr,!0},this.hasRenderPass=function(){return S},this.end=function(R,U){R.toneMapping=M,x=!0;let C=l,O=c;for(let P=0;P<y.length;P++){const L=y[P];if(L.enabled!==!1&&(L.render(R,O,C,U),L.needsSwap!==!1)){const T=C;C=O,O=T}}if(v!==R.outputColorSpace||g!==R.toneMapping){v=R.outputColorSpace,g=R.toneMapping,p.defines={},Ye.getTransfer(v)===an&&(p.defines.SRGB_TRANSFER="");const P=j3[g];P&&(p.defines[P]=""),p.needsUpdate=!0}p.uniforms.tDiffuse.value=C.texture,R.setRenderTarget(E),R.render(d,_),E=null,x=!1},this.isCompositing=function(){return x},this.dispose=function(){l.dispose(),c.dispose(),f.dispose(),p.dispose()}}const G1=new zi,C0=new Bc(1,1),V1=new R1,k1=new xR,X1=new O1,oM=[],lM=[],uM=new Float32Array(16),cM=new Float32Array(9),fM=new Float32Array(4);function pu(o,t,n){const a=o[0];if(a<=0||a>0)return o;const r=t*n;let l=oM[r];if(l===void 0&&(l=new Float32Array(r),oM[r]=l),t!==0){a.toArray(l,0);for(let c=1,f=0;c!==t;++c)f+=n,o[c].toArray(l,f)}return l}function Jn(o,t){if(o.length!==t.length)return!1;for(let n=0,a=o.length;n<a;n++)if(o[n]!==t[n])return!1;return!0}function $n(o,t){for(let n=0,a=t.length;n<a;n++)o[n]=t[n]}function wd(o,t){let n=lM[t];n===void 0&&(n=new Int32Array(t),lM[t]=n);for(let a=0;a!==t;++a)n[a]=o.allocateTextureUnit();return n}function K3(o,t){const n=this.cache;n[0]!==t&&(o.uniform1f(this.addr,t),n[0]=t)}function Q3(o,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(o.uniform2f(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Jn(n,t))return;o.uniform2fv(this.addr,t),$n(n,t)}}function J3(o,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(o.uniform3f(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else if(t.r!==void 0)(n[0]!==t.r||n[1]!==t.g||n[2]!==t.b)&&(o.uniform3f(this.addr,t.r,t.g,t.b),n[0]=t.r,n[1]=t.g,n[2]=t.b);else{if(Jn(n,t))return;o.uniform3fv(this.addr,t),$n(n,t)}}function $3(o,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(o.uniform4f(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Jn(n,t))return;o.uniform4fv(this.addr,t),$n(n,t)}}function tw(o,t){const n=this.cache,a=t.elements;if(a===void 0){if(Jn(n,t))return;o.uniformMatrix2fv(this.addr,!1,t),$n(n,t)}else{if(Jn(n,a))return;fM.set(a),o.uniformMatrix2fv(this.addr,!1,fM),$n(n,a)}}function ew(o,t){const n=this.cache,a=t.elements;if(a===void 0){if(Jn(n,t))return;o.uniformMatrix3fv(this.addr,!1,t),$n(n,t)}else{if(Jn(n,a))return;cM.set(a),o.uniformMatrix3fv(this.addr,!1,cM),$n(n,a)}}function nw(o,t){const n=this.cache,a=t.elements;if(a===void 0){if(Jn(n,t))return;o.uniformMatrix4fv(this.addr,!1,t),$n(n,t)}else{if(Jn(n,a))return;uM.set(a),o.uniformMatrix4fv(this.addr,!1,uM),$n(n,a)}}function iw(o,t){const n=this.cache;n[0]!==t&&(o.uniform1i(this.addr,t),n[0]=t)}function aw(o,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(o.uniform2i(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Jn(n,t))return;o.uniform2iv(this.addr,t),$n(n,t)}}function rw(o,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(o.uniform3i(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(Jn(n,t))return;o.uniform3iv(this.addr,t),$n(n,t)}}function sw(o,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(o.uniform4i(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Jn(n,t))return;o.uniform4iv(this.addr,t),$n(n,t)}}function ow(o,t){const n=this.cache;n[0]!==t&&(o.uniform1ui(this.addr,t),n[0]=t)}function lw(o,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(o.uniform2ui(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(Jn(n,t))return;o.uniform2uiv(this.addr,t),$n(n,t)}}function uw(o,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(o.uniform3ui(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(Jn(n,t))return;o.uniform3uiv(this.addr,t),$n(n,t)}}function cw(o,t){const n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(o.uniform4ui(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(Jn(n,t))return;o.uniform4uiv(this.addr,t),$n(n,t)}}function fw(o,t,n){const a=this.cache,r=n.allocateTextureUnit();a[0]!==r&&(o.uniform1i(this.addr,r),a[0]=r);let l;this.type===o.SAMPLER_2D_SHADOW?(C0.compareFunction=n.isReversedDepthBuffer()?ug:lg,l=C0):l=G1,n.setTexture2D(t||l,r)}function hw(o,t,n){const a=this.cache,r=n.allocateTextureUnit();a[0]!==r&&(o.uniform1i(this.addr,r),a[0]=r),n.setTexture3D(t||k1,r)}function dw(o,t,n){const a=this.cache,r=n.allocateTextureUnit();a[0]!==r&&(o.uniform1i(this.addr,r),a[0]=r),n.setTextureCube(t||X1,r)}function pw(o,t,n){const a=this.cache,r=n.allocateTextureUnit();a[0]!==r&&(o.uniform1i(this.addr,r),a[0]=r),n.setTexture2DArray(t||V1,r)}function mw(o){switch(o){case 5126:return K3;case 35664:return Q3;case 35665:return J3;case 35666:return $3;case 35674:return tw;case 35675:return ew;case 35676:return nw;case 5124:case 35670:return iw;case 35667:case 35671:return aw;case 35668:case 35672:return rw;case 35669:case 35673:return sw;case 5125:return ow;case 36294:return lw;case 36295:return uw;case 36296:return cw;case 35678:case 36198:case 36298:case 36306:case 35682:return fw;case 35679:case 36299:case 36307:return hw;case 35680:case 36300:case 36308:case 36293:return dw;case 36289:case 36303:case 36311:case 36292:return pw}}function _w(o,t){o.uniform1fv(this.addr,t)}function gw(o,t){const n=pu(t,this.size,2);o.uniform2fv(this.addr,n)}function vw(o,t){const n=pu(t,this.size,3);o.uniform3fv(this.addr,n)}function xw(o,t){const n=pu(t,this.size,4);o.uniform4fv(this.addr,n)}function yw(o,t){const n=pu(t,this.size,4);o.uniformMatrix2fv(this.addr,!1,n)}function Sw(o,t){const n=pu(t,this.size,9);o.uniformMatrix3fv(this.addr,!1,n)}function Mw(o,t){const n=pu(t,this.size,16);o.uniformMatrix4fv(this.addr,!1,n)}function Ew(o,t){o.uniform1iv(this.addr,t)}function bw(o,t){o.uniform2iv(this.addr,t)}function Tw(o,t){o.uniform3iv(this.addr,t)}function Aw(o,t){o.uniform4iv(this.addr,t)}function Rw(o,t){o.uniform1uiv(this.addr,t)}function Cw(o,t){o.uniform2uiv(this.addr,t)}function ww(o,t){o.uniform3uiv(this.addr,t)}function Dw(o,t){o.uniform4uiv(this.addr,t)}function Uw(o,t,n){const a=this.cache,r=t.length,l=wd(n,r);Jn(a,l)||(o.uniform1iv(this.addr,l),$n(a,l));let c;this.type===o.SAMPLER_2D_SHADOW?c=C0:c=G1;for(let f=0;f!==r;++f)n.setTexture2D(t[f]||c,l[f])}function Nw(o,t,n){const a=this.cache,r=t.length,l=wd(n,r);Jn(a,l)||(o.uniform1iv(this.addr,l),$n(a,l));for(let c=0;c!==r;++c)n.setTexture3D(t[c]||k1,l[c])}function Lw(o,t,n){const a=this.cache,r=t.length,l=wd(n,r);Jn(a,l)||(o.uniform1iv(this.addr,l),$n(a,l));for(let c=0;c!==r;++c)n.setTextureCube(t[c]||X1,l[c])}function Ow(o,t,n){const a=this.cache,r=t.length,l=wd(n,r);Jn(a,l)||(o.uniform1iv(this.addr,l),$n(a,l));for(let c=0;c!==r;++c)n.setTexture2DArray(t[c]||V1,l[c])}function Pw(o){switch(o){case 5126:return _w;case 35664:return gw;case 35665:return vw;case 35666:return xw;case 35674:return yw;case 35675:return Sw;case 35676:return Mw;case 5124:case 35670:return Ew;case 35667:case 35671:return bw;case 35668:case 35672:return Tw;case 35669:case 35673:return Aw;case 5125:return Rw;case 36294:return Cw;case 36295:return ww;case 36296:return Dw;case 35678:case 36198:case 36298:case 36306:case 35682:return Uw;case 35679:case 36299:case 36307:return Nw;case 35680:case 36300:case 36308:case 36293:return Lw;case 36289:case 36303:case 36311:case 36292:return Ow}}class Fw{constructor(t,n,a){this.id=t,this.addr=a,this.cache=[],this.type=n.type,this.setValue=mw(n.type)}}class zw{constructor(t,n,a){this.id=t,this.addr=a,this.cache=[],this.type=n.type,this.size=n.size,this.setValue=Pw(n.type)}}class Iw{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,n,a){const r=this.seq;for(let l=0,c=r.length;l!==c;++l){const f=r[l];f.setValue(t,n[f.id],a)}}}const y_=/(\w+)(\])?(\[|\.)?/g;function hM(o,t){o.seq.push(t),o.map[t.id]=t}function Bw(o,t,n){const a=o.name,r=a.length;for(y_.lastIndex=0;;){const l=y_.exec(a),c=y_.lastIndex;let f=l[1];const p=l[2]==="]",d=l[3];if(p&&(f=f|0),d===void 0||d==="["&&c+2===r){hM(n,d===void 0?new Fw(f,o,t):new zw(f,o,t));break}else{let v=n.map[f];v===void 0&&(v=new Iw(f),hM(n,v)),n=v}}}class $h{constructor(t,n){this.seq=[],this.map={};const a=t.getProgramParameter(n,t.ACTIVE_UNIFORMS);for(let c=0;c<a;++c){const f=t.getActiveUniform(n,c),p=t.getUniformLocation(n,f.name);Bw(f,p,this)}const r=[],l=[];for(const c of this.seq)c.type===t.SAMPLER_2D_SHADOW||c.type===t.SAMPLER_CUBE_SHADOW||c.type===t.SAMPLER_2D_ARRAY_SHADOW?r.push(c):l.push(c);r.length>0&&(this.seq=r.concat(l))}setValue(t,n,a,r){const l=this.map[n];l!==void 0&&l.setValue(t,a,r)}setOptional(t,n,a){const r=n[a];r!==void 0&&this.setValue(t,a,r)}static upload(t,n,a,r){for(let l=0,c=n.length;l!==c;++l){const f=n[l],p=a[f.id];p.needsUpdate!==!1&&f.setValue(t,p.value,r)}}static seqWithValue(t,n){const a=[];for(let r=0,l=t.length;r!==l;++r){const c=t[r];c.id in n&&a.push(c)}return a}}function dM(o,t,n){const a=o.createShader(t);return o.shaderSource(a,n),o.compileShader(a),a}const Hw=37297;let Gw=0;function Vw(o,t){const n=o.split(`
`),a=[],r=Math.max(t-6,0),l=Math.min(t+6,n.length);for(let c=r;c<l;c++){const f=c+1;a.push(`${f===t?">":" "} ${f}: ${n[c]}`)}return a.join(`
`)}const pM=new we;function kw(o){Ye._getMatrix(pM,Ye.workingColorSpace,o);const t=`mat3( ${pM.elements.map(n=>n.toFixed(4))} )`;switch(Ye.getTransfer(o)){case ud:return[t,"LinearTransferOETF"];case an:return[t,"sRGBTransferOETF"];default:return Me("WebGLProgram: Unsupported color space: ",o),[t,"LinearTransferOETF"]}}function mM(o,t,n){const a=o.getShaderParameter(t,o.COMPILE_STATUS),l=(o.getShaderInfoLog(t)||"").trim();if(a&&l==="")return"";const c=/ERROR: 0:(\d+)/.exec(l);if(c){const f=parseInt(c[1]);return n.toUpperCase()+`

`+l+`

`+Vw(o.getShaderSource(t),f)}else return l}function Xw(o,t){const n=kw(t);return[`vec4 ${o}( vec4 value ) {`,`	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );`,"}"].join(`
`)}const Ww={[f1]:"Linear",[h1]:"Reinhard",[d1]:"Cineon",[p1]:"ACESFilmic",[_1]:"AgX",[g1]:"Neutral",[m1]:"Custom"};function Yw(o,t){const n=Ww[t];return n===void 0?(Me("WebGLProgram: Unsupported toneMapping:",t),"vec3 "+o+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+o+"( vec3 color ) { return "+n+"ToneMapping( color ); }"}const Lh=new ft;function qw(){Ye.getLuminanceCoefficients(Lh);const o=Lh.x.toFixed(4),t=Lh.y.toFixed(4),n=Lh.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${o}, ${t}, ${n} );`,"	return dot( weights, rgb );","}"].join(`
`)}function jw(o){return[o.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",o.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(_c).join(`
`)}function Zw(o){const t=[];for(const n in o){const a=o[n];a!==!1&&t.push("#define "+n+" "+a)}return t.join(`
`)}function Kw(o,t){const n={},a=o.getProgramParameter(t,o.ACTIVE_ATTRIBUTES);for(let r=0;r<a;r++){const l=o.getActiveAttrib(t,r),c=l.name;let f=1;l.type===o.FLOAT_MAT2&&(f=2),l.type===o.FLOAT_MAT3&&(f=3),l.type===o.FLOAT_MAT4&&(f=4),n[c]={type:l.type,location:o.getAttribLocation(t,c),locationSize:f}}return n}function _c(o){return o!==""}function _M(o,t){const n=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return o.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function gM(o,t){return o.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const Qw=/^[ \t]*#include +<([\w\d./]+)>/gm;function w0(o){return o.replace(Qw,$w)}const Jw=new Map;function $w(o,t){let n=De[t];if(n===void 0){const a=Jw.get(t);if(a!==void 0)n=De[a],Me('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,a);else throw new Error("Can not resolve #include <"+t+">")}return w0(n)}const tD=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function vM(o){return o.replace(tD,eD)}function eD(o,t,n,a){let r="";for(let l=parseInt(t);l<parseInt(n);l++)r+=a.replace(/\[\s*i\s*\]/g,"[ "+l+" ]").replace(/UNROLLED_LOOP_INDEX/g,l);return r}function xM(o){let t=`precision ${o.precision} float;
	precision ${o.precision} int;
	precision ${o.precision} sampler2D;
	precision ${o.precision} samplerCube;
	precision ${o.precision} sampler3D;
	precision ${o.precision} sampler2DArray;
	precision ${o.precision} sampler2DShadow;
	precision ${o.precision} samplerCubeShadow;
	precision ${o.precision} sampler2DArrayShadow;
	precision ${o.precision} isampler2D;
	precision ${o.precision} isampler3D;
	precision ${o.precision} isamplerCube;
	precision ${o.precision} isampler2DArray;
	precision ${o.precision} usampler2D;
	precision ${o.precision} usampler3D;
	precision ${o.precision} usamplerCube;
	precision ${o.precision} usampler2DArray;
	`;return o.precision==="highp"?t+=`
#define HIGH_PRECISION`:o.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:o.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}const nD={[jh]:"SHADOWMAP_TYPE_PCF",[pc]:"SHADOWMAP_TYPE_VSM"};function iD(o){return nD[o.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const aD={[Ho]:"ENVMAP_TYPE_CUBE",[eu]:"ENVMAP_TYPE_CUBE",[Td]:"ENVMAP_TYPE_CUBE_UV"};function rD(o){return o.envMap===!1?"ENVMAP_TYPE_CUBE":aD[o.envMapMode]||"ENVMAP_TYPE_CUBE"}const sD={[eu]:"ENVMAP_MODE_REFRACTION"};function oD(o){return o.envMap===!1?"ENVMAP_MODE_REFLECTION":sD[o.envMapMode]||"ENVMAP_MODE_REFLECTION"}const lD={[c1]:"ENVMAP_BLENDING_MULTIPLY",[QA]:"ENVMAP_BLENDING_MIX",[JA]:"ENVMAP_BLENDING_ADD"};function uD(o){return o.envMap===!1?"ENVMAP_BLENDING_NONE":lD[o.combine]||"ENVMAP_BLENDING_NONE"}function cD(o){const t=o.envMapCubeUVHeight;if(t===null)return null;const n=Math.log2(t)-2,a=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,n),112)),texelHeight:a,maxMip:n}}function fD(o,t,n,a){const r=o.getContext(),l=n.defines;let c=n.vertexShader,f=n.fragmentShader;const p=iD(n),d=rD(n),_=oD(n),v=uD(n),g=cD(n),x=jw(n),M=Zw(l),E=r.createProgram();let y,S,R=n.glslVersion?"#version "+n.glslVersion+`
`:"";n.isRawShaderMaterial?(y=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,M].filter(_c).join(`
`),y.length>0&&(y+=`
`),S=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,M].filter(_c).join(`
`),S.length>0&&(S+=`
`)):(y=[xM(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,M,n.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",n.batching?"#define USE_BATCHING":"",n.batchingColor?"#define USE_BATCHING_COLOR":"",n.instancing?"#define USE_INSTANCING":"",n.instancingColor?"#define USE_INSTANCING_COLOR":"",n.instancingMorph?"#define USE_INSTANCING_MORPH":"",n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.map?"#define USE_MAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+_:"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.displacementMap?"#define USE_DISPLACEMENTMAP":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.mapUv?"#define MAP_UV "+n.mapUv:"",n.alphaMapUv?"#define ALPHAMAP_UV "+n.alphaMapUv:"",n.lightMapUv?"#define LIGHTMAP_UV "+n.lightMapUv:"",n.aoMapUv?"#define AOMAP_UV "+n.aoMapUv:"",n.emissiveMapUv?"#define EMISSIVEMAP_UV "+n.emissiveMapUv:"",n.bumpMapUv?"#define BUMPMAP_UV "+n.bumpMapUv:"",n.normalMapUv?"#define NORMALMAP_UV "+n.normalMapUv:"",n.displacementMapUv?"#define DISPLACEMENTMAP_UV "+n.displacementMapUv:"",n.metalnessMapUv?"#define METALNESSMAP_UV "+n.metalnessMapUv:"",n.roughnessMapUv?"#define ROUGHNESSMAP_UV "+n.roughnessMapUv:"",n.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+n.anisotropyMapUv:"",n.clearcoatMapUv?"#define CLEARCOATMAP_UV "+n.clearcoatMapUv:"",n.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+n.clearcoatNormalMapUv:"",n.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+n.clearcoatRoughnessMapUv:"",n.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+n.iridescenceMapUv:"",n.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+n.iridescenceThicknessMapUv:"",n.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+n.sheenColorMapUv:"",n.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+n.sheenRoughnessMapUv:"",n.specularMapUv?"#define SPECULARMAP_UV "+n.specularMapUv:"",n.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+n.specularColorMapUv:"",n.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+n.specularIntensityMapUv:"",n.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+n.transmissionMapUv:"",n.thicknessMapUv?"#define THICKNESSMAP_UV "+n.thicknessMapUv:"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexColors?"#define USE_COLOR":"",n.vertexAlphas?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.flatShading?"#define FLAT_SHADED":"",n.skinning?"#define USE_SKINNING":"",n.morphTargets?"#define USE_MORPHTARGETS":"",n.morphNormals&&n.flatShading===!1?"#define USE_MORPHNORMALS":"",n.morphColors?"#define USE_MORPHCOLORS":"",n.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+n.morphTextureStride:"",n.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+n.morphTargetsCount:"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+p:"",n.sizeAttenuation?"#define USE_SIZEATTENUATION":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(_c).join(`
`),S=[xM(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,M,n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",n.map?"#define USE_MAP":"",n.matcap?"#define USE_MATCAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+d:"",n.envMap?"#define "+_:"",n.envMap?"#define "+v:"",g?"#define CUBEUV_TEXEL_WIDTH "+g.texelWidth:"",g?"#define CUBEUV_TEXEL_HEIGHT "+g.texelHeight:"",g?"#define CUBEUV_MAX_MIP "+g.maxMip+".0":"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoat?"#define USE_CLEARCOAT":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.dispersion?"#define USE_DISPERSION":"",n.iridescence?"#define USE_IRIDESCENCE":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaTest?"#define USE_ALPHATEST":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.sheen?"#define USE_SHEEN":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexColors||n.instancingColor?"#define USE_COLOR":"",n.vertexAlphas||n.batchingColor?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.gradientMap?"#define USE_GRADIENTMAP":"",n.flatShading?"#define FLAT_SHADED":"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+p:"",n.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",n.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",n.toneMapping!==gr?"#define TONE_MAPPING":"",n.toneMapping!==gr?De.tonemapping_pars_fragment:"",n.toneMapping!==gr?Yw("toneMapping",n.toneMapping):"",n.dithering?"#define DITHERING":"",n.opaque?"#define OPAQUE":"",De.colorspace_pars_fragment,Xw("linearToOutputTexel",n.outputColorSpace),qw(),n.useDepthPacking?"#define DEPTH_PACKING "+n.depthPacking:"",`
`].filter(_c).join(`
`)),c=w0(c),c=_M(c,n),c=gM(c,n),f=w0(f),f=_M(f,n),f=gM(f,n),c=vM(c),f=vM(f),n.isRawShaderMaterial!==!0&&(R=`#version 300 es
`,y=[x,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+y,S=["#define varying in",n.glslVersion===LS?"":"layout(location = 0) out highp vec4 pc_fragColor;",n.glslVersion===LS?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+S);const U=R+y+c,C=R+S+f,O=dM(r,r.VERTEX_SHADER,U),P=dM(r,r.FRAGMENT_SHADER,C);r.attachShader(E,O),r.attachShader(E,P),n.index0AttributeName!==void 0?r.bindAttribLocation(E,0,n.index0AttributeName):n.morphTargets===!0&&r.bindAttribLocation(E,0,"position"),r.linkProgram(E);function L(G){if(o.debug.checkShaderErrors){const k=r.getProgramInfoLog(E)||"",J=r.getShaderInfoLog(O)||"",et=r.getShaderInfoLog(P)||"",Q=k.trim(),F=J.trim(),I=et.trim();let it=!0,ht=!0;if(r.getProgramParameter(E,r.LINK_STATUS)===!1)if(it=!1,typeof o.debug.onShaderError=="function")o.debug.onShaderError(r,E,O,P);else{const H=mM(r,O,"vertex"),z=mM(r,P,"fragment");Qe("THREE.WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(E,r.VALIDATE_STATUS)+`

Material Name: `+G.name+`
Material Type: `+G.type+`

Program Info Log: `+Q+`
`+H+`
`+z)}else Q!==""?Me("WebGLProgram: Program Info Log:",Q):(F===""||I==="")&&(ht=!1);ht&&(G.diagnostics={runnable:it,programLog:Q,vertexShader:{log:F,prefix:y},fragmentShader:{log:I,prefix:S}})}r.deleteShader(O),r.deleteShader(P),T=new $h(r,E),w=Kw(r,E)}let T;this.getUniforms=function(){return T===void 0&&L(this),T};let w;this.getAttributes=function(){return w===void 0&&L(this),w};let q=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return q===!1&&(q=r.getProgramParameter(E,Hw)),q},this.destroy=function(){a.releaseStatesOfProgram(this),r.deleteProgram(E),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=Gw++,this.cacheKey=t,this.usedTimes=1,this.program=E,this.vertexShader=O,this.fragmentShader=P,this}let hD=0;class dD{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){const n=t.vertexShader,a=t.fragmentShader,r=this._getShaderStage(n),l=this._getShaderStage(a),c=this._getShaderCacheForMaterial(t);return c.has(r)===!1&&(c.add(r),r.usedTimes++),c.has(l)===!1&&(c.add(l),l.usedTimes++),this}remove(t){const n=this.materialCache.get(t);for(const a of n)a.usedTimes--,a.usedTimes===0&&this.shaderCache.delete(a.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const n=this.materialCache;let a=n.get(t);return a===void 0&&(a=new Set,n.set(t,a)),a}_getShaderStage(t){const n=this.shaderCache;let a=n.get(t);return a===void 0&&(a=new pD(t),n.set(t,a)),a}}class pD{constructor(t){this.id=hD++,this.code=t,this.usedTimes=0}}function mD(o,t,n,a,r,l){const c=new C1,f=new dD,p=new Set,d=[],_=new Map,v=a.logarithmicDepthBuffer;let g=a.precision;const x={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function M(T){return p.add(T),T===0?"uv":`uv${T}`}function E(T,w,q,G,k){const J=G.fog,et=k.geometry,Q=T.isMeshStandardMaterial||T.isMeshLambertMaterial||T.isMeshPhongMaterial?G.environment:null,F=T.isMeshStandardMaterial||T.isMeshLambertMaterial&&!T.envMap||T.isMeshPhongMaterial&&!T.envMap,I=t.get(T.envMap||Q,F),it=I&&I.mapping===Td?I.image.height:null,ht=x[T.type];T.precision!==null&&(g=a.getMaxPrecision(T.precision),g!==T.precision&&Me("WebGLProgram.getParameters:",T.precision,"not supported, using",g,"instead."));const H=et.morphAttributes.position||et.morphAttributes.normal||et.morphAttributes.color,z=H!==void 0?H.length:0;let K=0;et.morphAttributes.position!==void 0&&(K=1),et.morphAttributes.normal!==void 0&&(K=2),et.morphAttributes.color!==void 0&&(K=3);let xt,Tt,Ut,nt;if(ht){const Vt=fr[ht];xt=Vt.vertexShader,Tt=Vt.fragmentShader}else xt=T.vertexShader,Tt=T.fragmentShader,f.update(T),Ut=f.getVertexShaderID(T),nt=f.getFragmentShaderID(T);const _t=o.getRenderTarget(),Et=o.state.buffers.depth.getReversed(),Ft=k.isInstancedMesh===!0,ee=k.isBatchedMesh===!0,Kt=!!T.map,Ne=!!T.matcap,qt=!!I,re=!!T.aoMap,_e=!!T.lightMap,se=!!T.bumpMap,lt=!!T.normalMap,W=!!T.displacementMap,We=!!T.emissiveMap,Ee=!!T.metalnessMap,ce=!!T.roughnessMap,Wt=T.anisotropy>0,B=T.clearcoat>0,A=T.dispersion>0,j=T.iridescence>0,gt=T.sheen>0,vt=T.transmission>0,dt=Wt&&!!T.anisotropyMap,Gt=B&&!!T.clearcoatMap,wt=B&&!!T.clearcoatNormalMap,ie=B&&!!T.clearcoatRoughnessMap,Yt=j&&!!T.iridescenceMap,Rt=j&&!!T.iridescenceThicknessMap,At=gt&&!!T.sheenColorMap,Ht=gt&&!!T.sheenRoughnessMap,Pt=!!T.specularMap,zt=!!T.specularColorMap,pe=!!T.specularIntensityMap,V=vt&&!!T.transmissionMap,Dt=vt&&!!T.thicknessMap,Ct=!!T.gradientMap,Lt=!!T.alphaMap,bt=T.alphaTest>0,mt=!!T.alphaHash,Xt=!!T.extensions;let le=gr;T.toneMapped&&(_t===null||_t.isXRRenderTarget===!0)&&(le=o.toneMapping);const Ge={shaderID:ht,shaderType:T.type,shaderName:T.name,vertexShader:xt,fragmentShader:Tt,defines:T.defines,customVertexShaderID:Ut,customFragmentShaderID:nt,isRawShaderMaterial:T.isRawShaderMaterial===!0,glslVersion:T.glslVersion,precision:g,batching:ee,batchingColor:ee&&k._colorsTexture!==null,instancing:Ft,instancingColor:Ft&&k.instanceColor!==null,instancingMorph:Ft&&k.morphTexture!==null,outputColorSpace:_t===null?o.outputColorSpace:_t.isXRRenderTarget===!0?_t.texture.colorSpace:iu,alphaToCoverage:!!T.alphaToCoverage,map:Kt,matcap:Ne,envMap:qt,envMapMode:qt&&I.mapping,envMapCubeUVHeight:it,aoMap:re,lightMap:_e,bumpMap:se,normalMap:lt,displacementMap:W,emissiveMap:We,normalMapObjectSpace:lt&&T.normalMapType===nR,normalMapTangentSpace:lt&&T.normalMapType===eR,metalnessMap:Ee,roughnessMap:ce,anisotropy:Wt,anisotropyMap:dt,clearcoat:B,clearcoatMap:Gt,clearcoatNormalMap:wt,clearcoatRoughnessMap:ie,dispersion:A,iridescence:j,iridescenceMap:Yt,iridescenceThicknessMap:Rt,sheen:gt,sheenColorMap:At,sheenRoughnessMap:Ht,specularMap:Pt,specularColorMap:zt,specularIntensityMap:pe,transmission:vt,transmissionMap:V,thicknessMap:Dt,gradientMap:Ct,opaque:T.transparent===!1&&T.blending===Yl&&T.alphaToCoverage===!1,alphaMap:Lt,alphaTest:bt,alphaHash:mt,combine:T.combine,mapUv:Kt&&M(T.map.channel),aoMapUv:re&&M(T.aoMap.channel),lightMapUv:_e&&M(T.lightMap.channel),bumpMapUv:se&&M(T.bumpMap.channel),normalMapUv:lt&&M(T.normalMap.channel),displacementMapUv:W&&M(T.displacementMap.channel),emissiveMapUv:We&&M(T.emissiveMap.channel),metalnessMapUv:Ee&&M(T.metalnessMap.channel),roughnessMapUv:ce&&M(T.roughnessMap.channel),anisotropyMapUv:dt&&M(T.anisotropyMap.channel),clearcoatMapUv:Gt&&M(T.clearcoatMap.channel),clearcoatNormalMapUv:wt&&M(T.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:ie&&M(T.clearcoatRoughnessMap.channel),iridescenceMapUv:Yt&&M(T.iridescenceMap.channel),iridescenceThicknessMapUv:Rt&&M(T.iridescenceThicknessMap.channel),sheenColorMapUv:At&&M(T.sheenColorMap.channel),sheenRoughnessMapUv:Ht&&M(T.sheenRoughnessMap.channel),specularMapUv:Pt&&M(T.specularMap.channel),specularColorMapUv:zt&&M(T.specularColorMap.channel),specularIntensityMapUv:pe&&M(T.specularIntensityMap.channel),transmissionMapUv:V&&M(T.transmissionMap.channel),thicknessMapUv:Dt&&M(T.thicknessMap.channel),alphaMapUv:Lt&&M(T.alphaMap.channel),vertexTangents:!!et.attributes.tangent&&(lt||Wt),vertexColors:T.vertexColors,vertexAlphas:T.vertexColors===!0&&!!et.attributes.color&&et.attributes.color.itemSize===4,pointsUvs:k.isPoints===!0&&!!et.attributes.uv&&(Kt||Lt),fog:!!J,useFog:T.fog===!0,fogExp2:!!J&&J.isFogExp2,flatShading:T.wireframe===!1&&(T.flatShading===!0||et.attributes.normal===void 0&&lt===!1&&(T.isMeshLambertMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isMeshPhysicalMaterial)),sizeAttenuation:T.sizeAttenuation===!0,logarithmicDepthBuffer:v,reversedDepthBuffer:Et,skinning:k.isSkinnedMesh===!0,morphTargets:et.morphAttributes.position!==void 0,morphNormals:et.morphAttributes.normal!==void 0,morphColors:et.morphAttributes.color!==void 0,morphTargetsCount:z,morphTextureStride:K,numDirLights:w.directional.length,numPointLights:w.point.length,numSpotLights:w.spot.length,numSpotLightMaps:w.spotLightMap.length,numRectAreaLights:w.rectArea.length,numHemiLights:w.hemi.length,numDirLightShadows:w.directionalShadowMap.length,numPointLightShadows:w.pointShadowMap.length,numSpotLightShadows:w.spotShadowMap.length,numSpotLightShadowsWithMaps:w.numSpotLightShadowsWithMaps,numLightProbes:w.numLightProbes,numClippingPlanes:l.numPlanes,numClipIntersection:l.numIntersection,dithering:T.dithering,shadowMapEnabled:o.shadowMap.enabled&&q.length>0,shadowMapType:o.shadowMap.type,toneMapping:le,decodeVideoTexture:Kt&&T.map.isVideoTexture===!0&&Ye.getTransfer(T.map.colorSpace)===an,decodeVideoTextureEmissive:We&&T.emissiveMap.isVideoTexture===!0&&Ye.getTransfer(T.emissiveMap.colorSpace)===an,premultipliedAlpha:T.premultipliedAlpha,doubleSided:T.side===jr,flipSided:T.side===Yi,useDepthPacking:T.depthPacking>=0,depthPacking:T.depthPacking||0,index0AttributeName:T.index0AttributeName,extensionClipCullDistance:Xt&&T.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Xt&&T.extensions.multiDraw===!0||ee)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:T.customProgramCacheKey()};return Ge.vertexUv1s=p.has(1),Ge.vertexUv2s=p.has(2),Ge.vertexUv3s=p.has(3),p.clear(),Ge}function y(T){const w=[];if(T.shaderID?w.push(T.shaderID):(w.push(T.customVertexShaderID),w.push(T.customFragmentShaderID)),T.defines!==void 0)for(const q in T.defines)w.push(q),w.push(T.defines[q]);return T.isRawShaderMaterial===!1&&(S(w,T),R(w,T),w.push(o.outputColorSpace)),w.push(T.customProgramCacheKey),w.join()}function S(T,w){T.push(w.precision),T.push(w.outputColorSpace),T.push(w.envMapMode),T.push(w.envMapCubeUVHeight),T.push(w.mapUv),T.push(w.alphaMapUv),T.push(w.lightMapUv),T.push(w.aoMapUv),T.push(w.bumpMapUv),T.push(w.normalMapUv),T.push(w.displacementMapUv),T.push(w.emissiveMapUv),T.push(w.metalnessMapUv),T.push(w.roughnessMapUv),T.push(w.anisotropyMapUv),T.push(w.clearcoatMapUv),T.push(w.clearcoatNormalMapUv),T.push(w.clearcoatRoughnessMapUv),T.push(w.iridescenceMapUv),T.push(w.iridescenceThicknessMapUv),T.push(w.sheenColorMapUv),T.push(w.sheenRoughnessMapUv),T.push(w.specularMapUv),T.push(w.specularColorMapUv),T.push(w.specularIntensityMapUv),T.push(w.transmissionMapUv),T.push(w.thicknessMapUv),T.push(w.combine),T.push(w.fogExp2),T.push(w.sizeAttenuation),T.push(w.morphTargetsCount),T.push(w.morphAttributeCount),T.push(w.numDirLights),T.push(w.numPointLights),T.push(w.numSpotLights),T.push(w.numSpotLightMaps),T.push(w.numHemiLights),T.push(w.numRectAreaLights),T.push(w.numDirLightShadows),T.push(w.numPointLightShadows),T.push(w.numSpotLightShadows),T.push(w.numSpotLightShadowsWithMaps),T.push(w.numLightProbes),T.push(w.shadowMapType),T.push(w.toneMapping),T.push(w.numClippingPlanes),T.push(w.numClipIntersection),T.push(w.depthPacking)}function R(T,w){c.disableAll(),w.instancing&&c.enable(0),w.instancingColor&&c.enable(1),w.instancingMorph&&c.enable(2),w.matcap&&c.enable(3),w.envMap&&c.enable(4),w.normalMapObjectSpace&&c.enable(5),w.normalMapTangentSpace&&c.enable(6),w.clearcoat&&c.enable(7),w.iridescence&&c.enable(8),w.alphaTest&&c.enable(9),w.vertexColors&&c.enable(10),w.vertexAlphas&&c.enable(11),w.vertexUv1s&&c.enable(12),w.vertexUv2s&&c.enable(13),w.vertexUv3s&&c.enable(14),w.vertexTangents&&c.enable(15),w.anisotropy&&c.enable(16),w.alphaHash&&c.enable(17),w.batching&&c.enable(18),w.dispersion&&c.enable(19),w.batchingColor&&c.enable(20),w.gradientMap&&c.enable(21),T.push(c.mask),c.disableAll(),w.fog&&c.enable(0),w.useFog&&c.enable(1),w.flatShading&&c.enable(2),w.logarithmicDepthBuffer&&c.enable(3),w.reversedDepthBuffer&&c.enable(4),w.skinning&&c.enable(5),w.morphTargets&&c.enable(6),w.morphNormals&&c.enable(7),w.morphColors&&c.enable(8),w.premultipliedAlpha&&c.enable(9),w.shadowMapEnabled&&c.enable(10),w.doubleSided&&c.enable(11),w.flipSided&&c.enable(12),w.useDepthPacking&&c.enable(13),w.dithering&&c.enable(14),w.transmission&&c.enable(15),w.sheen&&c.enable(16),w.opaque&&c.enable(17),w.pointsUvs&&c.enable(18),w.decodeVideoTexture&&c.enable(19),w.decodeVideoTextureEmissive&&c.enable(20),w.alphaToCoverage&&c.enable(21),T.push(c.mask)}function U(T){const w=x[T.type];let q;if(w){const G=fr[w];q=GR.clone(G.uniforms)}else q=T.uniforms;return q}function C(T,w){let q=_.get(w);return q!==void 0?++q.usedTimes:(q=new fD(o,w,T,r),d.push(q),_.set(w,q)),q}function O(T){if(--T.usedTimes===0){const w=d.indexOf(T);d[w]=d[d.length-1],d.pop(),_.delete(T.cacheKey),T.destroy()}}function P(T){f.remove(T)}function L(){f.dispose()}return{getParameters:E,getProgramCacheKey:y,getUniforms:U,acquireProgram:C,releaseProgram:O,releaseShaderCache:P,programs:d,dispose:L}}function _D(){let o=new WeakMap;function t(c){return o.has(c)}function n(c){let f=o.get(c);return f===void 0&&(f={},o.set(c,f)),f}function a(c){o.delete(c)}function r(c,f,p){o.get(c)[f]=p}function l(){o=new WeakMap}return{has:t,get:n,remove:a,update:r,dispose:l}}function gD(o,t){return o.groupOrder!==t.groupOrder?o.groupOrder-t.groupOrder:o.renderOrder!==t.renderOrder?o.renderOrder-t.renderOrder:o.material.id!==t.material.id?o.material.id-t.material.id:o.materialVariant!==t.materialVariant?o.materialVariant-t.materialVariant:o.z!==t.z?o.z-t.z:o.id-t.id}function yM(o,t){return o.groupOrder!==t.groupOrder?o.groupOrder-t.groupOrder:o.renderOrder!==t.renderOrder?o.renderOrder-t.renderOrder:o.z!==t.z?t.z-o.z:o.id-t.id}function SM(){const o=[];let t=0;const n=[],a=[],r=[];function l(){t=0,n.length=0,a.length=0,r.length=0}function c(g){let x=0;return g.isInstancedMesh&&(x+=2),g.isSkinnedMesh&&(x+=1),x}function f(g,x,M,E,y,S){let R=o[t];return R===void 0?(R={id:g.id,object:g,geometry:x,material:M,materialVariant:c(g),groupOrder:E,renderOrder:g.renderOrder,z:y,group:S},o[t]=R):(R.id=g.id,R.object=g,R.geometry=x,R.material=M,R.materialVariant=c(g),R.groupOrder=E,R.renderOrder=g.renderOrder,R.z=y,R.group=S),t++,R}function p(g,x,M,E,y,S){const R=f(g,x,M,E,y,S);M.transmission>0?a.push(R):M.transparent===!0?r.push(R):n.push(R)}function d(g,x,M,E,y,S){const R=f(g,x,M,E,y,S);M.transmission>0?a.unshift(R):M.transparent===!0?r.unshift(R):n.unshift(R)}function _(g,x){n.length>1&&n.sort(g||gD),a.length>1&&a.sort(x||yM),r.length>1&&r.sort(x||yM)}function v(){for(let g=t,x=o.length;g<x;g++){const M=o[g];if(M.id===null)break;M.id=null,M.object=null,M.geometry=null,M.material=null,M.group=null}}return{opaque:n,transmissive:a,transparent:r,init:l,push:p,unshift:d,finish:v,sort:_}}function vD(){let o=new WeakMap;function t(a,r){const l=o.get(a);let c;return l===void 0?(c=new SM,o.set(a,[c])):r>=l.length?(c=new SM,l.push(c)):c=l[r],c}function n(){o=new WeakMap}return{get:t,dispose:n}}function xD(){const o={};return{get:function(t){if(o[t.id]!==void 0)return o[t.id];let n;switch(t.type){case"DirectionalLight":n={direction:new ft,color:new qe};break;case"SpotLight":n={position:new ft,direction:new ft,color:new qe,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":n={position:new ft,color:new qe,distance:0,decay:0};break;case"HemisphereLight":n={direction:new ft,skyColor:new qe,groundColor:new qe};break;case"RectAreaLight":n={color:new qe,position:new ft,halfWidth:new ft,halfHeight:new ft};break}return o[t.id]=n,n}}}function yD(){const o={};return{get:function(t){if(o[t.id]!==void 0)return o[t.id];let n;switch(t.type){case"DirectionalLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new fn};break;case"SpotLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new fn};break;case"PointLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new fn,shadowCameraNear:1,shadowCameraFar:1e3};break}return o[t.id]=n,n}}}let SD=0;function MD(o,t){return(t.castShadow?2:0)-(o.castShadow?2:0)+(t.map?1:0)-(o.map?1:0)}function ED(o){const t=new xD,n=yD(),a={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let d=0;d<9;d++)a.probe.push(new ft);const r=new ft,l=new zn,c=new zn;function f(d){let _=0,v=0,g=0;for(let w=0;w<9;w++)a.probe[w].set(0,0,0);let x=0,M=0,E=0,y=0,S=0,R=0,U=0,C=0,O=0,P=0,L=0;d.sort(MD);for(let w=0,q=d.length;w<q;w++){const G=d[w],k=G.color,J=G.intensity,et=G.distance;let Q=null;if(G.shadow&&G.shadow.map&&(G.shadow.map.texture.format===nu?Q=G.shadow.map.texture:Q=G.shadow.map.depthTexture||G.shadow.map.texture),G.isAmbientLight)_+=k.r*J,v+=k.g*J,g+=k.b*J;else if(G.isLightProbe){for(let F=0;F<9;F++)a.probe[F].addScaledVector(G.sh.coefficients[F],J);L++}else if(G.isDirectionalLight){const F=t.get(G);if(F.color.copy(G.color).multiplyScalar(G.intensity),G.castShadow){const I=G.shadow,it=n.get(G);it.shadowIntensity=I.intensity,it.shadowBias=I.bias,it.shadowNormalBias=I.normalBias,it.shadowRadius=I.radius,it.shadowMapSize=I.mapSize,a.directionalShadow[x]=it,a.directionalShadowMap[x]=Q,a.directionalShadowMatrix[x]=G.shadow.matrix,R++}a.directional[x]=F,x++}else if(G.isSpotLight){const F=t.get(G);F.position.setFromMatrixPosition(G.matrixWorld),F.color.copy(k).multiplyScalar(J),F.distance=et,F.coneCos=Math.cos(G.angle),F.penumbraCos=Math.cos(G.angle*(1-G.penumbra)),F.decay=G.decay,a.spot[E]=F;const I=G.shadow;if(G.map&&(a.spotLightMap[O]=G.map,O++,I.updateMatrices(G),G.castShadow&&P++),a.spotLightMatrix[E]=I.matrix,G.castShadow){const it=n.get(G);it.shadowIntensity=I.intensity,it.shadowBias=I.bias,it.shadowNormalBias=I.normalBias,it.shadowRadius=I.radius,it.shadowMapSize=I.mapSize,a.spotShadow[E]=it,a.spotShadowMap[E]=Q,C++}E++}else if(G.isRectAreaLight){const F=t.get(G);F.color.copy(k).multiplyScalar(J),F.halfWidth.set(G.width*.5,0,0),F.halfHeight.set(0,G.height*.5,0),a.rectArea[y]=F,y++}else if(G.isPointLight){const F=t.get(G);if(F.color.copy(G.color).multiplyScalar(G.intensity),F.distance=G.distance,F.decay=G.decay,G.castShadow){const I=G.shadow,it=n.get(G);it.shadowIntensity=I.intensity,it.shadowBias=I.bias,it.shadowNormalBias=I.normalBias,it.shadowRadius=I.radius,it.shadowMapSize=I.mapSize,it.shadowCameraNear=I.camera.near,it.shadowCameraFar=I.camera.far,a.pointShadow[M]=it,a.pointShadowMap[M]=Q,a.pointShadowMatrix[M]=G.shadow.matrix,U++}a.point[M]=F,M++}else if(G.isHemisphereLight){const F=t.get(G);F.skyColor.copy(G.color).multiplyScalar(J),F.groundColor.copy(G.groundColor).multiplyScalar(J),a.hemi[S]=F,S++}}y>0&&(o.has("OES_texture_float_linear")===!0?(a.rectAreaLTC1=kt.LTC_FLOAT_1,a.rectAreaLTC2=kt.LTC_FLOAT_2):(a.rectAreaLTC1=kt.LTC_HALF_1,a.rectAreaLTC2=kt.LTC_HALF_2)),a.ambient[0]=_,a.ambient[1]=v,a.ambient[2]=g;const T=a.hash;(T.directionalLength!==x||T.pointLength!==M||T.spotLength!==E||T.rectAreaLength!==y||T.hemiLength!==S||T.numDirectionalShadows!==R||T.numPointShadows!==U||T.numSpotShadows!==C||T.numSpotMaps!==O||T.numLightProbes!==L)&&(a.directional.length=x,a.spot.length=E,a.rectArea.length=y,a.point.length=M,a.hemi.length=S,a.directionalShadow.length=R,a.directionalShadowMap.length=R,a.pointShadow.length=U,a.pointShadowMap.length=U,a.spotShadow.length=C,a.spotShadowMap.length=C,a.directionalShadowMatrix.length=R,a.pointShadowMatrix.length=U,a.spotLightMatrix.length=C+O-P,a.spotLightMap.length=O,a.numSpotLightShadowsWithMaps=P,a.numLightProbes=L,T.directionalLength=x,T.pointLength=M,T.spotLength=E,T.rectAreaLength=y,T.hemiLength=S,T.numDirectionalShadows=R,T.numPointShadows=U,T.numSpotShadows=C,T.numSpotMaps=O,T.numLightProbes=L,a.version=SD++)}function p(d,_){let v=0,g=0,x=0,M=0,E=0;const y=_.matrixWorldInverse;for(let S=0,R=d.length;S<R;S++){const U=d[S];if(U.isDirectionalLight){const C=a.directional[v];C.direction.setFromMatrixPosition(U.matrixWorld),r.setFromMatrixPosition(U.target.matrixWorld),C.direction.sub(r),C.direction.transformDirection(y),v++}else if(U.isSpotLight){const C=a.spot[x];C.position.setFromMatrixPosition(U.matrixWorld),C.position.applyMatrix4(y),C.direction.setFromMatrixPosition(U.matrixWorld),r.setFromMatrixPosition(U.target.matrixWorld),C.direction.sub(r),C.direction.transformDirection(y),x++}else if(U.isRectAreaLight){const C=a.rectArea[M];C.position.setFromMatrixPosition(U.matrixWorld),C.position.applyMatrix4(y),c.identity(),l.copy(U.matrixWorld),l.premultiply(y),c.extractRotation(l),C.halfWidth.set(U.width*.5,0,0),C.halfHeight.set(0,U.height*.5,0),C.halfWidth.applyMatrix4(c),C.halfHeight.applyMatrix4(c),M++}else if(U.isPointLight){const C=a.point[g];C.position.setFromMatrixPosition(U.matrixWorld),C.position.applyMatrix4(y),g++}else if(U.isHemisphereLight){const C=a.hemi[E];C.direction.setFromMatrixPosition(U.matrixWorld),C.direction.transformDirection(y),E++}}}return{setup:f,setupView:p,state:a}}function MM(o){const t=new ED(o),n=[],a=[];function r(_){d.camera=_,n.length=0,a.length=0}function l(_){n.push(_)}function c(_){a.push(_)}function f(){t.setup(n)}function p(_){t.setupView(n,_)}const d={lightsArray:n,shadowsArray:a,camera:null,lights:t,transmissionRenderTarget:{}};return{init:r,state:d,setupLights:f,setupLightsView:p,pushLight:l,pushShadow:c}}function bD(o){let t=new WeakMap;function n(r,l=0){const c=t.get(r);let f;return c===void 0?(f=new MM(o),t.set(r,[f])):l>=c.length?(f=new MM(o),c.push(f)):f=c[l],f}function a(){t=new WeakMap}return{get:n,dispose:a}}const TD=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,AD=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,RD=[new ft(1,0,0),new ft(-1,0,0),new ft(0,1,0),new ft(0,-1,0),new ft(0,0,1),new ft(0,0,-1)],CD=[new ft(0,-1,0),new ft(0,-1,0),new ft(0,0,1),new ft(0,0,-1),new ft(0,-1,0),new ft(0,-1,0)],EM=new zn,cc=new ft,S_=new ft;function wD(o,t,n){let a=new L1;const r=new fn,l=new fn,c=new Pn,f=new WR,p=new YR,d={},_=n.maxTextureSize,v={[Ys]:Yi,[Yi]:Ys,[jr]:jr},g=new Ga({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new fn},radius:{value:4}},vertexShader:TD,fragmentShader:AD}),x=g.clone();x.defines.HORIZONTAL_PASS=1;const M=new tr;M.setAttribute("position",new xr(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const E=new $a(M,g),y=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=jh;let S=this.type;this.render=function(P,L,T){if(y.enabled===!1||y.autoUpdate===!1&&y.needsUpdate===!1||P.length===0)return;this.type===NA&&(Me("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=jh);const w=o.getRenderTarget(),q=o.getActiveCubeFace(),G=o.getActiveMipmapLevel(),k=o.state;k.setBlending(Jr),k.buffers.depth.getReversed()===!0?k.buffers.color.setClear(0,0,0,0):k.buffers.color.setClear(1,1,1,1),k.buffers.depth.setTest(!0),k.setScissorTest(!1);const J=S!==this.type;J&&L.traverse(function(et){et.material&&(Array.isArray(et.material)?et.material.forEach(Q=>Q.needsUpdate=!0):et.material.needsUpdate=!0)});for(let et=0,Q=P.length;et<Q;et++){const F=P[et],I=F.shadow;if(I===void 0){Me("WebGLShadowMap:",F,"has no shadow.");continue}if(I.autoUpdate===!1&&I.needsUpdate===!1)continue;r.copy(I.mapSize);const it=I.getFrameExtents();r.multiply(it),l.copy(I.mapSize),(r.x>_||r.y>_)&&(r.x>_&&(l.x=Math.floor(_/it.x),r.x=l.x*it.x,I.mapSize.x=l.x),r.y>_&&(l.y=Math.floor(_/it.y),r.y=l.y*it.y,I.mapSize.y=l.y));const ht=o.state.buffers.depth.getReversed();if(I.camera._reversedDepth=ht,I.map===null||J===!0){if(I.map!==null&&(I.map.depthTexture!==null&&(I.map.depthTexture.dispose(),I.map.depthTexture=null),I.map.dispose()),this.type===pc){if(F.isPointLight){Me("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}I.map=new vr(r.x,r.y,{format:nu,type:es,minFilter:Si,magFilter:Si,generateMipmaps:!1}),I.map.texture.name=F.name+".shadowMap",I.map.depthTexture=new Bc(r.x,r.y,dr),I.map.depthTexture.name=F.name+".shadowMapDepth",I.map.depthTexture.format=ns,I.map.depthTexture.compareFunction=null,I.map.depthTexture.minFilter=ci,I.map.depthTexture.magFilter=ci}else F.isPointLight?(I.map=new H1(r.x),I.map.depthTexture=new BR(r.x,Sr)):(I.map=new vr(r.x,r.y),I.map.depthTexture=new Bc(r.x,r.y,Sr)),I.map.depthTexture.name=F.name+".shadowMap",I.map.depthTexture.format=ns,this.type===jh?(I.map.depthTexture.compareFunction=ht?ug:lg,I.map.depthTexture.minFilter=Si,I.map.depthTexture.magFilter=Si):(I.map.depthTexture.compareFunction=null,I.map.depthTexture.minFilter=ci,I.map.depthTexture.magFilter=ci);I.camera.updateProjectionMatrix()}const H=I.map.isWebGLCubeRenderTarget?6:1;for(let z=0;z<H;z++){if(I.map.isWebGLCubeRenderTarget)o.setRenderTarget(I.map,z),o.clear();else{z===0&&(o.setRenderTarget(I.map),o.clear());const K=I.getViewport(z);c.set(l.x*K.x,l.y*K.y,l.x*K.z,l.y*K.w),k.viewport(c)}if(F.isPointLight){const K=I.camera,xt=I.matrix,Tt=F.distance||K.far;Tt!==K.far&&(K.far=Tt,K.updateProjectionMatrix()),cc.setFromMatrixPosition(F.matrixWorld),K.position.copy(cc),S_.copy(K.position),S_.add(RD[z]),K.up.copy(CD[z]),K.lookAt(S_),K.updateMatrixWorld(),xt.makeTranslation(-cc.x,-cc.y,-cc.z),EM.multiplyMatrices(K.projectionMatrix,K.matrixWorldInverse),I._frustum.setFromProjectionMatrix(EM,K.coordinateSystem,K.reversedDepth)}else I.updateMatrices(F);a=I.getFrustum(),C(L,T,I.camera,F,this.type)}I.isPointLightShadow!==!0&&this.type===pc&&R(I,T),I.needsUpdate=!1}S=this.type,y.needsUpdate=!1,o.setRenderTarget(w,q,G)};function R(P,L){const T=t.update(E);g.defines.VSM_SAMPLES!==P.blurSamples&&(g.defines.VSM_SAMPLES=P.blurSamples,x.defines.VSM_SAMPLES=P.blurSamples,g.needsUpdate=!0,x.needsUpdate=!0),P.mapPass===null&&(P.mapPass=new vr(r.x,r.y,{format:nu,type:es})),g.uniforms.shadow_pass.value=P.map.depthTexture,g.uniforms.resolution.value=P.mapSize,g.uniforms.radius.value=P.radius,o.setRenderTarget(P.mapPass),o.clear(),o.renderBufferDirect(L,null,T,g,E,null),x.uniforms.shadow_pass.value=P.mapPass.texture,x.uniforms.resolution.value=P.mapSize,x.uniforms.radius.value=P.radius,o.setRenderTarget(P.map),o.clear(),o.renderBufferDirect(L,null,T,x,E,null)}function U(P,L,T,w){let q=null;const G=T.isPointLight===!0?P.customDistanceMaterial:P.customDepthMaterial;if(G!==void 0)q=G;else if(q=T.isPointLight===!0?p:f,o.localClippingEnabled&&L.clipShadows===!0&&Array.isArray(L.clippingPlanes)&&L.clippingPlanes.length!==0||L.displacementMap&&L.displacementScale!==0||L.alphaMap&&L.alphaTest>0||L.map&&L.alphaTest>0||L.alphaToCoverage===!0){const k=q.uuid,J=L.uuid;let et=d[k];et===void 0&&(et={},d[k]=et);let Q=et[J];Q===void 0&&(Q=q.clone(),et[J]=Q,L.addEventListener("dispose",O)),q=Q}if(q.visible=L.visible,q.wireframe=L.wireframe,w===pc?q.side=L.shadowSide!==null?L.shadowSide:L.side:q.side=L.shadowSide!==null?L.shadowSide:v[L.side],q.alphaMap=L.alphaMap,q.alphaTest=L.alphaToCoverage===!0?.5:L.alphaTest,q.map=L.map,q.clipShadows=L.clipShadows,q.clippingPlanes=L.clippingPlanes,q.clipIntersection=L.clipIntersection,q.displacementMap=L.displacementMap,q.displacementScale=L.displacementScale,q.displacementBias=L.displacementBias,q.wireframeLinewidth=L.wireframeLinewidth,q.linewidth=L.linewidth,T.isPointLight===!0&&q.isMeshDistanceMaterial===!0){const k=o.properties.get(q);k.light=T}return q}function C(P,L,T,w,q){if(P.visible===!1)return;if(P.layers.test(L.layers)&&(P.isMesh||P.isLine||P.isPoints)&&(P.castShadow||P.receiveShadow&&q===pc)&&(!P.frustumCulled||a.intersectsObject(P))){P.modelViewMatrix.multiplyMatrices(T.matrixWorldInverse,P.matrixWorld);const J=t.update(P),et=P.material;if(Array.isArray(et)){const Q=J.groups;for(let F=0,I=Q.length;F<I;F++){const it=Q[F],ht=et[it.materialIndex];if(ht&&ht.visible){const H=U(P,ht,w,q);P.onBeforeShadow(o,P,L,T,J,H,it),o.renderBufferDirect(T,null,J,H,P,it),P.onAfterShadow(o,P,L,T,J,H,it)}}}else if(et.visible){const Q=U(P,et,w,q);P.onBeforeShadow(o,P,L,T,J,Q,null),o.renderBufferDirect(T,null,J,Q,P,null),P.onAfterShadow(o,P,L,T,J,Q,null)}}const k=P.children;for(let J=0,et=k.length;J<et;J++)C(k[J],L,T,w,q)}function O(P){P.target.removeEventListener("dispose",O);for(const T in d){const w=d[T],q=P.target.uuid;q in w&&(w[q].dispose(),delete w[q])}}}function DD(o,t){function n(){let V=!1;const Dt=new Pn;let Ct=null;const Lt=new Pn(0,0,0,0);return{setMask:function(bt){Ct!==bt&&!V&&(o.colorMask(bt,bt,bt,bt),Ct=bt)},setLocked:function(bt){V=bt},setClear:function(bt,mt,Xt,le,Ge){Ge===!0&&(bt*=le,mt*=le,Xt*=le),Dt.set(bt,mt,Xt,le),Lt.equals(Dt)===!1&&(o.clearColor(bt,mt,Xt,le),Lt.copy(Dt))},reset:function(){V=!1,Ct=null,Lt.set(-1,0,0,0)}}}function a(){let V=!1,Dt=!1,Ct=null,Lt=null,bt=null;return{setReversed:function(mt){if(Dt!==mt){const Xt=t.get("EXT_clip_control");mt?Xt.clipControlEXT(Xt.LOWER_LEFT_EXT,Xt.ZERO_TO_ONE_EXT):Xt.clipControlEXT(Xt.LOWER_LEFT_EXT,Xt.NEGATIVE_ONE_TO_ONE_EXT),Dt=mt;const le=bt;bt=null,this.setClear(le)}},getReversed:function(){return Dt},setTest:function(mt){mt?_t(o.DEPTH_TEST):Et(o.DEPTH_TEST)},setMask:function(mt){Ct!==mt&&!V&&(o.depthMask(mt),Ct=mt)},setFunc:function(mt){if(Dt&&(mt=hR[mt]),Lt!==mt){switch(mt){case B_:o.depthFunc(o.NEVER);break;case H_:o.depthFunc(o.ALWAYS);break;case G_:o.depthFunc(o.LESS);break;case tu:o.depthFunc(o.LEQUAL);break;case V_:o.depthFunc(o.EQUAL);break;case k_:o.depthFunc(o.GEQUAL);break;case X_:o.depthFunc(o.GREATER);break;case W_:o.depthFunc(o.NOTEQUAL);break;default:o.depthFunc(o.LEQUAL)}Lt=mt}},setLocked:function(mt){V=mt},setClear:function(mt){bt!==mt&&(bt=mt,Dt&&(mt=1-mt),o.clearDepth(mt))},reset:function(){V=!1,Ct=null,Lt=null,bt=null,Dt=!1}}}function r(){let V=!1,Dt=null,Ct=null,Lt=null,bt=null,mt=null,Xt=null,le=null,Ge=null;return{setTest:function(Vt){V||(Vt?_t(o.STENCIL_TEST):Et(o.STENCIL_TEST))},setMask:function(Vt){Dt!==Vt&&!V&&(o.stencilMask(Vt),Dt=Vt)},setFunc:function(Vt,Jt,be){(Ct!==Vt||Lt!==Jt||bt!==be)&&(o.stencilFunc(Vt,Jt,be),Ct=Vt,Lt=Jt,bt=be)},setOp:function(Vt,Jt,be){(mt!==Vt||Xt!==Jt||le!==be)&&(o.stencilOp(Vt,Jt,be),mt=Vt,Xt=Jt,le=be)},setLocked:function(Vt){V=Vt},setClear:function(Vt){Ge!==Vt&&(o.clearStencil(Vt),Ge=Vt)},reset:function(){V=!1,Dt=null,Ct=null,Lt=null,bt=null,mt=null,Xt=null,le=null,Ge=null}}}const l=new n,c=new a,f=new r,p=new WeakMap,d=new WeakMap;let _={},v={},g=new WeakMap,x=[],M=null,E=!1,y=null,S=null,R=null,U=null,C=null,O=null,P=null,L=new qe(0,0,0),T=0,w=!1,q=null,G=null,k=null,J=null,et=null;const Q=o.getParameter(o.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let F=!1,I=0;const it=o.getParameter(o.VERSION);it.indexOf("WebGL")!==-1?(I=parseFloat(/^WebGL (\d)/.exec(it)[1]),F=I>=1):it.indexOf("OpenGL ES")!==-1&&(I=parseFloat(/^OpenGL ES (\d)/.exec(it)[1]),F=I>=2);let ht=null,H={};const z=o.getParameter(o.SCISSOR_BOX),K=o.getParameter(o.VIEWPORT),xt=new Pn().fromArray(z),Tt=new Pn().fromArray(K);function Ut(V,Dt,Ct,Lt){const bt=new Uint8Array(4),mt=o.createTexture();o.bindTexture(V,mt),o.texParameteri(V,o.TEXTURE_MIN_FILTER,o.NEAREST),o.texParameteri(V,o.TEXTURE_MAG_FILTER,o.NEAREST);for(let Xt=0;Xt<Ct;Xt++)V===o.TEXTURE_3D||V===o.TEXTURE_2D_ARRAY?o.texImage3D(Dt,0,o.RGBA,1,1,Lt,0,o.RGBA,o.UNSIGNED_BYTE,bt):o.texImage2D(Dt+Xt,0,o.RGBA,1,1,0,o.RGBA,o.UNSIGNED_BYTE,bt);return mt}const nt={};nt[o.TEXTURE_2D]=Ut(o.TEXTURE_2D,o.TEXTURE_2D,1),nt[o.TEXTURE_CUBE_MAP]=Ut(o.TEXTURE_CUBE_MAP,o.TEXTURE_CUBE_MAP_POSITIVE_X,6),nt[o.TEXTURE_2D_ARRAY]=Ut(o.TEXTURE_2D_ARRAY,o.TEXTURE_2D_ARRAY,1,1),nt[o.TEXTURE_3D]=Ut(o.TEXTURE_3D,o.TEXTURE_3D,1,1),l.setClear(0,0,0,1),c.setClear(1),f.setClear(0),_t(o.DEPTH_TEST),c.setFunc(tu),se(!1),lt(RS),_t(o.CULL_FACE),re(Jr);function _t(V){_[V]!==!0&&(o.enable(V),_[V]=!0)}function Et(V){_[V]!==!1&&(o.disable(V),_[V]=!1)}function Ft(V,Dt){return v[V]!==Dt?(o.bindFramebuffer(V,Dt),v[V]=Dt,V===o.DRAW_FRAMEBUFFER&&(v[o.FRAMEBUFFER]=Dt),V===o.FRAMEBUFFER&&(v[o.DRAW_FRAMEBUFFER]=Dt),!0):!1}function ee(V,Dt){let Ct=x,Lt=!1;if(V){Ct=g.get(Dt),Ct===void 0&&(Ct=[],g.set(Dt,Ct));const bt=V.textures;if(Ct.length!==bt.length||Ct[0]!==o.COLOR_ATTACHMENT0){for(let mt=0,Xt=bt.length;mt<Xt;mt++)Ct[mt]=o.COLOR_ATTACHMENT0+mt;Ct.length=bt.length,Lt=!0}}else Ct[0]!==o.BACK&&(Ct[0]=o.BACK,Lt=!0);Lt&&o.drawBuffers(Ct)}function Kt(V){return M!==V?(o.useProgram(V),M=V,!0):!1}const Ne={[Ro]:o.FUNC_ADD,[OA]:o.FUNC_SUBTRACT,[PA]:o.FUNC_REVERSE_SUBTRACT};Ne[FA]=o.MIN,Ne[zA]=o.MAX;const qt={[IA]:o.ZERO,[BA]:o.ONE,[HA]:o.SRC_COLOR,[z_]:o.SRC_ALPHA,[YA]:o.SRC_ALPHA_SATURATE,[XA]:o.DST_COLOR,[VA]:o.DST_ALPHA,[GA]:o.ONE_MINUS_SRC_COLOR,[I_]:o.ONE_MINUS_SRC_ALPHA,[WA]:o.ONE_MINUS_DST_COLOR,[kA]:o.ONE_MINUS_DST_ALPHA,[qA]:o.CONSTANT_COLOR,[jA]:o.ONE_MINUS_CONSTANT_COLOR,[ZA]:o.CONSTANT_ALPHA,[KA]:o.ONE_MINUS_CONSTANT_ALPHA};function re(V,Dt,Ct,Lt,bt,mt,Xt,le,Ge,Vt){if(V===Jr){E===!0&&(Et(o.BLEND),E=!1);return}if(E===!1&&(_t(o.BLEND),E=!0),V!==LA){if(V!==y||Vt!==w){if((S!==Ro||C!==Ro)&&(o.blendEquation(o.FUNC_ADD),S=Ro,C=Ro),Vt)switch(V){case Yl:o.blendFuncSeparate(o.ONE,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case CS:o.blendFunc(o.ONE,o.ONE);break;case wS:o.blendFuncSeparate(o.ZERO,o.ONE_MINUS_SRC_COLOR,o.ZERO,o.ONE);break;case DS:o.blendFuncSeparate(o.DST_COLOR,o.ONE_MINUS_SRC_ALPHA,o.ZERO,o.ONE);break;default:Qe("WebGLState: Invalid blending: ",V);break}else switch(V){case Yl:o.blendFuncSeparate(o.SRC_ALPHA,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case CS:o.blendFuncSeparate(o.SRC_ALPHA,o.ONE,o.ONE,o.ONE);break;case wS:Qe("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case DS:Qe("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Qe("WebGLState: Invalid blending: ",V);break}R=null,U=null,O=null,P=null,L.set(0,0,0),T=0,y=V,w=Vt}return}bt=bt||Dt,mt=mt||Ct,Xt=Xt||Lt,(Dt!==S||bt!==C)&&(o.blendEquationSeparate(Ne[Dt],Ne[bt]),S=Dt,C=bt),(Ct!==R||Lt!==U||mt!==O||Xt!==P)&&(o.blendFuncSeparate(qt[Ct],qt[Lt],qt[mt],qt[Xt]),R=Ct,U=Lt,O=mt,P=Xt),(le.equals(L)===!1||Ge!==T)&&(o.blendColor(le.r,le.g,le.b,Ge),L.copy(le),T=Ge),y=V,w=!1}function _e(V,Dt){V.side===jr?Et(o.CULL_FACE):_t(o.CULL_FACE);let Ct=V.side===Yi;Dt&&(Ct=!Ct),se(Ct),V.blending===Yl&&V.transparent===!1?re(Jr):re(V.blending,V.blendEquation,V.blendSrc,V.blendDst,V.blendEquationAlpha,V.blendSrcAlpha,V.blendDstAlpha,V.blendColor,V.blendAlpha,V.premultipliedAlpha),c.setFunc(V.depthFunc),c.setTest(V.depthTest),c.setMask(V.depthWrite),l.setMask(V.colorWrite);const Lt=V.stencilWrite;f.setTest(Lt),Lt&&(f.setMask(V.stencilWriteMask),f.setFunc(V.stencilFunc,V.stencilRef,V.stencilFuncMask),f.setOp(V.stencilFail,V.stencilZFail,V.stencilZPass)),We(V.polygonOffset,V.polygonOffsetFactor,V.polygonOffsetUnits),V.alphaToCoverage===!0?_t(o.SAMPLE_ALPHA_TO_COVERAGE):Et(o.SAMPLE_ALPHA_TO_COVERAGE)}function se(V){q!==V&&(V?o.frontFace(o.CW):o.frontFace(o.CCW),q=V)}function lt(V){V!==DA?(_t(o.CULL_FACE),V!==G&&(V===RS?o.cullFace(o.BACK):V===UA?o.cullFace(o.FRONT):o.cullFace(o.FRONT_AND_BACK))):Et(o.CULL_FACE),G=V}function W(V){V!==k&&(F&&o.lineWidth(V),k=V)}function We(V,Dt,Ct){V?(_t(o.POLYGON_OFFSET_FILL),(J!==Dt||et!==Ct)&&(J=Dt,et=Ct,c.getReversed()&&(Dt=-Dt),o.polygonOffset(Dt,Ct))):Et(o.POLYGON_OFFSET_FILL)}function Ee(V){V?_t(o.SCISSOR_TEST):Et(o.SCISSOR_TEST)}function ce(V){V===void 0&&(V=o.TEXTURE0+Q-1),ht!==V&&(o.activeTexture(V),ht=V)}function Wt(V,Dt,Ct){Ct===void 0&&(ht===null?Ct=o.TEXTURE0+Q-1:Ct=ht);let Lt=H[Ct];Lt===void 0&&(Lt={type:void 0,texture:void 0},H[Ct]=Lt),(Lt.type!==V||Lt.texture!==Dt)&&(ht!==Ct&&(o.activeTexture(Ct),ht=Ct),o.bindTexture(V,Dt||nt[V]),Lt.type=V,Lt.texture=Dt)}function B(){const V=H[ht];V!==void 0&&V.type!==void 0&&(o.bindTexture(V.type,null),V.type=void 0,V.texture=void 0)}function A(){try{o.compressedTexImage2D(...arguments)}catch(V){Qe("WebGLState:",V)}}function j(){try{o.compressedTexImage3D(...arguments)}catch(V){Qe("WebGLState:",V)}}function gt(){try{o.texSubImage2D(...arguments)}catch(V){Qe("WebGLState:",V)}}function vt(){try{o.texSubImage3D(...arguments)}catch(V){Qe("WebGLState:",V)}}function dt(){try{o.compressedTexSubImage2D(...arguments)}catch(V){Qe("WebGLState:",V)}}function Gt(){try{o.compressedTexSubImage3D(...arguments)}catch(V){Qe("WebGLState:",V)}}function wt(){try{o.texStorage2D(...arguments)}catch(V){Qe("WebGLState:",V)}}function ie(){try{o.texStorage3D(...arguments)}catch(V){Qe("WebGLState:",V)}}function Yt(){try{o.texImage2D(...arguments)}catch(V){Qe("WebGLState:",V)}}function Rt(){try{o.texImage3D(...arguments)}catch(V){Qe("WebGLState:",V)}}function At(V){xt.equals(V)===!1&&(o.scissor(V.x,V.y,V.z,V.w),xt.copy(V))}function Ht(V){Tt.equals(V)===!1&&(o.viewport(V.x,V.y,V.z,V.w),Tt.copy(V))}function Pt(V,Dt){let Ct=d.get(Dt);Ct===void 0&&(Ct=new WeakMap,d.set(Dt,Ct));let Lt=Ct.get(V);Lt===void 0&&(Lt=o.getUniformBlockIndex(Dt,V.name),Ct.set(V,Lt))}function zt(V,Dt){const Lt=d.get(Dt).get(V);p.get(Dt)!==Lt&&(o.uniformBlockBinding(Dt,Lt,V.__bindingPointIndex),p.set(Dt,Lt))}function pe(){o.disable(o.BLEND),o.disable(o.CULL_FACE),o.disable(o.DEPTH_TEST),o.disable(o.POLYGON_OFFSET_FILL),o.disable(o.SCISSOR_TEST),o.disable(o.STENCIL_TEST),o.disable(o.SAMPLE_ALPHA_TO_COVERAGE),o.blendEquation(o.FUNC_ADD),o.blendFunc(o.ONE,o.ZERO),o.blendFuncSeparate(o.ONE,o.ZERO,o.ONE,o.ZERO),o.blendColor(0,0,0,0),o.colorMask(!0,!0,!0,!0),o.clearColor(0,0,0,0),o.depthMask(!0),o.depthFunc(o.LESS),c.setReversed(!1),o.clearDepth(1),o.stencilMask(4294967295),o.stencilFunc(o.ALWAYS,0,4294967295),o.stencilOp(o.KEEP,o.KEEP,o.KEEP),o.clearStencil(0),o.cullFace(o.BACK),o.frontFace(o.CCW),o.polygonOffset(0,0),o.activeTexture(o.TEXTURE0),o.bindFramebuffer(o.FRAMEBUFFER,null),o.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),o.bindFramebuffer(o.READ_FRAMEBUFFER,null),o.useProgram(null),o.lineWidth(1),o.scissor(0,0,o.canvas.width,o.canvas.height),o.viewport(0,0,o.canvas.width,o.canvas.height),_={},ht=null,H={},v={},g=new WeakMap,x=[],M=null,E=!1,y=null,S=null,R=null,U=null,C=null,O=null,P=null,L=new qe(0,0,0),T=0,w=!1,q=null,G=null,k=null,J=null,et=null,xt.set(0,0,o.canvas.width,o.canvas.height),Tt.set(0,0,o.canvas.width,o.canvas.height),l.reset(),c.reset(),f.reset()}return{buffers:{color:l,depth:c,stencil:f},enable:_t,disable:Et,bindFramebuffer:Ft,drawBuffers:ee,useProgram:Kt,setBlending:re,setMaterial:_e,setFlipSided:se,setCullFace:lt,setLineWidth:W,setPolygonOffset:We,setScissorTest:Ee,activeTexture:ce,bindTexture:Wt,unbindTexture:B,compressedTexImage2D:A,compressedTexImage3D:j,texImage2D:Yt,texImage3D:Rt,updateUBOMapping:Pt,uniformBlockBinding:zt,texStorage2D:wt,texStorage3D:ie,texSubImage2D:gt,texSubImage3D:vt,compressedTexSubImage2D:dt,compressedTexSubImage3D:Gt,scissor:At,viewport:Ht,reset:pe}}function UD(o,t,n,a,r,l,c){const f=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,p=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),d=new fn,_=new WeakMap;let v;const g=new WeakMap;let x=!1;try{x=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function M(B,A){return x?new OffscreenCanvas(B,A):fd("canvas")}function E(B,A,j){let gt=1;const vt=Wt(B);if((vt.width>j||vt.height>j)&&(gt=j/Math.max(vt.width,vt.height)),gt<1)if(typeof HTMLImageElement<"u"&&B instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&B instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&B instanceof ImageBitmap||typeof VideoFrame<"u"&&B instanceof VideoFrame){const dt=Math.floor(gt*vt.width),Gt=Math.floor(gt*vt.height);v===void 0&&(v=M(dt,Gt));const wt=A?M(dt,Gt):v;return wt.width=dt,wt.height=Gt,wt.getContext("2d").drawImage(B,0,0,dt,Gt),Me("WebGLRenderer: Texture has been resized from ("+vt.width+"x"+vt.height+") to ("+dt+"x"+Gt+")."),wt}else return"data"in B&&Me("WebGLRenderer: Image in DataTexture is too big ("+vt.width+"x"+vt.height+")."),B;return B}function y(B){return B.generateMipmaps}function S(B){o.generateMipmap(B)}function R(B){return B.isWebGLCubeRenderTarget?o.TEXTURE_CUBE_MAP:B.isWebGL3DRenderTarget?o.TEXTURE_3D:B.isWebGLArrayRenderTarget||B.isCompressedArrayTexture?o.TEXTURE_2D_ARRAY:o.TEXTURE_2D}function U(B,A,j,gt,vt=!1){if(B!==null){if(o[B]!==void 0)return o[B];Me("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+B+"'")}let dt=A;if(A===o.RED&&(j===o.FLOAT&&(dt=o.R32F),j===o.HALF_FLOAT&&(dt=o.R16F),j===o.UNSIGNED_BYTE&&(dt=o.R8)),A===o.RED_INTEGER&&(j===o.UNSIGNED_BYTE&&(dt=o.R8UI),j===o.UNSIGNED_SHORT&&(dt=o.R16UI),j===o.UNSIGNED_INT&&(dt=o.R32UI),j===o.BYTE&&(dt=o.R8I),j===o.SHORT&&(dt=o.R16I),j===o.INT&&(dt=o.R32I)),A===o.RG&&(j===o.FLOAT&&(dt=o.RG32F),j===o.HALF_FLOAT&&(dt=o.RG16F),j===o.UNSIGNED_BYTE&&(dt=o.RG8)),A===o.RG_INTEGER&&(j===o.UNSIGNED_BYTE&&(dt=o.RG8UI),j===o.UNSIGNED_SHORT&&(dt=o.RG16UI),j===o.UNSIGNED_INT&&(dt=o.RG32UI),j===o.BYTE&&(dt=o.RG8I),j===o.SHORT&&(dt=o.RG16I),j===o.INT&&(dt=o.RG32I)),A===o.RGB_INTEGER&&(j===o.UNSIGNED_BYTE&&(dt=o.RGB8UI),j===o.UNSIGNED_SHORT&&(dt=o.RGB16UI),j===o.UNSIGNED_INT&&(dt=o.RGB32UI),j===o.BYTE&&(dt=o.RGB8I),j===o.SHORT&&(dt=o.RGB16I),j===o.INT&&(dt=o.RGB32I)),A===o.RGBA_INTEGER&&(j===o.UNSIGNED_BYTE&&(dt=o.RGBA8UI),j===o.UNSIGNED_SHORT&&(dt=o.RGBA16UI),j===o.UNSIGNED_INT&&(dt=o.RGBA32UI),j===o.BYTE&&(dt=o.RGBA8I),j===o.SHORT&&(dt=o.RGBA16I),j===o.INT&&(dt=o.RGBA32I)),A===o.RGB&&(j===o.UNSIGNED_INT_5_9_9_9_REV&&(dt=o.RGB9_E5),j===o.UNSIGNED_INT_10F_11F_11F_REV&&(dt=o.R11F_G11F_B10F)),A===o.RGBA){const Gt=vt?ud:Ye.getTransfer(gt);j===o.FLOAT&&(dt=o.RGBA32F),j===o.HALF_FLOAT&&(dt=o.RGBA16F),j===o.UNSIGNED_BYTE&&(dt=Gt===an?o.SRGB8_ALPHA8:o.RGBA8),j===o.UNSIGNED_SHORT_4_4_4_4&&(dt=o.RGBA4),j===o.UNSIGNED_SHORT_5_5_5_1&&(dt=o.RGB5_A1)}return(dt===o.R16F||dt===o.R32F||dt===o.RG16F||dt===o.RG32F||dt===o.RGBA16F||dt===o.RGBA32F)&&t.get("EXT_color_buffer_float"),dt}function C(B,A){let j;return B?A===null||A===Sr||A===Ic?j=o.DEPTH24_STENCIL8:A===dr?j=o.DEPTH32F_STENCIL8:A===zc&&(j=o.DEPTH24_STENCIL8,Me("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):A===null||A===Sr||A===Ic?j=o.DEPTH_COMPONENT24:A===dr?j=o.DEPTH_COMPONENT32F:A===zc&&(j=o.DEPTH_COMPONENT16),j}function O(B,A){return y(B)===!0||B.isFramebufferTexture&&B.minFilter!==ci&&B.minFilter!==Si?Math.log2(Math.max(A.width,A.height))+1:B.mipmaps!==void 0&&B.mipmaps.length>0?B.mipmaps.length:B.isCompressedTexture&&Array.isArray(B.image)?A.mipmaps.length:1}function P(B){const A=B.target;A.removeEventListener("dispose",P),T(A),A.isVideoTexture&&_.delete(A)}function L(B){const A=B.target;A.removeEventListener("dispose",L),q(A)}function T(B){const A=a.get(B);if(A.__webglInit===void 0)return;const j=B.source,gt=g.get(j);if(gt){const vt=gt[A.__cacheKey];vt.usedTimes--,vt.usedTimes===0&&w(B),Object.keys(gt).length===0&&g.delete(j)}a.remove(B)}function w(B){const A=a.get(B);o.deleteTexture(A.__webglTexture);const j=B.source,gt=g.get(j);delete gt[A.__cacheKey],c.memory.textures--}function q(B){const A=a.get(B);if(B.depthTexture&&(B.depthTexture.dispose(),a.remove(B.depthTexture)),B.isWebGLCubeRenderTarget)for(let gt=0;gt<6;gt++){if(Array.isArray(A.__webglFramebuffer[gt]))for(let vt=0;vt<A.__webglFramebuffer[gt].length;vt++)o.deleteFramebuffer(A.__webglFramebuffer[gt][vt]);else o.deleteFramebuffer(A.__webglFramebuffer[gt]);A.__webglDepthbuffer&&o.deleteRenderbuffer(A.__webglDepthbuffer[gt])}else{if(Array.isArray(A.__webglFramebuffer))for(let gt=0;gt<A.__webglFramebuffer.length;gt++)o.deleteFramebuffer(A.__webglFramebuffer[gt]);else o.deleteFramebuffer(A.__webglFramebuffer);if(A.__webglDepthbuffer&&o.deleteRenderbuffer(A.__webglDepthbuffer),A.__webglMultisampledFramebuffer&&o.deleteFramebuffer(A.__webglMultisampledFramebuffer),A.__webglColorRenderbuffer)for(let gt=0;gt<A.__webglColorRenderbuffer.length;gt++)A.__webglColorRenderbuffer[gt]&&o.deleteRenderbuffer(A.__webglColorRenderbuffer[gt]);A.__webglDepthRenderbuffer&&o.deleteRenderbuffer(A.__webglDepthRenderbuffer)}const j=B.textures;for(let gt=0,vt=j.length;gt<vt;gt++){const dt=a.get(j[gt]);dt.__webglTexture&&(o.deleteTexture(dt.__webglTexture),c.memory.textures--),a.remove(j[gt])}a.remove(B)}let G=0;function k(){G=0}function J(){const B=G;return B>=r.maxTextures&&Me("WebGLTextures: Trying to use "+B+" texture units while this GPU supports only "+r.maxTextures),G+=1,B}function et(B){const A=[];return A.push(B.wrapS),A.push(B.wrapT),A.push(B.wrapR||0),A.push(B.magFilter),A.push(B.minFilter),A.push(B.anisotropy),A.push(B.internalFormat),A.push(B.format),A.push(B.type),A.push(B.generateMipmaps),A.push(B.premultiplyAlpha),A.push(B.flipY),A.push(B.unpackAlignment),A.push(B.colorSpace),A.join()}function Q(B,A){const j=a.get(B);if(B.isVideoTexture&&Ee(B),B.isRenderTargetTexture===!1&&B.isExternalTexture!==!0&&B.version>0&&j.__version!==B.version){const gt=B.image;if(gt===null)Me("WebGLRenderer: Texture marked for update but no image data found.");else if(gt.complete===!1)Me("WebGLRenderer: Texture marked for update but image is incomplete");else{nt(j,B,A);return}}else B.isExternalTexture&&(j.__webglTexture=B.sourceTexture?B.sourceTexture:null);n.bindTexture(o.TEXTURE_2D,j.__webglTexture,o.TEXTURE0+A)}function F(B,A){const j=a.get(B);if(B.isRenderTargetTexture===!1&&B.version>0&&j.__version!==B.version){nt(j,B,A);return}else B.isExternalTexture&&(j.__webglTexture=B.sourceTexture?B.sourceTexture:null);n.bindTexture(o.TEXTURE_2D_ARRAY,j.__webglTexture,o.TEXTURE0+A)}function I(B,A){const j=a.get(B);if(B.isRenderTargetTexture===!1&&B.version>0&&j.__version!==B.version){nt(j,B,A);return}n.bindTexture(o.TEXTURE_3D,j.__webglTexture,o.TEXTURE0+A)}function it(B,A){const j=a.get(B);if(B.isCubeDepthTexture!==!0&&B.version>0&&j.__version!==B.version){_t(j,B,A);return}n.bindTexture(o.TEXTURE_CUBE_MAP,j.__webglTexture,o.TEXTURE0+A)}const ht={[Y_]:o.REPEAT,[Kr]:o.CLAMP_TO_EDGE,[q_]:o.MIRRORED_REPEAT},H={[ci]:o.NEAREST,[$A]:o.NEAREST_MIPMAP_NEAREST,[ch]:o.NEAREST_MIPMAP_LINEAR,[Si]:o.LINEAR,[Wm]:o.LINEAR_MIPMAP_NEAREST,[wo]:o.LINEAR_MIPMAP_LINEAR},z={[iR]:o.NEVER,[lR]:o.ALWAYS,[aR]:o.LESS,[lg]:o.LEQUAL,[rR]:o.EQUAL,[ug]:o.GEQUAL,[sR]:o.GREATER,[oR]:o.NOTEQUAL};function K(B,A){if(A.type===dr&&t.has("OES_texture_float_linear")===!1&&(A.magFilter===Si||A.magFilter===Wm||A.magFilter===ch||A.magFilter===wo||A.minFilter===Si||A.minFilter===Wm||A.minFilter===ch||A.minFilter===wo)&&Me("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),o.texParameteri(B,o.TEXTURE_WRAP_S,ht[A.wrapS]),o.texParameteri(B,o.TEXTURE_WRAP_T,ht[A.wrapT]),(B===o.TEXTURE_3D||B===o.TEXTURE_2D_ARRAY)&&o.texParameteri(B,o.TEXTURE_WRAP_R,ht[A.wrapR]),o.texParameteri(B,o.TEXTURE_MAG_FILTER,H[A.magFilter]),o.texParameteri(B,o.TEXTURE_MIN_FILTER,H[A.minFilter]),A.compareFunction&&(o.texParameteri(B,o.TEXTURE_COMPARE_MODE,o.COMPARE_REF_TO_TEXTURE),o.texParameteri(B,o.TEXTURE_COMPARE_FUNC,z[A.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(A.magFilter===ci||A.minFilter!==ch&&A.minFilter!==wo||A.type===dr&&t.has("OES_texture_float_linear")===!1)return;if(A.anisotropy>1||a.get(A).__currentAnisotropy){const j=t.get("EXT_texture_filter_anisotropic");o.texParameterf(B,j.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(A.anisotropy,r.getMaxAnisotropy())),a.get(A).__currentAnisotropy=A.anisotropy}}}function xt(B,A){let j=!1;B.__webglInit===void 0&&(B.__webglInit=!0,A.addEventListener("dispose",P));const gt=A.source;let vt=g.get(gt);vt===void 0&&(vt={},g.set(gt,vt));const dt=et(A);if(dt!==B.__cacheKey){vt[dt]===void 0&&(vt[dt]={texture:o.createTexture(),usedTimes:0},c.memory.textures++,j=!0),vt[dt].usedTimes++;const Gt=vt[B.__cacheKey];Gt!==void 0&&(vt[B.__cacheKey].usedTimes--,Gt.usedTimes===0&&w(A)),B.__cacheKey=dt,B.__webglTexture=vt[dt].texture}return j}function Tt(B,A,j){return Math.floor(Math.floor(B/j)/A)}function Ut(B,A,j,gt){const dt=B.updateRanges;if(dt.length===0)n.texSubImage2D(o.TEXTURE_2D,0,0,0,A.width,A.height,j,gt,A.data);else{dt.sort((Rt,At)=>Rt.start-At.start);let Gt=0;for(let Rt=1;Rt<dt.length;Rt++){const At=dt[Gt],Ht=dt[Rt],Pt=At.start+At.count,zt=Tt(Ht.start,A.width,4),pe=Tt(At.start,A.width,4);Ht.start<=Pt+1&&zt===pe&&Tt(Ht.start+Ht.count-1,A.width,4)===zt?At.count=Math.max(At.count,Ht.start+Ht.count-At.start):(++Gt,dt[Gt]=Ht)}dt.length=Gt+1;const wt=o.getParameter(o.UNPACK_ROW_LENGTH),ie=o.getParameter(o.UNPACK_SKIP_PIXELS),Yt=o.getParameter(o.UNPACK_SKIP_ROWS);o.pixelStorei(o.UNPACK_ROW_LENGTH,A.width);for(let Rt=0,At=dt.length;Rt<At;Rt++){const Ht=dt[Rt],Pt=Math.floor(Ht.start/4),zt=Math.ceil(Ht.count/4),pe=Pt%A.width,V=Math.floor(Pt/A.width),Dt=zt,Ct=1;o.pixelStorei(o.UNPACK_SKIP_PIXELS,pe),o.pixelStorei(o.UNPACK_SKIP_ROWS,V),n.texSubImage2D(o.TEXTURE_2D,0,pe,V,Dt,Ct,j,gt,A.data)}B.clearUpdateRanges(),o.pixelStorei(o.UNPACK_ROW_LENGTH,wt),o.pixelStorei(o.UNPACK_SKIP_PIXELS,ie),o.pixelStorei(o.UNPACK_SKIP_ROWS,Yt)}}function nt(B,A,j){let gt=o.TEXTURE_2D;(A.isDataArrayTexture||A.isCompressedArrayTexture)&&(gt=o.TEXTURE_2D_ARRAY),A.isData3DTexture&&(gt=o.TEXTURE_3D);const vt=xt(B,A),dt=A.source;n.bindTexture(gt,B.__webglTexture,o.TEXTURE0+j);const Gt=a.get(dt);if(dt.version!==Gt.__version||vt===!0){n.activeTexture(o.TEXTURE0+j);const wt=Ye.getPrimaries(Ye.workingColorSpace),ie=A.colorSpace===Fs?null:Ye.getPrimaries(A.colorSpace),Yt=A.colorSpace===Fs||wt===ie?o.NONE:o.BROWSER_DEFAULT_WEBGL;o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,A.flipY),o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),o.pixelStorei(o.UNPACK_ALIGNMENT,A.unpackAlignment),o.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,Yt);let Rt=E(A.image,!1,r.maxTextureSize);Rt=ce(A,Rt);const At=l.convert(A.format,A.colorSpace),Ht=l.convert(A.type);let Pt=U(A.internalFormat,At,Ht,A.colorSpace,A.isVideoTexture);K(gt,A);let zt;const pe=A.mipmaps,V=A.isVideoTexture!==!0,Dt=Gt.__version===void 0||vt===!0,Ct=dt.dataReady,Lt=O(A,Rt);if(A.isDepthTexture)Pt=C(A.format===Do,A.type),Dt&&(V?n.texStorage2D(o.TEXTURE_2D,1,Pt,Rt.width,Rt.height):n.texImage2D(o.TEXTURE_2D,0,Pt,Rt.width,Rt.height,0,At,Ht,null));else if(A.isDataTexture)if(pe.length>0){V&&Dt&&n.texStorage2D(o.TEXTURE_2D,Lt,Pt,pe[0].width,pe[0].height);for(let bt=0,mt=pe.length;bt<mt;bt++)zt=pe[bt],V?Ct&&n.texSubImage2D(o.TEXTURE_2D,bt,0,0,zt.width,zt.height,At,Ht,zt.data):n.texImage2D(o.TEXTURE_2D,bt,Pt,zt.width,zt.height,0,At,Ht,zt.data);A.generateMipmaps=!1}else V?(Dt&&n.texStorage2D(o.TEXTURE_2D,Lt,Pt,Rt.width,Rt.height),Ct&&Ut(A,Rt,At,Ht)):n.texImage2D(o.TEXTURE_2D,0,Pt,Rt.width,Rt.height,0,At,Ht,Rt.data);else if(A.isCompressedTexture)if(A.isCompressedArrayTexture){V&&Dt&&n.texStorage3D(o.TEXTURE_2D_ARRAY,Lt,Pt,pe[0].width,pe[0].height,Rt.depth);for(let bt=0,mt=pe.length;bt<mt;bt++)if(zt=pe[bt],A.format!==Ja)if(At!==null)if(V){if(Ct)if(A.layerUpdates.size>0){const Xt=tM(zt.width,zt.height,A.format,A.type);for(const le of A.layerUpdates){const Ge=zt.data.subarray(le*Xt/zt.data.BYTES_PER_ELEMENT,(le+1)*Xt/zt.data.BYTES_PER_ELEMENT);n.compressedTexSubImage3D(o.TEXTURE_2D_ARRAY,bt,0,0,le,zt.width,zt.height,1,At,Ge)}A.clearLayerUpdates()}else n.compressedTexSubImage3D(o.TEXTURE_2D_ARRAY,bt,0,0,0,zt.width,zt.height,Rt.depth,At,zt.data)}else n.compressedTexImage3D(o.TEXTURE_2D_ARRAY,bt,Pt,zt.width,zt.height,Rt.depth,0,zt.data,0,0);else Me("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else V?Ct&&n.texSubImage3D(o.TEXTURE_2D_ARRAY,bt,0,0,0,zt.width,zt.height,Rt.depth,At,Ht,zt.data):n.texImage3D(o.TEXTURE_2D_ARRAY,bt,Pt,zt.width,zt.height,Rt.depth,0,At,Ht,zt.data)}else{V&&Dt&&n.texStorage2D(o.TEXTURE_2D,Lt,Pt,pe[0].width,pe[0].height);for(let bt=0,mt=pe.length;bt<mt;bt++)zt=pe[bt],A.format!==Ja?At!==null?V?Ct&&n.compressedTexSubImage2D(o.TEXTURE_2D,bt,0,0,zt.width,zt.height,At,zt.data):n.compressedTexImage2D(o.TEXTURE_2D,bt,Pt,zt.width,zt.height,0,zt.data):Me("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):V?Ct&&n.texSubImage2D(o.TEXTURE_2D,bt,0,0,zt.width,zt.height,At,Ht,zt.data):n.texImage2D(o.TEXTURE_2D,bt,Pt,zt.width,zt.height,0,At,Ht,zt.data)}else if(A.isDataArrayTexture)if(V){if(Dt&&n.texStorage3D(o.TEXTURE_2D_ARRAY,Lt,Pt,Rt.width,Rt.height,Rt.depth),Ct)if(A.layerUpdates.size>0){const bt=tM(Rt.width,Rt.height,A.format,A.type);for(const mt of A.layerUpdates){const Xt=Rt.data.subarray(mt*bt/Rt.data.BYTES_PER_ELEMENT,(mt+1)*bt/Rt.data.BYTES_PER_ELEMENT);n.texSubImage3D(o.TEXTURE_2D_ARRAY,0,0,0,mt,Rt.width,Rt.height,1,At,Ht,Xt)}A.clearLayerUpdates()}else n.texSubImage3D(o.TEXTURE_2D_ARRAY,0,0,0,0,Rt.width,Rt.height,Rt.depth,At,Ht,Rt.data)}else n.texImage3D(o.TEXTURE_2D_ARRAY,0,Pt,Rt.width,Rt.height,Rt.depth,0,At,Ht,Rt.data);else if(A.isData3DTexture)V?(Dt&&n.texStorage3D(o.TEXTURE_3D,Lt,Pt,Rt.width,Rt.height,Rt.depth),Ct&&n.texSubImage3D(o.TEXTURE_3D,0,0,0,0,Rt.width,Rt.height,Rt.depth,At,Ht,Rt.data)):n.texImage3D(o.TEXTURE_3D,0,Pt,Rt.width,Rt.height,Rt.depth,0,At,Ht,Rt.data);else if(A.isFramebufferTexture){if(Dt)if(V)n.texStorage2D(o.TEXTURE_2D,Lt,Pt,Rt.width,Rt.height);else{let bt=Rt.width,mt=Rt.height;for(let Xt=0;Xt<Lt;Xt++)n.texImage2D(o.TEXTURE_2D,Xt,Pt,bt,mt,0,At,Ht,null),bt>>=1,mt>>=1}}else if(pe.length>0){if(V&&Dt){const bt=Wt(pe[0]);n.texStorage2D(o.TEXTURE_2D,Lt,Pt,bt.width,bt.height)}for(let bt=0,mt=pe.length;bt<mt;bt++)zt=pe[bt],V?Ct&&n.texSubImage2D(o.TEXTURE_2D,bt,0,0,At,Ht,zt):n.texImage2D(o.TEXTURE_2D,bt,Pt,At,Ht,zt);A.generateMipmaps=!1}else if(V){if(Dt){const bt=Wt(Rt);n.texStorage2D(o.TEXTURE_2D,Lt,Pt,bt.width,bt.height)}Ct&&n.texSubImage2D(o.TEXTURE_2D,0,0,0,At,Ht,Rt)}else n.texImage2D(o.TEXTURE_2D,0,Pt,At,Ht,Rt);y(A)&&S(gt),Gt.__version=dt.version,A.onUpdate&&A.onUpdate(A)}B.__version=A.version}function _t(B,A,j){if(A.image.length!==6)return;const gt=xt(B,A),vt=A.source;n.bindTexture(o.TEXTURE_CUBE_MAP,B.__webglTexture,o.TEXTURE0+j);const dt=a.get(vt);if(vt.version!==dt.__version||gt===!0){n.activeTexture(o.TEXTURE0+j);const Gt=Ye.getPrimaries(Ye.workingColorSpace),wt=A.colorSpace===Fs?null:Ye.getPrimaries(A.colorSpace),ie=A.colorSpace===Fs||Gt===wt?o.NONE:o.BROWSER_DEFAULT_WEBGL;o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,A.flipY),o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),o.pixelStorei(o.UNPACK_ALIGNMENT,A.unpackAlignment),o.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,ie);const Yt=A.isCompressedTexture||A.image[0].isCompressedTexture,Rt=A.image[0]&&A.image[0].isDataTexture,At=[];for(let mt=0;mt<6;mt++)!Yt&&!Rt?At[mt]=E(A.image[mt],!0,r.maxCubemapSize):At[mt]=Rt?A.image[mt].image:A.image[mt],At[mt]=ce(A,At[mt]);const Ht=At[0],Pt=l.convert(A.format,A.colorSpace),zt=l.convert(A.type),pe=U(A.internalFormat,Pt,zt,A.colorSpace),V=A.isVideoTexture!==!0,Dt=dt.__version===void 0||gt===!0,Ct=vt.dataReady;let Lt=O(A,Ht);K(o.TEXTURE_CUBE_MAP,A);let bt;if(Yt){V&&Dt&&n.texStorage2D(o.TEXTURE_CUBE_MAP,Lt,pe,Ht.width,Ht.height);for(let mt=0;mt<6;mt++){bt=At[mt].mipmaps;for(let Xt=0;Xt<bt.length;Xt++){const le=bt[Xt];A.format!==Ja?Pt!==null?V?Ct&&n.compressedTexSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+mt,Xt,0,0,le.width,le.height,Pt,le.data):n.compressedTexImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+mt,Xt,pe,le.width,le.height,0,le.data):Me("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):V?Ct&&n.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+mt,Xt,0,0,le.width,le.height,Pt,zt,le.data):n.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+mt,Xt,pe,le.width,le.height,0,Pt,zt,le.data)}}}else{if(bt=A.mipmaps,V&&Dt){bt.length>0&&Lt++;const mt=Wt(At[0]);n.texStorage2D(o.TEXTURE_CUBE_MAP,Lt,pe,mt.width,mt.height)}for(let mt=0;mt<6;mt++)if(Rt){V?Ct&&n.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+mt,0,0,0,At[mt].width,At[mt].height,Pt,zt,At[mt].data):n.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+mt,0,pe,At[mt].width,At[mt].height,0,Pt,zt,At[mt].data);for(let Xt=0;Xt<bt.length;Xt++){const Ge=bt[Xt].image[mt].image;V?Ct&&n.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+mt,Xt+1,0,0,Ge.width,Ge.height,Pt,zt,Ge.data):n.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+mt,Xt+1,pe,Ge.width,Ge.height,0,Pt,zt,Ge.data)}}else{V?Ct&&n.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+mt,0,0,0,Pt,zt,At[mt]):n.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+mt,0,pe,Pt,zt,At[mt]);for(let Xt=0;Xt<bt.length;Xt++){const le=bt[Xt];V?Ct&&n.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+mt,Xt+1,0,0,Pt,zt,le.image[mt]):n.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+mt,Xt+1,pe,Pt,zt,le.image[mt])}}}y(A)&&S(o.TEXTURE_CUBE_MAP),dt.__version=vt.version,A.onUpdate&&A.onUpdate(A)}B.__version=A.version}function Et(B,A,j,gt,vt,dt){const Gt=l.convert(j.format,j.colorSpace),wt=l.convert(j.type),ie=U(j.internalFormat,Gt,wt,j.colorSpace),Yt=a.get(A),Rt=a.get(j);if(Rt.__renderTarget=A,!Yt.__hasExternalTextures){const At=Math.max(1,A.width>>dt),Ht=Math.max(1,A.height>>dt);vt===o.TEXTURE_3D||vt===o.TEXTURE_2D_ARRAY?n.texImage3D(vt,dt,ie,At,Ht,A.depth,0,Gt,wt,null):n.texImage2D(vt,dt,ie,At,Ht,0,Gt,wt,null)}n.bindFramebuffer(o.FRAMEBUFFER,B),We(A)?f.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,gt,vt,Rt.__webglTexture,0,W(A)):(vt===o.TEXTURE_2D||vt>=o.TEXTURE_CUBE_MAP_POSITIVE_X&&vt<=o.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&o.framebufferTexture2D(o.FRAMEBUFFER,gt,vt,Rt.__webglTexture,dt),n.bindFramebuffer(o.FRAMEBUFFER,null)}function Ft(B,A,j){if(o.bindRenderbuffer(o.RENDERBUFFER,B),A.depthBuffer){const gt=A.depthTexture,vt=gt&&gt.isDepthTexture?gt.type:null,dt=C(A.stencilBuffer,vt),Gt=A.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT;We(A)?f.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,W(A),dt,A.width,A.height):j?o.renderbufferStorageMultisample(o.RENDERBUFFER,W(A),dt,A.width,A.height):o.renderbufferStorage(o.RENDERBUFFER,dt,A.width,A.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,Gt,o.RENDERBUFFER,B)}else{const gt=A.textures;for(let vt=0;vt<gt.length;vt++){const dt=gt[vt],Gt=l.convert(dt.format,dt.colorSpace),wt=l.convert(dt.type),ie=U(dt.internalFormat,Gt,wt,dt.colorSpace);We(A)?f.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,W(A),ie,A.width,A.height):j?o.renderbufferStorageMultisample(o.RENDERBUFFER,W(A),ie,A.width,A.height):o.renderbufferStorage(o.RENDERBUFFER,ie,A.width,A.height)}}o.bindRenderbuffer(o.RENDERBUFFER,null)}function ee(B,A,j){const gt=A.isWebGLCubeRenderTarget===!0;if(n.bindFramebuffer(o.FRAMEBUFFER,B),!(A.depthTexture&&A.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const vt=a.get(A.depthTexture);if(vt.__renderTarget=A,(!vt.__webglTexture||A.depthTexture.image.width!==A.width||A.depthTexture.image.height!==A.height)&&(A.depthTexture.image.width=A.width,A.depthTexture.image.height=A.height,A.depthTexture.needsUpdate=!0),gt){if(vt.__webglInit===void 0&&(vt.__webglInit=!0,A.depthTexture.addEventListener("dispose",P)),vt.__webglTexture===void 0){vt.__webglTexture=o.createTexture(),n.bindTexture(o.TEXTURE_CUBE_MAP,vt.__webglTexture),K(o.TEXTURE_CUBE_MAP,A.depthTexture);const Yt=l.convert(A.depthTexture.format),Rt=l.convert(A.depthTexture.type);let At;A.depthTexture.format===ns?At=o.DEPTH_COMPONENT24:A.depthTexture.format===Do&&(At=o.DEPTH24_STENCIL8);for(let Ht=0;Ht<6;Ht++)o.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+Ht,0,At,A.width,A.height,0,Yt,Rt,null)}}else Q(A.depthTexture,0);const dt=vt.__webglTexture,Gt=W(A),wt=gt?o.TEXTURE_CUBE_MAP_POSITIVE_X+j:o.TEXTURE_2D,ie=A.depthTexture.format===Do?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT;if(A.depthTexture.format===ns)We(A)?f.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,ie,wt,dt,0,Gt):o.framebufferTexture2D(o.FRAMEBUFFER,ie,wt,dt,0);else if(A.depthTexture.format===Do)We(A)?f.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,ie,wt,dt,0,Gt):o.framebufferTexture2D(o.FRAMEBUFFER,ie,wt,dt,0);else throw new Error("Unknown depthTexture format")}function Kt(B){const A=a.get(B),j=B.isWebGLCubeRenderTarget===!0;if(A.__boundDepthTexture!==B.depthTexture){const gt=B.depthTexture;if(A.__depthDisposeCallback&&A.__depthDisposeCallback(),gt){const vt=()=>{delete A.__boundDepthTexture,delete A.__depthDisposeCallback,gt.removeEventListener("dispose",vt)};gt.addEventListener("dispose",vt),A.__depthDisposeCallback=vt}A.__boundDepthTexture=gt}if(B.depthTexture&&!A.__autoAllocateDepthBuffer)if(j)for(let gt=0;gt<6;gt++)ee(A.__webglFramebuffer[gt],B,gt);else{const gt=B.texture.mipmaps;gt&&gt.length>0?ee(A.__webglFramebuffer[0],B,0):ee(A.__webglFramebuffer,B,0)}else if(j){A.__webglDepthbuffer=[];for(let gt=0;gt<6;gt++)if(n.bindFramebuffer(o.FRAMEBUFFER,A.__webglFramebuffer[gt]),A.__webglDepthbuffer[gt]===void 0)A.__webglDepthbuffer[gt]=o.createRenderbuffer(),Ft(A.__webglDepthbuffer[gt],B,!1);else{const vt=B.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,dt=A.__webglDepthbuffer[gt];o.bindRenderbuffer(o.RENDERBUFFER,dt),o.framebufferRenderbuffer(o.FRAMEBUFFER,vt,o.RENDERBUFFER,dt)}}else{const gt=B.texture.mipmaps;if(gt&&gt.length>0?n.bindFramebuffer(o.FRAMEBUFFER,A.__webglFramebuffer[0]):n.bindFramebuffer(o.FRAMEBUFFER,A.__webglFramebuffer),A.__webglDepthbuffer===void 0)A.__webglDepthbuffer=o.createRenderbuffer(),Ft(A.__webglDepthbuffer,B,!1);else{const vt=B.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,dt=A.__webglDepthbuffer;o.bindRenderbuffer(o.RENDERBUFFER,dt),o.framebufferRenderbuffer(o.FRAMEBUFFER,vt,o.RENDERBUFFER,dt)}}n.bindFramebuffer(o.FRAMEBUFFER,null)}function Ne(B,A,j){const gt=a.get(B);A!==void 0&&Et(gt.__webglFramebuffer,B,B.texture,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,0),j!==void 0&&Kt(B)}function qt(B){const A=B.texture,j=a.get(B),gt=a.get(A);B.addEventListener("dispose",L);const vt=B.textures,dt=B.isWebGLCubeRenderTarget===!0,Gt=vt.length>1;if(Gt||(gt.__webglTexture===void 0&&(gt.__webglTexture=o.createTexture()),gt.__version=A.version,c.memory.textures++),dt){j.__webglFramebuffer=[];for(let wt=0;wt<6;wt++)if(A.mipmaps&&A.mipmaps.length>0){j.__webglFramebuffer[wt]=[];for(let ie=0;ie<A.mipmaps.length;ie++)j.__webglFramebuffer[wt][ie]=o.createFramebuffer()}else j.__webglFramebuffer[wt]=o.createFramebuffer()}else{if(A.mipmaps&&A.mipmaps.length>0){j.__webglFramebuffer=[];for(let wt=0;wt<A.mipmaps.length;wt++)j.__webglFramebuffer[wt]=o.createFramebuffer()}else j.__webglFramebuffer=o.createFramebuffer();if(Gt)for(let wt=0,ie=vt.length;wt<ie;wt++){const Yt=a.get(vt[wt]);Yt.__webglTexture===void 0&&(Yt.__webglTexture=o.createTexture(),c.memory.textures++)}if(B.samples>0&&We(B)===!1){j.__webglMultisampledFramebuffer=o.createFramebuffer(),j.__webglColorRenderbuffer=[],n.bindFramebuffer(o.FRAMEBUFFER,j.__webglMultisampledFramebuffer);for(let wt=0;wt<vt.length;wt++){const ie=vt[wt];j.__webglColorRenderbuffer[wt]=o.createRenderbuffer(),o.bindRenderbuffer(o.RENDERBUFFER,j.__webglColorRenderbuffer[wt]);const Yt=l.convert(ie.format,ie.colorSpace),Rt=l.convert(ie.type),At=U(ie.internalFormat,Yt,Rt,ie.colorSpace,B.isXRRenderTarget===!0),Ht=W(B);o.renderbufferStorageMultisample(o.RENDERBUFFER,Ht,At,B.width,B.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+wt,o.RENDERBUFFER,j.__webglColorRenderbuffer[wt])}o.bindRenderbuffer(o.RENDERBUFFER,null),B.depthBuffer&&(j.__webglDepthRenderbuffer=o.createRenderbuffer(),Ft(j.__webglDepthRenderbuffer,B,!0)),n.bindFramebuffer(o.FRAMEBUFFER,null)}}if(dt){n.bindTexture(o.TEXTURE_CUBE_MAP,gt.__webglTexture),K(o.TEXTURE_CUBE_MAP,A);for(let wt=0;wt<6;wt++)if(A.mipmaps&&A.mipmaps.length>0)for(let ie=0;ie<A.mipmaps.length;ie++)Et(j.__webglFramebuffer[wt][ie],B,A,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+wt,ie);else Et(j.__webglFramebuffer[wt],B,A,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+wt,0);y(A)&&S(o.TEXTURE_CUBE_MAP),n.unbindTexture()}else if(Gt){for(let wt=0,ie=vt.length;wt<ie;wt++){const Yt=vt[wt],Rt=a.get(Yt);let At=o.TEXTURE_2D;(B.isWebGL3DRenderTarget||B.isWebGLArrayRenderTarget)&&(At=B.isWebGL3DRenderTarget?o.TEXTURE_3D:o.TEXTURE_2D_ARRAY),n.bindTexture(At,Rt.__webglTexture),K(At,Yt),Et(j.__webglFramebuffer,B,Yt,o.COLOR_ATTACHMENT0+wt,At,0),y(Yt)&&S(At)}n.unbindTexture()}else{let wt=o.TEXTURE_2D;if((B.isWebGL3DRenderTarget||B.isWebGLArrayRenderTarget)&&(wt=B.isWebGL3DRenderTarget?o.TEXTURE_3D:o.TEXTURE_2D_ARRAY),n.bindTexture(wt,gt.__webglTexture),K(wt,A),A.mipmaps&&A.mipmaps.length>0)for(let ie=0;ie<A.mipmaps.length;ie++)Et(j.__webglFramebuffer[ie],B,A,o.COLOR_ATTACHMENT0,wt,ie);else Et(j.__webglFramebuffer,B,A,o.COLOR_ATTACHMENT0,wt,0);y(A)&&S(wt),n.unbindTexture()}B.depthBuffer&&Kt(B)}function re(B){const A=B.textures;for(let j=0,gt=A.length;j<gt;j++){const vt=A[j];if(y(vt)){const dt=R(B),Gt=a.get(vt).__webglTexture;n.bindTexture(dt,Gt),S(dt),n.unbindTexture()}}}const _e=[],se=[];function lt(B){if(B.samples>0){if(We(B)===!1){const A=B.textures,j=B.width,gt=B.height;let vt=o.COLOR_BUFFER_BIT;const dt=B.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,Gt=a.get(B),wt=A.length>1;if(wt)for(let Yt=0;Yt<A.length;Yt++)n.bindFramebuffer(o.FRAMEBUFFER,Gt.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Yt,o.RENDERBUFFER,null),n.bindFramebuffer(o.FRAMEBUFFER,Gt.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+Yt,o.TEXTURE_2D,null,0);n.bindFramebuffer(o.READ_FRAMEBUFFER,Gt.__webglMultisampledFramebuffer);const ie=B.texture.mipmaps;ie&&ie.length>0?n.bindFramebuffer(o.DRAW_FRAMEBUFFER,Gt.__webglFramebuffer[0]):n.bindFramebuffer(o.DRAW_FRAMEBUFFER,Gt.__webglFramebuffer);for(let Yt=0;Yt<A.length;Yt++){if(B.resolveDepthBuffer&&(B.depthBuffer&&(vt|=o.DEPTH_BUFFER_BIT),B.stencilBuffer&&B.resolveStencilBuffer&&(vt|=o.STENCIL_BUFFER_BIT)),wt){o.framebufferRenderbuffer(o.READ_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.RENDERBUFFER,Gt.__webglColorRenderbuffer[Yt]);const Rt=a.get(A[Yt]).__webglTexture;o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,Rt,0)}o.blitFramebuffer(0,0,j,gt,0,0,j,gt,vt,o.NEAREST),p===!0&&(_e.length=0,se.length=0,_e.push(o.COLOR_ATTACHMENT0+Yt),B.depthBuffer&&B.resolveDepthBuffer===!1&&(_e.push(dt),se.push(dt),o.invalidateFramebuffer(o.DRAW_FRAMEBUFFER,se)),o.invalidateFramebuffer(o.READ_FRAMEBUFFER,_e))}if(n.bindFramebuffer(o.READ_FRAMEBUFFER,null),n.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),wt)for(let Yt=0;Yt<A.length;Yt++){n.bindFramebuffer(o.FRAMEBUFFER,Gt.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Yt,o.RENDERBUFFER,Gt.__webglColorRenderbuffer[Yt]);const Rt=a.get(A[Yt]).__webglTexture;n.bindFramebuffer(o.FRAMEBUFFER,Gt.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+Yt,o.TEXTURE_2D,Rt,0)}n.bindFramebuffer(o.DRAW_FRAMEBUFFER,Gt.__webglMultisampledFramebuffer)}else if(B.depthBuffer&&B.resolveDepthBuffer===!1&&p){const A=B.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT;o.invalidateFramebuffer(o.DRAW_FRAMEBUFFER,[A])}}}function W(B){return Math.min(r.maxSamples,B.samples)}function We(B){const A=a.get(B);return B.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&A.__useRenderToTexture!==!1}function Ee(B){const A=c.render.frame;_.get(B)!==A&&(_.set(B,A),B.update())}function ce(B,A){const j=B.colorSpace,gt=B.format,vt=B.type;return B.isCompressedTexture===!0||B.isVideoTexture===!0||j!==iu&&j!==Fs&&(Ye.getTransfer(j)===an?(gt!==Ja||vt!==Fa)&&Me("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Qe("WebGLTextures: Unsupported texture color space:",j)),A}function Wt(B){return typeof HTMLImageElement<"u"&&B instanceof HTMLImageElement?(d.width=B.naturalWidth||B.width,d.height=B.naturalHeight||B.height):typeof VideoFrame<"u"&&B instanceof VideoFrame?(d.width=B.displayWidth,d.height=B.displayHeight):(d.width=B.width,d.height=B.height),d}this.allocateTextureUnit=J,this.resetTextureUnits=k,this.setTexture2D=Q,this.setTexture2DArray=F,this.setTexture3D=I,this.setTextureCube=it,this.rebindTextures=Ne,this.setupRenderTarget=qt,this.updateRenderTargetMipmap=re,this.updateMultisampleRenderTarget=lt,this.setupDepthRenderbuffer=Kt,this.setupFrameBufferTexture=Et,this.useMultisampledRTT=We,this.isReversedDepthBuffer=function(){return n.buffers.depth.getReversed()}}function ND(o,t){function n(a,r=Fs){let l;const c=Ye.getTransfer(r);if(a===Fa)return o.UNSIGNED_BYTE;if(a===ig)return o.UNSIGNED_SHORT_4_4_4_4;if(a===ag)return o.UNSIGNED_SHORT_5_5_5_1;if(a===S1)return o.UNSIGNED_INT_5_9_9_9_REV;if(a===M1)return o.UNSIGNED_INT_10F_11F_11F_REV;if(a===x1)return o.BYTE;if(a===y1)return o.SHORT;if(a===zc)return o.UNSIGNED_SHORT;if(a===ng)return o.INT;if(a===Sr)return o.UNSIGNED_INT;if(a===dr)return o.FLOAT;if(a===es)return o.HALF_FLOAT;if(a===E1)return o.ALPHA;if(a===b1)return o.RGB;if(a===Ja)return o.RGBA;if(a===ns)return o.DEPTH_COMPONENT;if(a===Do)return o.DEPTH_STENCIL;if(a===T1)return o.RED;if(a===rg)return o.RED_INTEGER;if(a===nu)return o.RG;if(a===sg)return o.RG_INTEGER;if(a===og)return o.RGBA_INTEGER;if(a===Zh||a===Kh||a===Qh||a===Jh)if(c===an)if(l=t.get("WEBGL_compressed_texture_s3tc_srgb"),l!==null){if(a===Zh)return l.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(a===Kh)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(a===Qh)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(a===Jh)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(l=t.get("WEBGL_compressed_texture_s3tc"),l!==null){if(a===Zh)return l.COMPRESSED_RGB_S3TC_DXT1_EXT;if(a===Kh)return l.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(a===Qh)return l.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(a===Jh)return l.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(a===j_||a===Z_||a===K_||a===Q_)if(l=t.get("WEBGL_compressed_texture_pvrtc"),l!==null){if(a===j_)return l.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(a===Z_)return l.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(a===K_)return l.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(a===Q_)return l.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(a===J_||a===$_||a===t0||a===e0||a===n0||a===i0||a===a0)if(l=t.get("WEBGL_compressed_texture_etc"),l!==null){if(a===J_||a===$_)return c===an?l.COMPRESSED_SRGB8_ETC2:l.COMPRESSED_RGB8_ETC2;if(a===t0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:l.COMPRESSED_RGBA8_ETC2_EAC;if(a===e0)return l.COMPRESSED_R11_EAC;if(a===n0)return l.COMPRESSED_SIGNED_R11_EAC;if(a===i0)return l.COMPRESSED_RG11_EAC;if(a===a0)return l.COMPRESSED_SIGNED_RG11_EAC}else return null;if(a===r0||a===s0||a===o0||a===l0||a===u0||a===c0||a===f0||a===h0||a===d0||a===p0||a===m0||a===_0||a===g0||a===v0)if(l=t.get("WEBGL_compressed_texture_astc"),l!==null){if(a===r0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:l.COMPRESSED_RGBA_ASTC_4x4_KHR;if(a===s0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:l.COMPRESSED_RGBA_ASTC_5x4_KHR;if(a===o0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:l.COMPRESSED_RGBA_ASTC_5x5_KHR;if(a===l0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:l.COMPRESSED_RGBA_ASTC_6x5_KHR;if(a===u0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:l.COMPRESSED_RGBA_ASTC_6x6_KHR;if(a===c0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:l.COMPRESSED_RGBA_ASTC_8x5_KHR;if(a===f0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:l.COMPRESSED_RGBA_ASTC_8x6_KHR;if(a===h0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:l.COMPRESSED_RGBA_ASTC_8x8_KHR;if(a===d0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:l.COMPRESSED_RGBA_ASTC_10x5_KHR;if(a===p0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:l.COMPRESSED_RGBA_ASTC_10x6_KHR;if(a===m0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:l.COMPRESSED_RGBA_ASTC_10x8_KHR;if(a===_0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:l.COMPRESSED_RGBA_ASTC_10x10_KHR;if(a===g0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:l.COMPRESSED_RGBA_ASTC_12x10_KHR;if(a===v0)return c===an?l.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:l.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(a===x0||a===y0||a===S0)if(l=t.get("EXT_texture_compression_bptc"),l!==null){if(a===x0)return c===an?l.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:l.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(a===y0)return l.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(a===S0)return l.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(a===M0||a===E0||a===b0||a===T0)if(l=t.get("EXT_texture_compression_rgtc"),l!==null){if(a===M0)return l.COMPRESSED_RED_RGTC1_EXT;if(a===E0)return l.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(a===b0)return l.COMPRESSED_RED_GREEN_RGTC2_EXT;if(a===T0)return l.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return a===Ic?o.UNSIGNED_INT_24_8:o[a]!==void 0?o[a]:null}return{convert:n}}const LD=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,OD=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class PD{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,n){if(this.texture===null){const a=new P1(t.texture);(t.depthNear!==n.depthNear||t.depthFar!==n.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=a}}getMesh(t){if(this.texture!==null&&this.mesh===null){const n=t.cameras[0].viewport,a=new Ga({vertexShader:LD,fragmentShader:OD,uniforms:{depthColor:{value:this.texture},depthWidth:{value:n.z},depthHeight:{value:n.w}}});this.mesh=new $a(new Rd(20,20),a)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class FD extends hu{constructor(t,n){super();const a=this;let r=null,l=1,c=null,f="local-floor",p=1,d=null,_=null,v=null,g=null,x=null,M=null;const E=typeof XRWebGLBinding<"u",y=new PD,S={},R=n.getContextAttributes();let U=null,C=null;const O=[],P=[],L=new fn;let T=null;const w=new La;w.viewport=new Pn;const q=new La;q.viewport=new Pn;const G=[w,q],k=new jR;let J=null,et=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(nt){let _t=O[nt];return _t===void 0&&(_t=new $m,O[nt]=_t),_t.getTargetRaySpace()},this.getControllerGrip=function(nt){let _t=O[nt];return _t===void 0&&(_t=new $m,O[nt]=_t),_t.getGripSpace()},this.getHand=function(nt){let _t=O[nt];return _t===void 0&&(_t=new $m,O[nt]=_t),_t.getHandSpace()};function Q(nt){const _t=P.indexOf(nt.inputSource);if(_t===-1)return;const Et=O[_t];Et!==void 0&&(Et.update(nt.inputSource,nt.frame,d||c),Et.dispatchEvent({type:nt.type,data:nt.inputSource}))}function F(){r.removeEventListener("select",Q),r.removeEventListener("selectstart",Q),r.removeEventListener("selectend",Q),r.removeEventListener("squeeze",Q),r.removeEventListener("squeezestart",Q),r.removeEventListener("squeezeend",Q),r.removeEventListener("end",F),r.removeEventListener("inputsourceschange",I);for(let nt=0;nt<O.length;nt++){const _t=P[nt];_t!==null&&(P[nt]=null,O[nt].disconnect(_t))}J=null,et=null,y.reset();for(const nt in S)delete S[nt];t.setRenderTarget(U),x=null,g=null,v=null,r=null,C=null,Ut.stop(),a.isPresenting=!1,t.setPixelRatio(T),t.setSize(L.width,L.height,!1),a.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(nt){l=nt,a.isPresenting===!0&&Me("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(nt){f=nt,a.isPresenting===!0&&Me("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return d||c},this.setReferenceSpace=function(nt){d=nt},this.getBaseLayer=function(){return g!==null?g:x},this.getBinding=function(){return v===null&&E&&(v=new XRWebGLBinding(r,n)),v},this.getFrame=function(){return M},this.getSession=function(){return r},this.setSession=async function(nt){if(r=nt,r!==null){if(U=t.getRenderTarget(),r.addEventListener("select",Q),r.addEventListener("selectstart",Q),r.addEventListener("selectend",Q),r.addEventListener("squeeze",Q),r.addEventListener("squeezestart",Q),r.addEventListener("squeezeend",Q),r.addEventListener("end",F),r.addEventListener("inputsourceschange",I),R.xrCompatible!==!0&&await n.makeXRCompatible(),T=t.getPixelRatio(),t.getSize(L),E&&"createProjectionLayer"in XRWebGLBinding.prototype){let Et=null,Ft=null,ee=null;R.depth&&(ee=R.stencil?n.DEPTH24_STENCIL8:n.DEPTH_COMPONENT24,Et=R.stencil?Do:ns,Ft=R.stencil?Ic:Sr);const Kt={colorFormat:n.RGBA8,depthFormat:ee,scaleFactor:l};v=this.getBinding(),g=v.createProjectionLayer(Kt),r.updateRenderState({layers:[g]}),t.setPixelRatio(1),t.setSize(g.textureWidth,g.textureHeight,!1),C=new vr(g.textureWidth,g.textureHeight,{format:Ja,type:Fa,depthTexture:new Bc(g.textureWidth,g.textureHeight,Ft,void 0,void 0,void 0,void 0,void 0,void 0,Et),stencilBuffer:R.stencil,colorSpace:t.outputColorSpace,samples:R.antialias?4:0,resolveDepthBuffer:g.ignoreDepthValues===!1,resolveStencilBuffer:g.ignoreDepthValues===!1})}else{const Et={antialias:R.antialias,alpha:!0,depth:R.depth,stencil:R.stencil,framebufferScaleFactor:l};x=new XRWebGLLayer(r,n,Et),r.updateRenderState({baseLayer:x}),t.setPixelRatio(1),t.setSize(x.framebufferWidth,x.framebufferHeight,!1),C=new vr(x.framebufferWidth,x.framebufferHeight,{format:Ja,type:Fa,colorSpace:t.outputColorSpace,stencilBuffer:R.stencil,resolveDepthBuffer:x.ignoreDepthValues===!1,resolveStencilBuffer:x.ignoreDepthValues===!1})}C.isXRRenderTarget=!0,this.setFoveation(p),d=null,c=await r.requestReferenceSpace(f),Ut.setContext(r),Ut.start(),a.isPresenting=!0,a.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return y.getDepthTexture()};function I(nt){for(let _t=0;_t<nt.removed.length;_t++){const Et=nt.removed[_t],Ft=P.indexOf(Et);Ft>=0&&(P[Ft]=null,O[Ft].disconnect(Et))}for(let _t=0;_t<nt.added.length;_t++){const Et=nt.added[_t];let Ft=P.indexOf(Et);if(Ft===-1){for(let Kt=0;Kt<O.length;Kt++)if(Kt>=P.length){P.push(Et),Ft=Kt;break}else if(P[Kt]===null){P[Kt]=Et,Ft=Kt;break}if(Ft===-1)break}const ee=O[Ft];ee&&ee.connect(Et)}}const it=new ft,ht=new ft;function H(nt,_t,Et){it.setFromMatrixPosition(_t.matrixWorld),ht.setFromMatrixPosition(Et.matrixWorld);const Ft=it.distanceTo(ht),ee=_t.projectionMatrix.elements,Kt=Et.projectionMatrix.elements,Ne=ee[14]/(ee[10]-1),qt=ee[14]/(ee[10]+1),re=(ee[9]+1)/ee[5],_e=(ee[9]-1)/ee[5],se=(ee[8]-1)/ee[0],lt=(Kt[8]+1)/Kt[0],W=Ne*se,We=Ne*lt,Ee=Ft/(-se+lt),ce=Ee*-se;if(_t.matrixWorld.decompose(nt.position,nt.quaternion,nt.scale),nt.translateX(ce),nt.translateZ(Ee),nt.matrixWorld.compose(nt.position,nt.quaternion,nt.scale),nt.matrixWorldInverse.copy(nt.matrixWorld).invert(),ee[10]===-1)nt.projectionMatrix.copy(_t.projectionMatrix),nt.projectionMatrixInverse.copy(_t.projectionMatrixInverse);else{const Wt=Ne+Ee,B=qt+Ee,A=W-ce,j=We+(Ft-ce),gt=re*qt/B*Wt,vt=_e*qt/B*Wt;nt.projectionMatrix.makePerspective(A,j,gt,vt,Wt,B),nt.projectionMatrixInverse.copy(nt.projectionMatrix).invert()}}function z(nt,_t){_t===null?nt.matrixWorld.copy(nt.matrix):nt.matrixWorld.multiplyMatrices(_t.matrixWorld,nt.matrix),nt.matrixWorldInverse.copy(nt.matrixWorld).invert()}this.updateCamera=function(nt){if(r===null)return;let _t=nt.near,Et=nt.far;y.texture!==null&&(y.depthNear>0&&(_t=y.depthNear),y.depthFar>0&&(Et=y.depthFar)),k.near=q.near=w.near=_t,k.far=q.far=w.far=Et,(J!==k.near||et!==k.far)&&(r.updateRenderState({depthNear:k.near,depthFar:k.far}),J=k.near,et=k.far),k.layers.mask=nt.layers.mask|6,w.layers.mask=k.layers.mask&-5,q.layers.mask=k.layers.mask&-3;const Ft=nt.parent,ee=k.cameras;z(k,Ft);for(let Kt=0;Kt<ee.length;Kt++)z(ee[Kt],Ft);ee.length===2?H(k,w,q):k.projectionMatrix.copy(w.projectionMatrix),K(nt,k,Ft)};function K(nt,_t,Et){Et===null?nt.matrix.copy(_t.matrixWorld):(nt.matrix.copy(Et.matrixWorld),nt.matrix.invert(),nt.matrix.multiply(_t.matrixWorld)),nt.matrix.decompose(nt.position,nt.quaternion,nt.scale),nt.updateMatrixWorld(!0),nt.projectionMatrix.copy(_t.projectionMatrix),nt.projectionMatrixInverse.copy(_t.projectionMatrixInverse),nt.isPerspectiveCamera&&(nt.fov=A0*2*Math.atan(1/nt.projectionMatrix.elements[5]),nt.zoom=1)}this.getCamera=function(){return k},this.getFoveation=function(){if(!(g===null&&x===null))return p},this.setFoveation=function(nt){p=nt,g!==null&&(g.fixedFoveation=nt),x!==null&&x.fixedFoveation!==void 0&&(x.fixedFoveation=nt)},this.hasDepthSensing=function(){return y.texture!==null},this.getDepthSensingMesh=function(){return y.getMesh(k)},this.getCameraTexture=function(nt){return S[nt]};let xt=null;function Tt(nt,_t){if(_=_t.getViewerPose(d||c),M=_t,_!==null){const Et=_.views;x!==null&&(t.setRenderTargetFramebuffer(C,x.framebuffer),t.setRenderTarget(C));let Ft=!1;Et.length!==k.cameras.length&&(k.cameras.length=0,Ft=!0);for(let qt=0;qt<Et.length;qt++){const re=Et[qt];let _e=null;if(x!==null)_e=x.getViewport(re);else{const lt=v.getViewSubImage(g,re);_e=lt.viewport,qt===0&&(t.setRenderTargetTextures(C,lt.colorTexture,lt.depthStencilTexture),t.setRenderTarget(C))}let se=G[qt];se===void 0&&(se=new La,se.layers.enable(qt),se.viewport=new Pn,G[qt]=se),se.matrix.fromArray(re.transform.matrix),se.matrix.decompose(se.position,se.quaternion,se.scale),se.projectionMatrix.fromArray(re.projectionMatrix),se.projectionMatrixInverse.copy(se.projectionMatrix).invert(),se.viewport.set(_e.x,_e.y,_e.width,_e.height),qt===0&&(k.matrix.copy(se.matrix),k.matrix.decompose(k.position,k.quaternion,k.scale)),Ft===!0&&k.cameras.push(se)}const ee=r.enabledFeatures;if(ee&&ee.includes("depth-sensing")&&r.depthUsage=="gpu-optimized"&&E){v=a.getBinding();const qt=v.getDepthInformation(Et[0]);qt&&qt.isValid&&qt.texture&&y.init(qt,r.renderState)}if(ee&&ee.includes("camera-access")&&E){t.state.unbindTexture(),v=a.getBinding();for(let qt=0;qt<Et.length;qt++){const re=Et[qt].camera;if(re){let _e=S[re];_e||(_e=new P1,S[re]=_e);const se=v.getCameraImage(re);_e.sourceTexture=se}}}}for(let Et=0;Et<O.length;Et++){const Ft=P[Et],ee=O[Et];Ft!==null&&ee!==void 0&&ee.update(Ft,_t,d||c)}xt&&xt(nt,_t),_t.detectedPlanes&&a.dispatchEvent({type:"planesdetected",data:_t}),M=null}const Ut=new B1;Ut.setAnimationLoop(Tt),this.setAnimationLoop=function(nt){xt=nt},this.dispose=function(){}}}const yo=new is,zD=new zn;function ID(o,t){function n(y,S){y.matrixAutoUpdate===!0&&y.updateMatrix(),S.value.copy(y.matrix)}function a(y,S){S.color.getRGB(y.fogColor.value,F1(o)),S.isFog?(y.fogNear.value=S.near,y.fogFar.value=S.far):S.isFogExp2&&(y.fogDensity.value=S.density)}function r(y,S,R,U,C){S.isMeshBasicMaterial?l(y,S):S.isMeshLambertMaterial?(l(y,S),S.envMap&&(y.envMapIntensity.value=S.envMapIntensity)):S.isMeshToonMaterial?(l(y,S),v(y,S)):S.isMeshPhongMaterial?(l(y,S),_(y,S),S.envMap&&(y.envMapIntensity.value=S.envMapIntensity)):S.isMeshStandardMaterial?(l(y,S),g(y,S),S.isMeshPhysicalMaterial&&x(y,S,C)):S.isMeshMatcapMaterial?(l(y,S),M(y,S)):S.isMeshDepthMaterial?l(y,S):S.isMeshDistanceMaterial?(l(y,S),E(y,S)):S.isMeshNormalMaterial?l(y,S):S.isLineBasicMaterial?(c(y,S),S.isLineDashedMaterial&&f(y,S)):S.isPointsMaterial?p(y,S,R,U):S.isSpriteMaterial?d(y,S):S.isShadowMaterial?(y.color.value.copy(S.color),y.opacity.value=S.opacity):S.isShaderMaterial&&(S.uniformsNeedUpdate=!1)}function l(y,S){y.opacity.value=S.opacity,S.color&&y.diffuse.value.copy(S.color),S.emissive&&y.emissive.value.copy(S.emissive).multiplyScalar(S.emissiveIntensity),S.map&&(y.map.value=S.map,n(S.map,y.mapTransform)),S.alphaMap&&(y.alphaMap.value=S.alphaMap,n(S.alphaMap,y.alphaMapTransform)),S.bumpMap&&(y.bumpMap.value=S.bumpMap,n(S.bumpMap,y.bumpMapTransform),y.bumpScale.value=S.bumpScale,S.side===Yi&&(y.bumpScale.value*=-1)),S.normalMap&&(y.normalMap.value=S.normalMap,n(S.normalMap,y.normalMapTransform),y.normalScale.value.copy(S.normalScale),S.side===Yi&&y.normalScale.value.negate()),S.displacementMap&&(y.displacementMap.value=S.displacementMap,n(S.displacementMap,y.displacementMapTransform),y.displacementScale.value=S.displacementScale,y.displacementBias.value=S.displacementBias),S.emissiveMap&&(y.emissiveMap.value=S.emissiveMap,n(S.emissiveMap,y.emissiveMapTransform)),S.specularMap&&(y.specularMap.value=S.specularMap,n(S.specularMap,y.specularMapTransform)),S.alphaTest>0&&(y.alphaTest.value=S.alphaTest);const R=t.get(S),U=R.envMap,C=R.envMapRotation;U&&(y.envMap.value=U,yo.copy(C),yo.x*=-1,yo.y*=-1,yo.z*=-1,U.isCubeTexture&&U.isRenderTargetTexture===!1&&(yo.y*=-1,yo.z*=-1),y.envMapRotation.value.setFromMatrix4(zD.makeRotationFromEuler(yo)),y.flipEnvMap.value=U.isCubeTexture&&U.isRenderTargetTexture===!1?-1:1,y.reflectivity.value=S.reflectivity,y.ior.value=S.ior,y.refractionRatio.value=S.refractionRatio),S.lightMap&&(y.lightMap.value=S.lightMap,y.lightMapIntensity.value=S.lightMapIntensity,n(S.lightMap,y.lightMapTransform)),S.aoMap&&(y.aoMap.value=S.aoMap,y.aoMapIntensity.value=S.aoMapIntensity,n(S.aoMap,y.aoMapTransform))}function c(y,S){y.diffuse.value.copy(S.color),y.opacity.value=S.opacity,S.map&&(y.map.value=S.map,n(S.map,y.mapTransform))}function f(y,S){y.dashSize.value=S.dashSize,y.totalSize.value=S.dashSize+S.gapSize,y.scale.value=S.scale}function p(y,S,R,U){y.diffuse.value.copy(S.color),y.opacity.value=S.opacity,y.size.value=S.size*R,y.scale.value=U*.5,S.map&&(y.map.value=S.map,n(S.map,y.uvTransform)),S.alphaMap&&(y.alphaMap.value=S.alphaMap,n(S.alphaMap,y.alphaMapTransform)),S.alphaTest>0&&(y.alphaTest.value=S.alphaTest)}function d(y,S){y.diffuse.value.copy(S.color),y.opacity.value=S.opacity,y.rotation.value=S.rotation,S.map&&(y.map.value=S.map,n(S.map,y.mapTransform)),S.alphaMap&&(y.alphaMap.value=S.alphaMap,n(S.alphaMap,y.alphaMapTransform)),S.alphaTest>0&&(y.alphaTest.value=S.alphaTest)}function _(y,S){y.specular.value.copy(S.specular),y.shininess.value=Math.max(S.shininess,1e-4)}function v(y,S){S.gradientMap&&(y.gradientMap.value=S.gradientMap)}function g(y,S){y.metalness.value=S.metalness,S.metalnessMap&&(y.metalnessMap.value=S.metalnessMap,n(S.metalnessMap,y.metalnessMapTransform)),y.roughness.value=S.roughness,S.roughnessMap&&(y.roughnessMap.value=S.roughnessMap,n(S.roughnessMap,y.roughnessMapTransform)),S.envMap&&(y.envMapIntensity.value=S.envMapIntensity)}function x(y,S,R){y.ior.value=S.ior,S.sheen>0&&(y.sheenColor.value.copy(S.sheenColor).multiplyScalar(S.sheen),y.sheenRoughness.value=S.sheenRoughness,S.sheenColorMap&&(y.sheenColorMap.value=S.sheenColorMap,n(S.sheenColorMap,y.sheenColorMapTransform)),S.sheenRoughnessMap&&(y.sheenRoughnessMap.value=S.sheenRoughnessMap,n(S.sheenRoughnessMap,y.sheenRoughnessMapTransform))),S.clearcoat>0&&(y.clearcoat.value=S.clearcoat,y.clearcoatRoughness.value=S.clearcoatRoughness,S.clearcoatMap&&(y.clearcoatMap.value=S.clearcoatMap,n(S.clearcoatMap,y.clearcoatMapTransform)),S.clearcoatRoughnessMap&&(y.clearcoatRoughnessMap.value=S.clearcoatRoughnessMap,n(S.clearcoatRoughnessMap,y.clearcoatRoughnessMapTransform)),S.clearcoatNormalMap&&(y.clearcoatNormalMap.value=S.clearcoatNormalMap,n(S.clearcoatNormalMap,y.clearcoatNormalMapTransform),y.clearcoatNormalScale.value.copy(S.clearcoatNormalScale),S.side===Yi&&y.clearcoatNormalScale.value.negate())),S.dispersion>0&&(y.dispersion.value=S.dispersion),S.iridescence>0&&(y.iridescence.value=S.iridescence,y.iridescenceIOR.value=S.iridescenceIOR,y.iridescenceThicknessMinimum.value=S.iridescenceThicknessRange[0],y.iridescenceThicknessMaximum.value=S.iridescenceThicknessRange[1],S.iridescenceMap&&(y.iridescenceMap.value=S.iridescenceMap,n(S.iridescenceMap,y.iridescenceMapTransform)),S.iridescenceThicknessMap&&(y.iridescenceThicknessMap.value=S.iridescenceThicknessMap,n(S.iridescenceThicknessMap,y.iridescenceThicknessMapTransform))),S.transmission>0&&(y.transmission.value=S.transmission,y.transmissionSamplerMap.value=R.texture,y.transmissionSamplerSize.value.set(R.width,R.height),S.transmissionMap&&(y.transmissionMap.value=S.transmissionMap,n(S.transmissionMap,y.transmissionMapTransform)),y.thickness.value=S.thickness,S.thicknessMap&&(y.thicknessMap.value=S.thicknessMap,n(S.thicknessMap,y.thicknessMapTransform)),y.attenuationDistance.value=S.attenuationDistance,y.attenuationColor.value.copy(S.attenuationColor)),S.anisotropy>0&&(y.anisotropyVector.value.set(S.anisotropy*Math.cos(S.anisotropyRotation),S.anisotropy*Math.sin(S.anisotropyRotation)),S.anisotropyMap&&(y.anisotropyMap.value=S.anisotropyMap,n(S.anisotropyMap,y.anisotropyMapTransform))),y.specularIntensity.value=S.specularIntensity,y.specularColor.value.copy(S.specularColor),S.specularColorMap&&(y.specularColorMap.value=S.specularColorMap,n(S.specularColorMap,y.specularColorMapTransform)),S.specularIntensityMap&&(y.specularIntensityMap.value=S.specularIntensityMap,n(S.specularIntensityMap,y.specularIntensityMapTransform))}function M(y,S){S.matcap&&(y.matcap.value=S.matcap)}function E(y,S){const R=t.get(S).light;y.referencePosition.value.setFromMatrixPosition(R.matrixWorld),y.nearDistance.value=R.shadow.camera.near,y.farDistance.value=R.shadow.camera.far}return{refreshFogUniforms:a,refreshMaterialUniforms:r}}function BD(o,t,n,a){let r={},l={},c=[];const f=o.getParameter(o.MAX_UNIFORM_BUFFER_BINDINGS);function p(R,U){const C=U.program;a.uniformBlockBinding(R,C)}function d(R,U){let C=r[R.id];C===void 0&&(M(R),C=_(R),r[R.id]=C,R.addEventListener("dispose",y));const O=U.program;a.updateUBOMapping(R,O);const P=t.render.frame;l[R.id]!==P&&(g(R),l[R.id]=P)}function _(R){const U=v();R.__bindingPointIndex=U;const C=o.createBuffer(),O=R.__size,P=R.usage;return o.bindBuffer(o.UNIFORM_BUFFER,C),o.bufferData(o.UNIFORM_BUFFER,O,P),o.bindBuffer(o.UNIFORM_BUFFER,null),o.bindBufferBase(o.UNIFORM_BUFFER,U,C),C}function v(){for(let R=0;R<f;R++)if(c.indexOf(R)===-1)return c.push(R),R;return Qe("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function g(R){const U=r[R.id],C=R.uniforms,O=R.__cache;o.bindBuffer(o.UNIFORM_BUFFER,U);for(let P=0,L=C.length;P<L;P++){const T=Array.isArray(C[P])?C[P]:[C[P]];for(let w=0,q=T.length;w<q;w++){const G=T[w];if(x(G,P,w,O)===!0){const k=G.__offset,J=Array.isArray(G.value)?G.value:[G.value];let et=0;for(let Q=0;Q<J.length;Q++){const F=J[Q],I=E(F);typeof F=="number"||typeof F=="boolean"?(G.__data[0]=F,o.bufferSubData(o.UNIFORM_BUFFER,k+et,G.__data)):F.isMatrix3?(G.__data[0]=F.elements[0],G.__data[1]=F.elements[1],G.__data[2]=F.elements[2],G.__data[3]=0,G.__data[4]=F.elements[3],G.__data[5]=F.elements[4],G.__data[6]=F.elements[5],G.__data[7]=0,G.__data[8]=F.elements[6],G.__data[9]=F.elements[7],G.__data[10]=F.elements[8],G.__data[11]=0):(F.toArray(G.__data,et),et+=I.storage/Float32Array.BYTES_PER_ELEMENT)}o.bufferSubData(o.UNIFORM_BUFFER,k,G.__data)}}}o.bindBuffer(o.UNIFORM_BUFFER,null)}function x(R,U,C,O){const P=R.value,L=U+"_"+C;if(O[L]===void 0)return typeof P=="number"||typeof P=="boolean"?O[L]=P:O[L]=P.clone(),!0;{const T=O[L];if(typeof P=="number"||typeof P=="boolean"){if(T!==P)return O[L]=P,!0}else if(T.equals(P)===!1)return T.copy(P),!0}return!1}function M(R){const U=R.uniforms;let C=0;const O=16;for(let L=0,T=U.length;L<T;L++){const w=Array.isArray(U[L])?U[L]:[U[L]];for(let q=0,G=w.length;q<G;q++){const k=w[q],J=Array.isArray(k.value)?k.value:[k.value];for(let et=0,Q=J.length;et<Q;et++){const F=J[et],I=E(F),it=C%O,ht=it%I.boundary,H=it+ht;C+=ht,H!==0&&O-H<I.storage&&(C+=O-H),k.__data=new Float32Array(I.storage/Float32Array.BYTES_PER_ELEMENT),k.__offset=C,C+=I.storage}}}const P=C%O;return P>0&&(C+=O-P),R.__size=C,R.__cache={},this}function E(R){const U={boundary:0,storage:0};return typeof R=="number"||typeof R=="boolean"?(U.boundary=4,U.storage=4):R.isVector2?(U.boundary=8,U.storage=8):R.isVector3||R.isColor?(U.boundary=16,U.storage=12):R.isVector4?(U.boundary=16,U.storage=16):R.isMatrix3?(U.boundary=48,U.storage=48):R.isMatrix4?(U.boundary=64,U.storage=64):R.isTexture?Me("WebGLRenderer: Texture samplers can not be part of an uniforms group."):Me("WebGLRenderer: Unsupported uniform value type.",R),U}function y(R){const U=R.target;U.removeEventListener("dispose",y);const C=c.indexOf(U.__bindingPointIndex);c.splice(C,1),o.deleteBuffer(r[U.id]),delete r[U.id],delete l[U.id]}function S(){for(const R in r)o.deleteBuffer(r[R]);c=[],r={},l={}}return{bind:p,update:d,dispose:S}}const HD=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let sr=null;function GD(){return sr===null&&(sr=new LR(HD,16,16,nu,es),sr.name="DFG_LUT",sr.minFilter=Si,sr.magFilter=Si,sr.wrapS=Kr,sr.wrapT=Kr,sr.generateMipmaps=!1,sr.needsUpdate=!0),sr}class VD{constructor(t={}){const{canvas:n=cR(),context:a=null,depth:r=!0,stencil:l=!1,alpha:c=!1,antialias:f=!1,premultipliedAlpha:p=!0,preserveDrawingBuffer:d=!1,powerPreference:_="default",failIfMajorPerformanceCaveat:v=!1,reversedDepthBuffer:g=!1,outputBufferType:x=Fa}=t;this.isWebGLRenderer=!0;let M;if(a!==null){if(typeof WebGLRenderingContext<"u"&&a instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");M=a.getContextAttributes().alpha}else M=c;const E=x,y=new Set([og,sg,rg]),S=new Set([Fa,Sr,zc,Ic,ig,ag]),R=new Uint32Array(4),U=new Int32Array(4);let C=null,O=null;const P=[],L=[];let T=null;this.domElement=n,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=gr,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const w=this;let q=!1;this._outputColorSpace=Na;let G=0,k=0,J=null,et=-1,Q=null;const F=new Pn,I=new Pn;let it=null;const ht=new qe(0);let H=0,z=n.width,K=n.height,xt=1,Tt=null,Ut=null;const nt=new Pn(0,0,z,K),_t=new Pn(0,0,z,K);let Et=!1;const Ft=new L1;let ee=!1,Kt=!1;const Ne=new zn,qt=new ft,re=new Pn,_e={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let se=!1;function lt(){return J===null?xt:1}let W=a;function We(D,Y){return n.getContext(D,Y)}try{const D={alpha:!0,depth:r,stencil:l,antialias:f,premultipliedAlpha:p,preserveDrawingBuffer:d,powerPreference:_,failIfMajorPerformanceCaveat:v};if("setAttribute"in n&&n.setAttribute("data-engine",`three.js r${eg}`),n.addEventListener("webglcontextlost",Xt,!1),n.addEventListener("webglcontextrestored",le,!1),n.addEventListener("webglcontextcreationerror",Ge,!1),W===null){const Y="webgl2";if(W=We(Y,D),W===null)throw We(Y)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(D){throw Qe("WebGLRenderer: "+D.message),D}let Ee,ce,Wt,B,A,j,gt,vt,dt,Gt,wt,ie,Yt,Rt,At,Ht,Pt,zt,pe,V,Dt,Ct,Lt;function bt(){Ee=new V3(W),Ee.init(),Dt=new ND(W,Ee),ce=new O3(W,Ee,t,Dt),Wt=new DD(W,Ee),ce.reversedDepthBuffer&&g&&Wt.buffers.depth.setReversed(!0),B=new W3(W),A=new _D,j=new UD(W,Ee,Wt,A,ce,Dt,B),gt=new G3(w),vt=new KR(W),Ct=new N3(W,vt),dt=new k3(W,vt,B,Ct),Gt=new q3(W,dt,vt,Ct,B),zt=new Y3(W,ce,j),At=new P3(A),wt=new mD(w,gt,Ee,ce,Ct,At),ie=new ID(w,A),Yt=new vD,Rt=new bD(Ee),Pt=new U3(w,gt,Wt,Gt,M,p),Ht=new wD(w,Gt,ce),Lt=new BD(W,B,ce,Wt),pe=new L3(W,Ee,B),V=new X3(W,Ee,B),B.programs=wt.programs,w.capabilities=ce,w.extensions=Ee,w.properties=A,w.renderLists=Yt,w.shadowMap=Ht,w.state=Wt,w.info=B}bt(),E!==Fa&&(T=new Z3(E,n.width,n.height,r,l));const mt=new FD(w,W);this.xr=mt,this.getContext=function(){return W},this.getContextAttributes=function(){return W.getContextAttributes()},this.forceContextLoss=function(){const D=Ee.get("WEBGL_lose_context");D&&D.loseContext()},this.forceContextRestore=function(){const D=Ee.get("WEBGL_lose_context");D&&D.restoreContext()},this.getPixelRatio=function(){return xt},this.setPixelRatio=function(D){D!==void 0&&(xt=D,this.setSize(z,K,!1))},this.getSize=function(D){return D.set(z,K)},this.setSize=function(D,Y,ut=!0){if(mt.isPresenting){Me("WebGLRenderer: Can't change size while VR device is presenting.");return}z=D,K=Y,n.width=Math.floor(D*xt),n.height=Math.floor(Y*xt),ut===!0&&(n.style.width=D+"px",n.style.height=Y+"px"),T!==null&&T.setSize(n.width,n.height),this.setViewport(0,0,D,Y)},this.getDrawingBufferSize=function(D){return D.set(z*xt,K*xt).floor()},this.setDrawingBufferSize=function(D,Y,ut){z=D,K=Y,xt=ut,n.width=Math.floor(D*ut),n.height=Math.floor(Y*ut),this.setViewport(0,0,D,Y)},this.setEffects=function(D){if(E===Fa){console.error("THREE.WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(D){for(let Y=0;Y<D.length;Y++)if(D[Y].isOutputPass===!0){console.warn("THREE.WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}T.setEffects(D||[])},this.getCurrentViewport=function(D){return D.copy(F)},this.getViewport=function(D){return D.copy(nt)},this.setViewport=function(D,Y,ut,st){D.isVector4?nt.set(D.x,D.y,D.z,D.w):nt.set(D,Y,ut,st),Wt.viewport(F.copy(nt).multiplyScalar(xt).round())},this.getScissor=function(D){return D.copy(_t)},this.setScissor=function(D,Y,ut,st){D.isVector4?_t.set(D.x,D.y,D.z,D.w):_t.set(D,Y,ut,st),Wt.scissor(I.copy(_t).multiplyScalar(xt).round())},this.getScissorTest=function(){return Et},this.setScissorTest=function(D){Wt.setScissorTest(Et=D)},this.setOpaqueSort=function(D){Tt=D},this.setTransparentSort=function(D){Ut=D},this.getClearColor=function(D){return D.copy(Pt.getClearColor())},this.setClearColor=function(){Pt.setClearColor(...arguments)},this.getClearAlpha=function(){return Pt.getClearAlpha()},this.setClearAlpha=function(){Pt.setClearAlpha(...arguments)},this.clear=function(D=!0,Y=!0,ut=!0){let st=0;if(D){let at=!1;if(J!==null){const Nt=J.texture.format;at=y.has(Nt)}if(at){const Nt=J.texture.type,Bt=S.has(Nt),Ot=Pt.getClearColor(),jt=Pt.getClearAlpha(),Zt=Ot.r,me=Ot.g,ye=Ot.b;Bt?(R[0]=Zt,R[1]=me,R[2]=ye,R[3]=jt,W.clearBufferuiv(W.COLOR,0,R)):(U[0]=Zt,U[1]=me,U[2]=ye,U[3]=jt,W.clearBufferiv(W.COLOR,0,U))}else st|=W.COLOR_BUFFER_BIT}Y&&(st|=W.DEPTH_BUFFER_BIT),ut&&(st|=W.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),st!==0&&W.clear(st)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){n.removeEventListener("webglcontextlost",Xt,!1),n.removeEventListener("webglcontextrestored",le,!1),n.removeEventListener("webglcontextcreationerror",Ge,!1),Pt.dispose(),Yt.dispose(),Rt.dispose(),A.dispose(),gt.dispose(),Gt.dispose(),Ct.dispose(),Lt.dispose(),wt.dispose(),mt.dispose(),mt.removeEventListener("sessionstart",de),mt.removeEventListener("sessionend",_n),ge.stop()};function Xt(D){D.preventDefault(),PS("WebGLRenderer: Context Lost."),q=!0}function le(){PS("WebGLRenderer: Context Restored."),q=!1;const D=B.autoReset,Y=Ht.enabled,ut=Ht.autoUpdate,st=Ht.needsUpdate,at=Ht.type;bt(),B.autoReset=D,Ht.enabled=Y,Ht.autoUpdate=ut,Ht.needsUpdate=st,Ht.type=at}function Ge(D){Qe("WebGLRenderer: A WebGL context could not be created. Reason: ",D.statusMessage)}function Vt(D){const Y=D.target;Y.removeEventListener("dispose",Vt),Jt(Y)}function Jt(D){be(D),A.remove(D)}function be(D){const Y=A.get(D).programs;Y!==void 0&&(Y.forEach(function(ut){wt.releaseProgram(ut)}),D.isShaderMaterial&&wt.releaseShaderCache(D))}this.renderBufferDirect=function(D,Y,ut,st,at,Nt){Y===null&&(Y=_e);const Bt=at.isMesh&&at.matrixWorld.determinant()<0,Ot=bi(D,Y,ut,st,at);Wt.setMaterial(st,Bt);let jt=ut.index,Zt=1;if(st.wireframe===!0){if(jt=dt.getWireframeAttribute(ut),jt===void 0)return;Zt=2}const me=ut.drawRange,ye=ut.attributes.position;let Qt=me.start*Zt,Re=(me.start+me.count)*Zt;Nt!==null&&(Qt=Math.max(Qt,Nt.start*Zt),Re=Math.min(Re,(Nt.start+Nt.count)*Zt)),jt!==null?(Qt=Math.max(Qt,0),Re=Math.min(Re,jt.count)):ye!=null&&(Qt=Math.max(Qt,0),Re=Math.min(Re,ye.count));const Sn=Re-Qt;if(Sn<0||Sn===1/0)return;Ct.setup(at,st,Ot,ut,jt);let Mn,je=pe;if(jt!==null&&(Mn=vt.get(jt),je=V,je.setIndex(Mn)),at.isMesh)st.wireframe===!0?(Wt.setLineWidth(st.wireframeLinewidth*lt()),je.setMode(W.LINES)):je.setMode(W.TRIANGLES);else if(at.isLine){let jn=st.linewidth;jn===void 0&&(jn=1),Wt.setLineWidth(jn*lt()),at.isLineSegments?je.setMode(W.LINES):at.isLineLoop?je.setMode(W.LINE_LOOP):je.setMode(W.LINE_STRIP)}else at.isPoints?je.setMode(W.POINTS):at.isSprite&&je.setMode(W.TRIANGLES);if(at.isBatchedMesh)if(at._multiDrawInstances!==null)hd("WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),je.renderMultiDrawInstances(at._multiDrawStarts,at._multiDrawCounts,at._multiDrawCount,at._multiDrawInstances);else if(Ee.get("WEBGL_multi_draw"))je.renderMultiDraw(at._multiDrawStarts,at._multiDrawCounts,at._multiDrawCount);else{const jn=at._multiDrawStarts,ne=at._multiDrawCounts,Ti=at._multiDrawCount,ve=jt?vt.get(jt).bytesPerElement:1,Ai=A.get(st).currentProgram.getUniforms();for(let $i=0;$i<Ti;$i++)Ai.setValue(W,"_gl_DrawID",$i),je.render(jn[$i]/ve,ne[$i])}else if(at.isInstancedMesh)je.renderInstances(Qt,Sn,at.count);else if(ut.isInstancedBufferGeometry){const jn=ut._maxInstanceCount!==void 0?ut._maxInstanceCount:1/0,ne=Math.min(ut.instanceCount,jn);je.renderInstances(Qt,Sn,ne)}else je.render(Qt,Sn)};function It(D,Y,ut){D.transparent===!0&&D.side===jr&&D.forceSinglePass===!1?(D.side=Yi,D.needsUpdate=!0,In(D,Y,ut),D.side=Ys,D.needsUpdate=!0,In(D,Y,ut),D.side=jr):In(D,Y,ut)}this.compile=function(D,Y,ut=null){ut===null&&(ut=D),O=Rt.get(ut),O.init(Y),L.push(O),ut.traverseVisible(function(at){at.isLight&&at.layers.test(Y.layers)&&(O.pushLight(at),at.castShadow&&O.pushShadow(at))}),D!==ut&&D.traverseVisible(function(at){at.isLight&&at.layers.test(Y.layers)&&(O.pushLight(at),at.castShadow&&O.pushShadow(at))}),O.setupLights();const st=new Set;return D.traverse(function(at){if(!(at.isMesh||at.isPoints||at.isLine||at.isSprite))return;const Nt=at.material;if(Nt)if(Array.isArray(Nt))for(let Bt=0;Bt<Nt.length;Bt++){const Ot=Nt[Bt];It(Ot,ut,at),st.add(Ot)}else It(Nt,ut,at),st.add(Nt)}),O=L.pop(),st},this.compileAsync=function(D,Y,ut=null){const st=this.compile(D,Y,ut);return new Promise(at=>{function Nt(){if(st.forEach(function(Bt){A.get(Bt).currentProgram.isReady()&&st.delete(Bt)}),st.size===0){at(D);return}setTimeout(Nt,10)}Ee.get("KHR_parallel_shader_compile")!==null?Nt():setTimeout(Nt,10)})};let he=null;function oe(D){he&&he(D)}function de(){ge.stop()}function _n(){ge.start()}const ge=new B1;ge.setAnimationLoop(oe),typeof self<"u"&&ge.setContext(self),this.setAnimationLoop=function(D){he=D,mt.setAnimationLoop(D),D===null?ge.stop():ge.start()},mt.addEventListener("sessionstart",de),mt.addEventListener("sessionend",_n),this.render=function(D,Y){if(Y!==void 0&&Y.isCamera!==!0){Qe("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(q===!0)return;const ut=mt.enabled===!0&&mt.isPresenting===!0,st=T!==null&&(J===null||ut)&&T.begin(w,J);if(D.matrixWorldAutoUpdate===!0&&D.updateMatrixWorld(),Y.parent===null&&Y.matrixWorldAutoUpdate===!0&&Y.updateMatrixWorld(),mt.enabled===!0&&mt.isPresenting===!0&&(T===null||T.isCompositing()===!1)&&(mt.cameraAutoUpdate===!0&&mt.updateCamera(Y),Y=mt.getCamera()),D.isScene===!0&&D.onBeforeRender(w,D,Y,J),O=Rt.get(D,L.length),O.init(Y),L.push(O),Ne.multiplyMatrices(Y.projectionMatrix,Y.matrixWorldInverse),Ft.setFromProjectionMatrix(Ne,pr,Y.reversedDepth),Kt=this.localClippingEnabled,ee=At.init(this.clippingPlanes,Kt),C=Yt.get(D,P.length),C.init(),P.push(C),mt.enabled===!0&&mt.isPresenting===!0){const Bt=w.xr.getDepthSensingMesh();Bt!==null&&rn(Bt,Y,-1/0,w.sortObjects)}rn(D,Y,0,w.sortObjects),C.finish(),w.sortObjects===!0&&C.sort(Tt,Ut),se=mt.enabled===!1||mt.isPresenting===!1||mt.hasDepthSensing()===!1,se&&Pt.addToRenderList(C,D),this.info.render.frame++,ee===!0&&At.beginShadows();const at=O.state.shadowsArray;if(Ht.render(at,D,Y),ee===!0&&At.endShadows(),this.info.autoReset===!0&&this.info.reset(),(st&&T.hasRenderPass())===!1){const Bt=C.opaque,Ot=C.transmissive;if(O.setupLights(),Y.isArrayCamera){const jt=Y.cameras;if(Ot.length>0)for(let Zt=0,me=jt.length;Zt<me;Zt++){const ye=jt[Zt];Te(Bt,Ot,D,ye)}se&&Pt.render(D);for(let Zt=0,me=jt.length;Zt<me;Zt++){const ye=jt[Zt];sn(C,D,ye,ye.viewport)}}else Ot.length>0&&Te(Bt,Ot,D,Y),se&&Pt.render(D),sn(C,D,Y)}J!==null&&k===0&&(j.updateMultisampleRenderTarget(J),j.updateRenderTargetMipmap(J)),st&&T.end(w),D.isScene===!0&&D.onAfterRender(w,D,Y),Ct.resetDefaultState(),et=-1,Q=null,L.pop(),L.length>0?(O=L[L.length-1],ee===!0&&At.setGlobalState(w.clippingPlanes,O.state.camera)):O=null,P.pop(),P.length>0?C=P[P.length-1]:C=null};function rn(D,Y,ut,st){if(D.visible===!1)return;if(D.layers.test(Y.layers)){if(D.isGroup)ut=D.renderOrder;else if(D.isLOD)D.autoUpdate===!0&&D.update(Y);else if(D.isLight)O.pushLight(D),D.castShadow&&O.pushShadow(D);else if(D.isSprite){if(!D.frustumCulled||Ft.intersectsSprite(D)){st&&re.setFromMatrixPosition(D.matrixWorld).applyMatrix4(Ne);const Bt=Gt.update(D),Ot=D.material;Ot.visible&&C.push(D,Bt,Ot,ut,re.z,null)}}else if((D.isMesh||D.isLine||D.isPoints)&&(!D.frustumCulled||Ft.intersectsObject(D))){const Bt=Gt.update(D),Ot=D.material;if(st&&(D.boundingSphere!==void 0?(D.boundingSphere===null&&D.computeBoundingSphere(),re.copy(D.boundingSphere.center)):(Bt.boundingSphere===null&&Bt.computeBoundingSphere(),re.copy(Bt.boundingSphere.center)),re.applyMatrix4(D.matrixWorld).applyMatrix4(Ne)),Array.isArray(Ot)){const jt=Bt.groups;for(let Zt=0,me=jt.length;Zt<me;Zt++){const ye=jt[Zt],Qt=Ot[ye.materialIndex];Qt&&Qt.visible&&C.push(D,Bt,Qt,ut,re.z,ye)}}else Ot.visible&&C.push(D,Bt,Ot,ut,re.z,null)}}const Nt=D.children;for(let Bt=0,Ot=Nt.length;Bt<Ot;Bt++)rn(Nt[Bt],Y,ut,st)}function sn(D,Y,ut,st){const{opaque:at,transmissive:Nt,transparent:Bt}=D;O.setupLightsView(ut),ee===!0&&At.setGlobalState(w.clippingPlanes,ut),st&&Wt.viewport(F.copy(st)),at.length>0&&xe(at,Y,ut),Nt.length>0&&xe(Nt,Y,ut),Bt.length>0&&xe(Bt,Y,ut),Wt.buffers.depth.setTest(!0),Wt.buffers.depth.setMask(!0),Wt.buffers.color.setMask(!0),Wt.setPolygonOffset(!1)}function Te(D,Y,ut,st){if((ut.isScene===!0?ut.overrideMaterial:null)!==null)return;if(O.state.transmissionRenderTarget[st.id]===void 0){const Qt=Ee.has("EXT_color_buffer_half_float")||Ee.has("EXT_color_buffer_float");O.state.transmissionRenderTarget[st.id]=new vr(1,1,{generateMipmaps:!0,type:Qt?es:Fa,minFilter:wo,samples:Math.max(4,ce.samples),stencilBuffer:l,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Ye.workingColorSpace})}const Nt=O.state.transmissionRenderTarget[st.id],Bt=st.viewport||F;Nt.setSize(Bt.z*w.transmissionResolutionScale,Bt.w*w.transmissionResolutionScale);const Ot=w.getRenderTarget(),jt=w.getActiveCubeFace(),Zt=w.getActiveMipmapLevel();w.setRenderTarget(Nt),w.getClearColor(ht),H=w.getClearAlpha(),H<1&&w.setClearColor(16777215,.5),w.clear(),se&&Pt.render(ut);const me=w.toneMapping;w.toneMapping=gr;const ye=st.viewport;if(st.viewport!==void 0&&(st.viewport=void 0),O.setupLightsView(st),ee===!0&&At.setGlobalState(w.clippingPlanes,st),xe(D,ut,st),j.updateMultisampleRenderTarget(Nt),j.updateRenderTargetMipmap(Nt),Ee.has("WEBGL_multisampled_render_to_texture")===!1){let Qt=!1;for(let Re=0,Sn=Y.length;Re<Sn;Re++){const Mn=Y[Re],{object:je,geometry:jn,material:ne,group:Ti}=Mn;if(ne.side===jr&&je.layers.test(st.layers)){const ve=ne.side;ne.side=Yi,ne.needsUpdate=!0,Pe(je,ut,st,jn,ne,Ti),ne.side=ve,ne.needsUpdate=!0,Qt=!0}}Qt===!0&&(j.updateMultisampleRenderTarget(Nt),j.updateRenderTargetMipmap(Nt))}w.setRenderTarget(Ot,jt,Zt),w.setClearColor(ht,H),ye!==void 0&&(st.viewport=ye),w.toneMapping=me}function xe(D,Y,ut){const st=Y.isScene===!0?Y.overrideMaterial:null;for(let at=0,Nt=D.length;at<Nt;at++){const Bt=D[at],{object:Ot,geometry:jt,group:Zt}=Bt;let me=Bt.material;me.allowOverride===!0&&st!==null&&(me=st),Ot.layers.test(ut.layers)&&Pe(Ot,Y,ut,jt,me,Zt)}}function Pe(D,Y,ut,st,at,Nt){D.onBeforeRender(w,Y,ut,st,at,Nt),D.modelViewMatrix.multiplyMatrices(ut.matrixWorldInverse,D.matrixWorld),D.normalMatrix.getNormalMatrix(D.modelViewMatrix),at.onBeforeRender(w,Y,ut,st,D,Nt),at.transparent===!0&&at.side===jr&&at.forceSinglePass===!1?(at.side=Yi,at.needsUpdate=!0,w.renderBufferDirect(ut,Y,st,at,D,Nt),at.side=Ys,at.needsUpdate=!0,w.renderBufferDirect(ut,Y,st,at,D,Nt),at.side=jr):w.renderBufferDirect(ut,Y,st,at,D,Nt),D.onAfterRender(w,Y,ut,st,at,Nt)}function In(D,Y,ut){Y.isScene!==!0&&(Y=_e);const st=A.get(D),at=O.state.lights,Nt=O.state.shadowsArray,Bt=at.state.version,Ot=wt.getParameters(D,at.state,Nt,Y,ut),jt=wt.getProgramCacheKey(Ot);let Zt=st.programs;st.environment=D.isMeshStandardMaterial||D.isMeshLambertMaterial||D.isMeshPhongMaterial?Y.environment:null,st.fog=Y.fog;const me=D.isMeshStandardMaterial||D.isMeshLambertMaterial&&!D.envMap||D.isMeshPhongMaterial&&!D.envMap;st.envMap=gt.get(D.envMap||st.environment,me),st.envMapRotation=st.environment!==null&&D.envMap===null?Y.environmentRotation:D.envMapRotation,Zt===void 0&&(D.addEventListener("dispose",Vt),Zt=new Map,st.programs=Zt);let ye=Zt.get(jt);if(ye!==void 0){if(st.currentProgram===ye&&st.lightsStateVersion===Bt)return ti(D,Ot),ye}else Ot.uniforms=wt.getUniforms(D),D.onBeforeCompile(Ot,w),ye=wt.acquireProgram(Ot,jt),Zt.set(jt,ye),st.uniforms=Ot.uniforms;const Qt=st.uniforms;return(!D.isShaderMaterial&&!D.isRawShaderMaterial||D.clipping===!0)&&(Qt.clippingPlanes=At.uniform),ti(D,Ot),st.needsLights=Tn(D),st.lightsStateVersion=Bt,st.needsLights&&(Qt.ambientLightColor.value=at.state.ambient,Qt.lightProbe.value=at.state.probe,Qt.directionalLights.value=at.state.directional,Qt.directionalLightShadows.value=at.state.directionalShadow,Qt.spotLights.value=at.state.spot,Qt.spotLightShadows.value=at.state.spotShadow,Qt.rectAreaLights.value=at.state.rectArea,Qt.ltc_1.value=at.state.rectAreaLTC1,Qt.ltc_2.value=at.state.rectAreaLTC2,Qt.pointLights.value=at.state.point,Qt.pointLightShadows.value=at.state.pointShadow,Qt.hemisphereLights.value=at.state.hemi,Qt.directionalShadowMatrix.value=at.state.directionalShadowMatrix,Qt.spotLightMatrix.value=at.state.spotLightMatrix,Qt.spotLightMap.value=at.state.spotLightMap,Qt.pointShadowMatrix.value=at.state.pointShadowMatrix),st.currentProgram=ye,st.uniformsList=null,ye}function on(D){if(D.uniformsList===null){const Y=D.currentProgram.getUniforms();D.uniformsList=$h.seqWithValue(Y.seq,D.uniforms)}return D.uniformsList}function ti(D,Y){const ut=A.get(D);ut.outputColorSpace=Y.outputColorSpace,ut.batching=Y.batching,ut.batchingColor=Y.batchingColor,ut.instancing=Y.instancing,ut.instancingColor=Y.instancingColor,ut.instancingMorph=Y.instancingMorph,ut.skinning=Y.skinning,ut.morphTargets=Y.morphTargets,ut.morphNormals=Y.morphNormals,ut.morphColors=Y.morphColors,ut.morphTargetsCount=Y.morphTargetsCount,ut.numClippingPlanes=Y.numClippingPlanes,ut.numIntersection=Y.numClipIntersection,ut.vertexAlphas=Y.vertexAlphas,ut.vertexTangents=Y.vertexTangents,ut.toneMapping=Y.toneMapping}function bi(D,Y,ut,st,at){Y.isScene!==!0&&(Y=_e),j.resetTextureUnits();const Nt=Y.fog,Bt=st.isMeshStandardMaterial||st.isMeshLambertMaterial||st.isMeshPhongMaterial?Y.environment:null,Ot=J===null?w.outputColorSpace:J.isXRRenderTarget===!0?J.texture.colorSpace:iu,jt=st.isMeshStandardMaterial||st.isMeshLambertMaterial&&!st.envMap||st.isMeshPhongMaterial&&!st.envMap,Zt=gt.get(st.envMap||Bt,jt),me=st.vertexColors===!0&&!!ut.attributes.color&&ut.attributes.color.itemSize===4,ye=!!ut.attributes.tangent&&(!!st.normalMap||st.anisotropy>0),Qt=!!ut.morphAttributes.position,Re=!!ut.morphAttributes.normal,Sn=!!ut.morphAttributes.color;let Mn=gr;st.toneMapped&&(J===null||J.isXRRenderTarget===!0)&&(Mn=w.toneMapping);const je=ut.morphAttributes.position||ut.morphAttributes.normal||ut.morphAttributes.color,jn=je!==void 0?je.length:0,ne=A.get(st),Ti=O.state.lights;if(ee===!0&&(Kt===!0||D!==Q)){const Hn=D===Q&&st.id===et;At.setState(st,D,Hn)}let ve=!1;st.version===ne.__version?(ne.needsLights&&ne.lightsStateVersion!==Ti.state.version||ne.outputColorSpace!==Ot||at.isBatchedMesh&&ne.batching===!1||!at.isBatchedMesh&&ne.batching===!0||at.isBatchedMesh&&ne.batchingColor===!0&&at.colorTexture===null||at.isBatchedMesh&&ne.batchingColor===!1&&at.colorTexture!==null||at.isInstancedMesh&&ne.instancing===!1||!at.isInstancedMesh&&ne.instancing===!0||at.isSkinnedMesh&&ne.skinning===!1||!at.isSkinnedMesh&&ne.skinning===!0||at.isInstancedMesh&&ne.instancingColor===!0&&at.instanceColor===null||at.isInstancedMesh&&ne.instancingColor===!1&&at.instanceColor!==null||at.isInstancedMesh&&ne.instancingMorph===!0&&at.morphTexture===null||at.isInstancedMesh&&ne.instancingMorph===!1&&at.morphTexture!==null||ne.envMap!==Zt||st.fog===!0&&ne.fog!==Nt||ne.numClippingPlanes!==void 0&&(ne.numClippingPlanes!==At.numPlanes||ne.numIntersection!==At.numIntersection)||ne.vertexAlphas!==me||ne.vertexTangents!==ye||ne.morphTargets!==Qt||ne.morphNormals!==Re||ne.morphColors!==Sn||ne.toneMapping!==Mn||ne.morphTargetsCount!==jn)&&(ve=!0):(ve=!0,ne.__version=st.version);let Ai=ne.currentProgram;ve===!0&&(Ai=In(st,Y,at));let $i=!1,Va=!1,ta=!1;const $e=Ai.getUniforms(),Bn=ne.uniforms;if(Wt.useProgram(Ai.program)&&($i=!0,Va=!0,ta=!0),st.id!==et&&(et=st.id,Va=!0),$i||Q!==D){Wt.buffers.depth.getReversed()&&D.reversedDepth!==!0&&(D._reversedDepth=!0,D.updateProjectionMatrix()),$e.setValue(W,"projectionMatrix",D.projectionMatrix),$e.setValue(W,"viewMatrix",D.matrixWorldInverse);const ka=$e.map.cameraPosition;ka!==void 0&&ka.setValue(W,qt.setFromMatrixPosition(D.matrixWorld)),ce.logarithmicDepthBuffer&&$e.setValue(W,"logDepthBufFC",2/(Math.log(D.far+1)/Math.LN2)),(st.isMeshPhongMaterial||st.isMeshToonMaterial||st.isMeshLambertMaterial||st.isMeshBasicMaterial||st.isMeshStandardMaterial||st.isShaderMaterial)&&$e.setValue(W,"isOrthographic",D.isOrthographicCamera===!0),Q!==D&&(Q=D,Va=!0,ta=!0)}if(ne.needsLights&&(Ti.state.directionalShadowMap.length>0&&$e.setValue(W,"directionalShadowMap",Ti.state.directionalShadowMap,j),Ti.state.spotShadowMap.length>0&&$e.setValue(W,"spotShadowMap",Ti.state.spotShadowMap,j),Ti.state.pointShadowMap.length>0&&$e.setValue(W,"pointShadowMap",Ti.state.pointShadowMap,j)),at.isSkinnedMesh){$e.setOptional(W,at,"bindMatrix"),$e.setOptional(W,at,"bindMatrixInverse");const Hn=at.skeleton;Hn&&(Hn.boneTexture===null&&Hn.computeBoneTexture(),$e.setValue(W,"boneTexture",Hn.boneTexture,j))}at.isBatchedMesh&&($e.setOptional(W,at,"batchingTexture"),$e.setValue(W,"batchingTexture",at._matricesTexture,j),$e.setOptional(W,at,"batchingIdTexture"),$e.setValue(W,"batchingIdTexture",at._indirectTexture,j),$e.setOptional(W,at,"batchingColorTexture"),at._colorsTexture!==null&&$e.setValue(W,"batchingColorTexture",at._colorsTexture,j));const Ri=ut.morphAttributes;if((Ri.position!==void 0||Ri.normal!==void 0||Ri.color!==void 0)&&zt.update(at,ut,Ai),(Va||ne.receiveShadow!==at.receiveShadow)&&(ne.receiveShadow=at.receiveShadow,$e.setValue(W,"receiveShadow",at.receiveShadow)),(st.isMeshStandardMaterial||st.isMeshLambertMaterial||st.isMeshPhongMaterial)&&st.envMap===null&&Y.environment!==null&&(Bn.envMapIntensity.value=Y.environmentIntensity),Bn.dfgLUT!==void 0&&(Bn.dfgLUT.value=GD()),Va&&($e.setValue(W,"toneMappingExposure",w.toneMappingExposure),ne.needsLights&&gn(Bn,ta),Nt&&st.fog===!0&&ie.refreshFogUniforms(Bn,Nt),ie.refreshMaterialUniforms(Bn,st,xt,K,O.state.transmissionRenderTarget[D.id]),$h.upload(W,on(ne),Bn,j)),st.isShaderMaterial&&st.uniformsNeedUpdate===!0&&($h.upload(W,on(ne),Bn,j),st.uniformsNeedUpdate=!1),st.isSpriteMaterial&&$e.setValue(W,"center",at.center),$e.setValue(W,"modelViewMatrix",at.modelViewMatrix),$e.setValue(W,"normalMatrix",at.normalMatrix),$e.setValue(W,"modelMatrix",at.matrixWorld),st.isShaderMaterial||st.isRawShaderMaterial){const Hn=st.uniformsGroups;for(let ka=0,Er=Hn.length;ka<Er;ka++){const Yo=Hn[ka];Lt.update(Yo,Ai),Lt.bind(Yo,Ai)}}return Ai}function gn(D,Y){D.ambientLightColor.needsUpdate=Y,D.lightProbe.needsUpdate=Y,D.directionalLights.needsUpdate=Y,D.directionalLightShadows.needsUpdate=Y,D.pointLights.needsUpdate=Y,D.pointLightShadows.needsUpdate=Y,D.spotLights.needsUpdate=Y,D.spotLightShadows.needsUpdate=Y,D.rectAreaLights.needsUpdate=Y,D.hemisphereLights.needsUpdate=Y}function Tn(D){return D.isMeshLambertMaterial||D.isMeshToonMaterial||D.isMeshPhongMaterial||D.isMeshStandardMaterial||D.isShadowMaterial||D.isShaderMaterial&&D.lights===!0}this.getActiveCubeFace=function(){return G},this.getActiveMipmapLevel=function(){return k},this.getRenderTarget=function(){return J},this.setRenderTargetTextures=function(D,Y,ut){const st=A.get(D);st.__autoAllocateDepthBuffer=D.resolveDepthBuffer===!1,st.__autoAllocateDepthBuffer===!1&&(st.__useRenderToTexture=!1),A.get(D.texture).__webglTexture=Y,A.get(D.depthTexture).__webglTexture=st.__autoAllocateDepthBuffer?void 0:ut,st.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(D,Y){const ut=A.get(D);ut.__webglFramebuffer=Y,ut.__useDefaultFramebuffer=Y===void 0};const vn=W.createFramebuffer();this.setRenderTarget=function(D,Y=0,ut=0){J=D,G=Y,k=ut;let st=null,at=!1,Nt=!1;if(D){const Ot=A.get(D);if(Ot.__useDefaultFramebuffer!==void 0){Wt.bindFramebuffer(W.FRAMEBUFFER,Ot.__webglFramebuffer),F.copy(D.viewport),I.copy(D.scissor),it=D.scissorTest,Wt.viewport(F),Wt.scissor(I),Wt.setScissorTest(it),et=-1;return}else if(Ot.__webglFramebuffer===void 0)j.setupRenderTarget(D);else if(Ot.__hasExternalTextures)j.rebindTextures(D,A.get(D.texture).__webglTexture,A.get(D.depthTexture).__webglTexture);else if(D.depthBuffer){const me=D.depthTexture;if(Ot.__boundDepthTexture!==me){if(me!==null&&A.has(me)&&(D.width!==me.image.width||D.height!==me.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");j.setupDepthRenderbuffer(D)}}const jt=D.texture;(jt.isData3DTexture||jt.isDataArrayTexture||jt.isCompressedArrayTexture)&&(Nt=!0);const Zt=A.get(D).__webglFramebuffer;D.isWebGLCubeRenderTarget?(Array.isArray(Zt[Y])?st=Zt[Y][ut]:st=Zt[Y],at=!0):D.samples>0&&j.useMultisampledRTT(D)===!1?st=A.get(D).__webglMultisampledFramebuffer:Array.isArray(Zt)?st=Zt[ut]:st=Zt,F.copy(D.viewport),I.copy(D.scissor),it=D.scissorTest}else F.copy(nt).multiplyScalar(xt).floor(),I.copy(_t).multiplyScalar(xt).floor(),it=Et;if(ut!==0&&(st=vn),Wt.bindFramebuffer(W.FRAMEBUFFER,st)&&Wt.drawBuffers(D,st),Wt.viewport(F),Wt.scissor(I),Wt.setScissorTest(it),at){const Ot=A.get(D.texture);W.framebufferTexture2D(W.FRAMEBUFFER,W.COLOR_ATTACHMENT0,W.TEXTURE_CUBE_MAP_POSITIVE_X+Y,Ot.__webglTexture,ut)}else if(Nt){const Ot=Y;for(let jt=0;jt<D.textures.length;jt++){const Zt=A.get(D.textures[jt]);W.framebufferTextureLayer(W.FRAMEBUFFER,W.COLOR_ATTACHMENT0+jt,Zt.__webglTexture,ut,Ot)}}else if(D!==null&&ut!==0){const Ot=A.get(D.texture);W.framebufferTexture2D(W.FRAMEBUFFER,W.COLOR_ATTACHMENT0,W.TEXTURE_2D,Ot.__webglTexture,ut)}et=-1},this.readRenderTargetPixels=function(D,Y,ut,st,at,Nt,Bt,Ot=0){if(!(D&&D.isWebGLRenderTarget)){Qe("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let jt=A.get(D).__webglFramebuffer;if(D.isWebGLCubeRenderTarget&&Bt!==void 0&&(jt=jt[Bt]),jt){Wt.bindFramebuffer(W.FRAMEBUFFER,jt);try{const Zt=D.textures[Ot],me=Zt.format,ye=Zt.type;if(D.textures.length>1&&W.readBuffer(W.COLOR_ATTACHMENT0+Ot),!ce.textureFormatReadable(me)){Qe("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!ce.textureTypeReadable(ye)){Qe("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}Y>=0&&Y<=D.width-st&&ut>=0&&ut<=D.height-at&&W.readPixels(Y,ut,st,at,Dt.convert(me),Dt.convert(ye),Nt)}finally{const Zt=J!==null?A.get(J).__webglFramebuffer:null;Wt.bindFramebuffer(W.FRAMEBUFFER,Zt)}}},this.readRenderTargetPixelsAsync=async function(D,Y,ut,st,at,Nt,Bt,Ot=0){if(!(D&&D.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let jt=A.get(D).__webglFramebuffer;if(D.isWebGLCubeRenderTarget&&Bt!==void 0&&(jt=jt[Bt]),jt)if(Y>=0&&Y<=D.width-st&&ut>=0&&ut<=D.height-at){Wt.bindFramebuffer(W.FRAMEBUFFER,jt);const Zt=D.textures[Ot],me=Zt.format,ye=Zt.type;if(D.textures.length>1&&W.readBuffer(W.COLOR_ATTACHMENT0+Ot),!ce.textureFormatReadable(me))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!ce.textureTypeReadable(ye))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Qt=W.createBuffer();W.bindBuffer(W.PIXEL_PACK_BUFFER,Qt),W.bufferData(W.PIXEL_PACK_BUFFER,Nt.byteLength,W.STREAM_READ),W.readPixels(Y,ut,st,at,Dt.convert(me),Dt.convert(ye),0);const Re=J!==null?A.get(J).__webglFramebuffer:null;Wt.bindFramebuffer(W.FRAMEBUFFER,Re);const Sn=W.fenceSync(W.SYNC_GPU_COMMANDS_COMPLETE,0);return W.flush(),await fR(W,Sn,4),W.bindBuffer(W.PIXEL_PACK_BUFFER,Qt),W.getBufferSubData(W.PIXEL_PACK_BUFFER,0,Nt),W.deleteBuffer(Qt),W.deleteSync(Sn),Nt}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(D,Y=null,ut=0){const st=Math.pow(2,-ut),at=Math.floor(D.image.width*st),Nt=Math.floor(D.image.height*st),Bt=Y!==null?Y.x:0,Ot=Y!==null?Y.y:0;j.setTexture2D(D,0),W.copyTexSubImage2D(W.TEXTURE_2D,ut,0,0,Bt,Ot,at,Nt),Wt.unbindTexture()};const di=W.createFramebuffer(),Sa=W.createFramebuffer();this.copyTextureToTexture=function(D,Y,ut=null,st=null,at=0,Nt=0){let Bt,Ot,jt,Zt,me,ye,Qt,Re,Sn;const Mn=D.isCompressedTexture?D.mipmaps[Nt]:D.image;if(ut!==null)Bt=ut.max.x-ut.min.x,Ot=ut.max.y-ut.min.y,jt=ut.isBox3?ut.max.z-ut.min.z:1,Zt=ut.min.x,me=ut.min.y,ye=ut.isBox3?ut.min.z:0;else{const Bn=Math.pow(2,-at);Bt=Math.floor(Mn.width*Bn),Ot=Math.floor(Mn.height*Bn),D.isDataArrayTexture?jt=Mn.depth:D.isData3DTexture?jt=Math.floor(Mn.depth*Bn):jt=1,Zt=0,me=0,ye=0}st!==null?(Qt=st.x,Re=st.y,Sn=st.z):(Qt=0,Re=0,Sn=0);const je=Dt.convert(Y.format),jn=Dt.convert(Y.type);let ne;Y.isData3DTexture?(j.setTexture3D(Y,0),ne=W.TEXTURE_3D):Y.isDataArrayTexture||Y.isCompressedArrayTexture?(j.setTexture2DArray(Y,0),ne=W.TEXTURE_2D_ARRAY):(j.setTexture2D(Y,0),ne=W.TEXTURE_2D),W.pixelStorei(W.UNPACK_FLIP_Y_WEBGL,Y.flipY),W.pixelStorei(W.UNPACK_PREMULTIPLY_ALPHA_WEBGL,Y.premultiplyAlpha),W.pixelStorei(W.UNPACK_ALIGNMENT,Y.unpackAlignment);const Ti=W.getParameter(W.UNPACK_ROW_LENGTH),ve=W.getParameter(W.UNPACK_IMAGE_HEIGHT),Ai=W.getParameter(W.UNPACK_SKIP_PIXELS),$i=W.getParameter(W.UNPACK_SKIP_ROWS),Va=W.getParameter(W.UNPACK_SKIP_IMAGES);W.pixelStorei(W.UNPACK_ROW_LENGTH,Mn.width),W.pixelStorei(W.UNPACK_IMAGE_HEIGHT,Mn.height),W.pixelStorei(W.UNPACK_SKIP_PIXELS,Zt),W.pixelStorei(W.UNPACK_SKIP_ROWS,me),W.pixelStorei(W.UNPACK_SKIP_IMAGES,ye);const ta=D.isDataArrayTexture||D.isData3DTexture,$e=Y.isDataArrayTexture||Y.isData3DTexture;if(D.isDepthTexture){const Bn=A.get(D),Ri=A.get(Y),Hn=A.get(Bn.__renderTarget),ka=A.get(Ri.__renderTarget);Wt.bindFramebuffer(W.READ_FRAMEBUFFER,Hn.__webglFramebuffer),Wt.bindFramebuffer(W.DRAW_FRAMEBUFFER,ka.__webglFramebuffer);for(let Er=0;Er<jt;Er++)ta&&(W.framebufferTextureLayer(W.READ_FRAMEBUFFER,W.COLOR_ATTACHMENT0,A.get(D).__webglTexture,at,ye+Er),W.framebufferTextureLayer(W.DRAW_FRAMEBUFFER,W.COLOR_ATTACHMENT0,A.get(Y).__webglTexture,Nt,Sn+Er)),W.blitFramebuffer(Zt,me,Bt,Ot,Qt,Re,Bt,Ot,W.DEPTH_BUFFER_BIT,W.NEAREST);Wt.bindFramebuffer(W.READ_FRAMEBUFFER,null),Wt.bindFramebuffer(W.DRAW_FRAMEBUFFER,null)}else if(at!==0||D.isRenderTargetTexture||A.has(D)){const Bn=A.get(D),Ri=A.get(Y);Wt.bindFramebuffer(W.READ_FRAMEBUFFER,di),Wt.bindFramebuffer(W.DRAW_FRAMEBUFFER,Sa);for(let Hn=0;Hn<jt;Hn++)ta?W.framebufferTextureLayer(W.READ_FRAMEBUFFER,W.COLOR_ATTACHMENT0,Bn.__webglTexture,at,ye+Hn):W.framebufferTexture2D(W.READ_FRAMEBUFFER,W.COLOR_ATTACHMENT0,W.TEXTURE_2D,Bn.__webglTexture,at),$e?W.framebufferTextureLayer(W.DRAW_FRAMEBUFFER,W.COLOR_ATTACHMENT0,Ri.__webglTexture,Nt,Sn+Hn):W.framebufferTexture2D(W.DRAW_FRAMEBUFFER,W.COLOR_ATTACHMENT0,W.TEXTURE_2D,Ri.__webglTexture,Nt),at!==0?W.blitFramebuffer(Zt,me,Bt,Ot,Qt,Re,Bt,Ot,W.COLOR_BUFFER_BIT,W.NEAREST):$e?W.copyTexSubImage3D(ne,Nt,Qt,Re,Sn+Hn,Zt,me,Bt,Ot):W.copyTexSubImage2D(ne,Nt,Qt,Re,Zt,me,Bt,Ot);Wt.bindFramebuffer(W.READ_FRAMEBUFFER,null),Wt.bindFramebuffer(W.DRAW_FRAMEBUFFER,null)}else $e?D.isDataTexture||D.isData3DTexture?W.texSubImage3D(ne,Nt,Qt,Re,Sn,Bt,Ot,jt,je,jn,Mn.data):Y.isCompressedArrayTexture?W.compressedTexSubImage3D(ne,Nt,Qt,Re,Sn,Bt,Ot,jt,je,Mn.data):W.texSubImage3D(ne,Nt,Qt,Re,Sn,Bt,Ot,jt,je,jn,Mn):D.isDataTexture?W.texSubImage2D(W.TEXTURE_2D,Nt,Qt,Re,Bt,Ot,je,jn,Mn.data):D.isCompressedTexture?W.compressedTexSubImage2D(W.TEXTURE_2D,Nt,Qt,Re,Mn.width,Mn.height,je,Mn.data):W.texSubImage2D(W.TEXTURE_2D,Nt,Qt,Re,Bt,Ot,je,jn,Mn);W.pixelStorei(W.UNPACK_ROW_LENGTH,Ti),W.pixelStorei(W.UNPACK_IMAGE_HEIGHT,ve),W.pixelStorei(W.UNPACK_SKIP_PIXELS,Ai),W.pixelStorei(W.UNPACK_SKIP_ROWS,$i),W.pixelStorei(W.UNPACK_SKIP_IMAGES,Va),Nt===0&&Y.generateMipmaps&&W.generateMipmap(ne),Wt.unbindTexture()},this.initRenderTarget=function(D){A.get(D).__webglFramebuffer===void 0&&j.setupRenderTarget(D)},this.initTexture=function(D){D.isCubeTexture?j.setTextureCube(D,0):D.isData3DTexture?j.setTexture3D(D,0):D.isDataArrayTexture||D.isCompressedArrayTexture?j.setTexture2DArray(D,0):j.setTexture2D(D,0),Wt.unbindTexture()},this.resetState=function(){G=0,k=0,J=null,Wt.reset(),Ct.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return pr}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const n=this.getContext();n.drawingBufferColorSpace=Ye._getDrawingBufferColorSpace(t),n.unpackColorSpace=Ye._getUnpackColorSpace()}}function kD(){const o=Mi.useRef(null);return Mi.useEffect(()=>{if(!o.current)return;const t=o.current,n=window.innerWidth<768,a=new RR,r=new La(45,t.clientWidth/t.clientHeight,.1,1e3);r.position.z=4;const l=new VD({antialias:!n,alpha:!0});l.setSize(t.clientWidth,t.clientHeight),l.setPixelRatio(n?1:Math.min(window.devicePixelRatio,2)),t.appendChild(l.domElement);const c=new mc;a.add(c);const f=new dd(1.3,n?6:10,n?4:6),p=new Ga({uniforms:{color1:{value:new qe("#00F0FF")},color2:{value:new qe("#B026FF")}},vertexShader:`
            varying vec3 vPos;
            void main() {
                vPos = position;
                gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
            }
        `,fragmentShader:`
            uniform vec3 color1;
            uniform vec3 color2;
            varying vec3 vPos;
            void main() {
                // Gradient scaled to match the new 1.3 radius
                float mixValue = (vPos.y + 1.3) / 2.6; 
                gl_FragColor = vec4(mix(color1, color2, mixValue), 0.85); 
            }
        `,wireframe:!0,transparent:!0}),d=new Ga({uniforms:{color1:{value:new qe("#00F0FF")},color2:{value:new qe("#B026FF")}},vertexShader:`
            varying vec3 vPos;
            void main() {
                vPos = position;
                vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
                // Node size reduced by ~45% (from 25.0 to 13.75)
                gl_PointSize = 13.75 * (5.0 / -mvPosition.z); 
                gl_Position = projectionMatrix * mvPosition;
            }
        `,fragmentShader:`
            uniform vec3 color1;
            uniform vec3 color2;
            varying vec3 vPos;
            void main() {
                // Draw a perfect circle mathematically
                vec2 cxy = 2.0 * gl_PointCoord - 1.0;
                if (dot(cxy, cxy) > 1.0) discard;
                
                float mixValue = (vPos.y + 1.3) / 2.6;
                gl_FragColor = vec4(mix(color1, color2, mixValue), 1.0);
            }
        `,transparent:!0}),_=new $a(f,p),v=new IR(f,d);c.add(_),c.add(v);const g=new dd(.3,16,16),x=new fg({color:61695}),M=new $a(g,x);c.add(M),c.rotation.z=.2,c.rotation.x=.3;let E,y=!0;const S=new IntersectionObserver(C=>{C.forEach(O=>{y=O.isIntersecting})});S.observe(t);function R(){E=requestAnimationFrame(R),y&&(c.rotation.y+=.003,c.rotation.x+=.001,l.render(a,r))}R();const U=()=>{t&&(r.aspect=t.clientWidth/t.clientHeight,r.updateProjectionMatrix(),l.setSize(t.clientWidth,t.clientHeight))};return window.addEventListener("resize",U),()=>{S.disconnect(),window.removeEventListener("resize",U),cancelAnimationFrame(E),t&&t.contains(l.domElement)&&t.removeChild(l.domElement),f.dispose(),g.dispose(),p.dispose(),d.dispose(),x.dispose(),l.dispose()}},[]),tt.jsx("div",{ref:o,className:"w-full h-full absolute inset-0 pointer-events-none",style:{filter:"drop-shadow(0 0 30px rgba(176, 38, 255, 0.15))"}})}/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const XD=o=>o.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),WD=o=>o.replace(/^([A-Z])|[\s-_]+(\w)/g,(t,n,a)=>a?a.toUpperCase():n.toLowerCase()),bM=o=>{const t=WD(o);return t.charAt(0).toUpperCase()+t.slice(1)},W1=(...o)=>o.filter((t,n,a)=>!!t&&t.trim()!==""&&a.indexOf(t)===n).join(" ").trim(),YD=o=>{for(const t in o)if(t.startsWith("aria-")||t==="role"||t==="title")return!0};/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var qD={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const jD=Mi.forwardRef(({color:o="currentColor",size:t=24,strokeWidth:n=2,absoluteStrokeWidth:a,className:r="",children:l,iconNode:c,...f},p)=>Mi.createElement("svg",{ref:p,...qD,width:t,height:t,stroke:o,strokeWidth:a?Number(n)*24/Number(t):n,className:W1("lucide",r),...!l&&!YD(f)&&{"aria-hidden":"true"},...f},[...c.map(([d,_])=>Mi.createElement(d,_)),...Array.isArray(l)?l:[l]]));/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Xo=(o,t)=>{const n=Mi.forwardRef(({className:a,...r},l)=>Mi.createElement(jD,{ref:l,iconNode:t,className:W1(`lucide-${XD(bM(o))}`,`lucide-${o}`,a),...r}));return n.displayName=bM(o),n};/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ZD=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]],TM=Xo("arrow-right",ZD);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const KD=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],QD=Xo("chevron-right",KD);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const JD=[["path",{d:"m18 16 4-4-4-4",key:"1inbqp"}],["path",{d:"m6 8-4 4 4 4",key:"15zrgr"}],["path",{d:"m14.5 4-5 16",key:"e7oirm"}]],$D=Xo("code-xml",JD);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const tU=[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"m9 12 2 2 4-4",key:"dzmm74"}]],eU=Xo("shield-check",tU);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const nU=[["path",{d:"M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",key:"r04s7s"}]],or=Xo("star",nU);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const iU=[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]],aU=Xo("trending-up",iU);/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const rU=[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",key:"1xq2db"}]],sU=Xo("zap",rU);function Yr(o){if(o===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return o}function Y1(o,t){o.prototype=Object.create(t.prototype),o.prototype.constructor=o,o.__proto__=t}/*!
 * GSAP 3.14.2
 * https://gsap.com
 *
 * @license Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
*/var va={autoSleep:120,force3D:"auto",nullTargetWarn:1,units:{lineHeight:""}},ru={duration:.5,overwrite:!1,delay:0},hg,hi,bn,za=1e8,pn=1/za,D0=Math.PI*2,oU=D0/4,lU=0,q1=Math.sqrt,uU=Math.cos,cU=Math.sin,ri=function(t){return typeof t=="string"},Un=function(t){return typeof t=="function"},as=function(t){return typeof t=="number"},dg=function(t){return typeof t>"u"},Mr=function(t){return typeof t=="object"},ji=function(t){return t!==!1},pg=function(){return typeof window<"u"},Oh=function(t){return Un(t)||ri(t)},j1=typeof ArrayBuffer=="function"&&ArrayBuffer.isView||function(){},Ei=Array.isArray,fU=/random\([^)]+\)/g,hU=/,\s*/g,AM=/(?:-?\.?\d|\.)+/gi,Z1=/[-+=.]*\d+[.e\-+]*\d*[e\-+]*\d*/g,kl=/[-+=.]*\d+[.e-]*\d*[a-z%]*/g,M_=/[-+=.]*\d+\.?\d*(?:e-|e\+)?\d*/gi,K1=/[+-]=-?[.\d]+/,dU=/[^,'"\[\]\s]+/gi,pU=/^[+\-=e\s\d]*\d+[.\d]*([a-z]*|%)\s*$/i,Rn,lr,U0,mg,xa={},pd={},Q1,J1=function(t){return(pd=su(t,xa))&&Ji},_g=function(t,n){return console.warn("Invalid property",t,"set to",n,"Missing plugin? gsap.registerPlugin()")},Hc=function(t,n){return!n&&console.warn(t)},$1=function(t,n){return t&&(xa[t]=n)&&pd&&(pd[t]=n)||xa},Gc=function(){return 0},mU={suppressEvents:!0,isStart:!0,kill:!1},td={suppressEvents:!0,kill:!1},_U={suppressEvents:!0},gg={},ks=[],N0={},tE,ha={},E_={},RM=30,ed=[],vg="",xg=function(t){var n=t[0],a,r;if(Mr(n)||Un(n)||(t=[t]),!(a=(n._gsap||{}).harness)){for(r=ed.length;r--&&!ed[r].targetTest(n););a=ed[r]}for(r=t.length;r--;)t[r]&&(t[r]._gsap||(t[r]._gsap=new bE(t[r],a)))||t.splice(r,1);return t},Lo=function(t){return t._gsap||xg(Ia(t))[0]._gsap},eE=function(t,n,a){return(a=t[n])&&Un(a)?t[n]():dg(a)&&t.getAttribute&&t.getAttribute(n)||a},Zi=function(t,n){return(t=t.split(",")).forEach(n)||t},On=function(t){return Math.round(t*1e5)/1e5||0},An=function(t){return Math.round(t*1e7)/1e7||0},jl=function(t,n){var a=n.charAt(0),r=parseFloat(n.substr(2));return t=parseFloat(t),a==="+"?t+r:a==="-"?t-r:a==="*"?t*r:t/r},gU=function(t,n){for(var a=n.length,r=0;t.indexOf(n[r])<0&&++r<a;);return r<a},md=function(){var t=ks.length,n=ks.slice(0),a,r;for(N0={},ks.length=0,a=0;a<t;a++)r=n[a],r&&r._lazy&&(r.render(r._lazy[0],r._lazy[1],!0)._lazy=0)},yg=function(t){return!!(t._initted||t._startAt||t.add)},nE=function(t,n,a,r){ks.length&&!hi&&md(),t.render(n,a,!!(hi&&n<0&&yg(t))),ks.length&&!hi&&md()},iE=function(t){var n=parseFloat(t);return(n||n===0)&&(t+"").match(dU).length<2?n:ri(t)?t.trim():t},aE=function(t){return t},ya=function(t,n){for(var a in n)a in t||(t[a]=n[a]);return t},vU=function(t){return function(n,a){for(var r in a)r in n||r==="duration"&&t||r==="ease"||(n[r]=a[r])}},su=function(t,n){for(var a in n)t[a]=n[a];return t},CM=function o(t,n){for(var a in n)a!=="__proto__"&&a!=="constructor"&&a!=="prototype"&&(t[a]=Mr(n[a])?o(t[a]||(t[a]={}),n[a]):n[a]);return t},_d=function(t,n){var a={},r;for(r in t)r in n||(a[r]=t[r]);return a},bc=function(t){var n=t.parent||Rn,a=t.keyframes?vU(Ei(t.keyframes)):ya;if(ji(t.inherit))for(;n;)a(t,n.vars.defaults),n=n.parent||n._dp;return t},xU=function(t,n){for(var a=t.length,r=a===n.length;r&&a--&&t[a]===n[a];);return a<0},rE=function(t,n,a,r,l){var c=t[r],f;if(l)for(f=n[l];c&&c[l]>f;)c=c._prev;return c?(n._next=c._next,c._next=n):(n._next=t[a],t[a]=n),n._next?n._next._prev=n:t[r]=n,n._prev=c,n.parent=n._dp=t,n},Dd=function(t,n,a,r){a===void 0&&(a="_first"),r===void 0&&(r="_last");var l=n._prev,c=n._next;l?l._next=c:t[a]===n&&(t[a]=c),c?c._prev=l:t[r]===n&&(t[r]=l),n._next=n._prev=n.parent=null},qs=function(t,n){t.parent&&(!n||t.parent.autoRemoveChildren)&&t.parent.remove&&t.parent.remove(t),t._act=0},Oo=function(t,n){if(t&&(!n||n._end>t._dur||n._start<0))for(var a=t;a;)a._dirty=1,a=a.parent;return t},yU=function(t){for(var n=t.parent;n&&n.parent;)n._dirty=1,n.totalDuration(),n=n.parent;return t},L0=function(t,n,a,r){return t._startAt&&(hi?t._startAt.revert(td):t.vars.immediateRender&&!t.vars.autoRevert||t._startAt.render(n,!0,r))},SU=function o(t){return!t||t._ts&&o(t.parent)},wM=function(t){return t._repeat?ou(t._tTime,t=t.duration()+t._rDelay)*t:0},ou=function(t,n){var a=Math.floor(t=An(t/n));return t&&a===t?a-1:a},gd=function(t,n){return(t-n._start)*n._ts+(n._ts>=0?0:n._dirty?n.totalDuration():n._tDur)},Ud=function(t){return t._end=An(t._start+(t._tDur/Math.abs(t._ts||t._rts||pn)||0))},Nd=function(t,n){var a=t._dp;return a&&a.smoothChildTiming&&t._ts&&(t._start=An(a._time-(t._ts>0?n/t._ts:((t._dirty?t.totalDuration():t._tDur)-n)/-t._ts)),Ud(t),a._dirty||Oo(a,t)),t},sE=function(t,n){var a;if((n._time||!n._dur&&n._initted||n._start<t._time&&(n._dur||!n.add))&&(a=gd(t.rawTime(),n),(!n._dur||$c(0,n.totalDuration(),a)-n._tTime>pn)&&n.render(a,!0)),Oo(t,n)._dp&&t._initted&&t._time>=t._dur&&t._ts){if(t._dur<t.duration())for(a=t;a._dp;)a.rawTime()>=0&&a.totalTime(a._tTime),a=a._dp;t._zTime=-pn}},hr=function(t,n,a,r){return n.parent&&qs(n),n._start=An((as(a)?a:a||t!==Rn?Ua(t,a,n):t._time)+n._delay),n._end=An(n._start+(n.totalDuration()/Math.abs(n.timeScale())||0)),rE(t,n,"_first","_last",t._sort?"_start":0),O0(n)||(t._recent=n),r||sE(t,n),t._ts<0&&Nd(t,t._tTime),t},oE=function(t,n){return(xa.ScrollTrigger||_g("scrollTrigger",n))&&xa.ScrollTrigger.create(n,t)},lE=function(t,n,a,r,l){if(Mg(t,n,l),!t._initted)return 1;if(!a&&t._pt&&!hi&&(t._dur&&t.vars.lazy!==!1||!t._dur&&t.vars.lazy)&&tE!==pa.frame)return ks.push(t),t._lazy=[l,r],1},MU=function o(t){var n=t.parent;return n&&n._ts&&n._initted&&!n._lock&&(n.rawTime()<0||o(n))},O0=function(t){var n=t.data;return n==="isFromStart"||n==="isStart"},EU=function(t,n,a,r){var l=t.ratio,c=n<0||!n&&(!t._start&&MU(t)&&!(!t._initted&&O0(t))||(t._ts<0||t._dp._ts<0)&&!O0(t))?0:1,f=t._rDelay,p=0,d,_,v;if(f&&t._repeat&&(p=$c(0,t._tDur,n),_=ou(p,f),t._yoyo&&_&1&&(c=1-c),_!==ou(t._tTime,f)&&(l=1-c,t.vars.repeatRefresh&&t._initted&&t.invalidate())),c!==l||hi||r||t._zTime===pn||!n&&t._zTime){if(!t._initted&&lE(t,n,r,a,p))return;for(v=t._zTime,t._zTime=n||(a?pn:0),a||(a=n&&!v),t.ratio=c,t._from&&(c=1-c),t._time=0,t._tTime=p,d=t._pt;d;)d.r(c,d.d),d=d._next;n<0&&L0(t,n,a,!0),t._onUpdate&&!a&&_a(t,"onUpdate"),p&&t._repeat&&!a&&t.parent&&_a(t,"onRepeat"),(n>=t._tDur||n<0)&&t.ratio===c&&(c&&qs(t,1),!a&&!hi&&(_a(t,c?"onComplete":"onReverseComplete",!0),t._prom&&t._prom()))}else t._zTime||(t._zTime=n)},bU=function(t,n,a){var r;if(a>n)for(r=t._first;r&&r._start<=a;){if(r.data==="isPause"&&r._start>n)return r;r=r._next}else for(r=t._last;r&&r._start>=a;){if(r.data==="isPause"&&r._start<n)return r;r=r._prev}},lu=function(t,n,a,r){var l=t._repeat,c=An(n)||0,f=t._tTime/t._tDur;return f&&!r&&(t._time*=c/t._dur),t._dur=c,t._tDur=l?l<0?1e10:An(c*(l+1)+t._rDelay*l):c,f>0&&!r&&Nd(t,t._tTime=t._tDur*f),t.parent&&Ud(t),a||Oo(t.parent,t),t},DM=function(t){return t instanceof Pi?Oo(t):lu(t,t._dur)},TU={_start:0,endTime:Gc,totalDuration:Gc},Ua=function o(t,n,a){var r=t.labels,l=t._recent||TU,c=t.duration()>=za?l.endTime(!1):t._dur,f,p,d;return ri(n)&&(isNaN(n)||n in r)?(p=n.charAt(0),d=n.substr(-1)==="%",f=n.indexOf("="),p==="<"||p===">"?(f>=0&&(n=n.replace(/=/,"")),(p==="<"?l._start:l.endTime(l._repeat>=0))+(parseFloat(n.substr(1))||0)*(d?(f<0?l:a).totalDuration()/100:1)):f<0?(n in r||(r[n]=c),r[n]):(p=parseFloat(n.charAt(f-1)+n.substr(f+1)),d&&a&&(p=p/100*(Ei(a)?a[0]:a).totalDuration()),f>1?o(t,n.substr(0,f-1),a)+p:c+p)):n==null?c:+n},Tc=function(t,n,a){var r=as(n[1]),l=(r?2:1)+(t<2?0:1),c=n[l],f,p;if(r&&(c.duration=n[1]),c.parent=a,t){for(f=c,p=a;p&&!("immediateRender"in f);)f=p.vars.defaults||{},p=ji(p.vars.inherit)&&p.parent;c.immediateRender=ji(f.immediateRender),t<2?c.runBackwards=1:c.startAt=n[l-1]}return new qn(n[0],c,n[l+1])},Qs=function(t,n){return t||t===0?n(t):n},$c=function(t,n,a){return a<t?t:a>n?n:a},xi=function(t,n){return!ri(t)||!(n=pU.exec(t))?"":n[1]},AU=function(t,n,a){return Qs(a,function(r){return $c(t,n,r)})},P0=[].slice,uE=function(t,n){return t&&Mr(t)&&"length"in t&&(!n&&!t.length||t.length-1 in t&&Mr(t[0]))&&!t.nodeType&&t!==lr},RU=function(t,n,a){return a===void 0&&(a=[]),t.forEach(function(r){var l;return ri(r)&&!n||uE(r,1)?(l=a).push.apply(l,Ia(r)):a.push(r)})||a},Ia=function(t,n,a){return bn&&!n&&bn.selector?bn.selector(t):ri(t)&&!a&&(U0||!uu())?P0.call((n||mg).querySelectorAll(t),0):Ei(t)?RU(t,a):uE(t)?P0.call(t,0):t?[t]:[]},F0=function(t){return t=Ia(t)[0]||Hc("Invalid scope")||{},function(n){var a=t.current||t.nativeElement||t;return Ia(n,a.querySelectorAll?a:a===t?Hc("Invalid scope")||mg.createElement("div"):t)}},cE=function(t){return t.sort(function(){return .5-Math.random()})},fE=function(t){if(Un(t))return t;var n=Mr(t)?t:{each:t},a=Po(n.ease),r=n.from||0,l=parseFloat(n.base)||0,c={},f=r>0&&r<1,p=isNaN(r)||f,d=n.axis,_=r,v=r;return ri(r)?_=v={center:.5,edges:.5,end:1}[r]||0:!f&&p&&(_=r[0],v=r[1]),function(g,x,M){var E=(M||n).length,y=c[E],S,R,U,C,O,P,L,T,w;if(!y){if(w=n.grid==="auto"?0:(n.grid||[1,za])[1],!w){for(L=-za;L<(L=M[w++].getBoundingClientRect().left)&&w<E;);w<E&&w--}for(y=c[E]=[],S=p?Math.min(w,E)*_-.5:r%w,R=w===za?0:p?E*v/w-.5:r/w|0,L=0,T=za,P=0;P<E;P++)U=P%w-S,C=R-(P/w|0),y[P]=O=d?Math.abs(d==="y"?C:U):q1(U*U+C*C),O>L&&(L=O),O<T&&(T=O);r==="random"&&cE(y),y.max=L-T,y.min=T,y.v=E=(parseFloat(n.amount)||parseFloat(n.each)*(w>E?E-1:d?d==="y"?E/w:w:Math.max(w,E/w))||0)*(r==="edges"?-1:1),y.b=E<0?l-E:l,y.u=xi(n.amount||n.each)||0,a=a&&E<0?SE(a):a}return E=(y[g]-y.min)/y.max||0,An(y.b+(a?a(E):E)*y.v)+y.u}},z0=function(t){var n=Math.pow(10,((t+"").split(".")[1]||"").length);return function(a){var r=An(Math.round(parseFloat(a)/t)*t*n);return(r-r%1)/n+(as(a)?0:xi(a))}},hE=function(t,n){var a=Ei(t),r,l;return!a&&Mr(t)&&(r=a=t.radius||za,t.values?(t=Ia(t.values),(l=!as(t[0]))&&(r*=r)):t=z0(t.increment)),Qs(n,a?Un(t)?function(c){return l=t(c),Math.abs(l-c)<=r?l:c}:function(c){for(var f=parseFloat(l?c.x:c),p=parseFloat(l?c.y:0),d=za,_=0,v=t.length,g,x;v--;)l?(g=t[v].x-f,x=t[v].y-p,g=g*g+x*x):g=Math.abs(t[v]-f),g<d&&(d=g,_=v);return _=!r||d<=r?t[_]:c,l||_===c||as(c)?_:_+xi(c)}:z0(t))},dE=function(t,n,a,r){return Qs(Ei(t)?!n:a===!0?!!(a=0):!r,function(){return Ei(t)?t[~~(Math.random()*t.length)]:(a=a||1e-5)&&(r=a<1?Math.pow(10,(a+"").length-2):1)&&Math.floor(Math.round((t-a/2+Math.random()*(n-t+a*.99))/a)*a*r)/r})},CU=function(){for(var t=arguments.length,n=new Array(t),a=0;a<t;a++)n[a]=arguments[a];return function(r){return n.reduce(function(l,c){return c(l)},r)}},wU=function(t,n){return function(a){return t(parseFloat(a))+(n||xi(a))}},DU=function(t,n,a){return mE(t,n,0,1,a)},pE=function(t,n,a){return Qs(a,function(r){return t[~~n(r)]})},UU=function o(t,n,a){var r=n-t;return Ei(t)?pE(t,o(0,t.length),n):Qs(a,function(l){return(r+(l-t)%r)%r+t})},NU=function o(t,n,a){var r=n-t,l=r*2;return Ei(t)?pE(t,o(0,t.length-1),n):Qs(a,function(c){return c=(l+(c-t)%l)%l||0,t+(c>r?l-c:c)})},Vc=function(t){return t.replace(fU,function(n){var a=n.indexOf("[")+1,r=n.substring(a||7,a?n.indexOf("]"):n.length-1).split(hU);return dE(a?r:+r[0],a?0:+r[1],+r[2]||1e-5)})},mE=function(t,n,a,r,l){var c=n-t,f=r-a;return Qs(l,function(p){return a+((p-t)/c*f||0)})},LU=function o(t,n,a,r){var l=isNaN(t+n)?0:function(x){return(1-x)*t+x*n};if(!l){var c=ri(t),f={},p,d,_,v,g;if(a===!0&&(r=1)&&(a=null),c)t={p:t},n={p:n};else if(Ei(t)&&!Ei(n)){for(_=[],v=t.length,g=v-2,d=1;d<v;d++)_.push(o(t[d-1],t[d]));v--,l=function(M){M*=v;var E=Math.min(g,~~M);return _[E](M-E)},a=n}else r||(t=su(Ei(t)?[]:{},t));if(!_){for(p in n)Sg.call(f,t,p,"get",n[p]);l=function(M){return Tg(M,f)||(c?t.p:t)}}}return Qs(a,l)},UM=function(t,n,a){var r=t.labels,l=za,c,f,p;for(c in r)f=r[c]-n,f<0==!!a&&f&&l>(f=Math.abs(f))&&(p=c,l=f);return p},_a=function(t,n,a){var r=t.vars,l=r[n],c=bn,f=t._ctx,p,d,_;if(l)return p=r[n+"Params"],d=r.callbackScope||t,a&&ks.length&&md(),f&&(bn=f),_=p?l.apply(d,p):l.call(d),bn=c,_},gc=function(t){return qs(t),t.scrollTrigger&&t.scrollTrigger.kill(!!hi),t.progress()<1&&_a(t,"onInterrupt"),t},Xl,_E=[],gE=function(t){if(t)if(t=!t.name&&t.default||t,pg()||t.headless){var n=t.name,a=Un(t),r=n&&!a&&t.init?function(){this._props=[]}:t,l={init:Gc,render:Tg,add:Sg,kill:ZU,modifier:jU,rawVars:0},c={targetTest:0,get:0,getSetter:bg,aliases:{},register:0};if(uu(),t!==r){if(ha[n])return;ya(r,ya(_d(t,l),c)),su(r.prototype,su(l,_d(t,c))),ha[r.prop=n]=r,t.targetTest&&(ed.push(r),gg[n]=1),n=(n==="css"?"CSS":n.charAt(0).toUpperCase()+n.substr(1))+"Plugin"}$1(n,r),t.register&&t.register(Ji,r,Ki)}else _E.push(t)},dn=255,vc={aqua:[0,dn,dn],lime:[0,dn,0],silver:[192,192,192],black:[0,0,0],maroon:[128,0,0],teal:[0,128,128],blue:[0,0,dn],navy:[0,0,128],white:[dn,dn,dn],olive:[128,128,0],yellow:[dn,dn,0],orange:[dn,165,0],gray:[128,128,128],purple:[128,0,128],green:[0,128,0],red:[dn,0,0],pink:[dn,192,203],cyan:[0,dn,dn],transparent:[dn,dn,dn,0]},b_=function(t,n,a){return t+=t<0?1:t>1?-1:0,(t*6<1?n+(a-n)*t*6:t<.5?a:t*3<2?n+(a-n)*(2/3-t)*6:n)*dn+.5|0},vE=function(t,n,a){var r=t?as(t)?[t>>16,t>>8&dn,t&dn]:0:vc.black,l,c,f,p,d,_,v,g,x,M;if(!r){if(t.substr(-1)===","&&(t=t.substr(0,t.length-1)),vc[t])r=vc[t];else if(t.charAt(0)==="#"){if(t.length<6&&(l=t.charAt(1),c=t.charAt(2),f=t.charAt(3),t="#"+l+l+c+c+f+f+(t.length===5?t.charAt(4)+t.charAt(4):"")),t.length===9)return r=parseInt(t.substr(1,6),16),[r>>16,r>>8&dn,r&dn,parseInt(t.substr(7),16)/255];t=parseInt(t.substr(1),16),r=[t>>16,t>>8&dn,t&dn]}else if(t.substr(0,3)==="hsl"){if(r=M=t.match(AM),!n)p=+r[0]%360/360,d=+r[1]/100,_=+r[2]/100,c=_<=.5?_*(d+1):_+d-_*d,l=_*2-c,r.length>3&&(r[3]*=1),r[0]=b_(p+1/3,l,c),r[1]=b_(p,l,c),r[2]=b_(p-1/3,l,c);else if(~t.indexOf("="))return r=t.match(Z1),a&&r.length<4&&(r[3]=1),r}else r=t.match(AM)||vc.transparent;r=r.map(Number)}return n&&!M&&(l=r[0]/dn,c=r[1]/dn,f=r[2]/dn,v=Math.max(l,c,f),g=Math.min(l,c,f),_=(v+g)/2,v===g?p=d=0:(x=v-g,d=_>.5?x/(2-v-g):x/(v+g),p=v===l?(c-f)/x+(c<f?6:0):v===c?(f-l)/x+2:(l-c)/x+4,p*=60),r[0]=~~(p+.5),r[1]=~~(d*100+.5),r[2]=~~(_*100+.5)),a&&r.length<4&&(r[3]=1),r},xE=function(t){var n=[],a=[],r=-1;return t.split(Xs).forEach(function(l){var c=l.match(kl)||[];n.push.apply(n,c),a.push(r+=c.length+1)}),n.c=a,n},NM=function(t,n,a){var r="",l=(t+r).match(Xs),c=n?"hsla(":"rgba(",f=0,p,d,_,v;if(!l)return t;if(l=l.map(function(g){return(g=vE(g,n,1))&&c+(n?g[0]+","+g[1]+"%,"+g[2]+"%,"+g[3]:g.join(","))+")"}),a&&(_=xE(t),p=a.c,p.join(r)!==_.c.join(r)))for(d=t.replace(Xs,"1").split(kl),v=d.length-1;f<v;f++)r+=d[f]+(~p.indexOf(f)?l.shift()||c+"0,0,0,0)":(_.length?_:l.length?l:a).shift());if(!d)for(d=t.split(Xs),v=d.length-1;f<v;f++)r+=d[f]+l[f];return r+d[v]},Xs=(function(){var o="(?:\\b(?:(?:rgb|rgba|hsl|hsla)\\(.+?\\))|\\B#(?:[0-9a-f]{3,4}){1,2}\\b",t;for(t in vc)o+="|"+t+"\\b";return new RegExp(o+")","gi")})(),OU=/hsl[a]?\(/,yE=function(t){var n=t.join(" "),a;if(Xs.lastIndex=0,Xs.test(n))return a=OU.test(n),t[1]=NM(t[1],a),t[0]=NM(t[0],a,xE(t[1])),!0},kc,pa=(function(){var o=Date.now,t=500,n=33,a=o(),r=a,l=1e3/240,c=l,f=[],p,d,_,v,g,x,M=function E(y){var S=o()-r,R=y===!0,U,C,O,P;if((S>t||S<0)&&(a+=S-n),r+=S,O=r-a,U=O-c,(U>0||R)&&(P=++v.frame,g=O-v.time*1e3,v.time=O=O/1e3,c+=U+(U>=l?4:l-U),C=1),R||(p=d(E)),C)for(x=0;x<f.length;x++)f[x](O,g,P,y)};return v={time:0,frame:0,tick:function(){M(!0)},deltaRatio:function(y){return g/(1e3/(y||60))},wake:function(){Q1&&(!U0&&pg()&&(lr=U0=window,mg=lr.document||{},xa.gsap=Ji,(lr.gsapVersions||(lr.gsapVersions=[])).push(Ji.version),J1(pd||lr.GreenSockGlobals||!lr.gsap&&lr||{}),_E.forEach(gE)),_=typeof requestAnimationFrame<"u"&&requestAnimationFrame,p&&v.sleep(),d=_||function(y){return setTimeout(y,c-v.time*1e3+1|0)},kc=1,M(2))},sleep:function(){(_?cancelAnimationFrame:clearTimeout)(p),kc=0,d=Gc},lagSmoothing:function(y,S){t=y||1/0,n=Math.min(S||33,t)},fps:function(y){l=1e3/(y||240),c=v.time*1e3+l},add:function(y,S,R){var U=S?function(C,O,P,L){y(C,O,P,L),v.remove(U)}:y;return v.remove(y),f[R?"unshift":"push"](U),uu(),U},remove:function(y,S){~(S=f.indexOf(y))&&f.splice(S,1)&&x>=S&&x--},_listeners:f},v})(),uu=function(){return!kc&&pa.wake()},Xe={},PU=/^[\d.\-M][\d.\-,\s]/,FU=/["']/g,zU=function(t){for(var n={},a=t.substr(1,t.length-3).split(":"),r=a[0],l=1,c=a.length,f,p,d;l<c;l++)p=a[l],f=l!==c-1?p.lastIndexOf(","):p.length,d=p.substr(0,f),n[r]=isNaN(d)?d.replace(FU,"").trim():+d,r=p.substr(f+1).trim();return n},IU=function(t){var n=t.indexOf("(")+1,a=t.indexOf(")"),r=t.indexOf("(",n);return t.substring(n,~r&&r<a?t.indexOf(")",a+1):a)},BU=function(t){var n=(t+"").split("("),a=Xe[n[0]];return a&&n.length>1&&a.config?a.config.apply(null,~t.indexOf("{")?[zU(n[1])]:IU(t).split(",").map(iE)):Xe._CE&&PU.test(t)?Xe._CE("",t):a},SE=function(t){return function(n){return 1-t(1-n)}},ME=function o(t,n){for(var a=t._first,r;a;)a instanceof Pi?o(a,n):a.vars.yoyoEase&&(!a._yoyo||!a._repeat)&&a._yoyo!==n&&(a.timeline?o(a.timeline,n):(r=a._ease,a._ease=a._yEase,a._yEase=r,a._yoyo=n)),a=a._next},Po=function(t,n){return t&&(Un(t)?t:Xe[t]||BU(t))||n},Wo=function(t,n,a,r){a===void 0&&(a=function(p){return 1-n(1-p)}),r===void 0&&(r=function(p){return p<.5?n(p*2)/2:1-n((1-p)*2)/2});var l={easeIn:n,easeOut:a,easeInOut:r},c;return Zi(t,function(f){Xe[f]=xa[f]=l,Xe[c=f.toLowerCase()]=a;for(var p in l)Xe[c+(p==="easeIn"?".in":p==="easeOut"?".out":".inOut")]=Xe[f+"."+p]=l[p]}),l},EE=function(t){return function(n){return n<.5?(1-t(1-n*2))/2:.5+t((n-.5)*2)/2}},T_=function o(t,n,a){var r=n>=1?n:1,l=(a||(t?.3:.45))/(n<1?n:1),c=l/D0*(Math.asin(1/r)||0),f=function(_){return _===1?1:r*Math.pow(2,-10*_)*cU((_-c)*l)+1},p=t==="out"?f:t==="in"?function(d){return 1-f(1-d)}:EE(f);return l=D0/l,p.config=function(d,_){return o(t,d,_)},p},A_=function o(t,n){n===void 0&&(n=1.70158);var a=function(c){return c?--c*c*((n+1)*c+n)+1:0},r=t==="out"?a:t==="in"?function(l){return 1-a(1-l)}:EE(a);return r.config=function(l){return o(t,l)},r};Zi("Linear,Quad,Cubic,Quart,Quint,Strong",function(o,t){var n=t<5?t+1:t;Wo(o+",Power"+(n-1),t?function(a){return Math.pow(a,n)}:function(a){return a},function(a){return 1-Math.pow(1-a,n)},function(a){return a<.5?Math.pow(a*2,n)/2:1-Math.pow((1-a)*2,n)/2})});Xe.Linear.easeNone=Xe.none=Xe.Linear.easeIn;Wo("Elastic",T_("in"),T_("out"),T_());(function(o,t){var n=1/t,a=2*n,r=2.5*n,l=function(f){return f<n?o*f*f:f<a?o*Math.pow(f-1.5/t,2)+.75:f<r?o*(f-=2.25/t)*f+.9375:o*Math.pow(f-2.625/t,2)+.984375};Wo("Bounce",function(c){return 1-l(1-c)},l)})(7.5625,2.75);Wo("Expo",function(o){return Math.pow(2,10*(o-1))*o+o*o*o*o*o*o*(1-o)});Wo("Circ",function(o){return-(q1(1-o*o)-1)});Wo("Sine",function(o){return o===1?1:-uU(o*oU)+1});Wo("Back",A_("in"),A_("out"),A_());Xe.SteppedEase=Xe.steps=xa.SteppedEase={config:function(t,n){t===void 0&&(t=1);var a=1/t,r=t+(n?0:1),l=n?1:0,c=1-pn;return function(f){return((r*$c(0,c,f)|0)+l)*a}}};ru.ease=Xe["quad.out"];Zi("onComplete,onUpdate,onStart,onRepeat,onReverseComplete,onInterrupt",function(o){return vg+=o+","+o+"Params,"});var bE=function(t,n){this.id=lU++,t._gsap=this,this.target=t,this.harness=n,this.get=n?n.get:eE,this.set=n?n.getSetter:bg},Xc=(function(){function o(n){this.vars=n,this._delay=+n.delay||0,(this._repeat=n.repeat===1/0?-2:n.repeat||0)&&(this._rDelay=n.repeatDelay||0,this._yoyo=!!n.yoyo||!!n.yoyoEase),this._ts=1,lu(this,+n.duration,1,1),this.data=n.data,bn&&(this._ctx=bn,bn.data.push(this)),kc||pa.wake()}var t=o.prototype;return t.delay=function(a){return a||a===0?(this.parent&&this.parent.smoothChildTiming&&this.startTime(this._start+a-this._delay),this._delay=a,this):this._delay},t.duration=function(a){return arguments.length?this.totalDuration(this._repeat>0?a+(a+this._rDelay)*this._repeat:a):this.totalDuration()&&this._dur},t.totalDuration=function(a){return arguments.length?(this._dirty=0,lu(this,this._repeat<0?a:(a-this._repeat*this._rDelay)/(this._repeat+1))):this._tDur},t.totalTime=function(a,r){if(uu(),!arguments.length)return this._tTime;var l=this._dp;if(l&&l.smoothChildTiming&&this._ts){for(Nd(this,a),!l._dp||l.parent||sE(l,this);l&&l.parent;)l.parent._time!==l._start+(l._ts>=0?l._tTime/l._ts:(l.totalDuration()-l._tTime)/-l._ts)&&l.totalTime(l._tTime,!0),l=l.parent;!this.parent&&this._dp.autoRemoveChildren&&(this._ts>0&&a<this._tDur||this._ts<0&&a>0||!this._tDur&&!a)&&hr(this._dp,this,this._start-this._delay)}return(this._tTime!==a||!this._dur&&!r||this._initted&&Math.abs(this._zTime)===pn||!this._initted&&this._dur&&a||!a&&!this._initted&&(this.add||this._ptLookup))&&(this._ts||(this._pTime=a),nE(this,a,r)),this},t.time=function(a,r){return arguments.length?this.totalTime(Math.min(this.totalDuration(),a+wM(this))%(this._dur+this._rDelay)||(a?this._dur:0),r):this._time},t.totalProgress=function(a,r){return arguments.length?this.totalTime(this.totalDuration()*a,r):this.totalDuration()?Math.min(1,this._tTime/this._tDur):this.rawTime()>=0&&this._initted?1:0},t.progress=function(a,r){return arguments.length?this.totalTime(this.duration()*(this._yoyo&&!(this.iteration()&1)?1-a:a)+wM(this),r):this.duration()?Math.min(1,this._time/this._dur):this.rawTime()>0?1:0},t.iteration=function(a,r){var l=this.duration()+this._rDelay;return arguments.length?this.totalTime(this._time+(a-1)*l,r):this._repeat?ou(this._tTime,l)+1:1},t.timeScale=function(a,r){if(!arguments.length)return this._rts===-pn?0:this._rts;if(this._rts===a)return this;var l=this.parent&&this._ts?gd(this.parent._time,this):this._tTime;return this._rts=+a||0,this._ts=this._ps||a===-pn?0:this._rts,this.totalTime($c(-Math.abs(this._delay),this.totalDuration(),l),r!==!1),Ud(this),yU(this)},t.paused=function(a){return arguments.length?(this._ps!==a&&(this._ps=a,a?(this._pTime=this._tTime||Math.max(-this._delay,this.rawTime()),this._ts=this._act=0):(uu(),this._ts=this._rts,this.totalTime(this.parent&&!this.parent.smoothChildTiming?this.rawTime():this._tTime||this._pTime,this.progress()===1&&Math.abs(this._zTime)!==pn&&(this._tTime-=pn)))),this):this._ps},t.startTime=function(a){if(arguments.length){this._start=An(a);var r=this.parent||this._dp;return r&&(r._sort||!this.parent)&&hr(r,this,this._start-this._delay),this}return this._start},t.endTime=function(a){return this._start+(ji(a)?this.totalDuration():this.duration())/Math.abs(this._ts||1)},t.rawTime=function(a){var r=this.parent||this._dp;return r?a&&(!this._ts||this._repeat&&this._time&&this.totalProgress()<1)?this._tTime%(this._dur+this._rDelay):this._ts?gd(r.rawTime(a),this):this._tTime:this._tTime},t.revert=function(a){a===void 0&&(a=_U);var r=hi;return hi=a,yg(this)&&(this.timeline&&this.timeline.revert(a),this.totalTime(-.01,a.suppressEvents)),this.data!=="nested"&&a.kill!==!1&&this.kill(),hi=r,this},t.globalTime=function(a){for(var r=this,l=arguments.length?a:r.rawTime();r;)l=r._start+l/(Math.abs(r._ts)||1),r=r._dp;return!this.parent&&this._sat?this._sat.globalTime(a):l},t.repeat=function(a){return arguments.length?(this._repeat=a===1/0?-2:a,DM(this)):this._repeat===-2?1/0:this._repeat},t.repeatDelay=function(a){if(arguments.length){var r=this._time;return this._rDelay=a,DM(this),r?this.time(r):this}return this._rDelay},t.yoyo=function(a){return arguments.length?(this._yoyo=a,this):this._yoyo},t.seek=function(a,r){return this.totalTime(Ua(this,a),ji(r))},t.restart=function(a,r){return this.play().totalTime(a?-this._delay:0,ji(r)),this._dur||(this._zTime=-pn),this},t.play=function(a,r){return a!=null&&this.seek(a,r),this.reversed(!1).paused(!1)},t.reverse=function(a,r){return a!=null&&this.seek(a||this.totalDuration(),r),this.reversed(!0).paused(!1)},t.pause=function(a,r){return a!=null&&this.seek(a,r),this.paused(!0)},t.resume=function(){return this.paused(!1)},t.reversed=function(a){return arguments.length?(!!a!==this.reversed()&&this.timeScale(-this._rts||(a?-pn:0)),this):this._rts<0},t.invalidate=function(){return this._initted=this._act=0,this._zTime=-pn,this},t.isActive=function(){var a=this.parent||this._dp,r=this._start,l;return!!(!a||this._ts&&this._initted&&a.isActive()&&(l=a.rawTime(!0))>=r&&l<this.endTime(!0)-pn)},t.eventCallback=function(a,r,l){var c=this.vars;return arguments.length>1?(r?(c[a]=r,l&&(c[a+"Params"]=l),a==="onUpdate"&&(this._onUpdate=r)):delete c[a],this):c[a]},t.then=function(a){var r=this,l=r._prom;return new Promise(function(c){var f=Un(a)?a:aE,p=function(){var _=r.then;r.then=null,l&&l(),Un(f)&&(f=f(r))&&(f.then||f===r)&&(r.then=_),c(f),r.then=_};r._initted&&r.totalProgress()===1&&r._ts>=0||!r._tTime&&r._ts<0?p():r._prom=p})},t.kill=function(){gc(this)},o})();ya(Xc.prototype,{_time:0,_start:0,_end:0,_tTime:0,_tDur:0,_dirty:0,_repeat:0,_yoyo:!1,parent:null,_initted:!1,_rDelay:0,_ts:1,_dp:0,ratio:0,_zTime:-pn,_prom:0,_ps:!1,_rts:1});var Pi=(function(o){Y1(t,o);function t(a,r){var l;return a===void 0&&(a={}),l=o.call(this,a)||this,l.labels={},l.smoothChildTiming=!!a.smoothChildTiming,l.autoRemoveChildren=!!a.autoRemoveChildren,l._sort=ji(a.sortChildren),Rn&&hr(a.parent||Rn,Yr(l),r),a.reversed&&l.reverse(),a.paused&&l.paused(!0),a.scrollTrigger&&oE(Yr(l),a.scrollTrigger),l}var n=t.prototype;return n.to=function(r,l,c){return Tc(0,arguments,this),this},n.from=function(r,l,c){return Tc(1,arguments,this),this},n.fromTo=function(r,l,c,f){return Tc(2,arguments,this),this},n.set=function(r,l,c){return l.duration=0,l.parent=this,bc(l).repeatDelay||(l.repeat=0),l.immediateRender=!!l.immediateRender,new qn(r,l,Ua(this,c),1),this},n.call=function(r,l,c){return hr(this,qn.delayedCall(0,r,l),c)},n.staggerTo=function(r,l,c,f,p,d,_){return c.duration=l,c.stagger=c.stagger||f,c.onComplete=d,c.onCompleteParams=_,c.parent=this,new qn(r,c,Ua(this,p)),this},n.staggerFrom=function(r,l,c,f,p,d,_){return c.runBackwards=1,bc(c).immediateRender=ji(c.immediateRender),this.staggerTo(r,l,c,f,p,d,_)},n.staggerFromTo=function(r,l,c,f,p,d,_,v){return f.startAt=c,bc(f).immediateRender=ji(f.immediateRender),this.staggerTo(r,l,f,p,d,_,v)},n.render=function(r,l,c){var f=this._time,p=this._dirty?this.totalDuration():this._tDur,d=this._dur,_=r<=0?0:An(r),v=this._zTime<0!=r<0&&(this._initted||!d),g,x,M,E,y,S,R,U,C,O,P,L;if(this!==Rn&&_>p&&r>=0&&(_=p),_!==this._tTime||c||v){if(f!==this._time&&d&&(_+=this._time-f,r+=this._time-f),g=_,C=this._start,U=this._ts,S=!U,v&&(d||(f=this._zTime),(r||!l)&&(this._zTime=r)),this._repeat){if(P=this._yoyo,y=d+this._rDelay,this._repeat<-1&&r<0)return this.totalTime(y*100+r,l,c);if(g=An(_%y),_===p?(E=this._repeat,g=d):(O=An(_/y),E=~~O,E&&E===O&&(g=d,E--),g>d&&(g=d)),O=ou(this._tTime,y),!f&&this._tTime&&O!==E&&this._tTime-O*y-this._dur<=0&&(O=E),P&&E&1&&(g=d-g,L=1),E!==O&&!this._lock){var T=P&&O&1,w=T===(P&&E&1);if(E<O&&(T=!T),f=T?0:_%d?d:_,this._lock=1,this.render(f||(L?0:An(E*y)),l,!d)._lock=0,this._tTime=_,!l&&this.parent&&_a(this,"onRepeat"),this.vars.repeatRefresh&&!L&&(this.invalidate()._lock=1,O=E),f&&f!==this._time||S!==!this._ts||this.vars.onRepeat&&!this.parent&&!this._act)return this;if(d=this._dur,p=this._tDur,w&&(this._lock=2,f=T?d:-1e-4,this.render(f,!0),this.vars.repeatRefresh&&!L&&this.invalidate()),this._lock=0,!this._ts&&!S)return this;ME(this,L)}}if(this._hasPause&&!this._forcing&&this._lock<2&&(R=bU(this,An(f),An(g)),R&&(_-=g-(g=R._start))),this._tTime=_,this._time=g,this._act=!U,this._initted||(this._onUpdate=this.vars.onUpdate,this._initted=1,this._zTime=r,f=0),!f&&_&&d&&!l&&!O&&(_a(this,"onStart"),this._tTime!==_))return this;if(g>=f&&r>=0)for(x=this._first;x;){if(M=x._next,(x._act||g>=x._start)&&x._ts&&R!==x){if(x.parent!==this)return this.render(r,l,c);if(x.render(x._ts>0?(g-x._start)*x._ts:(x._dirty?x.totalDuration():x._tDur)+(g-x._start)*x._ts,l,c),g!==this._time||!this._ts&&!S){R=0,M&&(_+=this._zTime=-pn);break}}x=M}else{x=this._last;for(var q=r<0?r:g;x;){if(M=x._prev,(x._act||q<=x._end)&&x._ts&&R!==x){if(x.parent!==this)return this.render(r,l,c);if(x.render(x._ts>0?(q-x._start)*x._ts:(x._dirty?x.totalDuration():x._tDur)+(q-x._start)*x._ts,l,c||hi&&yg(x)),g!==this._time||!this._ts&&!S){R=0,M&&(_+=this._zTime=q?-pn:pn);break}}x=M}}if(R&&!l&&(this.pause(),R.render(g>=f?0:-pn)._zTime=g>=f?1:-1,this._ts))return this._start=C,Ud(this),this.render(r,l,c);this._onUpdate&&!l&&_a(this,"onUpdate",!0),(_===p&&this._tTime>=this.totalDuration()||!_&&f)&&(C===this._start||Math.abs(U)!==Math.abs(this._ts))&&(this._lock||((r||!d)&&(_===p&&this._ts>0||!_&&this._ts<0)&&qs(this,1),!l&&!(r<0&&!f)&&(_||f||!p)&&(_a(this,_===p&&r>=0?"onComplete":"onReverseComplete",!0),this._prom&&!(_<p&&this.timeScale()>0)&&this._prom())))}return this},n.add=function(r,l){var c=this;if(as(l)||(l=Ua(this,l,r)),!(r instanceof Xc)){if(Ei(r))return r.forEach(function(f){return c.add(f,l)}),this;if(ri(r))return this.addLabel(r,l);if(Un(r))r=qn.delayedCall(0,r);else return this}return this!==r?hr(this,r,l):this},n.getChildren=function(r,l,c,f){r===void 0&&(r=!0),l===void 0&&(l=!0),c===void 0&&(c=!0),f===void 0&&(f=-za);for(var p=[],d=this._first;d;)d._start>=f&&(d instanceof qn?l&&p.push(d):(c&&p.push(d),r&&p.push.apply(p,d.getChildren(!0,l,c)))),d=d._next;return p},n.getById=function(r){for(var l=this.getChildren(1,1,1),c=l.length;c--;)if(l[c].vars.id===r)return l[c]},n.remove=function(r){return ri(r)?this.removeLabel(r):Un(r)?this.killTweensOf(r):(r.parent===this&&Dd(this,r),r===this._recent&&(this._recent=this._last),Oo(this))},n.totalTime=function(r,l){return arguments.length?(this._forcing=1,!this._dp&&this._ts&&(this._start=An(pa.time-(this._ts>0?r/this._ts:(this.totalDuration()-r)/-this._ts))),o.prototype.totalTime.call(this,r,l),this._forcing=0,this):this._tTime},n.addLabel=function(r,l){return this.labels[r]=Ua(this,l),this},n.removeLabel=function(r){return delete this.labels[r],this},n.addPause=function(r,l,c){var f=qn.delayedCall(0,l||Gc,c);return f.data="isPause",this._hasPause=1,hr(this,f,Ua(this,r))},n.removePause=function(r){var l=this._first;for(r=Ua(this,r);l;)l._start===r&&l.data==="isPause"&&qs(l),l=l._next},n.killTweensOf=function(r,l,c){for(var f=this.getTweensOf(r,c),p=f.length;p--;)Is!==f[p]&&f[p].kill(r,l);return this},n.getTweensOf=function(r,l){for(var c=[],f=Ia(r),p=this._first,d=as(l),_;p;)p instanceof qn?gU(p._targets,f)&&(d?(!Is||p._initted&&p._ts)&&p.globalTime(0)<=l&&p.globalTime(p.totalDuration())>l:!l||p.isActive())&&c.push(p):(_=p.getTweensOf(f,l)).length&&c.push.apply(c,_),p=p._next;return c},n.tweenTo=function(r,l){l=l||{};var c=this,f=Ua(c,r),p=l,d=p.startAt,_=p.onStart,v=p.onStartParams,g=p.immediateRender,x,M=qn.to(c,ya({ease:l.ease||"none",lazy:!1,immediateRender:!1,time:f,overwrite:"auto",duration:l.duration||Math.abs((f-(d&&"time"in d?d.time:c._time))/c.timeScale())||pn,onStart:function(){if(c.pause(),!x){var y=l.duration||Math.abs((f-(d&&"time"in d?d.time:c._time))/c.timeScale());M._dur!==y&&lu(M,y,0,1).render(M._time,!0,!0),x=1}_&&_.apply(M,v||[])}},l));return g?M.render(0):M},n.tweenFromTo=function(r,l,c){return this.tweenTo(l,ya({startAt:{time:Ua(this,r)}},c))},n.recent=function(){return this._recent},n.nextLabel=function(r){return r===void 0&&(r=this._time),UM(this,Ua(this,r))},n.previousLabel=function(r){return r===void 0&&(r=this._time),UM(this,Ua(this,r),1)},n.currentLabel=function(r){return arguments.length?this.seek(r,!0):this.previousLabel(this._time+pn)},n.shiftChildren=function(r,l,c){c===void 0&&(c=0);var f=this._first,p=this.labels,d;for(r=An(r);f;)f._start>=c&&(f._start+=r,f._end+=r),f=f._next;if(l)for(d in p)p[d]>=c&&(p[d]+=r);return Oo(this)},n.invalidate=function(r){var l=this._first;for(this._lock=0;l;)l.invalidate(r),l=l._next;return o.prototype.invalidate.call(this,r)},n.clear=function(r){r===void 0&&(r=!0);for(var l=this._first,c;l;)c=l._next,this.remove(l),l=c;return this._dp&&(this._time=this._tTime=this._pTime=0),r&&(this.labels={}),Oo(this)},n.totalDuration=function(r){var l=0,c=this,f=c._last,p=za,d,_,v;if(arguments.length)return c.timeScale((c._repeat<0?c.duration():c.totalDuration())/(c.reversed()?-r:r));if(c._dirty){for(v=c.parent;f;)d=f._prev,f._dirty&&f.totalDuration(),_=f._start,_>p&&c._sort&&f._ts&&!c._lock?(c._lock=1,hr(c,f,_-f._delay,1)._lock=0):p=_,_<0&&f._ts&&(l-=_,(!v&&!c._dp||v&&v.smoothChildTiming)&&(c._start+=An(_/c._ts),c._time-=_,c._tTime-=_),c.shiftChildren(-_,!1,-1/0),p=0),f._end>l&&f._ts&&(l=f._end),f=d;lu(c,c===Rn&&c._time>l?c._time:l,1,1),c._dirty=0}return c._tDur},t.updateRoot=function(r){if(Rn._ts&&(nE(Rn,gd(r,Rn)),tE=pa.frame),pa.frame>=RM){RM+=va.autoSleep||120;var l=Rn._first;if((!l||!l._ts)&&va.autoSleep&&pa._listeners.length<2){for(;l&&!l._ts;)l=l._next;l||pa.sleep()}}},t})(Xc);ya(Pi.prototype,{_lock:0,_hasPause:0,_forcing:0});var HU=function(t,n,a,r,l,c,f){var p=new Ki(this._pt,t,n,0,1,DE,null,l),d=0,_=0,v,g,x,M,E,y,S,R;for(p.b=a,p.e=r,a+="",r+="",(S=~r.indexOf("random("))&&(r=Vc(r)),c&&(R=[a,r],c(R,t,n),a=R[0],r=R[1]),g=a.match(M_)||[];v=M_.exec(r);)M=v[0],E=r.substring(d,v.index),x?x=(x+1)%5:E.substr(-5)==="rgba("&&(x=1),M!==g[_++]&&(y=parseFloat(g[_-1])||0,p._pt={_next:p._pt,p:E||_===1?E:",",s:y,c:M.charAt(1)==="="?jl(y,M)-y:parseFloat(M)-y,m:x&&x<4?Math.round:0},d=M_.lastIndex);return p.c=d<r.length?r.substring(d,r.length):"",p.fp=f,(K1.test(r)||S)&&(p.e=0),this._pt=p,p},Sg=function(t,n,a,r,l,c,f,p,d,_){Un(r)&&(r=r(l||0,t,c));var v=t[n],g=a!=="get"?a:Un(v)?d?t[n.indexOf("set")||!Un(t["get"+n.substr(3)])?n:"get"+n.substr(3)](d):t[n]():v,x=Un(v)?d?WU:CE:Eg,M;if(ri(r)&&(~r.indexOf("random(")&&(r=Vc(r)),r.charAt(1)==="="&&(M=jl(g,r)+(xi(g)||0),(M||M===0)&&(r=M))),!_||g!==r||I0)return!isNaN(g*r)&&r!==""?(M=new Ki(this._pt,t,n,+g||0,r-(g||0),typeof v=="boolean"?qU:wE,0,x),d&&(M.fp=d),f&&M.modifier(f,this,t),this._pt=M):(!v&&!(n in t)&&_g(n,r),HU.call(this,t,n,g,r,x,p||va.stringFilter,d))},GU=function(t,n,a,r,l){if(Un(t)&&(t=Ac(t,l,n,a,r)),!Mr(t)||t.style&&t.nodeType||Ei(t)||j1(t))return ri(t)?Ac(t,l,n,a,r):t;var c={},f;for(f in t)c[f]=Ac(t[f],l,n,a,r);return c},TE=function(t,n,a,r,l,c){var f,p,d,_;if(ha[t]&&(f=new ha[t]).init(l,f.rawVars?n[t]:GU(n[t],r,l,c,a),a,r,c)!==!1&&(a._pt=p=new Ki(a._pt,l,t,0,1,f.render,f,0,f.priority),a!==Xl))for(d=a._ptLookup[a._targets.indexOf(l)],_=f._props.length;_--;)d[f._props[_]]=p;return f},Is,I0,Mg=function o(t,n,a){var r=t.vars,l=r.ease,c=r.startAt,f=r.immediateRender,p=r.lazy,d=r.onUpdate,_=r.runBackwards,v=r.yoyoEase,g=r.keyframes,x=r.autoRevert,M=t._dur,E=t._startAt,y=t._targets,S=t.parent,R=S&&S.data==="nested"?S.vars.targets:y,U=t._overwrite==="auto"&&!hg,C=t.timeline,O,P,L,T,w,q,G,k,J,et,Q,F,I;if(C&&(!g||!l)&&(l="none"),t._ease=Po(l,ru.ease),t._yEase=v?SE(Po(v===!0?l:v,ru.ease)):0,v&&t._yoyo&&!t._repeat&&(v=t._yEase,t._yEase=t._ease,t._ease=v),t._from=!C&&!!r.runBackwards,!C||g&&!r.stagger){if(k=y[0]?Lo(y[0]).harness:0,F=k&&r[k.prop],O=_d(r,gg),E&&(E._zTime<0&&E.progress(1),n<0&&_&&f&&!x?E.render(-1,!0):E.revert(_&&M?td:mU),E._lazy=0),c){if(qs(t._startAt=qn.set(y,ya({data:"isStart",overwrite:!1,parent:S,immediateRender:!0,lazy:!E&&ji(p),startAt:null,delay:0,onUpdate:d&&function(){return _a(t,"onUpdate")},stagger:0},c))),t._startAt._dp=0,t._startAt._sat=t,n<0&&(hi||!f&&!x)&&t._startAt.revert(td),f&&M&&n<=0&&a<=0){n&&(t._zTime=n);return}}else if(_&&M&&!E){if(n&&(f=!1),L=ya({overwrite:!1,data:"isFromStart",lazy:f&&!E&&ji(p),immediateRender:f,stagger:0,parent:S},O),F&&(L[k.prop]=F),qs(t._startAt=qn.set(y,L)),t._startAt._dp=0,t._startAt._sat=t,n<0&&(hi?t._startAt.revert(td):t._startAt.render(-1,!0)),t._zTime=n,!f)o(t._startAt,pn,pn);else if(!n)return}for(t._pt=t._ptCache=0,p=M&&ji(p)||p&&!M,P=0;P<y.length;P++){if(w=y[P],G=w._gsap||xg(y)[P]._gsap,t._ptLookup[P]=et={},N0[G.id]&&ks.length&&md(),Q=R===y?P:R.indexOf(w),k&&(J=new k).init(w,F||O,t,Q,R)!==!1&&(t._pt=T=new Ki(t._pt,w,J.name,0,1,J.render,J,0,J.priority),J._props.forEach(function(it){et[it]=T}),J.priority&&(q=1)),!k||F)for(L in O)ha[L]&&(J=TE(L,O,t,Q,w,R))?J.priority&&(q=1):et[L]=T=Sg.call(t,w,L,"get",O[L],Q,R,0,r.stringFilter);t._op&&t._op[P]&&t.kill(w,t._op[P]),U&&t._pt&&(Is=t,Rn.killTweensOf(w,et,t.globalTime(n)),I=!t.parent,Is=0),t._pt&&p&&(N0[G.id]=1)}q&&UE(t),t._onInit&&t._onInit(t)}t._onUpdate=d,t._initted=(!t._op||t._pt)&&!I,g&&n<=0&&C.render(za,!0,!0)},VU=function(t,n,a,r,l,c,f,p){var d=(t._pt&&t._ptCache||(t._ptCache={}))[n],_,v,g,x;if(!d)for(d=t._ptCache[n]=[],g=t._ptLookup,x=t._targets.length;x--;){if(_=g[x][n],_&&_.d&&_.d._pt)for(_=_.d._pt;_&&_.p!==n&&_.fp!==n;)_=_._next;if(!_)return I0=1,t.vars[n]="+=0",Mg(t,f),I0=0,p?Hc(n+" not eligible for reset"):1;d.push(_)}for(x=d.length;x--;)v=d[x],_=v._pt||v,_.s=(r||r===0)&&!l?r:_.s+(r||0)+c*_.c,_.c=a-_.s,v.e&&(v.e=On(a)+xi(v.e)),v.b&&(v.b=_.s+xi(v.b))},kU=function(t,n){var a=t[0]?Lo(t[0]).harness:0,r=a&&a.aliases,l,c,f,p;if(!r)return n;l=su({},n);for(c in r)if(c in l)for(p=r[c].split(","),f=p.length;f--;)l[p[f]]=l[c];return l},XU=function(t,n,a,r){var l=n.ease||r||"power1.inOut",c,f;if(Ei(n))f=a[t]||(a[t]=[]),n.forEach(function(p,d){return f.push({t:d/(n.length-1)*100,v:p,e:l})});else for(c in n)f=a[c]||(a[c]=[]),c==="ease"||f.push({t:parseFloat(t),v:n[c],e:l})},Ac=function(t,n,a,r,l){return Un(t)?t.call(n,a,r,l):ri(t)&&~t.indexOf("random(")?Vc(t):t},AE=vg+"repeat,repeatDelay,yoyo,repeatRefresh,yoyoEase,autoRevert",RE={};Zi(AE+",id,stagger,delay,duration,paused,scrollTrigger",function(o){return RE[o]=1});var qn=(function(o){Y1(t,o);function t(a,r,l,c){var f;typeof r=="number"&&(l.duration=r,r=l,l=null),f=o.call(this,c?r:bc(r))||this;var p=f.vars,d=p.duration,_=p.delay,v=p.immediateRender,g=p.stagger,x=p.overwrite,M=p.keyframes,E=p.defaults,y=p.scrollTrigger,S=p.yoyoEase,R=r.parent||Rn,U=(Ei(a)||j1(a)?as(a[0]):"length"in r)?[a]:Ia(a),C,O,P,L,T,w,q,G;if(f._targets=U.length?xg(U):Hc("GSAP target "+a+" not found. https://gsap.com",!va.nullTargetWarn)||[],f._ptLookup=[],f._overwrite=x,M||g||Oh(d)||Oh(_)){if(r=f.vars,C=f.timeline=new Pi({data:"nested",defaults:E||{},targets:R&&R.data==="nested"?R.vars.targets:U}),C.kill(),C.parent=C._dp=Yr(f),C._start=0,g||Oh(d)||Oh(_)){if(L=U.length,q=g&&fE(g),Mr(g))for(T in g)~AE.indexOf(T)&&(G||(G={}),G[T]=g[T]);for(O=0;O<L;O++)P=_d(r,RE),P.stagger=0,S&&(P.yoyoEase=S),G&&su(P,G),w=U[O],P.duration=+Ac(d,Yr(f),O,w,U),P.delay=(+Ac(_,Yr(f),O,w,U)||0)-f._delay,!g&&L===1&&P.delay&&(f._delay=_=P.delay,f._start+=_,P.delay=0),C.to(w,P,q?q(O,w,U):0),C._ease=Xe.none;C.duration()?d=_=0:f.timeline=0}else if(M){bc(ya(C.vars.defaults,{ease:"none"})),C._ease=Po(M.ease||r.ease||"none");var k=0,J,et,Q;if(Ei(M))M.forEach(function(F){return C.to(U,F,">")}),C.duration();else{P={};for(T in M)T==="ease"||T==="easeEach"||XU(T,M[T],P,M.easeEach);for(T in P)for(J=P[T].sort(function(F,I){return F.t-I.t}),k=0,O=0;O<J.length;O++)et=J[O],Q={ease:et.e,duration:(et.t-(O?J[O-1].t:0))/100*d},Q[T]=et.v,C.to(U,Q,k),k+=Q.duration;C.duration()<d&&C.to({},{duration:d-C.duration()})}}d||f.duration(d=C.duration())}else f.timeline=0;return x===!0&&!hg&&(Is=Yr(f),Rn.killTweensOf(U),Is=0),hr(R,Yr(f),l),r.reversed&&f.reverse(),r.paused&&f.paused(!0),(v||!d&&!M&&f._start===An(R._time)&&ji(v)&&SU(Yr(f))&&R.data!=="nested")&&(f._tTime=-pn,f.render(Math.max(0,-_)||0)),y&&oE(Yr(f),y),f}var n=t.prototype;return n.render=function(r,l,c){var f=this._time,p=this._tDur,d=this._dur,_=r<0,v=r>p-pn&&!_?p:r<pn?0:r,g,x,M,E,y,S,R,U,C;if(!d)EU(this,r,l,c);else if(v!==this._tTime||!r||c||!this._initted&&this._tTime||this._startAt&&this._zTime<0!==_||this._lazy){if(g=v,U=this.timeline,this._repeat){if(E=d+this._rDelay,this._repeat<-1&&_)return this.totalTime(E*100+r,l,c);if(g=An(v%E),v===p?(M=this._repeat,g=d):(y=An(v/E),M=~~y,M&&M===y?(g=d,M--):g>d&&(g=d)),S=this._yoyo&&M&1,S&&(C=this._yEase,g=d-g),y=ou(this._tTime,E),g===f&&!c&&this._initted&&M===y)return this._tTime=v,this;M!==y&&(U&&this._yEase&&ME(U,S),this.vars.repeatRefresh&&!S&&!this._lock&&g!==E&&this._initted&&(this._lock=c=1,this.render(An(E*M),!0).invalidate()._lock=0))}if(!this._initted){if(lE(this,_?r:g,c,l,v))return this._tTime=0,this;if(f!==this._time&&!(c&&this.vars.repeatRefresh&&M!==y))return this;if(d!==this._dur)return this.render(r,l,c)}if(this._tTime=v,this._time=g,!this._act&&this._ts&&(this._act=1,this._lazy=0),this.ratio=R=(C||this._ease)(g/d),this._from&&(this.ratio=R=1-R),!f&&v&&!l&&!y&&(_a(this,"onStart"),this._tTime!==v))return this;for(x=this._pt;x;)x.r(R,x.d),x=x._next;U&&U.render(r<0?r:U._dur*U._ease(g/this._dur),l,c)||this._startAt&&(this._zTime=r),this._onUpdate&&!l&&(_&&L0(this,r,l,c),_a(this,"onUpdate")),this._repeat&&M!==y&&this.vars.onRepeat&&!l&&this.parent&&_a(this,"onRepeat"),(v===this._tDur||!v)&&this._tTime===v&&(_&&!this._onUpdate&&L0(this,r,!0,!0),(r||!d)&&(v===this._tDur&&this._ts>0||!v&&this._ts<0)&&qs(this,1),!l&&!(_&&!f)&&(v||f||S)&&(_a(this,v===p?"onComplete":"onReverseComplete",!0),this._prom&&!(v<p&&this.timeScale()>0)&&this._prom()))}return this},n.targets=function(){return this._targets},n.invalidate=function(r){return(!r||!this.vars.runBackwards)&&(this._startAt=0),this._pt=this._op=this._onUpdate=this._lazy=this.ratio=0,this._ptLookup=[],this.timeline&&this.timeline.invalidate(r),o.prototype.invalidate.call(this,r)},n.resetTo=function(r,l,c,f,p){kc||pa.wake(),this._ts||this.play();var d=Math.min(this._dur,(this._dp._time-this._start)*this._ts),_;return this._initted||Mg(this,d),_=this._ease(d/this._dur),VU(this,r,l,c,f,_,d,p)?this.resetTo(r,l,c,f,1):(Nd(this,0),this.parent||rE(this._dp,this,"_first","_last",this._dp._sort?"_start":0),this.render(0))},n.kill=function(r,l){if(l===void 0&&(l="all"),!r&&(!l||l==="all"))return this._lazy=this._pt=0,this.parent?gc(this):this.scrollTrigger&&this.scrollTrigger.kill(!!hi),this;if(this.timeline){var c=this.timeline.totalDuration();return this.timeline.killTweensOf(r,l,Is&&Is.vars.overwrite!==!0)._first||gc(this),this.parent&&c!==this.timeline.totalDuration()&&lu(this,this._dur*this.timeline._tDur/c,0,1),this}var f=this._targets,p=r?Ia(r):f,d=this._ptLookup,_=this._pt,v,g,x,M,E,y,S;if((!l||l==="all")&&xU(f,p))return l==="all"&&(this._pt=0),gc(this);for(v=this._op=this._op||[],l!=="all"&&(ri(l)&&(E={},Zi(l,function(R){return E[R]=1}),l=E),l=kU(f,l)),S=f.length;S--;)if(~p.indexOf(f[S])){g=d[S],l==="all"?(v[S]=l,M=g,x={}):(x=v[S]=v[S]||{},M=l);for(E in M)y=g&&g[E],y&&((!("kill"in y.d)||y.d.kill(E)===!0)&&Dd(this,y,"_pt"),delete g[E]),x!=="all"&&(x[E]=1)}return this._initted&&!this._pt&&_&&gc(this),this},t.to=function(r,l){return new t(r,l,arguments[2])},t.from=function(r,l){return Tc(1,arguments)},t.delayedCall=function(r,l,c,f){return new t(l,0,{immediateRender:!1,lazy:!1,overwrite:!1,delay:r,onComplete:l,onReverseComplete:l,onCompleteParams:c,onReverseCompleteParams:c,callbackScope:f})},t.fromTo=function(r,l,c){return Tc(2,arguments)},t.set=function(r,l){return l.duration=0,l.repeatDelay||(l.repeat=0),new t(r,l)},t.killTweensOf=function(r,l,c){return Rn.killTweensOf(r,l,c)},t})(Xc);ya(qn.prototype,{_targets:[],_lazy:0,_startAt:0,_op:0,_onInit:0});Zi("staggerTo,staggerFrom,staggerFromTo",function(o){qn[o]=function(){var t=new Pi,n=P0.call(arguments,0);return n.splice(o==="staggerFromTo"?5:4,0,0),t[o].apply(t,n)}});var Eg=function(t,n,a){return t[n]=a},CE=function(t,n,a){return t[n](a)},WU=function(t,n,a,r){return t[n](r.fp,a)},YU=function(t,n,a){return t.setAttribute(n,a)},bg=function(t,n){return Un(t[n])?CE:dg(t[n])&&t.setAttribute?YU:Eg},wE=function(t,n){return n.set(n.t,n.p,Math.round((n.s+n.c*t)*1e6)/1e6,n)},qU=function(t,n){return n.set(n.t,n.p,!!(n.s+n.c*t),n)},DE=function(t,n){var a=n._pt,r="";if(!t&&n.b)r=n.b;else if(t===1&&n.e)r=n.e;else{for(;a;)r=a.p+(a.m?a.m(a.s+a.c*t):Math.round((a.s+a.c*t)*1e4)/1e4)+r,a=a._next;r+=n.c}n.set(n.t,n.p,r,n)},Tg=function(t,n){for(var a=n._pt;a;)a.r(t,a.d),a=a._next},jU=function(t,n,a,r){for(var l=this._pt,c;l;)c=l._next,l.p===r&&l.modifier(t,n,a),l=c},ZU=function(t){for(var n=this._pt,a,r;n;)r=n._next,n.p===t&&!n.op||n.op===t?Dd(this,n,"_pt"):n.dep||(a=1),n=r;return!a},KU=function(t,n,a,r){r.mSet(t,n,r.m.call(r.tween,a,r.mt),r)},UE=function(t){for(var n=t._pt,a,r,l,c;n;){for(a=n._next,r=l;r&&r.pr>n.pr;)r=r._next;(n._prev=r?r._prev:c)?n._prev._next=n:l=n,(n._next=r)?r._prev=n:c=n,n=a}t._pt=l},Ki=(function(){function o(n,a,r,l,c,f,p,d,_){this.t=a,this.s=l,this.c=c,this.p=r,this.r=f||wE,this.d=p||this,this.set=d||Eg,this.pr=_||0,this._next=n,n&&(n._prev=this)}var t=o.prototype;return t.modifier=function(a,r,l){this.mSet=this.mSet||this.set,this.set=KU,this.m=a,this.mt=l,this.tween=r},o})();Zi(vg+"parent,duration,ease,delay,overwrite,runBackwards,startAt,yoyo,immediateRender,repeat,repeatDelay,data,paused,reversed,lazy,callbackScope,stringFilter,id,yoyoEase,stagger,inherit,repeatRefresh,keyframes,autoRevert,scrollTrigger",function(o){return gg[o]=1});xa.TweenMax=xa.TweenLite=qn;xa.TimelineLite=xa.TimelineMax=Pi;Rn=new Pi({sortChildren:!1,defaults:ru,autoRemoveChildren:!0,id:"root",smoothChildTiming:!0});va.stringFilter=yE;var Fo=[],nd={},QU=[],LM=0,JU=0,R_=function(t){return(nd[t]||QU).map(function(n){return n()})},B0=function(){var t=Date.now(),n=[];t-LM>2&&(R_("matchMediaInit"),Fo.forEach(function(a){var r=a.queries,l=a.conditions,c,f,p,d;for(f in r)c=lr.matchMedia(r[f]).matches,c&&(p=1),c!==l[f]&&(l[f]=c,d=1);d&&(a.revert(),p&&n.push(a))}),R_("matchMediaRevert"),n.forEach(function(a){return a.onMatch(a,function(r){return a.add(null,r)})}),LM=t,R_("matchMedia"))},NE=(function(){function o(n,a){this.selector=a&&F0(a),this.data=[],this._r=[],this.isReverted=!1,this.id=JU++,n&&this.add(n)}var t=o.prototype;return t.add=function(a,r,l){Un(a)&&(l=r,r=a,a=Un);var c=this,f=function(){var d=bn,_=c.selector,v;return d&&d!==c&&d.data.push(c),l&&(c.selector=F0(l)),bn=c,v=r.apply(c,arguments),Un(v)&&c._r.push(v),bn=d,c.selector=_,c.isReverted=!1,v};return c.last=f,a===Un?f(c,function(p){return c.add(null,p)}):a?c[a]=f:f},t.ignore=function(a){var r=bn;bn=null,a(this),bn=r},t.getTweens=function(){var a=[];return this.data.forEach(function(r){return r instanceof o?a.push.apply(a,r.getTweens()):r instanceof qn&&!(r.parent&&r.parent.data==="nested")&&a.push(r)}),a},t.clear=function(){this._r.length=this.data.length=0},t.kill=function(a,r){var l=this;if(a?(function(){for(var f=l.getTweens(),p=l.data.length,d;p--;)d=l.data[p],d.data==="isFlip"&&(d.revert(),d.getChildren(!0,!0,!1).forEach(function(_){return f.splice(f.indexOf(_),1)}));for(f.map(function(_){return{g:_._dur||_._delay||_._sat&&!_._sat.vars.immediateRender?_.globalTime(0):-1/0,t:_}}).sort(function(_,v){return v.g-_.g||-1/0}).forEach(function(_){return _.t.revert(a)}),p=l.data.length;p--;)d=l.data[p],d instanceof Pi?d.data!=="nested"&&(d.scrollTrigger&&d.scrollTrigger.revert(),d.kill()):!(d instanceof qn)&&d.revert&&d.revert(a);l._r.forEach(function(_){return _(a,l)}),l.isReverted=!0})():this.data.forEach(function(f){return f.kill&&f.kill()}),this.clear(),r)for(var c=Fo.length;c--;)Fo[c].id===this.id&&Fo.splice(c,1)},t.revert=function(a){this.kill(a||{})},o})(),$U=(function(){function o(n){this.contexts=[],this.scope=n,bn&&bn.data.push(this)}var t=o.prototype;return t.add=function(a,r,l){Mr(a)||(a={matches:a});var c=new NE(0,l||this.scope),f=c.conditions={},p,d,_;bn&&!c.selector&&(c.selector=bn.selector),this.contexts.push(c),r=c.add("onMatch",r),c.queries=a;for(d in a)d==="all"?_=1:(p=lr.matchMedia(a[d]),p&&(Fo.indexOf(c)<0&&Fo.push(c),(f[d]=p.matches)&&(_=1),p.addListener?p.addListener(B0):p.addEventListener("change",B0)));return _&&r(c,function(v){return c.add(null,v)}),this},t.revert=function(a){this.kill(a||{})},t.kill=function(a){this.contexts.forEach(function(r){return r.kill(a,!0)})},o})(),vd={registerPlugin:function(){for(var t=arguments.length,n=new Array(t),a=0;a<t;a++)n[a]=arguments[a];n.forEach(function(r){return gE(r)})},timeline:function(t){return new Pi(t)},getTweensOf:function(t,n){return Rn.getTweensOf(t,n)},getProperty:function(t,n,a,r){ri(t)&&(t=Ia(t)[0]);var l=Lo(t||{}).get,c=a?aE:iE;return a==="native"&&(a=""),t&&(n?c((ha[n]&&ha[n].get||l)(t,n,a,r)):function(f,p,d){return c((ha[f]&&ha[f].get||l)(t,f,p,d))})},quickSetter:function(t,n,a){if(t=Ia(t),t.length>1){var r=t.map(function(_){return Ji.quickSetter(_,n,a)}),l=r.length;return function(_){for(var v=l;v--;)r[v](_)}}t=t[0]||{};var c=ha[n],f=Lo(t),p=f.harness&&(f.harness.aliases||{})[n]||n,d=c?function(_){var v=new c;Xl._pt=0,v.init(t,a?_+a:_,Xl,0,[t]),v.render(1,v),Xl._pt&&Tg(1,Xl)}:f.set(t,p);return c?d:function(_){return d(t,p,a?_+a:_,f,1)}},quickTo:function(t,n,a){var r,l=Ji.to(t,ya((r={},r[n]="+=0.1",r.paused=!0,r.stagger=0,r),a||{})),c=function(p,d,_){return l.resetTo(n,p,d,_)};return c.tween=l,c},isTweening:function(t){return Rn.getTweensOf(t,!0).length>0},defaults:function(t){return t&&t.ease&&(t.ease=Po(t.ease,ru.ease)),CM(ru,t||{})},config:function(t){return CM(va,t||{})},registerEffect:function(t){var n=t.name,a=t.effect,r=t.plugins,l=t.defaults,c=t.extendTimeline;(r||"").split(",").forEach(function(f){return f&&!ha[f]&&!xa[f]&&Hc(n+" effect requires "+f+" plugin.")}),E_[n]=function(f,p,d){return a(Ia(f),ya(p||{},l),d)},c&&(Pi.prototype[n]=function(f,p,d){return this.add(E_[n](f,Mr(p)?p:(d=p)&&{},this),d)})},registerEase:function(t,n){Xe[t]=Po(n)},parseEase:function(t,n){return arguments.length?Po(t,n):Xe},getById:function(t){return Rn.getById(t)},exportRoot:function(t,n){t===void 0&&(t={});var a=new Pi(t),r,l;for(a.smoothChildTiming=ji(t.smoothChildTiming),Rn.remove(a),a._dp=0,a._time=a._tTime=Rn._time,r=Rn._first;r;)l=r._next,(n||!(!r._dur&&r instanceof qn&&r.vars.onComplete===r._targets[0]))&&hr(a,r,r._start-r._delay),r=l;return hr(Rn,a,0),a},context:function(t,n){return t?new NE(t,n):bn},matchMedia:function(t){return new $U(t)},matchMediaRefresh:function(){return Fo.forEach(function(t){var n=t.conditions,a,r;for(r in n)n[r]&&(n[r]=!1,a=1);a&&t.revert()})||B0()},addEventListener:function(t,n){var a=nd[t]||(nd[t]=[]);~a.indexOf(n)||a.push(n)},removeEventListener:function(t,n){var a=nd[t],r=a&&a.indexOf(n);r>=0&&a.splice(r,1)},utils:{wrap:UU,wrapYoyo:NU,distribute:fE,random:dE,snap:hE,normalize:DU,getUnit:xi,clamp:AU,splitColor:vE,toArray:Ia,selector:F0,mapRange:mE,pipe:CU,unitize:wU,interpolate:LU,shuffle:cE},install:J1,effects:E_,ticker:pa,updateRoot:Pi.updateRoot,plugins:ha,globalTimeline:Rn,core:{PropTween:Ki,globals:$1,Tween:qn,Timeline:Pi,Animation:Xc,getCache:Lo,_removeLinkedListItem:Dd,reverting:function(){return hi},context:function(t){return t&&bn&&(bn.data.push(t),t._ctx=bn),bn},suppressOverwrites:function(t){return hg=t}}};Zi("to,from,fromTo,delayedCall,set,killTweensOf",function(o){return vd[o]=qn[o]});pa.add(Pi.updateRoot);Xl=vd.to({},{duration:0});var tN=function(t,n){for(var a=t._pt;a&&a.p!==n&&a.op!==n&&a.fp!==n;)a=a._next;return a},eN=function(t,n){var a=t._targets,r,l,c;for(r in n)for(l=a.length;l--;)c=t._ptLookup[l][r],c&&(c=c.d)&&(c._pt&&(c=tN(c,r)),c&&c.modifier&&c.modifier(n[r],t,a[l],r))},C_=function(t,n){return{name:t,headless:1,rawVars:1,init:function(r,l,c){c._onInit=function(f){var p,d;if(ri(l)&&(p={},Zi(l,function(_){return p[_]=1}),l=p),n){p={};for(d in l)p[d]=n(l[d]);l=p}eN(f,l)}}}},Ji=vd.registerPlugin({name:"attr",init:function(t,n,a,r,l){var c,f,p;this.tween=a;for(c in n)p=t.getAttribute(c)||"",f=this.add(t,"setAttribute",(p||0)+"",n[c],r,l,0,0,c),f.op=c,f.b=p,this._props.push(c)},render:function(t,n){for(var a=n._pt;a;)hi?a.set(a.t,a.p,a.b,a):a.r(t,a.d),a=a._next}},{name:"endArray",headless:1,init:function(t,n){for(var a=n.length;a--;)this.add(t,a,t[a]||0,n[a],0,0,0,0,0,1)}},C_("roundProps",z0),C_("modifiers"),C_("snap",hE))||vd;qn.version=Pi.version=Ji.version="3.14.2";Q1=1;pg()&&uu();Xe.Power0;Xe.Power1;Xe.Power2;Xe.Power3;Xe.Power4;Xe.Linear;Xe.Quad;Xe.Cubic;Xe.Quart;Xe.Quint;Xe.Strong;Xe.Elastic;Xe.Back;Xe.SteppedEase;Xe.Bounce;Xe.Sine;Xe.Expo;Xe.Circ;/*!
 * CSSPlugin 3.14.2
 * https://gsap.com
 *
 * Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
*/var OM,Bs,Zl,Ag,Uo,PM,Rg,nN=function(){return typeof window<"u"},rs={},bo=180/Math.PI,Kl=Math.PI/180,Il=Math.atan2,FM=1e8,Cg=/([A-Z])/g,iN=/(left|right|width|margin|padding|x)/i,aN=/[\s,\(]\S/,mr={autoAlpha:"opacity,visibility",scale:"scaleX,scaleY",alpha:"opacity"},H0=function(t,n){return n.set(n.t,n.p,Math.round((n.s+n.c*t)*1e4)/1e4+n.u,n)},rN=function(t,n){return n.set(n.t,n.p,t===1?n.e:Math.round((n.s+n.c*t)*1e4)/1e4+n.u,n)},sN=function(t,n){return n.set(n.t,n.p,t?Math.round((n.s+n.c*t)*1e4)/1e4+n.u:n.b,n)},oN=function(t,n){return n.set(n.t,n.p,t===1?n.e:t?Math.round((n.s+n.c*t)*1e4)/1e4+n.u:n.b,n)},lN=function(t,n){var a=n.s+n.c*t;n.set(n.t,n.p,~~(a+(a<0?-.5:.5))+n.u,n)},LE=function(t,n){return n.set(n.t,n.p,t?n.e:n.b,n)},OE=function(t,n){return n.set(n.t,n.p,t!==1?n.b:n.e,n)},uN=function(t,n,a){return t.style[n]=a},cN=function(t,n,a){return t.style.setProperty(n,a)},fN=function(t,n,a){return t._gsap[n]=a},hN=function(t,n,a){return t._gsap.scaleX=t._gsap.scaleY=a},dN=function(t,n,a,r,l){var c=t._gsap;c.scaleX=c.scaleY=a,c.renderTransform(l,c)},pN=function(t,n,a,r,l){var c=t._gsap;c[n]=a,c.renderTransform(l,c)},Cn="transform",Qi=Cn+"Origin",mN=function o(t,n){var a=this,r=this.target,l=r.style,c=r._gsap;if(t in rs&&l){if(this.tfm=this.tfm||{},t!=="transform")t=mr[t]||t,~t.indexOf(",")?t.split(",").forEach(function(f){return a.tfm[f]=qr(r,f)}):this.tfm[t]=c.x?c[t]:qr(r,t),t===Qi&&(this.tfm.zOrigin=c.zOrigin);else return mr.transform.split(",").forEach(function(f){return o.call(a,f,n)});if(this.props.indexOf(Cn)>=0)return;c.svg&&(this.svgo=r.getAttribute("data-svg-origin"),this.props.push(Qi,n,"")),t=Cn}(l||n)&&this.props.push(t,n,l[t])},PE=function(t){t.translate&&(t.removeProperty("translate"),t.removeProperty("scale"),t.removeProperty("rotate"))},_N=function(){var t=this.props,n=this.target,a=n.style,r=n._gsap,l,c;for(l=0;l<t.length;l+=3)t[l+1]?t[l+1]===2?n[t[l]](t[l+2]):n[t[l]]=t[l+2]:t[l+2]?a[t[l]]=t[l+2]:a.removeProperty(t[l].substr(0,2)==="--"?t[l]:t[l].replace(Cg,"-$1").toLowerCase());if(this.tfm){for(c in this.tfm)r[c]=this.tfm[c];r.svg&&(r.renderTransform(),n.setAttribute("data-svg-origin",this.svgo||"")),l=Rg(),(!l||!l.isStart)&&!a[Cn]&&(PE(a),r.zOrigin&&a[Qi]&&(a[Qi]+=" "+r.zOrigin+"px",r.zOrigin=0,r.renderTransform()),r.uncache=1)}},FE=function(t,n){var a={target:t,props:[],revert:_N,save:mN};return t._gsap||Ji.core.getCache(t),n&&t.style&&t.nodeType&&n.split(",").forEach(function(r){return a.save(r)}),a},zE,G0=function(t,n){var a=Bs.createElementNS?Bs.createElementNS((n||"http://www.w3.org/1999/xhtml").replace(/^https/,"http"),t):Bs.createElement(t);return a&&a.style?a:Bs.createElement(t)},ga=function o(t,n,a){var r=getComputedStyle(t);return r[n]||r.getPropertyValue(n.replace(Cg,"-$1").toLowerCase())||r.getPropertyValue(n)||!a&&o(t,cu(n)||n,1)||""},zM="O,Moz,ms,Ms,Webkit".split(","),cu=function(t,n,a){var r=n||Uo,l=r.style,c=5;if(t in l&&!a)return t;for(t=t.charAt(0).toUpperCase()+t.substr(1);c--&&!(zM[c]+t in l););return c<0?null:(c===3?"ms":c>=0?zM[c]:"")+t},V0=function(){nN()&&window.document&&(OM=window,Bs=OM.document,Zl=Bs.documentElement,Uo=G0("div")||{style:{}},G0("div"),Cn=cu(Cn),Qi=Cn+"Origin",Uo.style.cssText="border-width:0;line-height:0;position:absolute;padding:0",zE=!!cu("perspective"),Rg=Ji.core.reverting,Ag=1)},IM=function(t){var n=t.ownerSVGElement,a=G0("svg",n&&n.getAttribute("xmlns")||"http://www.w3.org/2000/svg"),r=t.cloneNode(!0),l;r.style.display="block",a.appendChild(r),Zl.appendChild(a);try{l=r.getBBox()}catch{}return a.removeChild(r),Zl.removeChild(a),l},BM=function(t,n){for(var a=n.length;a--;)if(t.hasAttribute(n[a]))return t.getAttribute(n[a])},IE=function(t){var n,a;try{n=t.getBBox()}catch{n=IM(t),a=1}return n&&(n.width||n.height)||a||(n=IM(t)),n&&!n.width&&!n.x&&!n.y?{x:+BM(t,["x","cx","x1"])||0,y:+BM(t,["y","cy","y1"])||0,width:0,height:0}:n},BE=function(t){return!!(t.getCTM&&(!t.parentNode||t.ownerSVGElement)&&IE(t))},js=function(t,n){if(n){var a=t.style,r;n in rs&&n!==Qi&&(n=Cn),a.removeProperty?(r=n.substr(0,2),(r==="ms"||n.substr(0,6)==="webkit")&&(n="-"+n),a.removeProperty(r==="--"?n:n.replace(Cg,"-$1").toLowerCase())):a.removeAttribute(n)}},Hs=function(t,n,a,r,l,c){var f=new Ki(t._pt,n,a,0,1,c?OE:LE);return t._pt=f,f.b=r,f.e=l,t._props.push(a),f},HM={deg:1,rad:1,turn:1},gN={grid:1,flex:1},Zs=function o(t,n,a,r){var l=parseFloat(a)||0,c=(a+"").trim().substr((l+"").length)||"px",f=Uo.style,p=iN.test(n),d=t.tagName.toLowerCase()==="svg",_=(d?"client":"offset")+(p?"Width":"Height"),v=100,g=r==="px",x=r==="%",M,E,y,S;if(r===c||!l||HM[r]||HM[c])return l;if(c!=="px"&&!g&&(l=o(t,n,a,"px")),S=t.getCTM&&BE(t),(x||c==="%")&&(rs[n]||~n.indexOf("adius")))return M=S?t.getBBox()[p?"width":"height"]:t[_],On(x?l/M*v:l/100*M);if(f[p?"width":"height"]=v+(g?c:r),E=r!=="rem"&&~n.indexOf("adius")||r==="em"&&t.appendChild&&!d?t:t.parentNode,S&&(E=(t.ownerSVGElement||{}).parentNode),(!E||E===Bs||!E.appendChild)&&(E=Bs.body),y=E._gsap,y&&x&&y.width&&p&&y.time===pa.time&&!y.uncache)return On(l/y.width*v);if(x&&(n==="height"||n==="width")){var R=t.style[n];t.style[n]=v+r,M=t[_],R?t.style[n]=R:js(t,n)}else(x||c==="%")&&!gN[ga(E,"display")]&&(f.position=ga(t,"position")),E===t&&(f.position="static"),E.appendChild(Uo),M=Uo[_],E.removeChild(Uo),f.position="absolute";return p&&x&&(y=Lo(E),y.time=pa.time,y.width=E[_]),On(g?M*l/v:M&&l?v/M*l:0)},qr=function(t,n,a,r){var l;return Ag||V0(),n in mr&&n!=="transform"&&(n=mr[n],~n.indexOf(",")&&(n=n.split(",")[0])),rs[n]&&n!=="transform"?(l=Yc(t,r),l=n!=="transformOrigin"?l[n]:l.svg?l.origin:yd(ga(t,Qi))+" "+l.zOrigin+"px"):(l=t.style[n],(!l||l==="auto"||r||~(l+"").indexOf("calc("))&&(l=xd[n]&&xd[n](t,n,a)||ga(t,n)||eE(t,n)||(n==="opacity"?1:0))),a&&!~(l+"").trim().indexOf(" ")?Zs(t,n,l,a)+a:l},vN=function(t,n,a,r){if(!a||a==="none"){var l=cu(n,t,1),c=l&&ga(t,l,1);c&&c!==a?(n=l,a=c):n==="borderColor"&&(a=ga(t,"borderTopColor"))}var f=new Ki(this._pt,t.style,n,0,1,DE),p=0,d=0,_,v,g,x,M,E,y,S,R,U,C,O;if(f.b=a,f.e=r,a+="",r+="",r.substring(0,6)==="var(--"&&(r=ga(t,r.substring(4,r.indexOf(")")))),r==="auto"&&(E=t.style[n],t.style[n]=r,r=ga(t,n)||r,E?t.style[n]=E:js(t,n)),_=[a,r],yE(_),a=_[0],r=_[1],g=a.match(kl)||[],O=r.match(kl)||[],O.length){for(;v=kl.exec(r);)y=v[0],R=r.substring(p,v.index),M?M=(M+1)%5:(R.substr(-5)==="rgba("||R.substr(-5)==="hsla(")&&(M=1),y!==(E=g[d++]||"")&&(x=parseFloat(E)||0,C=E.substr((x+"").length),y.charAt(1)==="="&&(y=jl(x,y)+C),S=parseFloat(y),U=y.substr((S+"").length),p=kl.lastIndex-U.length,U||(U=U||va.units[n]||C,p===r.length&&(r+=U,f.e+=U)),C!==U&&(x=Zs(t,n,E,U)||0),f._pt={_next:f._pt,p:R||d===1?R:",",s:x,c:S-x,m:M&&M<4||n==="zIndex"?Math.round:0});f.c=p<r.length?r.substring(p,r.length):""}else f.r=n==="display"&&r==="none"?OE:LE;return K1.test(r)&&(f.e=0),this._pt=f,f},GM={top:"0%",bottom:"100%",left:"0%",right:"100%",center:"50%"},xN=function(t){var n=t.split(" "),a=n[0],r=n[1]||"50%";return(a==="top"||a==="bottom"||r==="left"||r==="right")&&(t=a,a=r,r=t),n[0]=GM[a]||a,n[1]=GM[r]||r,n.join(" ")},yN=function(t,n){if(n.tween&&n.tween._time===n.tween._dur){var a=n.t,r=a.style,l=n.u,c=a._gsap,f,p,d;if(l==="all"||l===!0)r.cssText="",p=1;else for(l=l.split(","),d=l.length;--d>-1;)f=l[d],rs[f]&&(p=1,f=f==="transformOrigin"?Qi:Cn),js(a,f);p&&(js(a,Cn),c&&(c.svg&&a.removeAttribute("transform"),r.scale=r.rotate=r.translate="none",Yc(a,1),c.uncache=1,PE(r)))}},xd={clearProps:function(t,n,a,r,l){if(l.data!=="isFromStart"){var c=t._pt=new Ki(t._pt,n,a,0,0,yN);return c.u=r,c.pr=-10,c.tween=l,t._props.push(a),1}}},Wc=[1,0,0,1,0,0],HE={},GE=function(t){return t==="matrix(1, 0, 0, 1, 0, 0)"||t==="none"||!t},VM=function(t){var n=ga(t,Cn);return GE(n)?Wc:n.substr(7).match(Z1).map(On)},wg=function(t,n){var a=t._gsap||Lo(t),r=t.style,l=VM(t),c,f,p,d;return a.svg&&t.getAttribute("transform")?(p=t.transform.baseVal.consolidate().matrix,l=[p.a,p.b,p.c,p.d,p.e,p.f],l.join(",")==="1,0,0,1,0,0"?Wc:l):(l===Wc&&!t.offsetParent&&t!==Zl&&!a.svg&&(p=r.display,r.display="block",c=t.parentNode,(!c||!t.offsetParent&&!t.getBoundingClientRect().width)&&(d=1,f=t.nextElementSibling,Zl.appendChild(t)),l=VM(t),p?r.display=p:js(t,"display"),d&&(f?c.insertBefore(t,f):c?c.appendChild(t):Zl.removeChild(t))),n&&l.length>6?[l[0],l[1],l[4],l[5],l[12],l[13]]:l)},k0=function(t,n,a,r,l,c){var f=t._gsap,p=l||wg(t,!0),d=f.xOrigin||0,_=f.yOrigin||0,v=f.xOffset||0,g=f.yOffset||0,x=p[0],M=p[1],E=p[2],y=p[3],S=p[4],R=p[5],U=n.split(" "),C=parseFloat(U[0])||0,O=parseFloat(U[1])||0,P,L,T,w;a?p!==Wc&&(L=x*y-M*E)&&(T=C*(y/L)+O*(-E/L)+(E*R-y*S)/L,w=C*(-M/L)+O*(x/L)-(x*R-M*S)/L,C=T,O=w):(P=IE(t),C=P.x+(~U[0].indexOf("%")?C/100*P.width:C),O=P.y+(~(U[1]||U[0]).indexOf("%")?O/100*P.height:O)),r||r!==!1&&f.smooth?(S=C-d,R=O-_,f.xOffset=v+(S*x+R*E)-S,f.yOffset=g+(S*M+R*y)-R):f.xOffset=f.yOffset=0,f.xOrigin=C,f.yOrigin=O,f.smooth=!!r,f.origin=n,f.originIsAbsolute=!!a,t.style[Qi]="0px 0px",c&&(Hs(c,f,"xOrigin",d,C),Hs(c,f,"yOrigin",_,O),Hs(c,f,"xOffset",v,f.xOffset),Hs(c,f,"yOffset",g,f.yOffset)),t.setAttribute("data-svg-origin",C+" "+O)},Yc=function(t,n){var a=t._gsap||new bE(t);if("x"in a&&!n&&!a.uncache)return a;var r=t.style,l=a.scaleX<0,c="px",f="deg",p=getComputedStyle(t),d=ga(t,Qi)||"0",_,v,g,x,M,E,y,S,R,U,C,O,P,L,T,w,q,G,k,J,et,Q,F,I,it,ht,H,z,K,xt,Tt,Ut;return _=v=g=E=y=S=R=U=C=0,x=M=1,a.svg=!!(t.getCTM&&BE(t)),p.translate&&((p.translate!=="none"||p.scale!=="none"||p.rotate!=="none")&&(r[Cn]=(p.translate!=="none"?"translate3d("+(p.translate+" 0 0").split(" ").slice(0,3).join(", ")+") ":"")+(p.rotate!=="none"?"rotate("+p.rotate+") ":"")+(p.scale!=="none"?"scale("+p.scale.split(" ").join(",")+") ":"")+(p[Cn]!=="none"?p[Cn]:"")),r.scale=r.rotate=r.translate="none"),L=wg(t,a.svg),a.svg&&(a.uncache?(it=t.getBBox(),d=a.xOrigin-it.x+"px "+(a.yOrigin-it.y)+"px",I=""):I=!n&&t.getAttribute("data-svg-origin"),k0(t,I||d,!!I||a.originIsAbsolute,a.smooth!==!1,L)),O=a.xOrigin||0,P=a.yOrigin||0,L!==Wc&&(G=L[0],k=L[1],J=L[2],et=L[3],_=Q=L[4],v=F=L[5],L.length===6?(x=Math.sqrt(G*G+k*k),M=Math.sqrt(et*et+J*J),E=G||k?Il(k,G)*bo:0,R=J||et?Il(J,et)*bo+E:0,R&&(M*=Math.abs(Math.cos(R*Kl))),a.svg&&(_-=O-(O*G+P*J),v-=P-(O*k+P*et))):(Ut=L[6],xt=L[7],H=L[8],z=L[9],K=L[10],Tt=L[11],_=L[12],v=L[13],g=L[14],T=Il(Ut,K),y=T*bo,T&&(w=Math.cos(-T),q=Math.sin(-T),I=Q*w+H*q,it=F*w+z*q,ht=Ut*w+K*q,H=Q*-q+H*w,z=F*-q+z*w,K=Ut*-q+K*w,Tt=xt*-q+Tt*w,Q=I,F=it,Ut=ht),T=Il(-J,K),S=T*bo,T&&(w=Math.cos(-T),q=Math.sin(-T),I=G*w-H*q,it=k*w-z*q,ht=J*w-K*q,Tt=et*q+Tt*w,G=I,k=it,J=ht),T=Il(k,G),E=T*bo,T&&(w=Math.cos(T),q=Math.sin(T),I=G*w+k*q,it=Q*w+F*q,k=k*w-G*q,F=F*w-Q*q,G=I,Q=it),y&&Math.abs(y)+Math.abs(E)>359.9&&(y=E=0,S=180-S),x=On(Math.sqrt(G*G+k*k+J*J)),M=On(Math.sqrt(F*F+Ut*Ut)),T=Il(Q,F),R=Math.abs(T)>2e-4?T*bo:0,C=Tt?1/(Tt<0?-Tt:Tt):0),a.svg&&(I=t.getAttribute("transform"),a.forceCSS=t.setAttribute("transform","")||!GE(ga(t,Cn)),I&&t.setAttribute("transform",I))),Math.abs(R)>90&&Math.abs(R)<270&&(l?(x*=-1,R+=E<=0?180:-180,E+=E<=0?180:-180):(M*=-1,R+=R<=0?180:-180)),n=n||a.uncache,a.x=_-((a.xPercent=_&&(!n&&a.xPercent||(Math.round(t.offsetWidth/2)===Math.round(-_)?-50:0)))?t.offsetWidth*a.xPercent/100:0)+c,a.y=v-((a.yPercent=v&&(!n&&a.yPercent||(Math.round(t.offsetHeight/2)===Math.round(-v)?-50:0)))?t.offsetHeight*a.yPercent/100:0)+c,a.z=g+c,a.scaleX=On(x),a.scaleY=On(M),a.rotation=On(E)+f,a.rotationX=On(y)+f,a.rotationY=On(S)+f,a.skewX=R+f,a.skewY=U+f,a.transformPerspective=C+c,(a.zOrigin=parseFloat(d.split(" ")[2])||!n&&a.zOrigin||0)&&(r[Qi]=yd(d)),a.xOffset=a.yOffset=0,a.force3D=va.force3D,a.renderTransform=a.svg?MN:zE?VE:SN,a.uncache=0,a},yd=function(t){return(t=t.split(" "))[0]+" "+t[1]},w_=function(t,n,a){var r=xi(n);return On(parseFloat(n)+parseFloat(Zs(t,"x",a+"px",r)))+r},SN=function(t,n){n.z="0px",n.rotationY=n.rotationX="0deg",n.force3D=0,VE(t,n)},So="0deg",fc="0px",Mo=") ",VE=function(t,n){var a=n||this,r=a.xPercent,l=a.yPercent,c=a.x,f=a.y,p=a.z,d=a.rotation,_=a.rotationY,v=a.rotationX,g=a.skewX,x=a.skewY,M=a.scaleX,E=a.scaleY,y=a.transformPerspective,S=a.force3D,R=a.target,U=a.zOrigin,C="",O=S==="auto"&&t&&t!==1||S===!0;if(U&&(v!==So||_!==So)){var P=parseFloat(_)*Kl,L=Math.sin(P),T=Math.cos(P),w;P=parseFloat(v)*Kl,w=Math.cos(P),c=w_(R,c,L*w*-U),f=w_(R,f,-Math.sin(P)*-U),p=w_(R,p,T*w*-U+U)}y!==fc&&(C+="perspective("+y+Mo),(r||l)&&(C+="translate("+r+"%, "+l+"%) "),(O||c!==fc||f!==fc||p!==fc)&&(C+=p!==fc||O?"translate3d("+c+", "+f+", "+p+") ":"translate("+c+", "+f+Mo),d!==So&&(C+="rotate("+d+Mo),_!==So&&(C+="rotateY("+_+Mo),v!==So&&(C+="rotateX("+v+Mo),(g!==So||x!==So)&&(C+="skew("+g+", "+x+Mo),(M!==1||E!==1)&&(C+="scale("+M+", "+E+Mo),R.style[Cn]=C||"translate(0, 0)"},MN=function(t,n){var a=n||this,r=a.xPercent,l=a.yPercent,c=a.x,f=a.y,p=a.rotation,d=a.skewX,_=a.skewY,v=a.scaleX,g=a.scaleY,x=a.target,M=a.xOrigin,E=a.yOrigin,y=a.xOffset,S=a.yOffset,R=a.forceCSS,U=parseFloat(c),C=parseFloat(f),O,P,L,T,w;p=parseFloat(p),d=parseFloat(d),_=parseFloat(_),_&&(_=parseFloat(_),d+=_,p+=_),p||d?(p*=Kl,d*=Kl,O=Math.cos(p)*v,P=Math.sin(p)*v,L=Math.sin(p-d)*-g,T=Math.cos(p-d)*g,d&&(_*=Kl,w=Math.tan(d-_),w=Math.sqrt(1+w*w),L*=w,T*=w,_&&(w=Math.tan(_),w=Math.sqrt(1+w*w),O*=w,P*=w)),O=On(O),P=On(P),L=On(L),T=On(T)):(O=v,T=g,P=L=0),(U&&!~(c+"").indexOf("px")||C&&!~(f+"").indexOf("px"))&&(U=Zs(x,"x",c,"px"),C=Zs(x,"y",f,"px")),(M||E||y||S)&&(U=On(U+M-(M*O+E*L)+y),C=On(C+E-(M*P+E*T)+S)),(r||l)&&(w=x.getBBox(),U=On(U+r/100*w.width),C=On(C+l/100*w.height)),w="matrix("+O+","+P+","+L+","+T+","+U+","+C+")",x.setAttribute("transform",w),R&&(x.style[Cn]=w)},EN=function(t,n,a,r,l){var c=360,f=ri(l),p=parseFloat(l)*(f&&~l.indexOf("rad")?bo:1),d=p-r,_=r+d+"deg",v,g;return f&&(v=l.split("_")[1],v==="short"&&(d%=c,d!==d%(c/2)&&(d+=d<0?c:-c)),v==="cw"&&d<0?d=(d+c*FM)%c-~~(d/c)*c:v==="ccw"&&d>0&&(d=(d-c*FM)%c-~~(d/c)*c)),t._pt=g=new Ki(t._pt,n,a,r,d,rN),g.e=_,g.u="deg",t._props.push(a),g},kM=function(t,n){for(var a in n)t[a]=n[a];return t},bN=function(t,n,a){var r=kM({},a._gsap),l="perspective,force3D,transformOrigin,svgOrigin",c=a.style,f,p,d,_,v,g,x,M;r.svg?(d=a.getAttribute("transform"),a.setAttribute("transform",""),c[Cn]=n,f=Yc(a,1),js(a,Cn),a.setAttribute("transform",d)):(d=getComputedStyle(a)[Cn],c[Cn]=n,f=Yc(a,1),c[Cn]=d);for(p in rs)d=r[p],_=f[p],d!==_&&l.indexOf(p)<0&&(x=xi(d),M=xi(_),v=x!==M?Zs(a,p,d,M):parseFloat(d),g=parseFloat(_),t._pt=new Ki(t._pt,f,p,v,g-v,H0),t._pt.u=M||0,t._props.push(p));kM(f,r)};Zi("padding,margin,Width,Radius",function(o,t){var n="Top",a="Right",r="Bottom",l="Left",c=(t<3?[n,a,r,l]:[n+l,n+a,r+a,r+l]).map(function(f){return t<2?o+f:"border"+f+o});xd[t>1?"border"+o:o]=function(f,p,d,_,v){var g,x;if(arguments.length<4)return g=c.map(function(M){return qr(f,M,d)}),x=g.join(" "),x.split(g[0]).length===5?g[0]:x;g=(_+"").split(" "),x={},c.forEach(function(M,E){return x[M]=g[E]=g[E]||g[(E-1)/2|0]}),f.init(p,x,v)}});var kE={name:"css",register:V0,targetTest:function(t){return t.style&&t.nodeType},init:function(t,n,a,r,l){var c=this._props,f=t.style,p=a.vars.startAt,d,_,v,g,x,M,E,y,S,R,U,C,O,P,L,T,w;Ag||V0(),this.styles=this.styles||FE(t),T=this.styles.props,this.tween=a;for(E in n)if(E!=="autoRound"&&(_=n[E],!(ha[E]&&TE(E,n,a,r,t,l)))){if(x=typeof _,M=xd[E],x==="function"&&(_=_.call(a,r,t,l),x=typeof _),x==="string"&&~_.indexOf("random(")&&(_=Vc(_)),M)M(this,t,E,_,a)&&(L=1);else if(E.substr(0,2)==="--")d=(getComputedStyle(t).getPropertyValue(E)+"").trim(),_+="",Xs.lastIndex=0,Xs.test(d)||(y=xi(d),S=xi(_),S?y!==S&&(d=Zs(t,E,d,S)+S):y&&(_+=y)),this.add(f,"setProperty",d,_,r,l,0,0,E),c.push(E),T.push(E,0,f[E]);else if(x!=="undefined"){if(p&&E in p?(d=typeof p[E]=="function"?p[E].call(a,r,t,l):p[E],ri(d)&&~d.indexOf("random(")&&(d=Vc(d)),xi(d+"")||d==="auto"||(d+=va.units[E]||xi(qr(t,E))||""),(d+"").charAt(1)==="="&&(d=qr(t,E))):d=qr(t,E),g=parseFloat(d),R=x==="string"&&_.charAt(1)==="="&&_.substr(0,2),R&&(_=_.substr(2)),v=parseFloat(_),E in mr&&(E==="autoAlpha"&&(g===1&&qr(t,"visibility")==="hidden"&&v&&(g=0),T.push("visibility",0,f.visibility),Hs(this,f,"visibility",g?"inherit":"hidden",v?"inherit":"hidden",!v)),E!=="scale"&&E!=="transform"&&(E=mr[E],~E.indexOf(",")&&(E=E.split(",")[0]))),U=E in rs,U){if(this.styles.save(E),w=_,x==="string"&&_.substring(0,6)==="var(--"){if(_=ga(t,_.substring(4,_.indexOf(")"))),_.substring(0,5)==="calc("){var q=t.style.perspective;t.style.perspective=_,_=ga(t,"perspective"),q?t.style.perspective=q:js(t,"perspective")}v=parseFloat(_)}if(C||(O=t._gsap,O.renderTransform&&!n.parseTransform||Yc(t,n.parseTransform),P=n.smoothOrigin!==!1&&O.smooth,C=this._pt=new Ki(this._pt,f,Cn,0,1,O.renderTransform,O,0,-1),C.dep=1),E==="scale")this._pt=new Ki(this._pt,O,"scaleY",O.scaleY,(R?jl(O.scaleY,R+v):v)-O.scaleY||0,H0),this._pt.u=0,c.push("scaleY",E),E+="X";else if(E==="transformOrigin"){T.push(Qi,0,f[Qi]),_=xN(_),O.svg?k0(t,_,0,P,0,this):(S=parseFloat(_.split(" ")[2])||0,S!==O.zOrigin&&Hs(this,O,"zOrigin",O.zOrigin,S),Hs(this,f,E,yd(d),yd(_)));continue}else if(E==="svgOrigin"){k0(t,_,1,P,0,this);continue}else if(E in HE){EN(this,O,E,g,R?jl(g,R+_):_);continue}else if(E==="smoothOrigin"){Hs(this,O,"smooth",O.smooth,_);continue}else if(E==="force3D"){O[E]=_;continue}else if(E==="transform"){bN(this,_,t);continue}}else E in f||(E=cu(E)||E);if(U||(v||v===0)&&(g||g===0)&&!aN.test(_)&&E in f)y=(d+"").substr((g+"").length),v||(v=0),S=xi(_)||(E in va.units?va.units[E]:y),y!==S&&(g=Zs(t,E,d,S)),this._pt=new Ki(this._pt,U?O:f,E,g,(R?jl(g,R+v):v)-g,!U&&(S==="px"||E==="zIndex")&&n.autoRound!==!1?lN:H0),this._pt.u=S||0,U&&w!==_?(this._pt.b=d,this._pt.e=w,this._pt.r=oN):y!==S&&S!=="%"&&(this._pt.b=d,this._pt.r=sN);else if(E in f)vN.call(this,t,E,d,R?R+_:_);else if(E in t)this.add(t,E,d||t[E],R?R+_:_,r,l);else if(E!=="parseTransform"){_g(E,_);continue}U||(E in f?T.push(E,0,f[E]):typeof t[E]=="function"?T.push(E,2,t[E]()):T.push(E,1,d||t[E])),c.push(E)}}L&&UE(this)},render:function(t,n){if(n.tween._time||!Rg())for(var a=n._pt;a;)a.r(t,a.d),a=a._next;else n.styles.revert()},get:qr,aliases:mr,getSetter:function(t,n,a){var r=mr[n];return r&&r.indexOf(",")<0&&(n=r),n in rs&&n!==Qi&&(t._gsap.x||qr(t,"x"))?a&&PM===a?n==="scale"?hN:fN:(PM=a||{})&&(n==="scale"?dN:pN):t.style&&!dg(t.style[n])?uN:~n.indexOf("-")?cN:bg(t,n)},core:{_removeProperty:js,_getMatrix:wg}};Ji.utils.checkPrefix=cu;Ji.core.getStyleSaver=FE;(function(o,t,n,a){var r=Zi(o+","+t+","+n,function(l){rs[l]=1});Zi(t,function(l){va.units[l]="deg",HE[l]=1}),mr[r[13]]=o+","+t,Zi(a,function(l){var c=l.split(":");mr[c[1]]=r[c[0]]})})("x,y,z,scale,scaleX,scaleY,xPercent,yPercent","rotation,rotationX,rotationY,skewX,skewY","transform,transformOrigin,svgOrigin,force3D,smoothOrigin,transformPerspective","0:translateX,1:translateY,2:translateZ,8:rotate,8:rotationZ,8:rotateZ,9:rotateX,10:rotateY");Zi("x,y,z,top,right,bottom,left,width,height,fontSize,padding,margin,perspective",function(o){va.units[o]="px"});Ji.registerPlugin(kE);var ur=Ji.registerPlugin(kE)||Ji;ur.core.Tween;function TN(o,t){for(var n=0;n<t.length;n++){var a=t[n];a.enumerable=a.enumerable||!1,a.configurable=!0,"value"in a&&(a.writable=!0),Object.defineProperty(o,a.key,a)}}function AN(o,t,n){return t&&TN(o.prototype,t),o}/*!
 * Observer 3.14.2
 * https://gsap.com
 *
 * @license Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
*/var fi,id,ma,Gs,Vs,Ql,XE,To,Rc,WE,Qr,Ka,YE,qE=function(){return fi||typeof window<"u"&&(fi=window.gsap)&&fi.registerPlugin&&fi},jE=1,Wl=[],Oe=[],yr=[],Cc=Date.now,X0=function(t,n){return n},RN=function(){var t=Rc.core,n=t.bridge||{},a=t._scrollers,r=t._proxies;a.push.apply(a,Oe),r.push.apply(r,yr),Oe=a,yr=r,X0=function(c,f){return n[c](f)}},Ws=function(t,n){return~yr.indexOf(t)&&yr[yr.indexOf(t)+1][n]},wc=function(t){return!!~WE.indexOf(t)},Di=function(t,n,a,r,l){return t.addEventListener(n,a,{passive:r!==!1,capture:!!l})},wi=function(t,n,a,r){return t.removeEventListener(n,a,!!r)},Ph="scrollLeft",Fh="scrollTop",W0=function(){return Qr&&Qr.isPressed||Oe.cache++},Sd=function(t,n){var a=function r(l){if(l||l===0){jE&&(ma.history.scrollRestoration="manual");var c=Qr&&Qr.isPressed;l=r.v=Math.round(l)||(Qr&&Qr.iOS?1:0),t(l),r.cacheID=Oe.cache,c&&X0("ss",l)}else(n||Oe.cache!==r.cacheID||X0("ref"))&&(r.cacheID=Oe.cache,r.v=t());return r.v+r.offset};return a.offset=0,t&&a},Fi={s:Ph,p:"left",p2:"Left",os:"right",os2:"Right",d:"width",d2:"Width",a:"x",sc:Sd(function(o){return arguments.length?ma.scrollTo(o,Qn.sc()):ma.pageXOffset||Gs[Ph]||Vs[Ph]||Ql[Ph]||0})},Qn={s:Fh,p:"top",p2:"Top",os:"bottom",os2:"Bottom",d:"height",d2:"Height",a:"y",op:Fi,sc:Sd(function(o){return arguments.length?ma.scrollTo(Fi.sc(),o):ma.pageYOffset||Gs[Fh]||Vs[Fh]||Ql[Fh]||0})},Wi=function(t,n){return(n&&n._ctx&&n._ctx.selector||fi.utils.toArray)(t)[0]||(typeof t=="string"&&fi.config().nullTargetWarn!==!1?console.warn("Element not found:",t):null)},CN=function(t,n){for(var a=n.length;a--;)if(n[a]===t||n[a].contains(t))return!0;return!1},Ks=function(t,n){var a=n.s,r=n.sc;wc(t)&&(t=Gs.scrollingElement||Vs);var l=Oe.indexOf(t),c=r===Qn.sc?1:2;!~l&&(l=Oe.push(t)-1),Oe[l+c]||Di(t,"scroll",W0);var f=Oe[l+c],p=f||(Oe[l+c]=Sd(Ws(t,a),!0)||(wc(t)?r:Sd(function(d){return arguments.length?t[a]=d:t[a]})));return p.target=t,f||(p.smooth=fi.getProperty(t,"scrollBehavior")==="smooth"),p},Y0=function(t,n,a){var r=t,l=t,c=Cc(),f=c,p=n||50,d=Math.max(500,p*3),_=function(M,E){var y=Cc();E||y-c>p?(l=r,r=M,f=c,c=y):a?r+=M:r=l+(M-l)/(y-f)*(c-f)},v=function(){l=r=a?0:r,f=c=0},g=function(M){var E=f,y=l,S=Cc();return(M||M===0)&&M!==r&&_(M),c===f||S-f>d?0:(r+(a?y:-y))/((a?S:c)-E)*1e3};return{update:_,reset:v,getVelocity:g}},hc=function(t,n){return n&&!t._gsapAllow&&t.preventDefault(),t.changedTouches?t.changedTouches[0]:t},XM=function(t){var n=Math.max.apply(Math,t),a=Math.min.apply(Math,t);return Math.abs(n)>=Math.abs(a)?n:a},ZE=function(){Rc=fi.core.globals().ScrollTrigger,Rc&&Rc.core&&RN()},KE=function(t){return fi=t||qE(),!id&&fi&&typeof document<"u"&&document.body&&(ma=window,Gs=document,Vs=Gs.documentElement,Ql=Gs.body,WE=[ma,Gs,Vs,Ql],fi.utils.clamp,YE=fi.core.context||function(){},To="onpointerenter"in Ql?"pointer":"mouse",XE=Fn.isTouch=ma.matchMedia&&ma.matchMedia("(hover: none), (pointer: coarse)").matches?1:"ontouchstart"in ma||navigator.maxTouchPoints>0||navigator.msMaxTouchPoints>0?2:0,Ka=Fn.eventTypes=("ontouchstart"in Vs?"touchstart,touchmove,touchcancel,touchend":"onpointerdown"in Vs?"pointerdown,pointermove,pointercancel,pointerup":"mousedown,mousemove,mouseup,mouseup").split(","),setTimeout(function(){return jE=0},500),ZE(),id=1),id};Fi.op=Qn;Oe.cache=0;var Fn=(function(){function o(n){this.init(n)}var t=o.prototype;return t.init=function(a){id||KE(fi)||console.warn("Please gsap.registerPlugin(Observer)"),Rc||ZE();var r=a.tolerance,l=a.dragMinimum,c=a.type,f=a.target,p=a.lineHeight,d=a.debounce,_=a.preventDefault,v=a.onStop,g=a.onStopDelay,x=a.ignore,M=a.wheelSpeed,E=a.event,y=a.onDragStart,S=a.onDragEnd,R=a.onDrag,U=a.onPress,C=a.onRelease,O=a.onRight,P=a.onLeft,L=a.onUp,T=a.onDown,w=a.onChangeX,q=a.onChangeY,G=a.onChange,k=a.onToggleX,J=a.onToggleY,et=a.onHover,Q=a.onHoverEnd,F=a.onMove,I=a.ignoreCheck,it=a.isNormalizer,ht=a.onGestureStart,H=a.onGestureEnd,z=a.onWheel,K=a.onEnable,xt=a.onDisable,Tt=a.onClick,Ut=a.scrollSpeed,nt=a.capture,_t=a.allowClicks,Et=a.lockAxis,Ft=a.onLockAxis;this.target=f=Wi(f)||Vs,this.vars=a,x&&(x=fi.utils.toArray(x)),r=r||1e-9,l=l||0,M=M||1,Ut=Ut||1,c=c||"wheel,touch,pointer",d=d!==!1,p||(p=parseFloat(ma.getComputedStyle(Ql).lineHeight)||22);var ee,Kt,Ne,qt,re,_e,se,lt=this,W=0,We=0,Ee=a.passive||!_&&a.passive!==!1,ce=Ks(f,Fi),Wt=Ks(f,Qn),B=ce(),A=Wt(),j=~c.indexOf("touch")&&!~c.indexOf("pointer")&&Ka[0]==="pointerdown",gt=wc(f),vt=f.ownerDocument||Gs,dt=[0,0,0],Gt=[0,0,0],wt=0,ie=function(){return wt=Cc()},Yt=function(Jt,be){return(lt.event=Jt)&&x&&CN(Jt.target,x)||be&&j&&Jt.pointerType!=="touch"||I&&I(Jt,be)},Rt=function(){lt._vx.reset(),lt._vy.reset(),Kt.pause(),v&&v(lt)},At=function(){var Jt=lt.deltaX=XM(dt),be=lt.deltaY=XM(Gt),It=Math.abs(Jt)>=r,he=Math.abs(be)>=r;G&&(It||he)&&G(lt,Jt,be,dt,Gt),It&&(O&&lt.deltaX>0&&O(lt),P&&lt.deltaX<0&&P(lt),w&&w(lt),k&&lt.deltaX<0!=W<0&&k(lt),W=lt.deltaX,dt[0]=dt[1]=dt[2]=0),he&&(T&&lt.deltaY>0&&T(lt),L&&lt.deltaY<0&&L(lt),q&&q(lt),J&&lt.deltaY<0!=We<0&&J(lt),We=lt.deltaY,Gt[0]=Gt[1]=Gt[2]=0),(qt||Ne)&&(F&&F(lt),Ne&&(y&&Ne===1&&y(lt),R&&R(lt),Ne=0),qt=!1),_e&&!(_e=!1)&&Ft&&Ft(lt),re&&(z(lt),re=!1),ee=0},Ht=function(Jt,be,It){dt[It]+=Jt,Gt[It]+=be,lt._vx.update(Jt),lt._vy.update(be),d?ee||(ee=requestAnimationFrame(At)):At()},Pt=function(Jt,be){Et&&!se&&(lt.axis=se=Math.abs(Jt)>Math.abs(be)?"x":"y",_e=!0),se!=="y"&&(dt[2]+=Jt,lt._vx.update(Jt,!0)),se!=="x"&&(Gt[2]+=be,lt._vy.update(be,!0)),d?ee||(ee=requestAnimationFrame(At)):At()},zt=function(Jt){if(!Yt(Jt,1)){Jt=hc(Jt,_);var be=Jt.clientX,It=Jt.clientY,he=be-lt.x,oe=It-lt.y,de=lt.isDragging;lt.x=be,lt.y=It,(de||(he||oe)&&(Math.abs(lt.startX-be)>=l||Math.abs(lt.startY-It)>=l))&&(Ne||(Ne=de?2:1),de||(lt.isDragging=!0),Pt(he,oe))}},pe=lt.onPress=function(Vt){Yt(Vt,1)||Vt&&Vt.button||(lt.axis=se=null,Kt.pause(),lt.isPressed=!0,Vt=hc(Vt),W=We=0,lt.startX=lt.x=Vt.clientX,lt.startY=lt.y=Vt.clientY,lt._vx.reset(),lt._vy.reset(),Di(it?f:vt,Ka[1],zt,Ee,!0),lt.deltaX=lt.deltaY=0,U&&U(lt))},V=lt.onRelease=function(Vt){if(!Yt(Vt,1)){wi(it?f:vt,Ka[1],zt,!0);var Jt=!isNaN(lt.y-lt.startY),be=lt.isDragging,It=be&&(Math.abs(lt.x-lt.startX)>3||Math.abs(lt.y-lt.startY)>3),he=hc(Vt);!It&&Jt&&(lt._vx.reset(),lt._vy.reset(),_&&_t&&fi.delayedCall(.08,function(){if(Cc()-wt>300&&!Vt.defaultPrevented){if(Vt.target.click)Vt.target.click();else if(vt.createEvent){var oe=vt.createEvent("MouseEvents");oe.initMouseEvent("click",!0,!0,ma,1,he.screenX,he.screenY,he.clientX,he.clientY,!1,!1,!1,!1,0,null),Vt.target.dispatchEvent(oe)}}})),lt.isDragging=lt.isGesturing=lt.isPressed=!1,v&&be&&!it&&Kt.restart(!0),Ne&&At(),S&&be&&S(lt),C&&C(lt,It)}},Dt=function(Jt){return Jt.touches&&Jt.touches.length>1&&(lt.isGesturing=!0)&&ht(Jt,lt.isDragging)},Ct=function(){return(lt.isGesturing=!1)||H(lt)},Lt=function(Jt){if(!Yt(Jt)){var be=ce(),It=Wt();Ht((be-B)*Ut,(It-A)*Ut,1),B=be,A=It,v&&Kt.restart(!0)}},bt=function(Jt){if(!Yt(Jt)){Jt=hc(Jt,_),z&&(re=!0);var be=(Jt.deltaMode===1?p:Jt.deltaMode===2?ma.innerHeight:1)*M;Ht(Jt.deltaX*be,Jt.deltaY*be,0),v&&!it&&Kt.restart(!0)}},mt=function(Jt){if(!Yt(Jt)){var be=Jt.clientX,It=Jt.clientY,he=be-lt.x,oe=It-lt.y;lt.x=be,lt.y=It,qt=!0,v&&Kt.restart(!0),(he||oe)&&Pt(he,oe)}},Xt=function(Jt){lt.event=Jt,et(lt)},le=function(Jt){lt.event=Jt,Q(lt)},Ge=function(Jt){return Yt(Jt)||hc(Jt,_)&&Tt(lt)};Kt=lt._dc=fi.delayedCall(g||.25,Rt).pause(),lt.deltaX=lt.deltaY=0,lt._vx=Y0(0,50,!0),lt._vy=Y0(0,50,!0),lt.scrollX=ce,lt.scrollY=Wt,lt.isDragging=lt.isGesturing=lt.isPressed=!1,YE(this),lt.enable=function(Vt){return lt.isEnabled||(Di(gt?vt:f,"scroll",W0),c.indexOf("scroll")>=0&&Di(gt?vt:f,"scroll",Lt,Ee,nt),c.indexOf("wheel")>=0&&Di(f,"wheel",bt,Ee,nt),(c.indexOf("touch")>=0&&XE||c.indexOf("pointer")>=0)&&(Di(f,Ka[0],pe,Ee,nt),Di(vt,Ka[2],V),Di(vt,Ka[3],V),_t&&Di(f,"click",ie,!0,!0),Tt&&Di(f,"click",Ge),ht&&Di(vt,"gesturestart",Dt),H&&Di(vt,"gestureend",Ct),et&&Di(f,To+"enter",Xt),Q&&Di(f,To+"leave",le),F&&Di(f,To+"move",mt)),lt.isEnabled=!0,lt.isDragging=lt.isGesturing=lt.isPressed=qt=Ne=!1,lt._vx.reset(),lt._vy.reset(),B=ce(),A=Wt(),Vt&&Vt.type&&pe(Vt),K&&K(lt)),lt},lt.disable=function(){lt.isEnabled&&(Wl.filter(function(Vt){return Vt!==lt&&wc(Vt.target)}).length||wi(gt?vt:f,"scroll",W0),lt.isPressed&&(lt._vx.reset(),lt._vy.reset(),wi(it?f:vt,Ka[1],zt,!0)),wi(gt?vt:f,"scroll",Lt,nt),wi(f,"wheel",bt,nt),wi(f,Ka[0],pe,nt),wi(vt,Ka[2],V),wi(vt,Ka[3],V),wi(f,"click",ie,!0),wi(f,"click",Ge),wi(vt,"gesturestart",Dt),wi(vt,"gestureend",Ct),wi(f,To+"enter",Xt),wi(f,To+"leave",le),wi(f,To+"move",mt),lt.isEnabled=lt.isPressed=lt.isDragging=!1,xt&&xt(lt))},lt.kill=lt.revert=function(){lt.disable();var Vt=Wl.indexOf(lt);Vt>=0&&Wl.splice(Vt,1),Qr===lt&&(Qr=0)},Wl.push(lt),it&&wc(f)&&(Qr=lt),lt.enable(E)},AN(o,[{key:"velocityX",get:function(){return this._vx.getVelocity()}},{key:"velocityY",get:function(){return this._vy.getVelocity()}}]),o})();Fn.version="3.14.2";Fn.create=function(o){return new Fn(o)};Fn.register=KE;Fn.getAll=function(){return Wl.slice()};Fn.getById=function(o){return Wl.filter(function(t){return t.vars.id===o})[0]};qE()&&fi.registerPlugin(Fn);/*!
 * ScrollTrigger 3.14.2
 * https://gsap.com
 *
 * @license Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
*/var te,Gl,Le,mn,da,tn,Dg,Md,qc,Dc,xc,zh,gi,Ld,q0,Li,WM,YM,Vl,QE,D_,JE,Ni,j0,$E,tb,Ps,Z0,Ug,Jl,Ng,Uc,K0,U_,Ih=1,vi=Date.now,N_=vi(),Ha=0,yc=0,qM=function(t,n,a){var r=fa(t)&&(t.substr(0,6)==="clamp("||t.indexOf("max")>-1);return a["_"+n+"Clamp"]=r,r?t.substr(6,t.length-7):t},jM=function(t,n){return n&&(!fa(t)||t.substr(0,6)!=="clamp(")?"clamp("+t+")":t},wN=function o(){return yc&&requestAnimationFrame(o)},ZM=function(){return Ld=1},KM=function(){return Ld=0},cr=function(t){return t},Sc=function(t){return Math.round(t*1e5)/1e5||0},eb=function(){return typeof window<"u"},nb=function(){return te||eb()&&(te=window.gsap)&&te.registerPlugin&&te},Go=function(t){return!!~Dg.indexOf(t)},ib=function(t){return(t==="Height"?Ng:Le["inner"+t])||da["client"+t]||tn["client"+t]},ab=function(t){return Ws(t,"getBoundingClientRect")||(Go(t)?function(){return ld.width=Le.innerWidth,ld.height=Ng,ld}:function(){return Zr(t)})},DN=function(t,n,a){var r=a.d,l=a.d2,c=a.a;return(c=Ws(t,"getBoundingClientRect"))?function(){return c()[r]}:function(){return(n?ib(l):t["client"+l])||0}},UN=function(t,n){return!n||~yr.indexOf(t)?ab(t):function(){return ld}},_r=function(t,n){var a=n.s,r=n.d2,l=n.d,c=n.a;return Math.max(0,(a="scroll"+r)&&(c=Ws(t,a))?c()-ab(t)()[l]:Go(t)?(da[a]||tn[a])-ib(r):t[a]-t["offset"+r])},Bh=function(t,n){for(var a=0;a<Vl.length;a+=3)(!n||~n.indexOf(Vl[a+1]))&&t(Vl[a],Vl[a+1],Vl[a+2])},fa=function(t){return typeof t=="string"},yi=function(t){return typeof t=="function"},Mc=function(t){return typeof t=="number"},Ao=function(t){return typeof t=="object"},dc=function(t,n,a){return t&&t.progress(n?0:1)&&a&&t.pause()},L_=function(t,n){if(t.enabled){var a=t._ctx?t._ctx.add(function(){return n(t)}):n(t);a&&a.totalTime&&(t.callbackAnimation=a)}},Bl=Math.abs,rb="left",sb="top",Lg="right",Og="bottom",zo="width",Io="height",Nc="Right",Lc="Left",Oc="Top",Pc="Bottom",Yn="padding",Oa="margin",fu="Width",Pg="Height",Kn="px",Pa=function(t){return Le.getComputedStyle(t)},NN=function(t){var n=Pa(t).position;t.style.position=n==="absolute"||n==="fixed"?n:"relative"},QM=function(t,n){for(var a in n)a in t||(t[a]=n[a]);return t},Zr=function(t,n){var a=n&&Pa(t)[q0]!=="matrix(1, 0, 0, 1, 0, 0)"&&te.to(t,{x:0,y:0,xPercent:0,yPercent:0,rotation:0,rotationX:0,rotationY:0,scale:1,skewX:0,skewY:0}).progress(1),r=t.getBoundingClientRect();return a&&a.progress(0).kill(),r},Ed=function(t,n){var a=n.d2;return t["offset"+a]||t["client"+a]||0},ob=function(t){var n=[],a=t.labels,r=t.duration(),l;for(l in a)n.push(a[l]/r);return n},LN=function(t){return function(n){return te.utils.snap(ob(t),n)}},Fg=function(t){var n=te.utils.snap(t),a=Array.isArray(t)&&t.slice(0).sort(function(r,l){return r-l});return a?function(r,l,c){c===void 0&&(c=.001);var f;if(!l)return n(r);if(l>0){for(r-=c,f=0;f<a.length;f++)if(a[f]>=r)return a[f];return a[f-1]}else for(f=a.length,r+=c;f--;)if(a[f]<=r)return a[f];return a[0]}:function(r,l,c){c===void 0&&(c=.001);var f=n(r);return!l||Math.abs(f-r)<c||f-r<0==l<0?f:n(l<0?r-t:r+t)}},ON=function(t){return function(n,a){return Fg(ob(t))(n,a.direction)}},Hh=function(t,n,a,r){return a.split(",").forEach(function(l){return t(n,l,r)})},ai=function(t,n,a,r,l){return t.addEventListener(n,a,{passive:!r,capture:!!l})},ii=function(t,n,a,r){return t.removeEventListener(n,a,!!r)},Gh=function(t,n,a){a=a&&a.wheelHandler,a&&(t(n,"wheel",a),t(n,"touchmove",a))},JM={startColor:"green",endColor:"red",indent:0,fontSize:"16px",fontWeight:"normal"},Vh={toggleActions:"play",anticipatePin:0},bd={top:0,left:0,center:.5,bottom:1,right:1},ad=function(t,n){if(fa(t)){var a=t.indexOf("="),r=~a?+(t.charAt(a-1)+1)*parseFloat(t.substr(a+1)):0;~a&&(t.indexOf("%")>a&&(r*=n/100),t=t.substr(0,a-1)),t=r+(t in bd?bd[t]*n:~t.indexOf("%")?parseFloat(t)*n/100:parseFloat(t)||0)}return t},kh=function(t,n,a,r,l,c,f,p){var d=l.startColor,_=l.endColor,v=l.fontSize,g=l.indent,x=l.fontWeight,M=mn.createElement("div"),E=Go(a)||Ws(a,"pinType")==="fixed",y=t.indexOf("scroller")!==-1,S=E?tn:a,R=t.indexOf("start")!==-1,U=R?d:_,C="border-color:"+U+";font-size:"+v+";color:"+U+";font-weight:"+x+";pointer-events:none;white-space:nowrap;font-family:sans-serif,Arial;z-index:1000;padding:4px 8px;border-width:0;border-style:solid;";return C+="position:"+((y||p)&&E?"fixed;":"absolute;"),(y||p||!E)&&(C+=(r===Qn?Lg:Og)+":"+(c+parseFloat(g))+"px;"),f&&(C+="box-sizing:border-box;text-align:left;width:"+f.offsetWidth+"px;"),M._isStart=R,M.setAttribute("class","gsap-marker-"+t+(n?" marker-"+n:"")),M.style.cssText=C,M.innerText=n||n===0?t+"-"+n:t,S.children[0]?S.insertBefore(M,S.children[0]):S.appendChild(M),M._offset=M["offset"+r.op.d2],rd(M,0,r,R),M},rd=function(t,n,a,r){var l={display:"block"},c=a[r?"os2":"p2"],f=a[r?"p2":"os2"];t._isFlipped=r,l[a.a+"Percent"]=r?-100:0,l[a.a]=r?"1px":0,l["border"+c+fu]=1,l["border"+f+fu]=0,l[a.p]=n+"px",te.set(t,l)},Ue=[],Q0={},jc,$M=function(){return vi()-Ha>34&&(jc||(jc=requestAnimationFrame(ts)))},Hl=function(){(!Ni||!Ni.isPressed||Ni.startX>tn.clientWidth)&&(Oe.cache++,Ni?jc||(jc=requestAnimationFrame(ts)):ts(),Ha||ko("scrollStart"),Ha=vi())},O_=function(){tb=Le.innerWidth,$E=Le.innerHeight},Ec=function(t){Oe.cache++,(t===!0||!gi&&!JE&&!mn.fullscreenElement&&!mn.webkitFullscreenElement&&(!j0||tb!==Le.innerWidth||Math.abs(Le.innerHeight-$E)>Le.innerHeight*.25))&&Md.restart(!0)},Vo={},PN=[],lb=function o(){return ii(Ie,"scrollEnd",o)||No(!0)},ko=function(t){return Vo[t]&&Vo[t].map(function(n){return n()})||PN},ca=[],ub=function(t){for(var n=0;n<ca.length;n+=5)(!t||ca[n+4]&&ca[n+4].query===t)&&(ca[n].style.cssText=ca[n+1],ca[n].getBBox&&ca[n].setAttribute("transform",ca[n+2]||""),ca[n+3].uncache=1)},cb=function(){return Oe.forEach(function(t){return yi(t)&&++t.cacheID&&(t.rec=t())})},zg=function(t,n){var a;for(Li=0;Li<Ue.length;Li++)a=Ue[Li],a&&(!n||a._ctx===n)&&(t?a.kill(1):a.revert(!0,!0));Uc=!0,n&&ub(n),n||ko("revert")},fb=function(t,n){Oe.cache++,(n||!Oi)&&Oe.forEach(function(a){return yi(a)&&a.cacheID++&&(a.rec=0)}),fa(t)&&(Le.history.scrollRestoration=Ug=t)},Oi,Bo=0,t1,FN=function(){if(t1!==Bo){var t=t1=Bo;requestAnimationFrame(function(){return t===Bo&&No(!0)})}},hb=function(){tn.appendChild(Jl),Ng=!Ni&&Jl.offsetHeight||Le.innerHeight,tn.removeChild(Jl)},e1=function(t){return qc(".gsap-marker-start, .gsap-marker-end, .gsap-marker-scroller-start, .gsap-marker-scroller-end").forEach(function(n){return n.style.display=t?"none":"block"})},No=function(t,n){if(da=mn.documentElement,tn=mn.body,Dg=[Le,mn,da,tn],Ha&&!t&&!Uc){ai(Ie,"scrollEnd",lb);return}hb(),Oi=Ie.isRefreshing=!0,Uc||cb();var a=ko("refreshInit");QE&&Ie.sort(),n||zg(),Oe.forEach(function(r){yi(r)&&(r.smooth&&(r.target.style.scrollBehavior="auto"),r(0))}),Ue.slice(0).forEach(function(r){return r.refresh()}),Uc=!1,Ue.forEach(function(r){if(r._subPinOffset&&r.pin){var l=r.vars.horizontal?"offsetWidth":"offsetHeight",c=r.pin[l];r.revert(!0,1),r.adjustPinSpacing(r.pin[l]-c),r.refresh()}}),K0=1,e1(!0),Ue.forEach(function(r){var l=_r(r.scroller,r._dir),c=r.vars.end==="max"||r._endClamp&&r.end>l,f=r._startClamp&&r.start>=l;(c||f)&&r.setPositions(f?l-1:r.start,c?Math.max(f?l:r.start+1,l):r.end,!0)}),e1(!1),K0=0,a.forEach(function(r){return r&&r.render&&r.render(-1)}),Oe.forEach(function(r){yi(r)&&(r.smooth&&requestAnimationFrame(function(){return r.target.style.scrollBehavior="smooth"}),r.rec&&r(r.rec))}),fb(Ug,1),Md.pause(),Bo++,Oi=2,ts(2),Ue.forEach(function(r){return yi(r.vars.onRefresh)&&r.vars.onRefresh(r)}),Oi=Ie.isRefreshing=!1,ko("refresh")},J0=0,sd=1,Fc,ts=function(t){if(t===2||!Oi&&!Uc){Ie.isUpdating=!0,Fc&&Fc.update(0);var n=Ue.length,a=vi(),r=a-N_>=50,l=n&&Ue[0].scroll();if(sd=J0>l?-1:1,Oi||(J0=l),r&&(Ha&&!Ld&&a-Ha>200&&(Ha=0,ko("scrollEnd")),xc=N_,N_=a),sd<0){for(Li=n;Li-- >0;)Ue[Li]&&Ue[Li].update(0,r);sd=1}else for(Li=0;Li<n;Li++)Ue[Li]&&Ue[Li].update(0,r);Ie.isUpdating=!1}jc=0},$0=[rb,sb,Og,Lg,Oa+Pc,Oa+Nc,Oa+Oc,Oa+Lc,"display","flexShrink","float","zIndex","gridColumnStart","gridColumnEnd","gridRowStart","gridRowEnd","gridArea","justifySelf","alignSelf","placeSelf","order"],od=$0.concat([zo,Io,"boxSizing","max"+fu,"max"+Pg,"position",Oa,Yn,Yn+Oc,Yn+Nc,Yn+Pc,Yn+Lc]),zN=function(t,n,a){$l(a);var r=t._gsap;if(r.spacerIsNative)$l(r.spacerState);else if(t._gsap.swappedIn){var l=n.parentNode;l&&(l.insertBefore(t,n),l.removeChild(n))}t._gsap.swappedIn=!1},P_=function(t,n,a,r){if(!t._gsap.swappedIn){for(var l=$0.length,c=n.style,f=t.style,p;l--;)p=$0[l],c[p]=a[p];c.position=a.position==="absolute"?"absolute":"relative",a.display==="inline"&&(c.display="inline-block"),f[Og]=f[Lg]="auto",c.flexBasis=a.flexBasis||"auto",c.overflow="visible",c.boxSizing="border-box",c[zo]=Ed(t,Fi)+Kn,c[Io]=Ed(t,Qn)+Kn,c[Yn]=f[Oa]=f[sb]=f[rb]="0",$l(r),f[zo]=f["max"+fu]=a[zo],f[Io]=f["max"+Pg]=a[Io],f[Yn]=a[Yn],t.parentNode!==n&&(t.parentNode.insertBefore(n,t),n.appendChild(t)),t._gsap.swappedIn=!0}},IN=/([A-Z])/g,$l=function(t){if(t){var n=t.t.style,a=t.length,r=0,l,c;for((t.t._gsap||te.core.getCache(t.t)).uncache=1;r<a;r+=2)c=t[r+1],l=t[r],c?n[l]=c:n[l]&&n.removeProperty(l.replace(IN,"-$1").toLowerCase())}},Xh=function(t){for(var n=od.length,a=t.style,r=[],l=0;l<n;l++)r.push(od[l],a[od[l]]);return r.t=t,r},BN=function(t,n,a){for(var r=[],l=t.length,c=a?8:0,f;c<l;c+=2)f=t[c],r.push(f,f in n?n[f]:t[c+1]);return r.t=t.t,r},ld={left:0,top:0},n1=function(t,n,a,r,l,c,f,p,d,_,v,g,x,M){yi(t)&&(t=t(p)),fa(t)&&t.substr(0,3)==="max"&&(t=g+(t.charAt(4)==="="?ad("0"+t.substr(3),a):0));var E=x?x.time():0,y,S,R;if(x&&x.seek(0),isNaN(t)||(t=+t),Mc(t))x&&(t=te.utils.mapRange(x.scrollTrigger.start,x.scrollTrigger.end,0,g,t)),f&&rd(f,a,r,!0);else{yi(n)&&(n=n(p));var U=(t||"0").split(" "),C,O,P,L;R=Wi(n,p)||tn,C=Zr(R)||{},(!C||!C.left&&!C.top)&&Pa(R).display==="none"&&(L=R.style.display,R.style.display="block",C=Zr(R),L?R.style.display=L:R.style.removeProperty("display")),O=ad(U[0],C[r.d]),P=ad(U[1]||"0",a),t=C[r.p]-d[r.p]-_+O+l-P,f&&rd(f,P,r,a-P<20||f._isStart&&P>20),a-=a-P}if(M&&(p[M]=t||-.001,t<0&&(t=0)),c){var T=t+a,w=c._isStart;y="scroll"+r.d2,rd(c,T,r,w&&T>20||!w&&(v?Math.max(tn[y],da[y]):c.parentNode[y])<=T+1),v&&(d=Zr(f),v&&(c.style[r.op.p]=d[r.op.p]-r.op.m-c._offset+Kn))}return x&&R&&(y=Zr(R),x.seek(g),S=Zr(R),x._caScrollDist=y[r.p]-S[r.p],t=t/x._caScrollDist*g),x&&x.seek(E),x?t:Math.round(t)},HN=/(webkit|moz|length|cssText|inset)/i,i1=function(t,n,a,r){if(t.parentNode!==n){var l=t.style,c,f;if(n===tn){t._stOrig=l.cssText,f=Pa(t);for(c in f)!+c&&!HN.test(c)&&f[c]&&typeof l[c]=="string"&&c!=="0"&&(l[c]=f[c]);l.top=a,l.left=r}else l.cssText=t._stOrig;te.core.getCache(t).uncache=1,n.appendChild(t)}},db=function(t,n,a){var r=n,l=r;return function(c){var f=Math.round(t());return f!==r&&f!==l&&Math.abs(f-r)>3&&Math.abs(f-l)>3&&(c=f,a&&a()),l=r,r=Math.round(c),r}},Wh=function(t,n,a){var r={};r[n.p]="+="+a,te.set(t,r)},a1=function(t,n){var a=Ks(t,n),r="_scroll"+n.p2,l=function c(f,p,d,_,v){var g=c.tween,x=p.onComplete,M={};d=d||a();var E=db(a,d,function(){g.kill(),c.tween=0});return v=_&&v||0,_=_||f-d,g&&g.kill(),p[r]=f,p.inherit=!1,p.modifiers=M,M[r]=function(){return E(d+_*g.ratio+v*g.ratio*g.ratio)},p.onUpdate=function(){Oe.cache++,c.tween&&ts()},p.onComplete=function(){c.tween=0,x&&x.call(g)},g=c.tween=te.to(t,p),g};return t[r]=a,a.wheelHandler=function(){return l.tween&&l.tween.kill()&&(l.tween=0)},ai(t,"wheel",a.wheelHandler),Ie.isTouch&&ai(t,"touchmove",a.wheelHandler),l},Ie=(function(){function o(n,a){Gl||o.register(te)||console.warn("Please gsap.registerPlugin(ScrollTrigger)"),Z0(this),this.init(n,a)}var t=o.prototype;return t.init=function(a,r){if(this.progress=this.start=0,this.vars&&this.kill(!0,!0),!yc){this.update=this.refresh=this.kill=cr;return}a=QM(fa(a)||Mc(a)||a.nodeType?{trigger:a}:a,Vh);var l=a,c=l.onUpdate,f=l.toggleClass,p=l.id,d=l.onToggle,_=l.onRefresh,v=l.scrub,g=l.trigger,x=l.pin,M=l.pinSpacing,E=l.invalidateOnRefresh,y=l.anticipatePin,S=l.onScrubComplete,R=l.onSnapComplete,U=l.once,C=l.snap,O=l.pinReparent,P=l.pinSpacer,L=l.containerAnimation,T=l.fastScrollEnd,w=l.preventOverlaps,q=a.horizontal||a.containerAnimation&&a.horizontal!==!1?Fi:Qn,G=!v&&v!==0,k=Wi(a.scroller||Le),J=te.core.getCache(k),et=Go(k),Q=("pinType"in a?a.pinType:Ws(k,"pinType")||et&&"fixed")==="fixed",F=[a.onEnter,a.onLeave,a.onEnterBack,a.onLeaveBack],I=G&&a.toggleActions.split(" "),it="markers"in a?a.markers:Vh.markers,ht=et?0:parseFloat(Pa(k)["border"+q.p2+fu])||0,H=this,z=a.onRefreshInit&&function(){return a.onRefreshInit(H)},K=DN(k,et,q),xt=UN(k,et),Tt=0,Ut=0,nt=0,_t=Ks(k,q),Et,Ft,ee,Kt,Ne,qt,re,_e,se,lt,W,We,Ee,ce,Wt,B,A,j,gt,vt,dt,Gt,wt,ie,Yt,Rt,At,Ht,Pt,zt,pe,V,Dt,Ct,Lt,bt,mt,Xt,le;if(H._startClamp=H._endClamp=!1,H._dir=q,y*=45,H.scroller=k,H.scroll=L?L.time.bind(L):_t,Kt=_t(),H.vars=a,r=r||a.animation,"refreshPriority"in a&&(QE=1,a.refreshPriority===-9999&&(Fc=H)),J.tweenScroll=J.tweenScroll||{top:a1(k,Qn),left:a1(k,Fi)},H.tweenTo=Et=J.tweenScroll[q.p],H.scrubDuration=function(It){Dt=Mc(It)&&It,Dt?V?V.duration(It):V=te.to(r,{ease:"expo",totalProgress:"+=0",inherit:!1,duration:Dt,paused:!0,onComplete:function(){return S&&S(H)}}):(V&&V.progress(1).kill(),V=0)},r&&(r.vars.lazy=!1,r._initted&&!H.isReverted||r.vars.immediateRender!==!1&&a.immediateRender!==!1&&r.duration()&&r.render(0,!0,!0),H.animation=r.pause(),r.scrollTrigger=H,H.scrubDuration(v),zt=0,p||(p=r.vars.id)),C&&((!Ao(C)||C.push)&&(C={snapTo:C}),"scrollBehavior"in tn.style&&te.set(et?[tn,da]:k,{scrollBehavior:"auto"}),Oe.forEach(function(It){return yi(It)&&It.target===(et?mn.scrollingElement||da:k)&&(It.smooth=!1)}),ee=yi(C.snapTo)?C.snapTo:C.snapTo==="labels"?LN(r):C.snapTo==="labelsDirectional"?ON(r):C.directional!==!1?function(It,he){return Fg(C.snapTo)(It,vi()-Ut<500?0:he.direction)}:te.utils.snap(C.snapTo),Ct=C.duration||{min:.1,max:2},Ct=Ao(Ct)?Dc(Ct.min,Ct.max):Dc(Ct,Ct),Lt=te.delayedCall(C.delay||Dt/2||.1,function(){var It=_t(),he=vi()-Ut<500,oe=Et.tween;if((he||Math.abs(H.getVelocity())<10)&&!oe&&!Ld&&Tt!==It){var de=(It-qt)/ce,_n=r&&!G?r.totalProgress():de,ge=he?0:(_n-pe)/(vi()-xc)*1e3||0,rn=te.utils.clamp(-de,1-de,Bl(ge/2)*ge/.185),sn=de+(C.inertia===!1?0:rn),Te,xe,Pe=C,In=Pe.onStart,on=Pe.onInterrupt,ti=Pe.onComplete;if(Te=ee(sn,H),Mc(Te)||(Te=sn),xe=Math.max(0,Math.round(qt+Te*ce)),It<=re&&It>=qt&&xe!==It){if(oe&&!oe._initted&&oe.data<=Bl(xe-It))return;C.inertia===!1&&(rn=Te-de),Et(xe,{duration:Ct(Bl(Math.max(Bl(sn-_n),Bl(Te-_n))*.185/ge/.05||0)),ease:C.ease||"power3",data:Bl(xe-It),onInterrupt:function(){return Lt.restart(!0)&&on&&on(H)},onComplete:function(){H.update(),Tt=_t(),r&&!G&&(V?V.resetTo("totalProgress",Te,r._tTime/r._tDur):r.progress(Te)),zt=pe=r&&!G?r.totalProgress():H.progress,R&&R(H),ti&&ti(H)}},It,rn*ce,xe-It-rn*ce),In&&In(H,Et.tween)}}else H.isActive&&Tt!==It&&Lt.restart(!0)}).pause()),p&&(Q0[p]=H),g=H.trigger=Wi(g||x!==!0&&x),le=g&&g._gsap&&g._gsap.stRevert,le&&(le=le(H)),x=x===!0?g:Wi(x),fa(f)&&(f={targets:g,className:f}),x&&(M===!1||M===Oa||(M=!M&&x.parentNode&&x.parentNode.style&&Pa(x.parentNode).display==="flex"?!1:Yn),H.pin=x,Ft=te.core.getCache(x),Ft.spacer?Wt=Ft.pinState:(P&&(P=Wi(P),P&&!P.nodeType&&(P=P.current||P.nativeElement),Ft.spacerIsNative=!!P,P&&(Ft.spacerState=Xh(P))),Ft.spacer=j=P||mn.createElement("div"),j.classList.add("pin-spacer"),p&&j.classList.add("pin-spacer-"+p),Ft.pinState=Wt=Xh(x)),a.force3D!==!1&&te.set(x,{force3D:!0}),H.spacer=j=Ft.spacer,Pt=Pa(x),ie=Pt[M+q.os2],vt=te.getProperty(x),dt=te.quickSetter(x,q.a,Kn),P_(x,j,Pt),A=Xh(x)),it){We=Ao(it)?QM(it,JM):JM,lt=kh("scroller-start",p,k,q,We,0),W=kh("scroller-end",p,k,q,We,0,lt),gt=lt["offset"+q.op.d2];var Ge=Wi(Ws(k,"content")||k);_e=this.markerStart=kh("start",p,Ge,q,We,gt,0,L),se=this.markerEnd=kh("end",p,Ge,q,We,gt,0,L),L&&(Xt=te.quickSetter([_e,se],q.a,Kn)),!Q&&!(yr.length&&Ws(k,"fixedMarkers")===!0)&&(NN(et?tn:k),te.set([lt,W],{force3D:!0}),Rt=te.quickSetter(lt,q.a,Kn),Ht=te.quickSetter(W,q.a,Kn))}if(L){var Vt=L.vars.onUpdate,Jt=L.vars.onUpdateParams;L.eventCallback("onUpdate",function(){H.update(0,0,1),Vt&&Vt.apply(L,Jt||[])})}if(H.previous=function(){return Ue[Ue.indexOf(H)-1]},H.next=function(){return Ue[Ue.indexOf(H)+1]},H.revert=function(It,he){if(!he)return H.kill(!0);var oe=It!==!1||!H.enabled,de=gi;oe!==H.isReverted&&(oe&&(bt=Math.max(_t(),H.scroll.rec||0),nt=H.progress,mt=r&&r.progress()),_e&&[_e,se,lt,W].forEach(function(_n){return _n.style.display=oe?"none":"block"}),oe&&(gi=H,H.update(oe)),x&&(!O||!H.isActive)&&(oe?zN(x,j,Wt):P_(x,j,Pa(x),Yt)),oe||H.update(oe),gi=de,H.isReverted=oe)},H.refresh=function(It,he,oe,de){if(!((gi||!H.enabled)&&!he)){if(x&&It&&Ha){ai(o,"scrollEnd",lb);return}!Oi&&z&&z(H),gi=H,Et.tween&&!oe&&(Et.tween.kill(),Et.tween=0),V&&V.pause(),E&&r&&(r.revert({kill:!1}).invalidate(),r.getChildren?r.getChildren(!0,!0,!1).forEach(function(Zt){return Zt.vars.immediateRender&&Zt.render(0,!0,!0)}):r.vars.immediateRender&&r.render(0,!0,!0)),H.isReverted||H.revert(!0,!0),H._subPinOffset=!1;var _n=K(),ge=xt(),rn=L?L.duration():_r(k,q),sn=ce<=.01||!ce,Te=0,xe=de||0,Pe=Ao(oe)?oe.end:a.end,In=a.endTrigger||g,on=Ao(oe)?oe.start:a.start||(a.start===0||!g?0:x?"0 0":"0 100%"),ti=H.pinnedContainer=a.pinnedContainer&&Wi(a.pinnedContainer,H),bi=g&&Math.max(0,Ue.indexOf(H))||0,gn=bi,Tn,vn,di,Sa,D,Y,ut,st,at,Nt,Bt,Ot,jt;for(it&&Ao(oe)&&(Ot=te.getProperty(lt,q.p),jt=te.getProperty(W,q.p));gn-- >0;)Y=Ue[gn],Y.end||Y.refresh(0,1)||(gi=H),ut=Y.pin,ut&&(ut===g||ut===x||ut===ti)&&!Y.isReverted&&(Nt||(Nt=[]),Nt.unshift(Y),Y.revert(!0,!0)),Y!==Ue[gn]&&(bi--,gn--);for(yi(on)&&(on=on(H)),on=qM(on,"start",H),qt=n1(on,g,_n,q,_t(),_e,lt,H,ge,ht,Q,rn,L,H._startClamp&&"_startClamp")||(x?-.001:0),yi(Pe)&&(Pe=Pe(H)),fa(Pe)&&!Pe.indexOf("+=")&&(~Pe.indexOf(" ")?Pe=(fa(on)?on.split(" ")[0]:"")+Pe:(Te=ad(Pe.substr(2),_n),Pe=fa(on)?on:(L?te.utils.mapRange(0,L.duration(),L.scrollTrigger.start,L.scrollTrigger.end,qt):qt)+Te,In=g)),Pe=qM(Pe,"end",H),re=Math.max(qt,n1(Pe||(In?"100% 0":rn),In,_n,q,_t()+Te,se,W,H,ge,ht,Q,rn,L,H._endClamp&&"_endClamp"))||-.001,Te=0,gn=bi;gn--;)Y=Ue[gn]||{},ut=Y.pin,ut&&Y.start-Y._pinPush<=qt&&!L&&Y.end>0&&(Tn=Y.end-(H._startClamp?Math.max(0,Y.start):Y.start),(ut===g&&Y.start-Y._pinPush<qt||ut===ti)&&isNaN(on)&&(Te+=Tn*(1-Y.progress)),ut===x&&(xe+=Tn));if(qt+=Te,re+=Te,H._startClamp&&(H._startClamp+=Te),H._endClamp&&!Oi&&(H._endClamp=re||-.001,re=Math.min(re,_r(k,q))),ce=re-qt||(qt-=.01)&&.001,sn&&(nt=te.utils.clamp(0,1,te.utils.normalize(qt,re,bt))),H._pinPush=xe,_e&&Te&&(Tn={},Tn[q.a]="+="+Te,ti&&(Tn[q.p]="-="+_t()),te.set([_e,se],Tn)),x&&!(K0&&H.end>=_r(k,q)))Tn=Pa(x),Sa=q===Qn,di=_t(),Gt=parseFloat(vt(q.a))+xe,!rn&&re>1&&(Bt=(et?mn.scrollingElement||da:k).style,Bt={style:Bt,value:Bt["overflow"+q.a.toUpperCase()]},et&&Pa(tn)["overflow"+q.a.toUpperCase()]!=="scroll"&&(Bt.style["overflow"+q.a.toUpperCase()]="scroll")),P_(x,j,Tn),A=Xh(x),vn=Zr(x,!0),st=Q&&Ks(k,Sa?Fi:Qn)(),M?(Yt=[M+q.os2,ce+xe+Kn],Yt.t=j,gn=M===Yn?Ed(x,q)+ce+xe:0,gn&&(Yt.push(q.d,gn+Kn),j.style.flexBasis!=="auto"&&(j.style.flexBasis=gn+Kn)),$l(Yt),ti&&Ue.forEach(function(Zt){Zt.pin===ti&&Zt.vars.pinSpacing!==!1&&(Zt._subPinOffset=!0)}),Q&&_t(bt)):(gn=Ed(x,q),gn&&j.style.flexBasis!=="auto"&&(j.style.flexBasis=gn+Kn)),Q&&(D={top:vn.top+(Sa?di-qt:st)+Kn,left:vn.left+(Sa?st:di-qt)+Kn,boxSizing:"border-box",position:"fixed"},D[zo]=D["max"+fu]=Math.ceil(vn.width)+Kn,D[Io]=D["max"+Pg]=Math.ceil(vn.height)+Kn,D[Oa]=D[Oa+Oc]=D[Oa+Nc]=D[Oa+Pc]=D[Oa+Lc]="0",D[Yn]=Tn[Yn],D[Yn+Oc]=Tn[Yn+Oc],D[Yn+Nc]=Tn[Yn+Nc],D[Yn+Pc]=Tn[Yn+Pc],D[Yn+Lc]=Tn[Yn+Lc],B=BN(Wt,D,O),Oi&&_t(0)),r?(at=r._initted,D_(1),r.render(r.duration(),!0,!0),wt=vt(q.a)-Gt+ce+xe,At=Math.abs(ce-wt)>1,Q&&At&&B.splice(B.length-2,2),r.render(0,!0,!0),at||r.invalidate(!0),r.parent||r.totalTime(r.totalTime()),D_(0)):wt=ce,Bt&&(Bt.value?Bt.style["overflow"+q.a.toUpperCase()]=Bt.value:Bt.style.removeProperty("overflow-"+q.a));else if(g&&_t()&&!L)for(vn=g.parentNode;vn&&vn!==tn;)vn._pinOffset&&(qt-=vn._pinOffset,re-=vn._pinOffset),vn=vn.parentNode;Nt&&Nt.forEach(function(Zt){return Zt.revert(!1,!0)}),H.start=qt,H.end=re,Kt=Ne=Oi?bt:_t(),!L&&!Oi&&(Kt<bt&&_t(bt),H.scroll.rec=0),H.revert(!1,!0),Ut=vi(),Lt&&(Tt=-1,Lt.restart(!0)),gi=0,r&&G&&(r._initted||mt)&&r.progress()!==mt&&r.progress(mt||0,!0).render(r.time(),!0,!0),(sn||nt!==H.progress||L||E||r&&!r._initted)&&(r&&!G&&(r._initted||nt||r.vars.immediateRender!==!1)&&r.totalProgress(L&&qt<-.001&&!nt?te.utils.normalize(qt,re,0):nt,!0),H.progress=sn||(Kt-qt)/ce===nt?0:nt),x&&M&&(j._pinOffset=Math.round(H.progress*wt)),V&&V.invalidate(),isNaN(Ot)||(Ot-=te.getProperty(lt,q.p),jt-=te.getProperty(W,q.p),Wh(lt,q,Ot),Wh(_e,q,Ot-(de||0)),Wh(W,q,jt),Wh(se,q,jt-(de||0))),sn&&!Oi&&H.update(),_&&!Oi&&!Ee&&(Ee=!0,_(H),Ee=!1)}},H.getVelocity=function(){return(_t()-Ne)/(vi()-xc)*1e3||0},H.endAnimation=function(){dc(H.callbackAnimation),r&&(V?V.progress(1):r.paused()?G||dc(r,H.direction<0,1):dc(r,r.reversed()))},H.labelToScroll=function(It){return r&&r.labels&&(qt||H.refresh()||qt)+r.labels[It]/r.duration()*ce||0},H.getTrailing=function(It){var he=Ue.indexOf(H),oe=H.direction>0?Ue.slice(0,he).reverse():Ue.slice(he+1);return(fa(It)?oe.filter(function(de){return de.vars.preventOverlaps===It}):oe).filter(function(de){return H.direction>0?de.end<=qt:de.start>=re})},H.update=function(It,he,oe){if(!(L&&!oe&&!It)){var de=Oi===!0?bt:H.scroll(),_n=It?0:(de-qt)/ce,ge=_n<0?0:_n>1?1:_n||0,rn=H.progress,sn,Te,xe,Pe,In,on,ti,bi;if(he&&(Ne=Kt,Kt=L?_t():de,C&&(pe=zt,zt=r&&!G?r.totalProgress():ge)),y&&x&&!gi&&!Ih&&Ha&&(!ge&&qt<de+(de-Ne)/(vi()-xc)*y?ge=1e-4:ge===1&&re>de+(de-Ne)/(vi()-xc)*y&&(ge=.9999)),ge!==rn&&H.enabled){if(sn=H.isActive=!!ge&&ge<1,Te=!!rn&&rn<1,on=sn!==Te,In=on||!!ge!=!!rn,H.direction=ge>rn?1:-1,H.progress=ge,In&&!gi&&(xe=ge&&!rn?0:ge===1?1:rn===1?2:3,G&&(Pe=!on&&I[xe+1]!=="none"&&I[xe+1]||I[xe],bi=r&&(Pe==="complete"||Pe==="reset"||Pe in r))),w&&(on||bi)&&(bi||v||!r)&&(yi(w)?w(H):H.getTrailing(w).forEach(function(di){return di.endAnimation()})),G||(V&&!gi&&!Ih?(V._dp._time-V._start!==V._time&&V.render(V._dp._time-V._start),V.resetTo?V.resetTo("totalProgress",ge,r._tTime/r._tDur):(V.vars.totalProgress=ge,V.invalidate().restart())):r&&r.totalProgress(ge,!!(gi&&(Ut||It)))),x){if(It&&M&&(j.style[M+q.os2]=ie),!Q)dt(Sc(Gt+wt*ge));else if(In){if(ti=!It&&ge>rn&&re+1>de&&de+1>=_r(k,q),O)if(!It&&(sn||ti)){var gn=Zr(x,!0),Tn=de-qt;i1(x,tn,gn.top+(q===Qn?Tn:0)+Kn,gn.left+(q===Qn?0:Tn)+Kn)}else i1(x,j);$l(sn||ti?B:A),At&&ge<1&&sn||dt(Gt+(ge===1&&!ti?wt:0))}}C&&!Et.tween&&!gi&&!Ih&&Lt.restart(!0),f&&(on||U&&ge&&(ge<1||!U_))&&qc(f.targets).forEach(function(di){return di.classList[sn||U?"add":"remove"](f.className)}),c&&!G&&!It&&c(H),In&&!gi?(G&&(bi&&(Pe==="complete"?r.pause().totalProgress(1):Pe==="reset"?r.restart(!0).pause():Pe==="restart"?r.restart(!0):r[Pe]()),c&&c(H)),(on||!U_)&&(d&&on&&L_(H,d),F[xe]&&L_(H,F[xe]),U&&(ge===1?H.kill(!1,1):F[xe]=0),on||(xe=ge===1?1:3,F[xe]&&L_(H,F[xe]))),T&&!sn&&Math.abs(H.getVelocity())>(Mc(T)?T:2500)&&(dc(H.callbackAnimation),V?V.progress(1):dc(r,Pe==="reverse"?1:!ge,1))):G&&c&&!gi&&c(H)}if(Ht){var vn=L?de/L.duration()*(L._caScrollDist||0):de;Rt(vn+(lt._isFlipped?1:0)),Ht(vn)}Xt&&Xt(-de/L.duration()*(L._caScrollDist||0))}},H.enable=function(It,he){H.enabled||(H.enabled=!0,ai(k,"resize",Ec),et||ai(k,"scroll",Hl),z&&ai(o,"refreshInit",z),It!==!1&&(H.progress=nt=0,Kt=Ne=Tt=_t()),he!==!1&&H.refresh())},H.getTween=function(It){return It&&Et?Et.tween:V},H.setPositions=function(It,he,oe,de){if(L){var _n=L.scrollTrigger,ge=L.duration(),rn=_n.end-_n.start;It=_n.start+rn*It/ge,he=_n.start+rn*he/ge}H.refresh(!1,!1,{start:jM(It,oe&&!!H._startClamp),end:jM(he,oe&&!!H._endClamp)},de),H.update()},H.adjustPinSpacing=function(It){if(Yt&&It){var he=Yt.indexOf(q.d)+1;Yt[he]=parseFloat(Yt[he])+It+Kn,Yt[1]=parseFloat(Yt[1])+It+Kn,$l(Yt)}},H.disable=function(It,he){if(It!==!1&&H.revert(!0,!0),H.enabled&&(H.enabled=H.isActive=!1,he||V&&V.pause(),bt=0,Ft&&(Ft.uncache=1),z&&ii(o,"refreshInit",z),Lt&&(Lt.pause(),Et.tween&&Et.tween.kill()&&(Et.tween=0)),!et)){for(var oe=Ue.length;oe--;)if(Ue[oe].scroller===k&&Ue[oe]!==H)return;ii(k,"resize",Ec),et||ii(k,"scroll",Hl)}},H.kill=function(It,he){H.disable(It,he),V&&!he&&V.kill(),p&&delete Q0[p];var oe=Ue.indexOf(H);oe>=0&&Ue.splice(oe,1),oe===Li&&sd>0&&Li--,oe=0,Ue.forEach(function(de){return de.scroller===H.scroller&&(oe=1)}),oe||Oi||(H.scroll.rec=0),r&&(r.scrollTrigger=null,It&&r.revert({kill:!1}),he||r.kill()),_e&&[_e,se,lt,W].forEach(function(de){return de.parentNode&&de.parentNode.removeChild(de)}),Fc===H&&(Fc=0),x&&(Ft&&(Ft.uncache=1),oe=0,Ue.forEach(function(de){return de.pin===x&&oe++}),oe||(Ft.spacer=0)),a.onKill&&a.onKill(H)},Ue.push(H),H.enable(!1,!1),le&&le(H),r&&r.add&&!ce){var be=H.update;H.update=function(){H.update=be,Oe.cache++,qt||re||H.refresh()},te.delayedCall(.01,H.update),ce=.01,qt=re=0}else H.refresh();x&&FN()},o.register=function(a){return Gl||(te=a||nb(),eb()&&window.document&&o.enable(),Gl=yc),Gl},o.defaults=function(a){if(a)for(var r in a)Vh[r]=a[r];return Vh},o.disable=function(a,r){yc=0,Ue.forEach(function(c){return c[r?"kill":"disable"](a)}),ii(Le,"wheel",Hl),ii(mn,"scroll",Hl),clearInterval(zh),ii(mn,"touchcancel",cr),ii(tn,"touchstart",cr),Hh(ii,mn,"pointerdown,touchstart,mousedown",ZM),Hh(ii,mn,"pointerup,touchend,mouseup",KM),Md.kill(),Bh(ii);for(var l=0;l<Oe.length;l+=3)Gh(ii,Oe[l],Oe[l+1]),Gh(ii,Oe[l],Oe[l+2])},o.enable=function(){if(Le=window,mn=document,da=mn.documentElement,tn=mn.body,te&&(qc=te.utils.toArray,Dc=te.utils.clamp,Z0=te.core.context||cr,D_=te.core.suppressOverwrites||cr,Ug=Le.history.scrollRestoration||"auto",J0=Le.pageYOffset||0,te.core.globals("ScrollTrigger",o),tn)){yc=1,Jl=document.createElement("div"),Jl.style.height="100vh",Jl.style.position="absolute",hb(),wN(),Fn.register(te),o.isTouch=Fn.isTouch,Ps=Fn.isTouch&&/(iPad|iPhone|iPod|Mac)/g.test(navigator.userAgent),j0=Fn.isTouch===1,ai(Le,"wheel",Hl),Dg=[Le,mn,da,tn],te.matchMedia?(o.matchMedia=function(d){var _=te.matchMedia(),v;for(v in d)_.add(v,d[v]);return _},te.addEventListener("matchMediaInit",function(){cb(),zg()}),te.addEventListener("matchMediaRevert",function(){return ub()}),te.addEventListener("matchMedia",function(){No(0,1),ko("matchMedia")}),te.matchMedia().add("(orientation: portrait)",function(){return O_(),O_})):console.warn("Requires GSAP 3.11.0 or later"),O_(),ai(mn,"scroll",Hl);var a=tn.hasAttribute("style"),r=tn.style,l=r.borderTopStyle,c=te.core.Animation.prototype,f,p;for(c.revert||Object.defineProperty(c,"revert",{value:function(){return this.time(-.01,!0)}}),r.borderTopStyle="solid",f=Zr(tn),Qn.m=Math.round(f.top+Qn.sc())||0,Fi.m=Math.round(f.left+Fi.sc())||0,l?r.borderTopStyle=l:r.removeProperty("border-top-style"),a||(tn.setAttribute("style",""),tn.removeAttribute("style")),zh=setInterval($M,250),te.delayedCall(.5,function(){return Ih=0}),ai(mn,"touchcancel",cr),ai(tn,"touchstart",cr),Hh(ai,mn,"pointerdown,touchstart,mousedown",ZM),Hh(ai,mn,"pointerup,touchend,mouseup",KM),q0=te.utils.checkPrefix("transform"),od.push(q0),Gl=vi(),Md=te.delayedCall(.2,No).pause(),Vl=[mn,"visibilitychange",function(){var d=Le.innerWidth,_=Le.innerHeight;mn.hidden?(WM=d,YM=_):(WM!==d||YM!==_)&&Ec()},mn,"DOMContentLoaded",No,Le,"load",No,Le,"resize",Ec],Bh(ai),Ue.forEach(function(d){return d.enable(0,1)}),p=0;p<Oe.length;p+=3)Gh(ii,Oe[p],Oe[p+1]),Gh(ii,Oe[p],Oe[p+2])}},o.config=function(a){"limitCallbacks"in a&&(U_=!!a.limitCallbacks);var r=a.syncInterval;r&&clearInterval(zh)||(zh=r)&&setInterval($M,r),"ignoreMobileResize"in a&&(j0=o.isTouch===1&&a.ignoreMobileResize),"autoRefreshEvents"in a&&(Bh(ii)||Bh(ai,a.autoRefreshEvents||"none"),JE=(a.autoRefreshEvents+"").indexOf("resize")===-1)},o.scrollerProxy=function(a,r){var l=Wi(a),c=Oe.indexOf(l),f=Go(l);~c&&Oe.splice(c,f?6:2),r&&(f?yr.unshift(Le,r,tn,r,da,r):yr.unshift(l,r))},o.clearMatchMedia=function(a){Ue.forEach(function(r){return r._ctx&&r._ctx.query===a&&r._ctx.kill(!0,!0)})},o.isInViewport=function(a,r,l){var c=(fa(a)?Wi(a):a).getBoundingClientRect(),f=c[l?zo:Io]*r||0;return l?c.right-f>0&&c.left+f<Le.innerWidth:c.bottom-f>0&&c.top+f<Le.innerHeight},o.positionInViewport=function(a,r,l){fa(a)&&(a=Wi(a));var c=a.getBoundingClientRect(),f=c[l?zo:Io],p=r==null?f/2:r in bd?bd[r]*f:~r.indexOf("%")?parseFloat(r)*f/100:parseFloat(r)||0;return l?(c.left+p)/Le.innerWidth:(c.top+p)/Le.innerHeight},o.killAll=function(a){if(Ue.slice(0).forEach(function(l){return l.vars.id!=="ScrollSmoother"&&l.kill()}),a!==!0){var r=Vo.killAll||[];Vo={},r.forEach(function(l){return l()})}},o})();Ie.version="3.14.2";Ie.saveStyles=function(o){return o?qc(o).forEach(function(t){if(t&&t.style){var n=ca.indexOf(t);n>=0&&ca.splice(n,5),ca.push(t,t.style.cssText,t.getBBox&&t.getAttribute("transform"),te.core.getCache(t),Z0())}}):ca};Ie.revert=function(o,t){return zg(!o,t)};Ie.create=function(o,t){return new Ie(o,t)};Ie.refresh=function(o){return o?Ec(!0):(Gl||Ie.register())&&No(!0)};Ie.update=function(o){return++Oe.cache&&ts(o===!0?2:0)};Ie.clearScrollMemory=fb;Ie.maxScroll=function(o,t){return _r(o,t?Fi:Qn)};Ie.getScrollFunc=function(o,t){return Ks(Wi(o),t?Fi:Qn)};Ie.getById=function(o){return Q0[o]};Ie.getAll=function(){return Ue.filter(function(o){return o.vars.id!=="ScrollSmoother"})};Ie.isScrolling=function(){return!!Ha};Ie.snapDirectional=Fg;Ie.addEventListener=function(o,t){var n=Vo[o]||(Vo[o]=[]);~n.indexOf(t)||n.push(t)};Ie.removeEventListener=function(o,t){var n=Vo[o],a=n&&n.indexOf(t);a>=0&&n.splice(a,1)};Ie.batch=function(o,t){var n=[],a={},r=t.interval||.016,l=t.batchMax||1e9,c=function(d,_){var v=[],g=[],x=te.delayedCall(r,function(){_(v,g),v=[],g=[]}).pause();return function(M){v.length||x.restart(!0),v.push(M.trigger),g.push(M),l<=v.length&&x.progress(1)}},f;for(f in t)a[f]=f.substr(0,2)==="on"&&yi(t[f])&&f!=="onRefreshInit"?c(f,t[f]):t[f];return yi(l)&&(l=l(),ai(Ie,"refresh",function(){return l=t.batchMax()})),qc(o).forEach(function(p){var d={};for(f in a)d[f]=a[f];d.trigger=p,n.push(Ie.create(d))}),n};var r1=function(t,n,a,r){return n>r?t(r):n<0&&t(0),a>r?(r-n)/(a-n):a<0?n/(n-a):1},F_=function o(t,n){n===!0?t.style.removeProperty("touch-action"):t.style.touchAction=n===!0?"auto":n?"pan-"+n+(Fn.isTouch?" pinch-zoom":""):"none",t===da&&o(tn,n)},Yh={auto:1,scroll:1},GN=function(t){var n=t.event,a=t.target,r=t.axis,l=(n.changedTouches?n.changedTouches[0]:n).target,c=l._gsap||te.core.getCache(l),f=vi(),p;if(!c._isScrollT||f-c._isScrollT>2e3){for(;l&&l!==tn&&(l.scrollHeight<=l.clientHeight&&l.scrollWidth<=l.clientWidth||!(Yh[(p=Pa(l)).overflowY]||Yh[p.overflowX]));)l=l.parentNode;c._isScroll=l&&l!==a&&!Go(l)&&(Yh[(p=Pa(l)).overflowY]||Yh[p.overflowX]),c._isScrollT=f}(c._isScroll||r==="x")&&(n.stopPropagation(),n._gsapAllow=!0)},pb=function(t,n,a,r){return Fn.create({target:t,capture:!0,debounce:!1,lockAxis:!0,type:n,onWheel:r=r&&GN,onPress:r,onDrag:r,onScroll:r,onEnable:function(){return a&&ai(mn,Fn.eventTypes[0],o1,!1,!0)},onDisable:function(){return ii(mn,Fn.eventTypes[0],o1,!0)}})},VN=/(input|label|select|textarea)/i,s1,o1=function(t){var n=VN.test(t.target.tagName);(n||s1)&&(t._gsapAllow=!0,s1=n)},kN=function(t){Ao(t)||(t={}),t.preventDefault=t.isNormalizer=t.allowClicks=!0,t.type||(t.type="wheel,touch"),t.debounce=!!t.debounce,t.id=t.id||"normalizer";var n=t,a=n.normalizeScrollX,r=n.momentum,l=n.allowNestedScroll,c=n.onRelease,f,p,d=Wi(t.target)||da,_=te.core.globals().ScrollSmoother,v=_&&_.get(),g=Ps&&(t.content&&Wi(t.content)||v&&t.content!==!1&&!v.smooth()&&v.content()),x=Ks(d,Qn),M=Ks(d,Fi),E=1,y=(Fn.isTouch&&Le.visualViewport?Le.visualViewport.scale*Le.visualViewport.width:Le.outerWidth)/Le.innerWidth,S=0,R=yi(r)?function(){return r(f)}:function(){return r||2.8},U,C,O=pb(d,t.type,!0,l),P=function(){return C=!1},L=cr,T=cr,w=function(){p=_r(d,Qn),T=Dc(Ps?1:0,p),a&&(L=Dc(0,_r(d,Fi))),U=Bo},q=function(){g._gsap.y=Sc(parseFloat(g._gsap.y)+x.offset)+"px",g.style.transform="matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, "+parseFloat(g._gsap.y)+", 0, 1)",x.offset=x.cacheID=0},G=function(){if(C){requestAnimationFrame(P);var it=Sc(f.deltaY/2),ht=T(x.v-it);if(g&&ht!==x.v+x.offset){x.offset=ht-x.v;var H=Sc((parseFloat(g&&g._gsap.y)||0)-x.offset);g.style.transform="matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, "+H+", 0, 1)",g._gsap.y=H+"px",x.cacheID=Oe.cache,ts()}return!0}x.offset&&q(),C=!0},k,J,et,Q,F=function(){w(),k.isActive()&&k.vars.scrollY>p&&(x()>p?k.progress(1)&&x(p):k.resetTo("scrollY",p))};return g&&te.set(g,{y:"+=0"}),t.ignoreCheck=function(I){return Ps&&I.type==="touchmove"&&G()||E>1.05&&I.type!=="touchstart"||f.isGesturing||I.touches&&I.touches.length>1},t.onPress=function(){C=!1;var I=E;E=Sc((Le.visualViewport&&Le.visualViewport.scale||1)/y),k.pause(),I!==E&&F_(d,E>1.01?!0:a?!1:"x"),J=M(),et=x(),w(),U=Bo},t.onRelease=t.onGestureStart=function(I,it){if(x.offset&&q(),!it)Q.restart(!0);else{Oe.cache++;var ht=R(),H,z;a&&(H=M(),z=H+ht*.05*-I.velocityX/.227,ht*=r1(M,H,z,_r(d,Fi)),k.vars.scrollX=L(z)),H=x(),z=H+ht*.05*-I.velocityY/.227,ht*=r1(x,H,z,_r(d,Qn)),k.vars.scrollY=T(z),k.invalidate().duration(ht).play(.01),(Ps&&k.vars.scrollY>=p||H>=p-1)&&te.to({},{onUpdate:F,duration:ht})}c&&c(I)},t.onWheel=function(){k._ts&&k.pause(),vi()-S>1e3&&(U=0,S=vi())},t.onChange=function(I,it,ht,H,z){if(Bo!==U&&w(),it&&a&&M(L(H[2]===it?J+(I.startX-I.x):M()+it-H[1])),ht){x.offset&&q();var K=z[2]===ht,xt=K?et+I.startY-I.y:x()+ht-z[1],Tt=T(xt);K&&xt!==Tt&&(et+=Tt-xt),x(Tt)}(ht||it)&&ts()},t.onEnable=function(){F_(d,a?!1:"x"),Ie.addEventListener("refresh",F),ai(Le,"resize",F),x.smooth&&(x.target.style.scrollBehavior="auto",x.smooth=M.smooth=!1),O.enable()},t.onDisable=function(){F_(d,!0),ii(Le,"resize",F),Ie.removeEventListener("refresh",F),O.kill()},t.lockAxis=t.lockAxis!==!1,f=new Fn(t),f.iOS=Ps,Ps&&!x()&&x(1),Ps&&te.ticker.add(cr),Q=f._dc,k=te.to(f,{ease:"power4",paused:!0,inherit:!1,scrollX:a?"+=0.1":"+=0",scrollY:"+=0.1",modifiers:{scrollY:db(x,x(),function(){return k.pause()})},onUpdate:ts,onComplete:Q.vars.onComplete}),f};Ie.sort=function(o){if(yi(o))return Ue.sort(o);var t=Le.pageYOffset||0;return Ie.getAll().forEach(function(n){return n._sortY=n.trigger?t+n.trigger.getBoundingClientRect().top:n.start+Le.innerHeight}),Ue.sort(o||function(n,a){return(n.vars.refreshPriority||0)*-1e6+(n.vars.containerAnimation?1e6:n._sortY)-((a.vars.containerAnimation?1e6:a._sortY)+(a.vars.refreshPriority||0)*-1e6)})};Ie.observe=function(o){return new Fn(o)};Ie.normalizeScroll=function(o){if(typeof o>"u")return Ni;if(o===!0&&Ni)return Ni.enable();if(o===!1){Ni&&Ni.kill(),Ni=o;return}var t=o instanceof Fn?o:kN(o);return Ni&&Ni.target===t.target&&Ni.kill(),Go(t.target)&&(Ni=t),t};Ie.core={_getVelocityProp:Y0,_inputObserver:pb,_scrollers:Oe,_proxies:yr,bridge:{ss:function(){Ha||ko("scrollStart"),Ha=vi()},ref:function(){return gi}}};nb()&&te.registerPlugin(Ie);/*!
 * @gsap/react 2.1.2
 * https://gsap.com
 *
 * Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license or for
 * Club GSAP members, the agreement issued with that membership.
 * @author: Jack Doyle, jack@greensock.com
*/let l1=typeof document<"u"?Mi.useLayoutEffect:Mi.useEffect,u1=o=>o&&!Array.isArray(o)&&typeof o=="object",qh=[],XN={},mb=ur;const Ig=(o,t=qh)=>{let n=XN;u1(o)?(n=o,o=null,t="dependencies"in n?n.dependencies:qh):u1(t)&&(n=t,t="dependencies"in n?n.dependencies:qh),o&&typeof o!="function"&&console.warn("First parameter must be a function or config object");const{scope:a,revertOnUpdate:r}=n,l=Mi.useRef(!1),c=Mi.useRef(mb.context(()=>{},a)),f=Mi.useRef(d=>c.current.add(null,d)),p=t&&t.length&&!r;return p&&l1(()=>(l.current=!0,()=>c.current.revert()),qh),l1(()=>{if(o&&c.current.add(o,a),!p||!l.current)return()=>c.current.revert()},t),{context:c.current,contextSafe:f.current}};Ig.register=o=>{mb=o};Ig.headless=!0;ur.registerPlugin(Ie);function WN(){const o=Mi.useRef(null),t=Mi.useRef(null),n=Mi.useRef([]);Ig(()=>{let r=ur.matchMedia();return r.add("(min-width: 768px)",()=>{if(o.current){const l=o.current.querySelectorAll(".hero-anim");ur.from(l,{y:30,opacity:0,stagger:.2,duration:1,ease:"power3.out",delay:.2})}if(t.current){const l=t.current.querySelectorAll(".process-step");ur.from(l,{scrollTrigger:{trigger:t.current,start:"top 80%",toggleActions:"play none none none"},y:40,opacity:0,duration:.8,stagger:.2,ease:"power2.out"})}n.current.forEach(l=>{l&&ur.from(l,{scrollTrigger:{trigger:l,start:"top 90%"},opacity:0,duration:1.5,ease:"power2.inOut"})})}),r.add("(max-width: 767px)",()=>{if(o.current){const l=o.current.querySelectorAll(".hero-anim");ur.from(l,{y:20,opacity:0,stagger:.1,duration:.8,ease:"power3.out",delay:.1})}if(t.current){const l=t.current.querySelectorAll(".process-step");ur.from(l,{scrollTrigger:{trigger:t.current,start:"top 90%",toggleActions:"play none none none"},y:20,opacity:0,duration:.6,stagger:.1,ease:"power2.out"})}n.current.forEach(l=>{l&&ur.from(l,{scrollTrigger:{trigger:l,start:"top 90%"},opacity:0,duration:1,ease:"power2.inOut"})})}),()=>r.revert()},[]);const a=r=>{r&&!n.current.includes(r)&&n.current.push(r)};return tt.jsxs("div",{className:"min-h-screen bg-midnight text-white selection:bg-magenta/30 selection:text-white",children:[tt.jsx("nav",{className:"fixed top-0 left-0 right-0 z-50 px-6 py-4",children:tt.jsxs("div",{className:"max-w-7xl mx-auto glass-panel rounded-2xl px-6 py-3 flex items-center justify-between",children:[tt.jsxs("div",{className:"flex items-center gap-3",children:[tt.jsxs("svg",{width:"36",height:"36",viewBox:"0 0 100 100",className:"overflow-visible",children:[tt.jsxs("defs",{children:[tt.jsxs("linearGradient",{id:"logoGrad",x1:"0%",y1:"100%",x2:"100%",y2:"0%",children:[tt.jsx("stop",{offset:"0%",stopColor:"#00F0FF"}),tt.jsx("stop",{offset:"100%",stopColor:"#B026FF"})]}),tt.jsxs("filter",{id:"glow",children:[tt.jsx("feGaussianBlur",{stdDeviation:"2",result:"coloredBlur"}),tt.jsxs("feMerge",{children:[tt.jsx("feMergeNode",{in:"coloredBlur"}),tt.jsx("feMergeNode",{in:"SourceGraphic"})]})]})]}),tt.jsxs("g",{stroke:"url(#logoGrad)",strokeWidth:"2",fill:"none",children:[tt.jsx("circle",{cx:"50",cy:"50",r:"40"}),tt.jsx("circle",{cx:"50",cy:"50",r:"20"}),tt.jsx("line",{x1:"50",y1:"10",x2:"50",y2:"90"}),tt.jsx("line",{x1:"10",y1:"50",x2:"90",y2:"50"}),tt.jsx("line",{x1:"21.7",y1:"21.7",x2:"78.3",y2:"78.3"}),tt.jsx("line",{x1:"21.7",y1:"78.3",x2:"78.3",y2:"21.7"}),tt.jsx("ellipse",{cx:"50",cy:"50",rx:"40",ry:"15"}),tt.jsx("ellipse",{cx:"50",cy:"50",rx:"15",ry:"40"})]}),tt.jsxs("g",{fill:"url(#logoGrad)",children:[tt.jsx("circle",{cx:"50",cy:"10",r:"3"}),tt.jsx("circle",{cx:"50",cy:"90",r:"3"}),tt.jsx("circle",{cx:"10",cy:"50",r:"3"}),tt.jsx("circle",{cx:"90",cy:"50",r:"3"}),tt.jsx("circle",{cx:"21.7",cy:"21.7",r:"3"}),tt.jsx("circle",{cx:"78.3",cy:"78.3",r:"3"}),tt.jsx("circle",{cx:"21.7",cy:"78.3",r:"3"}),tt.jsx("circle",{cx:"78.3",cy:"21.7",r:"3"}),tt.jsx("circle",{cx:"50",cy:"30",r:"2.5"}),tt.jsx("circle",{cx:"50",cy:"70",r:"2.5"}),tt.jsx("circle",{cx:"30",cy:"50",r:"2.5"}),tt.jsx("circle",{cx:"70",cy:"50",r:"2.5"}),tt.jsx("circle",{cx:"35.8",cy:"35.8",r:"2.5"}),tt.jsx("circle",{cx:"64.2",cy:"64.2",r:"2.5"}),tt.jsx("circle",{cx:"35.8",cy:"64.2",r:"2.5"}),tt.jsx("circle",{cx:"64.2",cy:"35.8",r:"2.5"})]}),tt.jsx("circle",{cx:"50",cy:"50",r:"4",fill:"#00F0FF",filter:"url(#glow)"})]}),tt.jsx("span",{className:"font-display font-bold text-xl tracking-widest uppercase",children:"Uncoded Hub"})]}),tt.jsxs("button",{className:"cyan-energy-btn !py-2.5 !px-6 !text-sm !font-medium shrink-0",children:[tt.jsx("span",{className:"hidden sm:inline",children:"Start a Project"}),tt.jsx("span",{className:"sm:hidden",children:"Start"}),tt.jsx(TM,{className:"w-4 h-4"})]})]})}),tt.jsxs("section",{className:"relative pt-40 pb-24 px-6 overflow-hidden min-h-[90vh] flex items-center",children:[tt.jsx("div",{className:"absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-magenta/10 rounded-full blur-[120px] pointer-events-none"}),tt.jsx("div",{className:"absolute top-1/2 left-1/4 -translate-y-1/2 w-[600px] h-[600px] bg-cyan/10 rounded-full blur-[100px] pointer-events-none"}),tt.jsxs("div",{className:"max-w-7xl mx-auto flex flex-col lg:flex-row items-center relative z-10 w-full min-h-[600px]",ref:o,children:[tt.jsxs("div",{className:"w-full lg:w-[55%] space-y-8 relative z-20 pt-10 lg:pt-0",children:[tt.jsxs("h1",{className:"hero-anim font-display text-5xl md:text-7xl font-bold leading-[1.1] tracking-tight text-white drop-shadow-2xl",children:["Your Business Deserves to be Online. ",tt.jsx("br",{}),tt.jsx("span",{className:"text-gradient",children:"We Make it Happen in 5 Days."})]}),tt.jsx("p",{className:"hero-anim text-lg md:text-xl text-steel max-w-xl leading-relaxed drop-shadow-md",children:"Stop losing customers to competitors who have a website. Get a fully functional, professional digital storefront built for revenue, not just looks."}),tt.jsxs("div",{className:"hero-anim flex flex-col items-start gap-4 pt-4",children:[tt.jsxs("button",{className:"cyan-energy-btn !text-lg !px-8 !py-4",children:["Claim Your 5-Day Build ",tt.jsx(QD,{className:"w-5 h-5"})]}),tt.jsx("div",{className:"mt-6 border-l-2 border-cyan/30 pl-4",ref:a,children:tt.jsx("p",{className:"italic text-white/90 text-sm max-w-md drop-shadow-md",children:'"A business without a website is a business that sleeps. Your website is the only salesman that works 24/7, 365 days a year without asking for a raise."'})})]})]}),tt.jsx("div",{className:"absolute top-0 right-0 w-full h-[350px] md:h-[500px] opacity-30 -z-10 lg:relative lg:w-[50%] lg:h-[700px] lg:opacity-100 lg:z-10 lg:-ml-[5%] pointer-events-none flex justify-center items-center",children:tt.jsx(kD,{})})]})]}),tt.jsx("section",{className:"py-24 px-6 relative z-10 bg-cyber/30 border-t border-white/5",children:tt.jsxs("div",{className:"max-w-4xl mx-auto",ref:t,children:[tt.jsxs("div",{className:"text-center mb-16",children:[tt.jsx("h2",{className:"font-display text-3xl md:text-5xl font-bold mb-4",children:"From Idea to Live in 120 Hours."}),tt.jsx("p",{className:"text-steel text-lg",children:"Here is How:"})]}),tt.jsxs("div",{className:"relative",children:[tt.jsx("div",{className:"absolute left-[28px] md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-cyan via-magenta to-transparent md:-translate-x-1/2"}),tt.jsx("div",{className:"space-y-12",children:[{day:"1",title:"Strategy & Architecture",desc:"We learn your business and map the blueprint."},{day:"2-3",title:"Design & Development",desc:"We build the engine and design the interface."},{day:"4",title:"Review & Refine",desc:"You review, we perfect it."},{day:"5",title:"Launch & Handover",desc:"You go live to the world."}].map((r,l)=>tt.jsxs("div",{className:`process-step relative flex flex-col md:flex-row items-start md:items-center gap-8 group ${l%2===0?"md:flex-row-reverse":""}`,children:[tt.jsx("div",{className:"absolute left-0 md:left-1/2 w-14 h-14 rounded-full bg-midnight border-2 border-cyber flex items-center justify-center md:-translate-x-1/2 z-10 group-hover:border-cyan transition-colors duration-300 shadow-[0_0_10px_rgba(0,0,0,0.5)]",children:tt.jsxs("span",{className:"font-mono font-bold text-sm text-white group-hover:text-cyan transition-colors",children:["D",r.day]})}),tt.jsx("div",{className:`ml-20 md:ml-0 md:w-1/2 ${l%2===0?"md:pl-16":"md:pr-16 md:text-right"}`,children:tt.jsxs("div",{className:"frosted-glass p-6 rounded-2xl transition-all duration-500 group-hover:-translate-y-2 group-hover:shadow-[0_15px_40px_rgba(0,229,255,0.1)] group-hover:border-white/30",children:[tt.jsxs("h4",{className:"font-display text-xl font-bold mb-2 text-white group-hover:text-cyan transition-colors duration-300",children:["Day ",r.day,": ",r.title]}),tt.jsx("p",{className:"text-white/80 text-sm leading-relaxed",children:r.desc})]})})]},r.day))})]}),tt.jsx("div",{className:"mt-20 max-w-2xl mx-auto text-center",ref:a,children:tt.jsxs("div",{className:"bg-cyber/40 border border-white/10 rounded-2xl p-8 relative overflow-hidden",children:[tt.jsx("div",{className:"absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan to-magenta"}),tt.jsx("p",{className:"font-display text-xl md:text-2xl italic text-white/90 leading-relaxed",children:'"Speed is the currency of modern business. While your competitors spend months debating colors, you could be closing sales."'})]})})]})}),tt.jsx("section",{className:"py-24 px-6 relative z-10",children:tt.jsxs("div",{className:"max-w-7xl mx-auto",children:[tt.jsx("div",{className:"text-center mb-16",children:tt.jsx("h2",{className:"font-display text-3xl md:text-5xl font-bold mb-4",children:"Built to Convert. Designed to Impress."})}),tt.jsxs("div",{className:"grid md:grid-cols-3 gap-8",children:[tt.jsxs("div",{className:"portfolio-card rounded-2xl border border-white/10 bg-cyber/50 group cursor-pointer",children:[tt.jsxs("div",{className:"h-48 overflow-hidden relative",children:[tt.jsx("img",{src:"https://picsum.photos/seed/retail/600/400",alt:"Local Retail & Services",className:"w-full h-full object-cover",referrerPolicy:"no-referrer"}),tt.jsx("div",{className:"absolute inset-0 bg-midnight/20 group-hover:bg-transparent transition-colors duration-300"})]}),tt.jsxs("div",{className:"p-6",children:[tt.jsx("h3",{className:"font-display text-xl font-bold mb-2",children:"Local Retail & Services"}),tt.jsx("p",{className:"text-steel text-sm",children:"Optimized for local SEO and foot traffic conversion."})]})]}),tt.jsxs("div",{className:"portfolio-card rounded-2xl border border-white/10 bg-cyber/50 group cursor-pointer",children:[tt.jsxs("div",{className:"h-48 overflow-hidden relative",children:[tt.jsx("img",{src:"https://picsum.photos/seed/portfolio/600/400",alt:"Professional Portfolios",className:"w-full h-full object-cover",referrerPolicy:"no-referrer"}),tt.jsx("div",{className:"absolute inset-0 bg-midnight/20 group-hover:bg-transparent transition-colors duration-300"})]}),tt.jsxs("div",{className:"p-6",children:[tt.jsx("h3",{className:"font-display text-xl font-bold mb-2",children:"Professional Portfolios"}),tt.jsx("p",{className:"text-steel text-sm",children:"Sleek, authoritative designs that build instant trust."})]})]}),tt.jsxs("div",{className:"portfolio-card rounded-2xl border border-white/10 bg-cyber/50 group cursor-pointer",children:[tt.jsxs("div",{className:"h-48 overflow-hidden relative",children:[tt.jsx("img",{src:"https://picsum.photos/seed/ecommerce/600/400",alt:"E-commerce Hubs",className:"w-full h-full object-cover",referrerPolicy:"no-referrer"}),tt.jsx("div",{className:"absolute inset-0 bg-midnight/20 group-hover:bg-transparent transition-colors duration-300"})]}),tt.jsxs("div",{className:"p-6",children:[tt.jsx("h3",{className:"font-display text-xl font-bold mb-2",children:"E-commerce Hubs"}),tt.jsx("p",{className:"text-steel text-sm",children:"Frictionless checkout experiences designed to sell."})]})]})]}),tt.jsx("div",{className:"mt-16 text-center",ref:a,children:tt.jsx("p",{className:"italic text-steel text-lg max-w-3xl mx-auto",children:'"Design isn’t just how it looks; it’s how it converts. A confused visitor leaves, but a guided visitor buys."'})})]})}),tt.jsx("section",{className:"py-24 px-6 relative z-10 bg-cyber/30 border-t border-white/5",children:tt.jsxs("div",{className:"max-w-7xl mx-auto grid md:grid-cols-2 gap-16 items-center",children:[tt.jsxs("div",{children:[tt.jsx("h2",{className:"font-display text-3xl md:text-5xl font-bold mb-6",children:"The Uncoded Advantage."}),tt.jsx("p",{className:"text-steel text-lg leading-relaxed mb-8",children:"We utilize advanced no-code architecture. What does that mean for you? Zero bloated code, lightning-fast load times, and a website you can easily understand and manage without hiring an expensive IT team."}),tt.jsxs("ul",{className:"space-y-4 mb-8",children:[tt.jsxs("li",{className:"flex items-center gap-3 text-white/90",children:[tt.jsx(sU,{className:"w-5 h-5 text-cyan"})," Lightning-fast load times"]}),tt.jsxs("li",{className:"flex items-center gap-3 text-white/90",children:[tt.jsx($D,{className:"w-5 h-5 text-magenta"})," Zero bloated code"]}),tt.jsxs("li",{className:"flex items-center gap-3 text-white/90",children:[tt.jsx(eU,{className:"w-5 h-5 text-cyan"})," Easy to manage & secure"]})]})]}),tt.jsxs("div",{ref:a,className:"bg-midnight p-8 rounded-3xl border border-white/10 relative overflow-hidden",children:[tt.jsx("div",{className:"absolute top-0 right-0 w-32 h-32 bg-magenta/10 rounded-full blur-[50px]"}),tt.jsx("div",{className:"absolute bottom-0 left-0 w-32 h-32 bg-cyan/10 rounded-full blur-[50px]"}),tt.jsx("p",{className:"font-display text-2xl italic text-white/90 leading-relaxed relative z-10",children:'"Complexity kills progress. The best technology is the kind that gets out of your way and lets you run your business."'})]})]})}),tt.jsx("section",{className:"py-24 px-6 relative z-10",children:tt.jsxs("div",{className:"max-w-7xl mx-auto",children:[tt.jsx("div",{className:"text-center mb-16",children:tt.jsx("h2",{className:"font-display text-3xl md:text-5xl font-bold mb-4",children:"Real Results & Our Growth Partnership"})}),tt.jsxs("div",{className:"grid md:grid-cols-2 gap-8 mb-16",children:[tt.jsxs("div",{className:"bg-cyber/50 p-8 rounded-2xl border border-white/5",children:[tt.jsxs("div",{className:"flex text-cyan mb-4",children:[tt.jsx(or,{className:"w-5 h-5 fill-current"}),tt.jsx(or,{className:"w-5 h-5 fill-current"}),tt.jsx(or,{className:"w-5 h-5 fill-current"}),tt.jsx(or,{className:"w-5 h-5 fill-current"}),tt.jsx(or,{className:"w-5 h-5 fill-current"})]}),tt.jsx("p",{className:"text-lg text-white/90 mb-6",children:'"They delivered exactly what they promised in 5 days. Our conversion rate doubled in the first month."'}),tt.jsxs("div",{className:"flex items-center gap-4",children:[tt.jsx("div",{className:"w-10 h-10 rounded-full bg-white/10"}),tt.jsxs("div",{children:[tt.jsx("p",{className:"font-bold text-sm",children:"Sarah J."}),tt.jsx("p",{className:"text-steel text-xs",children:"Local Retail Owner"})]})]})]}),tt.jsxs("div",{className:"bg-cyber/50 p-8 rounded-2xl border border-white/5",children:[tt.jsxs("div",{className:"flex text-cyan mb-4",children:[tt.jsx(or,{className:"w-5 h-5 fill-current"}),tt.jsx(or,{className:"w-5 h-5 fill-current"}),tt.jsx(or,{className:"w-5 h-5 fill-current"}),tt.jsx(or,{className:"w-5 h-5 fill-current"}),tt.jsx(or,{className:"w-5 h-5 fill-current"})]}),tt.jsx("p",{className:"text-lg text-white/90 mb-6",children:`"The speed is unmatched. I didn't have to wait months to get my portfolio online. Highly recommended."`}),tt.jsxs("div",{className:"flex items-center gap-4",children:[tt.jsx("div",{className:"w-10 h-10 rounded-full bg-white/10"}),tt.jsxs("div",{children:[tt.jsx("p",{className:"font-bold text-sm",children:"David M."}),tt.jsx("p",{className:"text-steel text-xs",children:"Consultant"})]})]})]})]}),tt.jsxs("div",{className:"bg-gradient-to-br from-cyber to-midnight p-8 md:p-12 rounded-3xl border border-white/10 flex flex-col md:flex-row gap-8 items-center",children:[tt.jsx("div",{className:"w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center shrink-0 border border-white/10",children:tt.jsx(aU,{className:"w-8 h-8 text-magenta"})}),tt.jsxs("div",{children:[tt.jsx("h3",{className:"font-display text-2xl font-bold mb-3",children:"The Partnership Pitch"}),tt.jsx("p",{className:"text-steel leading-relaxed",children:"We don't just hand you the keys and leave. With our monthly Growth & Security Partnership, we maintain, secure, and update your site so you can focus entirely on your customers."})]})]}),tt.jsx("div",{className:"mt-16 text-center",ref:a,children:tt.jsx("p",{className:"italic text-steel text-lg max-w-3xl mx-auto",children:`"The cost of a professional website is an investment. The cost of a bad website—or no website at all—is every customer who couldn't find you."`})})]})}),tt.jsxs("section",{className:"py-24 px-6 relative z-10 bg-cyber/80 border-t border-white/5 text-center",children:[tt.jsx("div",{className:"absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-magenta/10 via-midnight to-midnight pointer-events-none"}),tt.jsxs("div",{className:"max-w-3xl mx-auto relative z-10",children:[tt.jsx("h2",{className:"font-display text-4xl md:text-6xl font-bold mb-8",children:"Ready to digitize your business this week?"}),tt.jsxs("button",{className:"cyan-energy-btn !px-10 !py-5 !text-xl mx-auto w-full md:w-auto",children:["Book Your Strategy Call Now ",tt.jsx(TM,{className:"w-6 h-6"})]})]})]}),tt.jsx("footer",{className:"py-8 text-center border-t border-white/5 text-steel font-mono text-sm bg-midnight relative z-10",children:tt.jsxs("p",{children:["© ",new Date().getFullYear()," Uncoded Hub. All systems operational."]})})]})}wA.createRoot(document.getElementById("root")).render(tt.jsx(Mi.StrictMode,{children:tt.jsx(WN,{})}));
